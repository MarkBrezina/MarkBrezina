#!/usr/bin/env python3
"""Render the TikZ chronology of 01_glance.tex to figures/chronology.png (standalone build)."""
import os, re, subprocess
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
src = open("src/01_glance.tex", encoding="utf-8").read()
tikz = re.search(r"\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}", src, re.S).group(0)
pre = open("main.tex", encoding="utf-8").read()
colours = "\n".join(l for l in pre.splitlines() if l.startswith("\\definecolor"))
doc = ("\\documentclass[border=4pt]{standalone}\n\\usepackage[T1]{fontenc}\\usepackage{lmodern}\\usepackage{mathpazo}\\usepackage{helvet}"
       "\\usepackage{xcolor}\\usepackage{tikz}\\usetikzlibrary{arrows.meta,positioning,shapes.geometric,calc,fit,backgrounds}\n"
       + colours + "\n\\begin{document}\n" + tikz + "\n\\end{document}\n")
os.makedirs("build/chrono", exist_ok=True)
open("build/chrono/chrono.tex", "w").write(doc)
subprocess.run(["pdflatex", "-interaction=nonstopmode", "-output-directory=build/chrono", "build/chrono/chrono.tex"],
               check=True, capture_output=True)
subprocess.run(["pdftoppm", "-png", "-r", "170", "-singlefile", "build/chrono/chrono.pdf", "figures/chronology"], check=True)
print("figures/chronology.png")
