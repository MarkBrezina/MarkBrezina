#!/bin/bash
# Build compendium.md (GitHub-flavoured markdown) from the LaTeX source.
# Needs a full build first (latexmk -pdf main.tex) so that main.aux carries every label.
set -e
cd "$(dirname "$0")/.."
for f in figures/*.pdf; do
  [ -e "$f" ] || continue
  pdftoppm -png -r 150 -singlefile "$f" "${f%.pdf}"
done
python3 md/render_chronology.py
python3 md/prep.py
pandoc md/flat_md.tex -f latex -t gfm --wrap=none --markdown-headings=atx --top-level-division=part -o md/compendium_raw.md
python3 md/post.py md/compendium_raw.md compendium.md
echo "compendium.md: $(wc -l < compendium.md) lines"
