#!/usr/bin/env python3
"""Flatten main.tex into a pandoc-friendly LaTeX file (md/flat_md.tex) and convert the tables.

Steps
  1. inline every \\input{src/...};
  2. read main.aux: label -> (type, number) from cleveref's @cref entries; resolve \\cref/\\Cref/\\eqref
     to text; give every labelled numbered equation a \\tag{number};
  3. number parts / chapters / sections / subsections and theorem-like environments in source order
     (exactly as the report class does) and turn theorem environments into bold run-in headings;
  4. convert tcolorbox boxes to block quotes, status tags to bold brackets, \\src to italics;
  5. replace every tabular/longtable by a GitHub pipe table (cells converted by pandoc in one batch);
  6. figures: .pdf -> .png (rendered beforehand by build_md.sh), tikz chronology -> figures/chronology.png;
  7. strip the preamble to what pandoc needs (\\newcommand, \\newtheorem -> nothing, operators).

Run from the compendium root after a full latexmk build:  python3 md/prep.py
Then:  pandoc md/flat_md.tex -f latex -t gfm --wrap=none --markdown-headings=atx --top-level-division=part -o compendium.md
"""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

THEOREM_ENVS = ["theorem", "proposition", "lemma", "corollary", "conjecture", "hypothesis", "known",
                "definition", "assumption", "example", "experiment", "deskrule", "remark"]
THEOREM_NAMES = {"known": "Known result", "deskrule": "Rule"}
TAGS = {"PROVED": "PROVED", "KNOWN": "KNOWN RESULT", "HYP": "HYPOTHESIS", "CONJ": "CONJECTURE",
        "MEAS": "MEASURED", "PEND": "PENDING RUN", "REFUTED": "REFUTED AS STATED", "OPEN": "OPEN",
        "SETUP": "SETUP", "PLAN": "PLAN", "PRACTICE": "PRACTICE", "LOG": "LOG"}
ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]


# --------------------------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------------------------
def read(p):
    with open(p, encoding="utf-8") as fh:
        return fh.read()


def balanced(s, i):
    """s[i] == '{' -> index just after the matching '}'."""
    depth = 0
    j = i
    while j < len(s):
        c = s[j]
        if c == "\\":
            j += 2
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return j + 1
        j += 1
    raise ValueError("unbalanced braces")


def find_cmd_args(s, cmd, nargs=1, optional=True):
    """Yield (start, end, [opt], [args]) for every \\cmd[opt]{a}{b}... in s."""
    out = []
    for m in re.finditer(r"\\" + cmd + r"(?![A-Za-z])", s):
        j = m.end()
        opt = None
        while j < len(s) and s[j] in " \t":
            j += 1
        if optional and j < len(s) and s[j] == "[":
            k = s.index("]", j)
            opt = s[j + 1:k]
            j = k + 1
        args = []
        for _ in range(nargs):
            while j < len(s) and s[j] in " \t\n":
                j += 1
            if j < len(s) and s[j] == "{":
                e = balanced(s, j)
                args.append(s[j + 1:e - 1])
                j = e
            else:
                break
        if len(args) == nargs:
            out.append((m.start(), j, opt, args))
    return out


def replace_cmd(s, cmd, fn, nargs=1, optional=True):
    """Replace every \\cmd[opt]{args} by fn(opt, args)."""
    occ = find_cmd_args(s, cmd, nargs, optional)
    for start, end, opt, args in reversed(occ):
        s = s[:start] + fn(opt, args) + s[end:]
    return s


# --------------------------------------------------------------------------------------------
# 1. flatten
# --------------------------------------------------------------------------------------------
def flatten(main, depth=0):
    """Inline every \\input{...} recursively (chapters input further files: the appendices, the
    generated test-bench body, the hypothesis table)."""
    def rep(m):
        p = m.group(1)
        if not p.endswith(".tex"):
            p += ".tex"
        if os.path.exists(p) and depth < 6:
            return "\n% ---- " + p + " ----\n" + flatten(read(p), depth + 1) + "\n"
        return ""
    return re.sub(r"\\input\{([^}]+)\}", rep, main)


# --------------------------------------------------------------------------------------------
# 2. labels from the aux file
# --------------------------------------------------------------------------------------------
def load_labels(auxpath):
    labels = {}
    if not os.path.exists(auxpath):
        return labels
    for m in re.finditer(r"\\newlabel\{([^}]+)@cref\}\{\{\[([^\]]*)\]\[[^\]]*\]\[[^\]]*\](\{[^}]*\}|[^}]*)\}", read(auxpath)):
        labels[m.group(1)] = (m.group(2), m.group(3).strip("{}"))
    return labels


TABLES = []   # markdown pipe tables, substituted back by post.py (tokens QQTABLEnQQ survive pandoc)

CREF_NAMES = {"equation": "equation", "section": "Section", "subsection": "Section", "subsubsection": "Section",
              "chapter": "Chapter", "part": "Part", "figure": "Figure", "table": "Table", "lstlisting": "Listing",
              "appendix": "Appendix", "theorem": "Theorem", "proposition": "Proposition", "lemma": "Lemma",
              "corollary": "Corollary", "conjecture": "Conjecture", "hypothesis": "Hypothesis",
              "known": "Known result", "definition": "Definition", "assumption": "Assumption",
              "example": "Example", "experiment": "Experiment", "deskrule": "Rule", "remark": "Remark",
              "item": "item", "page": "page", "subfigure": "Figure"}


def cref_text(keys, labels, capital):
    parts = []
    for k in [x.strip() for x in keys.split(",")]:
        if k in labels:
            typ, num = labels[k]
            name = CREF_NAMES.get(typ, typ.capitalize())
            if typ == "equation":
                parts.append(("Equation " if capital else "equation ") + f"({num})")
            elif typ == "appendix":
                parts.append(f"Appendix {num}")
            elif typ == "chapter" and num and num[0].isalpha():
                parts.append(f"Appendix {num}")
            else:
                parts.append(f"{name} {num}")
        else:
            parts.append(f"[{k}]")
    if len(parts) == 1:
        return parts[0]
    return ", ".join(parts[:-1]) + " and " + parts[-1]


# --------------------------------------------------------------------------------------------
# 5. tables
# --------------------------------------------------------------------------------------------
def split_top(s, sep):
    """Split s at sep occurrences that are not inside braces or math."""
    out, depth, cur, i, inmath = [], 0, [], 0, False
    while i < len(s):
        c = s[i]
        if depth == 0 and not inmath and s.startswith(sep, i):
            out.append("".join(cur)); cur = []; i += len(sep); continue
        if c == "\\" and i + 1 < len(s):
            nxt = s[i + 1]
            if nxt == "(" or nxt == "[":
                inmath = True
            elif nxt == ")" or nxt == "]":
                inmath = False
            cur.append(s[i:i + 2]); i += 2; continue
        if c == "$":
            inmath = not inmath
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        if depth == 0 and not inmath and s.startswith(sep, i):
            out.append("".join(cur)); cur = []; i += len(sep); continue
        cur.append(c); i += 1
    out.append("".join(cur))
    return out


RULES = re.compile(r"\\(toprule|midrule|bottomrule|hline|endhead|endfirsthead|endfoot|endlastfoot|tabularnewline)\b"
                   r"|\\cmidrule(\([^)]*\))?\{[^}]*\}|\\addlinespace(\[[^\]]*\])?|\\specialrule\{[^}]*\}\{[^}]*\}\{[^}]*\}"
                   r"|\\rowcolor\{[^}]*\}|\\arrayrulecolor\{[^}]*\}|\\noalign\{[^}]*\}")


def parse_tabular(body):
    body = RULES.sub(" ", body)
    body = re.sub(r"\\\\\[[^\]]*\]", r"\\\\", body)
    rows = []
    for raw in split_top(body, "\\\\"):
        raw = raw.strip()
        if not raw:
            continue
        cells = []
        for c in split_top(raw, "&"):
            c = c.strip()
            m = re.match(r"^\\multicolumn\{(\d+)\}\{[^}]*\}\{", c)
            if m:
                n = int(m.group(1))
                e = balanced(c, m.end() - 1)
                content = c[m.end():e - 1]
                cells.append(content)
                cells.extend([""] * (n - 1))
                continue
            c = replace_cmd(c, "multirow", lambda o, a: a[-1], nargs=3, optional=True)
            cells.append(c)
        rows.append(cells)
    return rows


def pandoc_cells(cells):
    """Convert many LaTeX snippets to markdown in one pandoc call."""
    if not cells:
        return []
    MARK = "QQCELLSEPQQ"
    doc = ("\n\n" + MARK + "\n\n").join(c if c.strip() else "~" for c in cells)
    pre = read("md/preamble_min.tex")
    src = pre + "\n\\begin{document}\n" + doc + "\n\\end{document}\n"
    p = subprocess.run(["pandoc", "-f", "latex", "-t", "gfm", "--wrap=none"], input=src, capture_output=True, text=True)
    out = p.stdout
    parts = [x.strip() for x in out.split(MARK)]
    if len(parts) != len(cells):
        # fall back: convert one by one
        parts = []
        for c in cells:
            q = subprocess.run(["pandoc", "-f", "latex", "-t", "gfm", "--wrap=none"],
                               input=pre + "\n\\begin{document}\n" + (c if c.strip() else "~") + "\n\\end{document}\n",
                               capture_output=True, text=True)
            parts.append(q.stdout.strip())
    res = []
    for x in parts:
        x = x.replace("\n", " ").replace("|", "\\|").strip()
        if x in ("~", "\\~"):
            x = ""
        res.append(x)
    return res


def table_to_pipe(rows):
    if not rows:
        return ""
    ncol = max(len(r) for r in rows)
    rows = [r + [""] * (ncol - len(r)) for r in rows]
    flat = [c for r in rows for c in r]
    conv = pandoc_cells(flat)
    rows = [conv[i * ncol:(i + 1) * ncol] for i in range(len(rows))]
    head = rows[0]
    lines = ["| " + " | ".join(h if h else " " for h in head) + " |", "|" + "---|" * ncol]
    for r in rows[1:]:
        lines.append("| " + " | ".join(c if c else " " for c in r) + " |")
    return "\n".join(lines)


def convert_tables(s, labels):
    """Replace table/longtable/sidewaystable environments (and bare tabulars) by markdown pipe tables,
    emitted as \\begin{verbatimmd}...\\end{verbatimmd} blocks that pandoc leaves alone (raw)."""
    def env_blocks(text, env):
        res = []
        for m in re.finditer(r"\\begin\{" + env + r"\}", text):
            e = text.find("\\end{" + env + "}", m.end())
            if e < 0:
                continue
            res.append((m.start(), e + len("\\end{" + env + "}")))
        return res

    def tabular_inner(block):
        """Find the tabular/tabularx/longtable body inside a block; returns (body, caption, label)."""
        caption = None; label = None
        for _, _, _, args in find_cmd_args(block, "caption", 1, True):
            caption = args[0]
        m = re.search(r"\\label\{(tab:[^}]+)\}", block)
        if m:
            label = m.group(1)
        mm = re.search(r"\\begin\{(tabular|tabularx|longtable|tabular\*)\}", block)
        if not mm:
            return None, caption, label
        env = mm.group(1)
        j = mm.end()
        # skip the optional width/pos and the column spec
        if env in ("tabularx", "tabular*"):
            j = balanced(block, block.index("{", j))
        while j < len(block) and block[j] in " \n":
            j += 1
        if j < len(block) and block[j] == "[":
            j = block.index("]", j) + 1
        while j < len(block) and block[j] in " \n":
            j += 1
        if j < len(block) and block[j] == "{":
            j = balanced(block, j)
        endm = block.find("\\end{" + env.replace("*", "\\*") + "}", j) if "*" not in env else block.find("\\end{tabular*}", j)
        if endm < 0:
            endm = block.rfind("\\end{")
        body = block[j:endm]
        # longtable captions live inside the body
        body = replace_cmd(body, "caption", lambda o, a: "", 1, True)
        body = re.sub(r"\\label\{[^}]*\}", "", body)
        return body, caption, label

    def render(block):
        body, caption, label = tabular_inner(block)
        if body is None:
            return None
        rows = parse_tabular(body)
        md = table_to_pipe(rows)
        cap = ""
        if caption is not None:
            num = labels.get(label, ("table", "?"))[1] if label else "?"
            cap_md = pandoc_cells([caption])[0]
            cap = f"**Table {num}.** {cap_md}\n\n"
        TABLES.append(cap + md)
        return "\n\nQQTABLE%dQQ\n\n" % (len(TABLES) - 1)

    for env in ("sidewaystable", "table\\*", "table", "longtable"):
        envname = env.replace("\\*", "*")
        blocks = env_blocks(s, env)
        for a, b in reversed(blocks):
            r = render(s[a:b])
            if r is not None:
                s = s[:a] + r + s[b:]
    # bare tabulars left (inside minipages, keyboxes, text)
    for env in ("tabularx", "tabular"):
        blocks = env_blocks(s, env)
        for a, b in reversed(blocks):
            block = s[a:b]
            r = render(block)
            if r is not None:
                s = s[:a] + r + s[b:]
    return s


# --------------------------------------------------------------------------------------------
# 3. numbering of sections and theorem environments
# --------------------------------------------------------------------------------------------
def number_headings_and_theorems(s):
    out = []
    part = chap = sec = sub = thm = 0
    appendix = False
    i = 0
    pattern = re.compile(r"\\appendix(?![A-Za-z])|\\(part|chapter|section|subsection|subsubsection)\*?(\[[^\]]*\])?\{|\\begin\{(" + "|".join(THEOREM_ENVS) + r")\}|\\end\{(" + "|".join(THEOREM_ENVS) + r")\}|\\begin\{inwords\}|\\end\{inwords\}")
    while True:
        m = pattern.search(s, i)
        if not m:
            out.append(s[i:]); break
        out.append(s[i:m.start()])
        if m.group(0) == "\\appendix":
            appendix = True; chap = 0
            i = m.end(); continue
        if m.group(0) == "\\begin{inwords}":
            out.append("\n\n\\noindent\\textbf{In words.} "); i = m.end(); continue
        if m.group(0) == "\\end{inwords}":
            out.append("\n\n"); i = m.end(); continue
        if m.group(1):
            kind = m.group(1)
            starred = s[m.start():m.end()].count("*") > 0
            e = balanced(s, m.end() - 1)
            title = s[m.end():e - 1]
            if kind == "part":
                part += 1; label = f"Part {ROMAN[part - 1]}: "
                out.append(f"\\part{{{label}{title}}}")
            elif kind == "chapter":
                if starred:
                    out.append(f"\\chapter{{{title}}}")
                else:
                    chap += 1; sec = sub = thm = 0
                    cl = chr(ord('A') + chap - 1) if appendix else str(chap)
                    label = f"Appendix {cl}: " if appendix else f"Chapter {cl}: "
                    out.append(f"\\chapter{{{label}{title}}}")
            elif kind == "section":
                if starred:
                    out.append(f"\\section{{{title}}}")
                else:
                    sec += 1; sub = 0
                    cl = chr(ord('A') + chap - 1) if appendix else str(chap)
                    out.append(f"\\section{{{cl}.{sec} {title}}}")
            elif kind == "subsection":
                if starred:
                    out.append(f"\\subsection{{{title}}}")
                else:
                    sub += 1
                    cl = chr(ord('A') + chap - 1) if appendix else str(chap)
                    out.append(f"\\subsection{{{cl}.{sec}.{sub} {title}}}")
            else:
                out.append(f"\\paragraph{{{title}}}")
            i = e; continue
        if m.group(3):
            env = m.group(3)
            thm += 1
            cl = chr(ord('A') + chap - 1) if appendix else str(chap)
            name = THEOREM_NAMES.get(env, env.capitalize())
            j = m.end()
            opt = ""
            if j < len(s) and s[j] == "[":
                k = j
                depth = 0
                while k < len(s):
                    if s[k] == "[": depth += 1
                    elif s[k] == "]":
                        depth -= 1
                        if depth == 0: break
                    k += 1
                opt = s[j + 1:k]; j = k + 1
            head = f"\n\n\\noindent\\textbf{{{name} {cl}.{thm}}}"
            if opt:
                head += f"\\textbf{{ ({opt})}}"
            head += "\\textbf{.} "
            out.append(head); i = j; continue
        if m.group(4):
            out.append("\n\n"); i = m.end(); continue
    return "".join(out)


# --------------------------------------------------------------------------------------------
# 4. boxes, tags, misc
# --------------------------------------------------------------------------------------------
def boxes_and_tags(s):
    for box in ("keybox", "plainbox"):
        s = re.sub(r"\\begin\{" + box + r"\}\[([^\]]*)\]", lambda m: "\n\n\\begin{quote}\\textbf{" + m.group(1) + "}\\par ", s)
        s = re.sub(r"\\begin\{" + box + r"\}", "\n\n\\begin{quote}", s)
        s = s.replace("\\end{" + box + "}", "\\end{quote}\n\n")
    s = s.replace("\\begin{sourcebox}", "\n\n\\begin{quote}").replace("\\end{sourcebox}", "\\end{quote}\n\n")
    for cmd, txt in TAGS.items():
        s = re.sub(r"\\" + cmd + r"(?![A-Za-z])\\?;?", "\\\\textbf{[" + txt + "]}", s)
    s = replace_cmd(s, "src", lambda o, a: "\\textit{" + a[0] + "}", 1, False)
    s = replace_cmd(s, "srcraw", lambda o, a: "\\textit{" + a[0] + "}", 1, False)
    s = s.replace("\\tfrac12", "\\tfrac{1}{2}")
    s = re.sub(r"\\begin\{psmallmatrix\}", "\\\\begin{pmatrix}", s)
    s = s.replace("\\end{psmallmatrix}", "\\end{pmatrix}")
    s = s.replace("\\upmu", "\\mu").replace("\\upsigma", "\\sigma").replace("\\upgamma", "\\gamma")
    s = re.sub(r"\\needspace\{[^}]*\}", "", s)
    s = re.sub(r"\\Needspace\{[^}]*\}", "", s)
    s = re.sub(r"\\clearpage|\\newpage|\\cleardoublepage|\\noindent|\\centering|\\small|\\footnotesize|\\scriptsize|\\normalsize|\\large|\\Large|\\LARGE|\\huge|\\Huge", "", s)
    s = re.sub(r"\\vspace\*?\{[^}]*\}|\\hspace\*?\{[^}]*\}|\\vfill|\\hfill", " ", s)
    s = re.sub(r"\\setlength\{[^}]*\}\{[^}]*\}", "", s)
    s = re.sub(r"\\captionsetup\{[^}]*\}", "", s)
    s = re.sub(r"\\begin\{(landscape|sidewaysfigure)\}", "\\\\begin{figure}", s)
    s = re.sub(r"\\end\{(landscape|sidewaysfigure)\}", "\\\\end{figure}", s)
    s = re.sub(r"\\begin\{minipage\}(\[[^\]]*\])?\{[^}]*\}", "", s)
    s = s.replace("\\end{minipage}", "\n\n")
    s = re.sub(r"\\begin\{subfigure\}(\[[^\]]*\])?\{[^}]*\}", "", s)
    s = s.replace("\\end{subfigure}", "\n\n")
    s = re.sub(r"\\begin\{threeparttable\}|\\end\{threeparttable\}|\\begin\{tablenotes\}|\\end\{tablenotes\}", "", s)
    s = re.sub(r"\\lstset\{[^\n]*\}\n", "", s)
    s = re.sub(r"\\lstinputlisting(\[[^\]]*\])?\{[^}]*\}", "", s)
    s = re.sub(r"\\markboth\{[^}]*\}\{[^}]*\}", "", s)
    s = re.sub(r"\\addcontentsline\{[^}]*\}\{[^}]*\}\{[^}]*\}", "", s)
    s = re.sub(r"\\thispagestyle\{[^}]*\}|\\pagestyle\{[^}]*\}", "", s)
    s = re.sub(r"\\phantomsection", "", s)
    s = re.sub(r"\\allowbreak", "", s)
    s = re.sub(r"\\mbox\{", "{", s)
    s = re.sub(r"\\nopagebreak|\\pagebreak(\[\d\])?|\\linebreak(\[\d\])?|\\enlargethispage\{[^}]*\}", "", s)
    return s


def figures(s):
    # includegraphics: pdf -> png; strip options
    def rep(m):
        f = m.group(2)
        base = os.path.basename(f)
        if base.endswith(".pdf"):
            base = base[:-4] + ".png"
        elif not re.search(r"\.(png|jpg|jpeg)$", base):
            for ext in (".png", ".jpg", ".pdf"):
                if os.path.exists(os.path.join("figures", base + ext)):
                    base = base + (".png" if ext == ".pdf" else ext); break
        if base.startswith("lab/"):
            return "\\includegraphics{figures/" + base + "}"
        return "\\includegraphics{figures/" + base + "}"
    s = re.sub(r"\\includegraphics(\[[^\]]*\])?\{([^}]+)\}", rep, s)
    # tikz chronology
    s = re.sub(r"\\resizebox\{[^}]*\}\{[^}]*\}\{%?\s*\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}\}", "\\\\includegraphics{figures/chronology.png}", s, flags=re.S)
    s = re.sub(r"\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}", "\\\\includegraphics{figures/chronology.png}", s, flags=re.S)
    return s


def titlepage(s):
    a = s.find("\\begin{titlepage}"); b = s.find("\\end{titlepage}")
    if a >= 0 and b >= 0:
        s = s[:a] + ("\\chapter*{The Collected Framework}\n\n\\includegraphics{figures/tomorrow_wordmark.png}\n\n"
                     "\\textbf{Tomorrow Capital Research --- Mark Brezina --- compiled edition, November 2026.}\n\n"
                     "Geometric--informational market models, the five conjectures, aggregation theory and its tests, "
                     "the working notes and the operating plan. Single-source compendium of the programme's documents "
                     "(April 2025 -- November 2026), with every statement tagged by its epistemic status and every number "
                     "traced to its source.\n\n"
                     "Reading key: \\textbf{[PROVED]} an elementary proof is in this document; \\textbf{[KNOWN RESULT]} quoted with a reference; "
                     "\\textbf{[HYPOTHESIS]} / \\textbf{[CONJECTURE]} to be tested; \\textbf{[MEASURED]} matched in hindsight on data; "
                     "\\textbf{[PENDING RUN]} test defined, data host not yet reached; \\textbf{[REFUTED AS STATED]} shown wrong as originally stated; "
                     "\\textbf{[SETUP]} a definition or modelling choice; \\textbf{[PLAN]} an operating intention; \\textbf{[PRACTICE]} a working rule; "
                     "\\textbf{[LOG]} a dated working-log entry. Source labels such as \\textit{[AT-III \\S 6.2]} point to the document and section the content comes from.\n\n") + s[b + len("\\end{titlepage}"):]
    s = re.sub(r"\{\\renewcommand\{\\src\}\[1\]\{\}\\tableofcontents\}|\\tableofcontents", "", s)
    return s


def equations_tags(s, labels):
    """Give labelled equations their number as \\tag{}; drop other labels."""
    def rep(m):
        k = m.group(1)
        if k in labels and labels[k][0] == "equation":
            return "\\tag{" + labels[k][1] + "}"
        return ""
    s = re.sub(r"\\label\{([^}]+)\}", rep, s)
    return s


def crefs(s, labels):
    s = replace_cmd(s, "Cref", lambda o, a: cref_text(a[0], labels, True), 1, False)
    s = replace_cmd(s, "cref", lambda o, a: cref_text(a[0], labels, False), 1, False)
    s = replace_cmd(s, "eqref", lambda o, a: "(" + labels.get(a[0], ("equation", "?"))[1] + ")", 1, False)
    s = replace_cmd(s, "ref", lambda o, a: labels.get(a[0], ("", "?"))[1], 1, False)
    s = replace_cmd(s, "pageref", lambda o, a: "", 1, False)
    return s


def strip_comments(s):
    """Remove LaTeX comments (an unescaped % to the end of the line), keeping \\% ."""
    out = []
    for line in s.split("\n"):
        i = 0; cut = None
        while i < len(line):
            if line[i] == "\\":
                i += 2; continue
            if line[i] == "%":
                cut = i; break
            i += 1
        out.append(line if cut is None else line[:cut])
    return "\n".join(out)


def proofs(s):
    """\\begin{proof}[Title] ... \\end{proof} -> italic run-in heading (bracket-balanced title)."""
    out = []
    i = 0
    while True:
        m = re.search(r"\\begin\{proof\}", s[i:])
        if not m:
            out.append(s[i:]); break
        a = i + m.start(); j = i + m.end()
        out.append(s[i:a])
        title = "Proof"
        if j < len(s) and s[j] == "[":
            depth = 0; k = j
            while k < len(s):
                if s[k] == "[": depth += 1
                elif s[k] == "]":
                    depth -= 1
                    if depth == 0: break
                k += 1
            title = s[j + 1:k]; j = k + 1
        out.append("\n\n\\textit{" + title + ".} ")
        i = j
    s = "".join(out)
    return s.replace("\\end{proof}", " $\\square$\n\n")


def minimal_preamble(main):
    """Keep \\newcommand / \\DeclareMathOperator / \\documentclass from main.tex for pandoc."""
    pre = main[:main.index("\\begin{document}")]
    keep = ["\\documentclass{report}", "\\usepackage{amsmath,amssymb}"]
    for line in pre.splitlines():
        t = line.strip()
        if t.startswith("\\newcommand") and "\\src" not in t and "tagbox" not in t and not any("\\" + k + "}" in t for k in TAGS):
            keep.append(t)
        elif t.startswith("\\DeclareMathOperator"):
            m = re.match(r"\\DeclareMathOperator(\*?)\{(\\[A-Za-z]+)\}\{(.*)\}", t)
            if m:
                keep.append("\\newcommand{" + m.group(2) + "}{\\operatorname" + m.group(1) + "{" + m.group(3) + "}}")
    keep.append("\\newcommand{\\texorpdfstring}[2]{#1}")
    keep.append("\\newcommand{\\IfFileExists}[3]{#2}")
    return "\n".join(keep) + "\n"


def main():
    main_tex = read(os.environ.get("MAIN_TEX", "main.tex"))
    labels = load_labels(os.environ.get("MAIN_AUX", "main.aux"))
    if not labels:
        print("WARNING: main.aux not found or empty -- run latexmk first", file=sys.stderr)
    body = flatten(main_tex)
    body = body[body.index("\\begin{document}") + len("\\begin{document}"):]
    body = body.replace("\\end{document}", "")
    with open("md/preamble_min.tex", "w", encoding="utf-8") as fh:
        fh.write(minimal_preamble(main_tex))
    body = strip_comments(body)
    body = titlepage(body)
    body = boxes_and_tags(body)
    body = crefs(body, labels)
    body = convert_tables(body, labels)       # tables before theorem numbering (cells are converted separately)
    body = number_headings_and_theorems(body)
    body = equations_tags(body, labels)
    body = figures(body)
    body = proofs(body)
    body = body.replace("\\qed", "").replace("\\qedhere", "")
    out = minimal_preamble(main_tex) + "\\begin{document}\n" + body + "\n\\end{document}\n"
    with open("md/flat_md.tex", "w", encoding="utf-8") as fh:
        fh.write(out)
    import json
    with open("md/tables.json", "w", encoding="utf-8") as fh:
        json.dump(TABLES, fh)
    print("wrote md/flat_md.tex", len(out), "chars;", len(labels), "labels;", len(TABLES), "tables")


if __name__ == "__main__":
    main()
