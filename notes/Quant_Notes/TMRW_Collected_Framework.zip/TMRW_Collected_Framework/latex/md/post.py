#!/usr/bin/env python3
"""Post-process pandoc's GFM output: substitute the pipe tables, tidy leftovers."""
import json, re, sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding="utf-8").read()
tables = json.load(open("md/tables.json", encoding="utf-8"))
s = re.sub(r"QQTABLE(\d+)QQ", lambda m: "\n" + tables[int(m.group(1))] + "\n", s)
# pandoc leaves the \tag inside display math: GitHub's MathJax renders it. Nothing to do.
# figures: pandoc writes <figure><img ...> or ![...](...) ; normalise to markdown images with alt
s = re.sub(r'<figure>\s*<img src="([^"]+)"[^>]*/?>\s*(?:<figcaption[^>]*>(.*?)</figcaption>)?\s*</figure>',
           lambda m: f"![{re.sub('<[^>]+>', '', m.group(2) or '')}]({m.group(1)})\n\n*{re.sub('<[^>]+>', '', m.group(2) or '')}*" if m.group(2) else f"![]({m.group(1)})", s, flags=re.S)
s = re.sub(r'<img src="([^"]+)"[^>]*/?>', r"![](\1)", s)
# empty divs / spans from unknown environments
s = re.sub(r'<div class="[^"]*">\s*', "", s); s = re.sub(r"\n</div>\n", "\n", s)
s = re.sub(r'<span class="[^"]*">(.*?)</span>', r"\1", s, flags=re.S)
# stray latex
s = s.replace("\\noindent", "").replace("\\par", "")
s = re.sub(r"\n{3,}", "\n\n", s)
# heading numbers: pandoc may escape the colon; nothing to do. Remove pandoc's auto {#id} attributes if any
s = re.sub(r"\s*\{#[^}]*\}", "", s)
open(dst, "w", encoding="utf-8").write(s)
print("wrote", dst, len(s), "chars")
