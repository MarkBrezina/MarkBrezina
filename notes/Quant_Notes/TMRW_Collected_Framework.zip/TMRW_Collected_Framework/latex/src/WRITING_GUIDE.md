# Writing guide for the chapters of the Collected Framework

You are writing one or more LaTeX chapter files of `/home/claude/tmrw-compendium/main.tex`
(read `main.tex` first: it defines every macro, colour, box and theorem environment you may use).
The document is a *compacted but complete* single-source account of a research programme:
"massively compacted, extensive": every hypothesis, every equation, every result, every number,
every figure and every working of the source documents must be present, but written once, densely,
with no repetition and no filler. Target length per chapter is given in your brief.

## Files

* Source texts (plain text extracted with `pdftotext -layout`, so columns/tables are whitespace-aligned):
  `/home/claude/tmrw-compendium/text/*.txt`, `*.md`, and the working notes in
  `/home/claude/tmrw-compendium/text/quant-notes/*.md`. The original PDFs are in
  `/mnt/user-data/attachments/da886d18-d2c6-5029-9d36-be762638701e/` if you need to look at a page
  (`pdftoppm -png -r 60 -f N -l N file.pdf out` then view the PNG) — do this for tables or figures
  whose text extraction is unreadable.
* Figures already extracted into `/home/claude/tmrw-compendium/figures/` (use `\includegraphics` with
  the bare file name, `\graphicspath` is set): `agg_society.pdf`, `agg_bound_composites.pdf`,
  `agg_computed_physics.pdf`, `agg_pantheon.pdf`, `agg_zeta.pdf`, `agg_zeta_layers.pdf` (AT-III
  figures 1–6), `part2_measured.pdf` (AT-II figure 1), `agg3_value_distribution.png`,
  `agg3_four_types.png` (AT-0 figures), `conj4_value_surface.jpg`, `conj4_mfg_interactions.jpg`,
  `conj4_hybrid_jumps.jpg`, `conj4_agent_network.jpg`, `conj4_asset_edges.jpg` (Conjecture 4
  figures), `diagram_company_algorithm.png`, `diagram_data_sources.jpg`, `diagram_ai_engines.jpg`,
  `diagram_org_chart.jpg`, `diagram_venture_cycle.jpg` (the firm's diagrams), `tmrw_logo.png`,
  `tomorrow_wordmark.png`.
* Write your chapter to `/home/claude/tmrw-compendium/src/<name>.tex` exactly as named in your brief.
  Do not touch other chapter files or `main.tex`.

## Compile check (mandatory before you report)

`bash /home/claude/tmrw-compendium/src/compile_one.sh <name>` compiles main.tex with only your
chapter(s) included. It must finish with **no errors** (undefined references to labels in other
chapters are fine; "Overfull \hbox" warnings over ~20pt must be fixed — split long equations
with `gathered`/`align`/`multlined`, narrow table columns with `p{..}` or `tabularx`, use
`\allowbreak` in long identifiers). It prints the page count of your chapter: compare with the target.

## Conventions

### Status tags (put one at the start of every statement that makes a claim)

`\PROVED` (an elementary proof is in the document), `\KNOWN` (quoted with a reference),
`\HYP` / `\CONJ` (to be tested), `\MEAS` (matched in hindsight on data; give the number),
`\PEND` (test defined, data host not reached), `\REFUTED` (shown wrong as originally stated),
`\OPEN`, `\SETUP` (a definition or modelling choice), `\PLAN` (an operating intention),
`\PRACTICE` (a working rule from the notes, used in practice), `\LOG` (a dated working-log entry).

Usage: `\begin{theorem}[Speed ratio]\label{thm:speed}\PROVED\; ...` or in text:
`\HYP\; Dark energy depends on local emptiness ...`.

### Source labels

Every section (and every table/figure caption) names where its content comes from, with
`\src{[AT-III §6.2]}` style labels appended at the end of the section heading or the first
paragraph: `\section{The exact layer \src{[AT-III §3]}}`. Source keys:

| key | document |
|---|---|
| GI | Geometric–Informational Multi-Agent System Framework (`Geometric_Informational_Multi-Agent_System_Framework.txt`) |
| GI-H | the hybrid-systems extension (contained in the Extended overview; jumps, reset maps, complex states) |
| GI-X | Extended Geometric Information Framework Overview (`Extended_Geometric_Information_Framework_Overview.txt`) |
| MD-1 | Initial draft of the market dynamics model (`Initial_draft.txt`) |
| MD-2 | Second initial draft (`2nd_initial_draft.txt`) |
| WP | Whitepaper – Financial markets model (`Whitepaper_-_Financial_markets_model.txt`; `TMRW_first.txt` is the same text plus a "Model" sketch — label the sketch WP-M) |
| FS | Framework summary (`Framework_summary.md`) |
| C1 … C4 | Conjecture 1 Path switching, 2 Central pricing, 3 Stealth-optimal distribution, 4 The full market model (`Conjecture_*.txt`) |
| C5 | Conjecture 5 "The final problem" (`The_final_problem.txt`, quant-notes `08-tomorrows-conjectures.md`, the bullets in `quant_bucket.md`) |
| AT-0 | Aggregation theory, the original 54-page setup (`Aggregation_theory_3.txt`; `Aggregation_theory_4` is identical) |
| AT-II | Aggregation theory part 2, the matching rule (`aggregation_part2.txt`) |
| AT-III | Aggregation theory, the collected account with the hindsight tests (`aggregation_theory_2.txt`; `final.txt` is the blank template of it plus a placeholder application "A: the dark energy") |
| BP | TMRW Business plan (`TMRW_Business_plan.md`) |
| DG | the five diagrams (company algorithm, data sources, AI engines, org chart, venture cycle) |
| NB | the working notes (`quant-notes/01…12`), cite as `[NB-01 §Inventory skew]` |
| QB | the raw quant bucket (`quant_bucket.md`), only where the notes do not contain the item |

### Theorem-like environments (all numbered per chapter, defined in main.tex)

`theorem, proposition, lemma, corollary, conjecture, hypothesis, known, definition, assumption,
example, experiment, deskrule (a working rule, prints as "Rule"), remark`, and the unnumbered `inwords`. (There is no environment named `rule` — `\rule` is a LaTeX primitive — use `deskrule`.) Keep the original numbering of the
source in the title when it helps: `\begin{hypothesis}[AT-0 Hypothesis 9.1: ...]`.

### Boxes

`\begin{keybox}[Title] ... \end{keybox}` for the one-paragraph summary at the top of each chapter
("What this chapter establishes"), `plainbox` for worked examples / recipes, `sourcebox` for short
verbatim quotations from a source (use sparingly, ≤ 5 lines).

### Editorial additions

Anything that is *not* in the sources (a bridge sentence, a reconciliation, a reading of what a
result means for the firm) must be marked: put it in a `\begin{remark}[... --- editorial]` or
append `(editorial)` to the heading. Never silently invent a number, a reference or a result.
If a source leaves a number blank (the `final.txt` template), say so.

### Numbers

Quote every number exactly as the source gives it (same precision, same unit) and add the source
label. Measured results go in tables with columns such as `Quantity & Measured & Expected & Verdict`.
Use `\num`-free plain numbers; thousands separators as in the source (e.g. `113,938.8`).

### Style

* British spelling, plain declarative sentences, no marketing language, no "we are excited".
* Every chapter begins with `\chapter{...}` (the brief says whether to begin with `\part{...}`),
  then a `keybox` summary (≤ 120 words), then the sections.
* Equations: `equation`/`align`/`gathered`, labelled `\label{eq:<chapterkey>-<slug>}` with the keys
  given in your brief; use `\eqref` for references.
* Tables: `booktabs` (`\toprule\midrule\bottomrule`), `\small` or `\footnotesize`, captions above
  with `\caption{...}\label{tab:...}`; long tables as `longtable`. Never let a table exceed
  `\textwidth` (use `p{}` columns or `tabularx` with `X`).
* Figures: `\begin{figure}[t]\centering\includegraphics[width=...]{file}\caption{...}\label{fig:...}\end{figure}`.
  Captions must carry the source label and say what each panel shows.
* Code: `lstlisting` (the `literate` table in main.tex handles ≈ − × → ± σ γ θ μ λ Δ κ ∑ ≤ ≥ ² ·;
  other non-ASCII characters inside listings must be replaced).
* Non-ASCII in text: write `é` etc. directly (utf8 inputenc) but *not* in math mode;
  use `\ensuremath{\upsigma}` style only if needed; `≈` → `$\approx$`, `×` → `$\times$`,
  `—` → `---`, `–` → `--`, `…` → `\dots`, `≤` → `$\le$`, `²` → `$^2$`, `°` → `$^\circ$`,
  `≥` → `$\ge$`, `→` → `$\to$`, `∝` → `$\propto$`, `√` → `$\sqrt{\cdot}$`, `−` → `-`.
* Underscores and ampersands in text must be escaped (`\_`, `\&`); product names in
  `\texttt{}` (`\texttt{GIFT\_BASKET}`).
* Use `\cref{...}` for cross-references to labels listed in the label registry below; for a label
  in another chapter use `\cref` too (it resolves in the full build).
* No `\section` deeper than `\subsection` except run-in `\subsubsection` paragraphs.
* Dates: `7 April 2025`.

## Label registry (defined by the chapters; use these exact names for cross-references)

Parts: `part:glance part:field part:market part:conjectures part:aggregation part:notes part:plan part:synthesis`.
Chapters: `ch:thesis` (01), `ch:gi ch:gix` (02), `ch:md ch:wp` (03), `ch:c1 ch:c2 ch:c3 ch:c4 ch:c5` (04),
`ch:at0` (05), `ch:at0r` (06), `ch:atii` (07), `ch:atiii` (08),
`ch:nb-mm ch:nb-prosperity ch:nb-options ch:nb-statarb ch:nb-trend ch:nb-arch ch:nb-rl ch:nb-multiscale ch:nb-toolkit` (09),
`ch:layers ch:infra ch:diagrams` (10), `ch:people ch:brand` (11), `ch:fit ch:ledger ch:open` (12),
`app:notation app:proofs app:data app:bitcoin app:labrun app:sources app:refs` (13, bib).

Key results that other chapters cite (define exactly these labels in the chapter that owns them):

* 01: `fig:chrono tab:expectations tab:shortanswer tab:sources`
* 02: `eq:gi-diffusion eq:gi-ricci eq:gi-coupling eq:gi-agentode eq:gi-edge eq:gi-infodiff eq:gi-coupled-geom eq:gih-reset eq:gix-cost eq:gix-fieldpde eq:gix-action lst:gix-loop`
* 03: `eq:md-pos eq:md-theta eq:md-val eq:md-surface eq:md-global eq:md-agent eq:md-bellman lst:md-dp eq:md-RL eq:md-Q eq:wp-layers eq:wp-state eq:wpm-action sec:wp-model`
* 04: `eq:c1-mix eq:c1-obj eq:c2-decomp eq:c2-impact eq:c2-maps eq:c3-schedules eq:c3-functionals eq:c3-obj fig:c4 eq:c4-state eq:c4-J eq:c5-objective`
* 05: `fig:at0-values eq:at0-actions eq:at0-softmax eq:at0-J eq:at0-bellman eq:at0-common eq:at0-mfe eq:at0-FP eq:at0-contest eq:at0-regions eq:at0-merger eq:at0-B14 eq:at0-eq eq:at0-control eq:at0-mfg sec:regimes sec:changing-eq hyp:at0-91 hyp:at0-92 hyp:at0-93 exp:at0-111 conj:at0-62`
* 06: `eq:E8 eq:F1 eq:G1 eq:H1 eq:K1 eq:K2 eq:K45 eq:L1 eq:L23 eq:L4 eq:M4 eq:N2 eq:O1 prop:J2 sec:landscape tab:phenomenology sec:lumping thm:lumping`
* 07: `sec:parti tab:established fig:part2 tab:symbols def:kinds sec:matching prop:additive cor:indexreturn thm:konig thm:internalgrows thm:masssuper thm:volsub known:virial eq:leftover hyp:epps hyp:scaleform sec:parts-dynamics eq:langevin eq:actionreaction eq:ofi eq:fp-book sec:quantum-exact eq:imagschrodinger sec:large-orders sec:twosided tab:partii-status`
* 08: `tab:domains sec:exactlayer thm:speed eq:speed thm:turbulence eq:turbulence thm:mean thm:cascade eq:cascade thm:mixture eq:mixture thm:squeezing thm:linearfield eq:linearfield known:signlaw sec:p1 tab:p1 fig:society sec:p2 tab:p2 sec:p3 fig:bound fig:physics hyp:bound sec:gravity fig:pantheon tab:gravity tab:scales sec:markets tab:markets sec:zeta eq:riemannsiegel fig:zeta fig:zetalayers sec:bitcoin-special tab:original-inside tab:status9 sec:darkenergy hyp:darkenergy`
* 09: `sec:nb-skew eq:nb-as eq:nb-skew tab:nb-quotes tab:nb-bands tab:nb-prosperity-rounds tab:nb-quoting-rules eq:nb-ncskew eq:nb-duvol sec:nb-voucher eq:nb-bs tab:nb-horizons eq:nb-statarb-spread eq:nb-trend-signal eq:nb-sharpe sec:nb-c5 rule:nb-pnl`
* 10: `sec:business-layer sec:portfolio-layer sec:strategy-layer sec:execution-layer tab:tech fig:dg-algorithm fig:dg-data fig:dg-engines fig:dg-org fig:dg-cycle`
* 12: `tab:crosswalk sec:reconcile tab:allnumbers tab:hyp-status`
* 13: `tab:btc-bins tab:btc-ic tab:btc-coef tab:btc-states tab:btc-oos`

## What "compacted but complete" means

1. Every definition, assumption, equation, proposition, theorem, hypothesis, conjecture,
   experiment and worked example in the source appears, in the source's own notation (unify
   notation only where the brief says so), with its original number in brackets when useful.
2. Every number (measured, expected, counted, simulated) appears in a table with its source.
3. Prose is compressed to the sentences that carry information: motivations are one sentence,
   explanations are kept when they carry a mechanism, repetition across sources is removed and
   replaced by a cross-reference.
4. The chapter closes with a short "Status" table (statement, tag, where tested) unless the brief says otherwise.
