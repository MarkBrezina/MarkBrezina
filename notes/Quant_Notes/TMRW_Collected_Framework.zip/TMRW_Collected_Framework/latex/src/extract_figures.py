#!/usr/bin/env python3
"""Crop the vector figures out of the aggregation-theory PDFs and pull the
raster figures out of Conjecture 4 and Aggregation theory 3.

Vector figures (AT-III = aggregation_theory_2.pdf, AT-II = aggregation_part2.pdf)
are located by their caption line ("Figure N:") and the cluster of drawing
objects (lines, rects, curves, small chars) that sits above the caption.  The
page is then cropped with pypdf by setting the media box and crop box, which
keeps the figure as vector graphics.

Run from the compendium root:  python3 src/extract_figures.py
"""
import os
import re
import subprocess
import sys

import pdfplumber
from pypdf import PdfReader, PdfWriter

ATT = "/mnt/user-data/attachments/da886d18-d2c6-5029-9d36-be762638701e"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)

AT3 = os.path.join(ATT, "cf3c02ab-aggregation_theory_2.pdf")      # AT-III (with numbers)
AT2 = os.path.join(ATT, "5e455461-aggregation_part2.pdf")          # AT-II
AT0 = os.path.join(ATT, "558329c0-Aggregation_theory_3.pdf")       # AT-0
C4 = os.path.join(ATT, "93ded658-Conjecture_4_-_The_Full_Market_Model.pdf")

# (pdf, 1-based page, output name, which caption on that page (0 = first))
VECTOR_TARGETS = [
    (AT3, 8, "agg_society.pdf", 0),
    (AT3, 9, "agg_bound_composites.pdf", 0),
    (AT3, 10, "agg_computed_physics.pdf", 0),
    (AT3, 12, "agg_pantheon.pdf", 0),
    (AT3, 17, "agg_zeta.pdf", 0),
    (AT3, 18, "agg_zeta_layers.pdf", 0),
    (AT2, 3, "part2_measured.pdf", 0),
]

MARGIN = 3.0


def find_caption_tops(page):
    """Return the top y (pdfplumber coordinates, from top) of every caption
    line that starts with 'Figure N:'."""
    words = page.extract_words(keep_blank_chars=False, use_text_flow=True)
    tops = []
    for i, w in enumerate(words):
        if re.fullmatch(r"Figure", w["text"]) and i + 1 < len(words):
            nxt = words[i + 1]["text"]
            if re.fullmatch(r"\d+[:.]", nxt) and abs(nxt_top(words, i) - w["top"]) < 2:
                tops.append(w["top"])
    return tops


def nxt_top(words, i):
    return words[i + 1]["top"]


def cluster_bbox(page, caption_top, page_top_limit):
    """Bounding box of drawing objects above the caption (down to page_top_limit)."""
    objs = []
    for kind in ("lines", "rects", "curves"):
        for o in getattr(page, kind):
            if o["bottom"] <= caption_top + 1 and o["top"] >= page_top_limit:
                # skip full-width rules (table rules / header rules)
                if (o["x1"] - o["x0"]) > 250 and kind in ("lines", "rects") and (o["bottom"] - o["top"]) < 2:
                    continue
                objs.append(o)
    if not objs:
        return None
    # keep only the cluster that is vertically contiguous with the caption:
    # walk upwards from the caption and stop at the first vertical gap > 25pt
    objs.sort(key=lambda o: -o["bottom"])
    kept = [objs[0]]
    cur_top = objs[0]["top"]
    for o in objs[1:]:
        if o["bottom"] >= cur_top - 25:
            kept.append(o)
            cur_top = min(cur_top, o["top"])
        else:
            break
    objs = kept
    x0 = min(o["x0"] for o in objs)
    x1 = max(o["x1"] for o in objs)
    top = min(o["top"] for o in objs)
    bottom = max(o["bottom"] for o in objs)
    # include small characters (axis labels, tick labels, legends) near the cluster
    for ch in page.chars:
        if ch["size"] < 9 and ch["top"] >= top - 14 and ch["bottom"] <= caption_top - 1 \
                and ch["x0"] >= x0 - 40 and ch["x1"] <= x1 + 40:
            x0 = min(x0, ch["x0"]); x1 = max(x1, ch["x1"])
            top = min(top, ch["top"]); bottom = max(bottom, ch["bottom"])
    return x0 - MARGIN, top - MARGIN, x1 + MARGIN, bottom + MARGIN


def crop_vector(pdf_path, pageno, out_name, which):
    with pdfplumber.open(pdf_path) as pdf:
        page = pdf.pages[pageno - 1]
        H = float(page.height)
        caps = find_caption_tops(page)
        if not caps:
            print(f"  !! no caption found on {os.path.basename(pdf_path)} p{pageno}")
            return False
        caps.sort()
        cap = caps[which]
        upper = caps[which - 1] + 30 if which > 0 else 0
        bbox = cluster_bbox(page, cap, upper)
        if bbox is None:
            print(f"  !! no drawing objects above caption on p{pageno}")
            return False
        x0, top, x1, bottom = bbox
    reader = PdfReader(pdf_path)
    pg = reader.pages[pageno - 1]
    # pypdf uses PDF coordinates (origin bottom-left)
    llx, lly, urx, ury = x0, H - bottom, x1, H - top
    pg.mediabox.lower_left = (llx, lly)
    pg.mediabox.upper_right = (urx, ury)
    pg.cropbox.lower_left = (llx, lly)
    pg.cropbox.upper_right = (urx, ury)
    w = PdfWriter()
    w.add_page(pg)
    with open(os.path.join(FIG, out_name), "wb") as fh:
        w.write(fh)
    print(f"  {out_name}: p{pageno} bbox=({x0:.0f},{top:.0f})-({x1:.0f},{bottom:.0f})")
    return True


def rasters():
    tmp = os.path.join(ROOT, "build", "pdfimages")
    os.makedirs(tmp, exist_ok=True)
    # Conjecture 4 figures: images 002,003,004,006,007; logo = 000 with 001 as smask
    subprocess.run(["pdfimages", "-png", C4, os.path.join(tmp, "c4")], check=True)
    mapping = {
        "c4-002.png": "conj4_value_surface.jpg",
        "c4-003.png": "conj4_mfg_interactions.jpg",
        "c4-004.png": "conj4_hybrid_jumps.jpg",
        "c4-006.png": "conj4_agent_network.jpg",
        "c4-007.png": "conj4_asset_edges.jpg",
    }
    from PIL import Image
    for src, dst in mapping.items():
        p = os.path.join(tmp, src)
        if not os.path.exists(p):
            print("  !! missing", p); continue
        im = Image.open(p).convert("RGB")
        im.thumbnail((1400, 1400))
        im.save(os.path.join(FIG, dst), quality=86)
        print(f"  {dst}: {im.size}")
    logo = os.path.join(tmp, "c4-000.png"); mask = os.path.join(tmp, "c4-001.png")
    if os.path.exists(logo):
        im = Image.open(logo).convert("RGB")
        if os.path.exists(mask):
            m = Image.open(mask).convert("L").resize(im.size)
            im.putalpha(m)
        im.save(os.path.join(FIG, "tmrw_logo.png"))
        print("  tmrw_logo.png:", im.size)
    # Aggregation theory 3 figures: 000 (+001 mask), 002 (+003 mask)
    subprocess.run(["pdfimages", "-png", AT0, os.path.join(tmp, "a3")], check=True)
    for src, msk, dst in [("a3-000.png", "a3-001.png", "agg3_value_distribution.png"),
                          ("a3-002.png", "a3-003.png", "agg3_four_types.png")]:
        p = os.path.join(tmp, src)
        if not os.path.exists(p):
            print("  !! missing", p); continue
        im = Image.open(p).convert("RGBA")
        mp = os.path.join(tmp, msk)
        if os.path.exists(mp):
            m = Image.open(mp).convert("L")
            if m.size == im.size:
                bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
                im.putalpha(m)
                im = Image.alpha_composite(bg, im)
        im = im.convert("RGB")
        im.thumbnail((1600, 1600))
        im.save(os.path.join(FIG, dst))
        print(f"  {dst}: {im.size}")
    # wordmark from the business plan docx media
    wm = os.path.join(FIG, "business_plan_media", "media", "image1.png")
    if os.path.exists(wm):
        Image.open(wm).save(os.path.join(FIG, "tomorrow_wordmark.png"))
        print("  tomorrow_wordmark.png")


if __name__ == "__main__":
    print("vector figures")
    for pdf, pg, name, which in VECTOR_TARGETS:
        crop_vector(pdf, pg, name, which)
    print("raster figures")
    rasters()
