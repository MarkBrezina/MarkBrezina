#!/usr/bin/env python3
"""Write src/hypstatus_body.tex (the H1-H12 verdict rows) from the test bench's results/summary.json."""
import json, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
summ = os.path.join(ROOT, "..", "tmrw-lab", "results", "summary.json")
rows = []
def tex(s):
    return re.sub(r"([&%$#_{}])", r"\\\1", str(s)).replace("^", r"\^{}").replace("~", r"\textasciitilde{}")
if os.path.exists(summ):
    s = json.load(open(summ))
    for r in s["results"]:
        if not r["name"].startswith("hypotheses."):
            continue
        hid = r["name"].split(".")[1].split("_")[0].upper().replace("H0", "H")
        title = r["title"]
        title = re.sub(r"^H\d+\s+", "", title)
        m = sum(1 for n in r["numbers"] if n["verdict"] == "match"); j = sum(1 for n in r["numbers"] if n["expected"] is not None)
        rows.append(f"{hid} & {tex(title)} & {tex(r['data_origin'])} & \\textbf{{{tex(r['verdict'])}}} & {m}/{j} \\\\")
else:
    rows.append("-- & no run recorded & -- & -- & -- \\\\")
body = ("\\begin{tabular}{@{}lp{8.2cm}llc@{}}\n\\toprule\n & Hypothesis & Data & Verdict & Matches \\\\\n\\midrule\n"
        + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")
open(os.path.join(ROOT, "src", "hypstatus_body.tex"), "w").write(body)
print(len(rows), "rows")
