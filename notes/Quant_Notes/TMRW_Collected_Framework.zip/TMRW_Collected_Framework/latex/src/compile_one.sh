#!/bin/bash
# Compile main.tex with only the named chapter file(s) included, in a private build dir.
# usage: bash src/compile_one.sh 05_aggregation_original [06_aggregation_rigorous ...]
set -u
ROOT=/home/claude/tmrw-compendium
cd "$ROOT" || exit 1
if [ $# -lt 1 ]; then echo "usage: compile_one.sh <chapter-name-without-.tex> [...]"; exit 1; fi
TAG=$(echo "$@" | tr ' ' '_' | tr -c 'A-Za-z0-9_\n' '_')
B="$ROOT/build/one_$TAG"
mkdir -p "$B"
# assemble a main file that inputs only the requested chapters
{
  sed -n '1,/^\\begin{document}/p' main.tex
  for c in "$@"; do echo "\\input{src/$c}"; done
  echo "\\end{document}"
} > "$B/main_one.tex"
# figures and src are referenced relative to ROOT; run pdflatex with ROOT as cwd via -output-directory
for i in 1 2; do
  pdflatex -interaction=nonstopmode -halt-on-error -output-directory="$B" "$B/main_one.tex" > "$B/pdflatex.log" 2>&1
  status=$?
  if [ $status -ne 0 ]; then
    echo "=== LaTeX ERROR (pass $i) ==="
    grep -n -A3 '^!' "$B/main_one.log" | head -60
    exit 2
  fi
done
echo "=== OK: $(pdfinfo "$B/main_one.pdf" 2>/dev/null | awk '/^Pages/{print $2}') pages -> $B/main_one.pdf"
echo "--- overfull boxes over 20pt ---"
grep -n 'Overfull \\hbox ([2-9][0-9]\.[0-9]*pt\|Overfull \\hbox ([0-9]\{3,\}' "$B/main_one.log" | head -20
echo "--- undefined references (other chapters' labels are expected) ---"
grep -c 'Reference .* undefined' "$B/main_one.log"
exit 0
