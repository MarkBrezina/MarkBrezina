## The Collected Framework

![image](figures/tomorrow_wordmark.png)

**Tomorrow Capital Research — Mark Brezina — compiled edition, November 2026.**

Geometric–informational market models, the five conjectures, aggregation theory and its tests, the working notes and the operating plan. Single-source compendium of the programme’s documents (April 2025 – November 2026), with every statement tagged by its epistemic status and every number traced to its source.

Reading key: **\[PROVED\]** an elementary proof is in this document; **\[KNOWN RESULT\]** quoted with a reference; **\[HYPOTHESIS\]** / **\[CONJECTURE\]** to be tested; **\[MEASURED\]** matched in hindsight on data; **\[PENDING RUN\]** test defined, data host not yet reached; **\[REFUTED AS STATED\]** shown wrong as originally stated; **\[SETUP\]** a definition or modelling choice; **\[PLAN\]** an operating intention; **\[PRACTICE\]** a working rule; **\[LOG\]** a dated working-log entry. Source labels such as *\[AT-III §6.2\]* point to the document and section the content comes from.

## Abstract

This document collects, compacts and cross-references everything the research programme of Tomorrow Capital Research has produced between April 2025 and November 2026: the geometric–informational multi-agent framework and its hybrid extension (Part II); the market dynamics model, the whitepaper, the model sketch and the first theoretic proposal (Part III); the five conjectures — path switching, central pricing, stealth-optimal distribution, the full market model and the final problem (Part IV); aggregation theory in its four layers — the original setup, the rigorous mean-field layer, the matching rule, and the collected account with the hindsight tests on societies, gases, nuclei, hadrons, collider events, galaxies, markets and the Riemann zeta function (Part V); the working notes that carry the theory to the desk — market making and inventory control, the Prosperity competitions, options and vouchers, the statistical-arbitrage and trend blueprints, the multi-layer architecture, reinforcement learning, multiscale thinking and the research toolkit (Part VI); the operating plan of the firm (Part VII); and a synthesis that places every result in one architecture, with a ledger of every measured number, the status of every hypothesis and the open problems (Part VIII). The appendices give the notation, the proofs that are not inline, the data and code, the Bitcoin study tables, the test-bench run (Appendix E: the `tmrw_lab` package that re-runs every testable statement), the index of sources and the references.

The thesis that runs through all of it is a matching rule: additive quantities match exactly across levels of a hierarchy; squared quantities split into a collective part and an internal part, with the gap measuring the internal motion; and the parameters of that split — the collective share $\kappa$, the speed ratio $\varphi$, the turbulence ratio $\Psi$, the dynamical-to-visible ratio $\Upsilon$, the lag $\tau$ — are domain parameters to be measured, not universal constants. Where the documents disagree, the disagreement is recorded; where a number was never produced, a dash says so.

## How to read this document

> **The whole document in one paragraph**
>
> A market, a gas, a galaxy and a population are systems of units whose individual motions add up to the motion of a whole. The firm’s first documents built the frame in which that happens (a manifold with fields and agents, a layered market graph, a hybrid control problem) and stated four conjectures about how prices form inside it. Aggregation theory then asked the general question — what does a whole equal exactly, and what differs from the sum of its parts — and answered it with short exact statements (a triangle inequality, König’s split, Minkowski’s inequality with an exact turbulence identity, Jensen’s inequality for growth, a cascade factorisation, a mixture law, a squeezing bound, an exact split of a velocity field, the virial sign law) whose free parameters were then measured in hindsight on public data. The working notes apply the same picture to one order book at a time: fair value, inventory, skew, taking and making, blueprints for arbitrage and trend. The operating plan is the firm built around it. Everything that can be run is run again in the test bench.

###### Variable resolution.

Each part opens with a one-paragraph summary in a box and closes with a status table. Part I is the whole programme on a few pages; the parts that follow are the documents themselves, compacted; Part VIII is the reconciliation. A reader who wants results only reads Part I and Part VIII; a reader who wants the mathematics reads Part II, Part III, Part IV and Part V; a reader who wants the practice reads Part VI; the firm is Part VII.

###### Status discipline.

Every statement that makes a claim carries one of the tags on the title page. A tag is a statement about evidence, not about importance: a **\[HYPOTHESIS\]** may be the most important sentence in a chapter. **\[MEASURED\]** is used only where a number was produced and is quoted; **\[PENDING RUN\]** where the test is defined but the data host could not be reached when the run was made; **\[REFUTED AS STATED\]** where a hindsight test showed the statement false as it was originally written (the corrected statement is then given next to it).

###### Editorial additions.

Everything that is not in a source — a bridging sentence, a reconciliation between two documents, a reading of what a result means for the desk — is marked “editorial”, either in the heading or in a remark. Numbers are never editorial.

###### Provenance.

Every section heading and every table or figure caption carries a source label. Table 1 lists the documents; Appendix F indexes which section of this document compacts which section of which source.

**Table 1.** The source documents, in the order they were written. Labels are used throughout as *\[LABEL §n\]*.

| Label | Date | Document | Compacted in |
|---|---|---|---|
| GI | 2025 (undated) | Geometric–Informational Multi-Agent System Framework (8 pp.) | Chapter 2 |
| GI-X | 2025 (undated) | Extended Geometric Information Framework Overview (19 pp.) | Chapter 3 |
| GI-H | 26 Apr 2025 | Extended Geometric–Informational Multi-Agent System with Hybrid Frames and Complex Dynamics | Chapter 2 |
| NB-02/03 | Apr 2025 | Prosperity 3 team log and the Prosperity playbook (working notes) | Chapter 16 |
| MD-1 | 13 May 2025 | Initial draft: market dynamics model (4 pp.) | Chapter 4 |
| MD-2 | May 2025 | Second initial draft (extended) | Chapter 4 |
| BP | 27 Sep 2025 | TMRW Business plan (initial theoretic proposal, four layers, infrastructure, people, brand) | Chapter 5, Chapter 24, Chapter 25, Chapter 27 and Chapter 28 |
| DG | 2025 | Five diagrams: company algorithm, data sources, AI engines, org chart, venture cycle | Chapter 26 |
| WP | 21 Oct 2025 | Whitepaper — Financial markets model (20 pp.) | Chapter 5 |
| WP-M | Oct 2025 | The “Model” sketch appended to the whitepaper (`TMRW_first.pdf`) | Section 5.8 |
| FS | 23 Oct 2025 | Framework summary (one page) | Chapter 5 |
| C1–C4 | 1 Dec 2025 | Conjectures 1–4: path switching; central pricing; stealth-optimal distribution; the full market model | Chapter 6, Chapter 7, Chapter 8 and Chapter 9 |
| AT-0 | 1 Jan – 13 Jul 2026 (compiled 23 Oct 2026) | Aggregation theory: the original setup and the rigorous layer (54 pp.) | Chapter 11 and Chapter 12 |
| AT-II | 23 Oct 2026 | Aggregation theory, part 2: the matching rule (13 pp.) | Chapter 13 |
| AT-III | 25 Oct 2026 | Aggregation theory: the collected account with the hindsight tests (23 pp.); the 5 Nov 2026 template adds application A (dark energy, unfilled) | Chapter 14 |
| NB-01 … NB-12 | 2025–Nov 2026 | The consolidated working notes (market making, Prosperity, options, stat-arb, trend, architecture, conjectures, RL, multiscale, scraps, getting started) | Part VI, Chapter 10 |
| QB | 2025–2026 | The raw quant bucket the notes were consolidated from | Part VI |
| C5 | Nov 2026 | Conjecture 5: the final problem (NB-08, QB) | Chapter 10 |
| LAB | Nov 2026 | `tmrw_lab`: the test bench (this edition) | Appendix E |

# Part I: The programme at a glance

## Chapter 1: The thesis, the propositions and the matching rule

> **What this chapter establishes**
>
> One picture of the whole programme: its chronology (Figure 1.1); the three propositions in the form in which they were finally tested *\[AT-III §1.1\]*; the matching rule that unifies them *\[AT-II §3\]*; the table of expectations for the tests that were defined but not yet run *\[AT-III §8.2, user’s summary\]* together with what the test bench of this edition produced (Table 1.1); and the short-answer table of the collected account (Table 1.2). The rest of the document is the evidence behind these pages.

### 1.1 Chronology *\[all sources\]*

![Chronology of the programme. Labels as in Table 1. The Prosperity competitions (NB-02/03) ran in April 2025 (Prosperity 3) and 2026 (Prosperity 4); the working notes were consolidated in November 2026.](figures/chronology.png)

*Chronology of the programme. Labels as in Table 1. The Prosperity competitions (NB-02/03) ran in April 2025 (Prosperity 3) and 2026 (Prosperity 4); the working notes were consolidated in November 2026.*

### 1.2 The three propositions, as finally stated *\[AT-III §1.1\]*

The programme began with a framework for agents whose individual decisions add up to the motion of a whole — an order book, a market, a population (Part II and Part III). Aggregation theory turned three working propositions into statements that can be proved or tested; AT-II fixed the setup and added the matching rule; AT-III tested the propositions in the following form.

Three applications were added *\[AT-III §1.1\]*: **A** the dark energy (reserved in the November 2026 template, body unfilled, Section 14.8); **B** star clusters, galaxies and beyond, with collective motion as the hypothesis, plus a separate rule: space expands with the distance between objects at an unknown speed per unit of space, which should be measured and corrected for (Section 14.7); **C** stocks, crypto and order books, extended down to the order book (Section 14.9); **D** the Riemann zeta function, whose zeros might be found “in the same manner”: the real and imaginary parts as aggregating layers of the function (Section 14.10).

### 1.3 The matching rule *\[AT-II §3\]*

> **The matching rule**
>
> Across the levels of a hierarchy of units, groups and groups of groups:
>
> 1.  **Additive quantities match exactly.** Weighted sums, counts, order flow, momentum, money: the whole equals the sum of the parts to rounding error (Proposition 13.6).
>
> 2.  **Squared quantities split into a collective part and an internal part.** Energy, variance, squared returns, squared velocities: $\sum_i w_i\lvert x_i\rvert^2 = \lvert X\rvert^2 + \sum_i w_i\lvert x_i-X\rvert^2$ (König’s split, Theorem 13.9); the whole carries only the collective part.
>
> 3.  **The gap measures the internal motion.** Its size is a domain parameter, measured as the collective share $\kappa=\lvert X\rvert^2/\sum_i w_i\lvert x_i\rvert^2$, the speed ratio $\varphi=\lvert X\rvert/\sum_i w_i\lvert x_i\rvert$, the turbulence ratio $\Psi$ with $\Psi^2=H+(1-H)\bar\rho$, the dynamical-to-visible ratio $\Upsilon=M_{\mathrm{dyn}}/M_{\mathrm{vis}}$ and the lag $\tau$ (Table 13.2).
>
> What is not additive and not a split of a square is *emergent*: it has to be matched by a two-sided procedure (Section 13.6).

### 1.4 Expectations and what the test bench found *\[AT-III §8.2; LAB\]*

Table 1.1 lists the tests that AT-III defined but could not run (its data hosts were not reachable from the build machine), with the value each was expected to give, the one that was measured in hindsight, and what the test bench of this edition produced (Appendix E). A value from the bench is marked *synthetic* when the loader fell back to a generated file with the planted answer: such a value tests the code path, not the world.

**Table 1.1.** Expected values of the matching parameters, domain by domain, against what was measured. Expected values from *\[AT-III §7–8, Table 9\]* and the author’s summary; measured values from *\[AT-III\]*; bench values from Appendix E.

| Domain | Quantity | Expected | Measured (AT-III) | Test bench (this edition) |
|---|---|---|---|---|
| CMS dimuons at the $J/\psi$ | $M/(m_1+m_2)$ | $\approx 14.7$ | – | not run (CERN open data unreachable) |
| ATLAS four leptons | $(M_{4\ell}-M_{12}-M_{34})/M_{4\ell}$ | $\ge 0$; median $\approx 17\%$ | $0.172$ (832/832) | 832/832, median 0.172 (synthetic stand-in) |
| Open star clusters | $\Upsilon=M_{\mathrm{dyn}}/M_{\mathrm{vis}}$ | 1–5 | – | 2.7 (synthetic, planted) |
| Random field-star groups | $\Upsilon$ | $\sim 10^{5}$ | – | $7.9\times10^{4}$ (synthetic, planted) |
| Galaxy clusters | $\Upsilon$ | 30–100+ | – | not run |
| S&P 500 | collective share $\kappa$; $\sigma$ ratio | $\kappa\approx0.2$–$0.4$; $0.6$–$0.75$ | – | 0.30; 0.62 (synthetic basket; Stooq unreachable) |
| Crypto basket | $\kappa$ against bar length | rising $\approx0.75\to0.8$ | – | 0.15 (1 s) $\to$ 0.78 (5 min), $\tau=4.2$ s (synthetic; Binance unreachable) |
| Order book (BTC) | mid move $\div$ microprice offset | far above 1, flat after seconds | – | 1.3 (100 ms), 3.0 (60 s) on the synthetic stand-in; real level-1 data needed |

### 1.5 The short answer *\[AT-III Table 1\]*

**Table 1.2.** The propositions in their final form: what is exact, what is measured, and the verdict so far *\[AT-III Table 1\]*.

|   | Exact (proved) | Measured (hindsight) |
|---|---|---|
| P1 | Speed ratio $\varphi\le1$, collective share $\kappa\le\varphi^2\le1$, turbulence ratio $\Psi\le1$ with $\Psi^2=H+(1-H)\bar\rho$ exactly; each factor of a cascade is at most 1. The mean is not lowered: with fixed weights it is preserved exactly. Compound growth of the whole exceeds the weighted mean of the parts’. | Holds everywhere it was measured. The size of each factor is a domain parameter, set by alignment and correlation; there is no universal factor such as one half. The collective share of growth-rate energy is 0.116 from US counties to the nation, 0.402 from countries to world GDP and 0.727 from metros to the Case–Shiller composite. |
| P2 | The aggregate response is exactly the impact-weighted mixture of unit responses; it lies between two shifted copies of the lag distribution; coarse bins capture a share $\ge1-(\text{spread})/\Delta$ of it. | COVID-19 waves, the 2006–11 housing crash and a beam in a magnet all fit the mixture law ($R^2$ 0.992, 0.993, 1.0000). The squeezed share rises from 0.01 (daily bins) to 0.93 (yearly bins) for the first wave. |
| P3 | König and virial: a bound composite carries internal energy $(1+2/n)K$; it is lighter than its parts for attractive $1/r$-type binding and heavier for confinement. Free composites are always heavier (invariant mass). | All 2,938 nuclei and hydrogen are lighter than their parts; all 15 hadrons are heavier; all 832 ATLAS four-lepton events have whole $\ge$ parts. In a simulated gas, collective motion turns into heat with total energy conserved to $1.11\times10^{-16}$. |
| A | The dark energy (reserved; unfilled in the template). | – |
| B | The velocity field splits exactly into bulk, linear field and internal motion; expansion is the trace of the linear field. | Pantheon+: $H_0=73.25\pm1.40\,\mathrm{km\,s^{-1}\,Mpc^{-1}}$, one rate at all distances ($\chi^2=5.7$ for 6 degrees of freedom). The motion left after removing it carries a bulk flow of 290 km/s, mostly removed by a gravity model. |
| C | Index returns are weighted sums of stock returns; order flow adds exactly across levels and venues. | Earlier runs: every exact statement held to rounding error; a market-wide move takes about 5 s to reach all coins. New tests are listed in Section 14.9. |
| D | Zeros of $Z(t)$ are where the units of the Riemann–Siegel sum cancel. | All 1,747,146 zeros up to height 1,000,000 lie on the critical line, as counted independently (missing: 0). The statistics are those of random-matrix energy levels. This is a check, not a proof of the Riemann hypothesis. |

### 1.6 What the firm does with it (editorial)

The documents were written for three readers at once — the mathematician, the trader and the firm — and the same architecture serves all three. For the desk, the matching rule says which quantities can be carried across horizons and instruments without loss (order flow, inventory, money) and which cannot (variance, impact, energy): a strategy that sums the former and splits the latter is the only kind that is consistent across the four horizon layers of Chapter 20. For the models, the collective share $\kappa$ measured on an index, a basket or a book is the fraction of the squared motion that a top-down model can hope to explain; the rest is internal and needs the bottom-up (order-book) layer of Section 13.5. For the firm, the four layers of the operating plan (Chapter 24) are the hierarchy of Definition 13.5 read as an organisation: the business layer sees only additive quantities (capital, PnL, flows), the strategy layer sees the squares (risk, impact), and the execution layer sees the internal motion that the levels above cannot. The five conjectures (Part IV) are the places where that reading has been turned into a testable statement about prices; Part VIII reconciles them with the theorems.

# Part II: The geometric–informational framework

## Chapter 2: The geometric–informational multi-agent system *\[GI\]*

> **What this chapter establishes**
>
> The source *\[GI\]* fixes the foundational frame of the programme as one coupled dynamical system on three spaces: a time-dependent Riemannian manifold $(M,g(t))$ carrying fields $\phi_k(x,t)$ that diffuse (2.1) and a metric that flows (2.2); agents $i\in I(t)$ with position $x_i\in M$ and internal state $s_i=(x_i,C_i,V_i,U_i,\kappa_i,\dots)$ whose dynamics (2.5) are coupled through a matrix $W(t)$ (2.4); and a multilayer information graph $G(t)$ with an edge law (2.6) and Laplacian diffusion of beliefs (2.7). Agents source curvature and field values (2.8). The extension *\[GI-H\]* makes the frame switchable: a hybrid state space $X=M\times S$ whose reset maps (2.12) carry value functions and rewire links at a jump, and complex-valued agent states. Everything here is a modelling choice (**\[SETUP\]**) or a quoted standard result (**\[KNOWN RESULT\]**): the sources prove nothing, simulate nothing and test nothing.

### 2.1 The manifold $(M,g(t))$ and the state *\[GI §1\]*

**Definition 2.1** **(Foundational frame).** **\[SETUP\]** The frame is a time-dependent differentiable manifold $(M,g(t))$: $M$ a smooth manifold of dimension $d$, compact or unbounded, possibly with boundary or non-trivial topology; $g(t)$ a Riemannian metric (pseudo-Riemannian if time is included) giving distances $d_g$, angles and curvature. The *field state* is the metric $g_{ab}(x,t)$, the curvature tensors $R_{abcd}(x,t)$ — equivalently $\mathrm{Rm}(x,t)$, the Ricci tensor $\operatorname{Ric}(x,t)$ and the scalar curvature $R(x,t)$ — the volume/area forms, and additional scalar or tensor fields $\{\phi_k(x,t)\}$ on $M$; $\Delta_g$ is the Laplace–Beltrami operator.

**\[SETUP\]** Curvature encodes “holes” and “indents”; sectional curvatures govern how agents perceive distance and area; curvature and topology (holes, handles) influence agent motion through geodesic distances and may evolve in time; non-trivial topology is represented by non-zero homology groups or non-contractible loops; the fields $\phi_k$ are local resources, potentials or “add-variables” living in localised regions of $M$. The state of the full system is a point in the product of the manifold layer $(g,\{\phi_k\})$, the agent state space $\prod_i S_i(t)$ and the network state space of Section 2.6 *\[GI §5\]*. **\[KNOWN RESULT\]** Differential geometry extends to metric spaces and networks, with graph curvatures (Ollivier–Ricci, Forman) *\[GI ref. 2\]*; the source gives this as the justification for the Riemannian treatment.

### 2.2 The fields and their diffusion *\[GI §1, §5\]*

**\[SETUP\]** Each field satisfies a PDE on $M$ — reaction–diffusion or wave type — driven by the agent density; the canonical case is a diffusion field coupled to the agents by a source/sink term, $$\tag{2.1}
  tial_t\phi = D\,\Delta_g\phi + f(\phi,\rho_{\mathrm{agents}}),\qquad
  \rho_{\mathrm{agents}}(x,t)=\rho(x,t)=\sum_{i\in I(t)}\delta\big(x-x_i(t)\big),$$ $D$ the diffusion constant, $\rho$ the empirical agent density. The reaction term is written $f(\phi,\rho_{\rm agents})$ *\[GI §1\]*, $F(\phi,\rho_{\rm agents})$ *\[GI §5\]* and $S(\phi,\{x_i\})$ *\[GI §4\]*; (2.1) stands for all three. For many agents $\rho$ becomes a smooth density obeying a continuity or Fokker–Planck equation (Section 2.9).

### 2.3 Geometry evolution: the Ricci-flow law *\[GI §1\]*

**Known result 2.2** **(Ricci flow).** **\[KNOWN RESULT\]** The canonical evolution of the metric is the Ricci flow $$\tag{2.2}
  tial_t g_{ab} = -2\,\operatorname{Ric}_{ab}(g),$$ a non-linear PDE that “smooths” curvature on $M$, a heat equation on geometry *\[GI ref. 1\]*.

**\[SETUP\]** The source augments (2.2) with a source term from the agent distribution, $$\tag{2.3}
  tial_t g = -2\,\operatorname{Ric}(g) + \alpha\,T_{\mathrm{agents}},$$ “analogous to Einstein’s equation”, $T_{\rm agents}$ depending on agent mass–energy, $\alpha$ a coupling constant; the concrete $T_{\rm agents}$ used later is a sum of Dirac masses at the agent positions, (2.8). The foundational field is thus the triple $(M,g(t),\{\phi_k\})$ evolving by coupled geometric flows and diffusion equations under agent presence and intrinsic geometry.

### 2.4 Agents and the coupling matrix $W(t)$ *\[GI §2\]*

**Definition 2.3** **(Agent).** **\[SETUP\]** The agents form a possibly variable set $I(t)=\{1,\dots,N(t)\}$. Agent $i$ has

1.  a *position* $x_i(t)\in M$, moved by continuous or discrete dynamics on $M$, e.g. $\dot x_i=v_i(s_i,\{s_j\})$ or jumps along geodesics;

2.  an *internal state* $s_i(t)\in S_i$ holding a cost $C_i(t)$, a value $V_i(t)$, an expected utility $U_i(t)$, an information coefficient $\kappa_i(t)$ and strategy variables, so $s_i\in\mathbb{R}^m$ or a product space; in summary notation $s_i=(x_i,C_i,V_i,U_i,\kappa_i,\dots)$ *\[GI §5\]*;

3.  a *decision/control* $a_i(t)$ (velocities, strategy updates) chosen to optimise a cost or utility $J_i\big(s_i,\{s_j:j\in\mathcal{N}_i\},\Phi\big)$ depending on its own state, its neighbours $\mathcal{N}_i$ in the network and the local field values $\Phi(x_i)$; in the game-theoretic reading $U_i=V_i-C_i$ and agents adjust $s_i$ or $a_i$ by gradient descent/ascent or best response.

**\[SETUP\]** *Variable state space.* As agents move or form coalitions their state is augmented — joining a group attaches a membership index to $s_i$, entering a region with a special resource adds a local-field variable — so $s_i\in S_i(t)$, a state space depending on location or group membership (Section 2.8.2).

**Definition 2.4** **(Coupling matrix).** **\[SETUP\]** Pairwise interactions are encoded by $W(t)=[w_{ij}(t)]$, $w_{ij}(t)\ge0$ the strength of influence of agent $j$ on agent $i$, positive only if $i$ and $j$ are allowed to interact (neighbours in the information graph, or within a distance threshold on $M$). The neighbourhood of $i$ is $N_i(t)=\{j: w_{ij}(t)>0\}$ and $$\tag{2.4}
  w_{ij}(t)=f\big(d_g(x_i,x_j),\,s_i(t),\,s_j(t)\big),\qquad
  w_{ij}=0\ \text{ if } d_g(x_i,x_j)>R\ \text{ or the interact-state flag is off},$$ $R$ an interaction range; the interact-state rule is violated, and $w_{ij}=0$ imposed, when $i,j$ belong to different teams or run non-overlapping strategies. $W$ may depend on agent states (a dynamic matrix) or on the geodesic distance.

**\[KNOWN RESULT\]** For an unweighted graph the Laplacian is $L=D-A$ with $L_{ii}=\deg(v_i)$ and $L_{ij}=-1$ for adjacent $i,j$ *\[GI ref. 4\]*; $W(t)$ generalises $A$ by weighting edges by geometry or state. **\[KNOWN RESULT\]** A multi-agent system is “a system composed of multiple interacting intelligent agents” *\[GI ref. 3\]*; payoffs depending on graph neighbours are graphical games (Kearns et al., quoted in *\[GI §2\]*).

### 2.5 Agent dynamics *\[GI §2, §5\]*

**\[SETUP\]** Each agent’s state obeys a coupled ODE (or difference equation) driven by its neighbours and by the fields at its position, $$\tag{2.5}
  \dot s_i = F_i\big(s_i,\{s_j: j\in N_i(t)\},\Phi(x_i),t\big),\qquad
  \dot x_i = v_i(s_i,\Phi),\quad \dot C_i = G_i\big(s_i,\{s_j\}_{j\in N_i},\Phi\big),\ \dots$$ $\Phi(x_i)$ the current value of the fields (geometry or $\phi$) at $x_i$, $v_i$ a velocity, $G_i$ the cost dynamics, possibly derived from optimising $J_i(s_i,\{s_j\})$. Named instances: gradient descent on cost, $\dot s_i=-\nabla_{s_i}J_i$, and a replicator equation. The agents play a differential game and (2.5) is gradient-play; in a simulation each step’s action is a local optimisation or best-response problem, solved by local computation or by learning (evolutionary algorithms) *\[GI §6\]*. The collection is a multi-agent dynamical system *\[GI ref. 3\]*.

### 2.6 The multilayer information graph *\[GI §3\]*

**Definition 2.5** **(Informational layer).** **\[SETUP\]** $G(t)=(V,E(t))$ is a graph, possibly directed and weighted, on the agent set $V=I(t)$; an edge $e_{ij}\in E$ means that $i$ receives information from $j$ (or they interact socially). Edges are typed or layered into channels (communication, trust, strategy sharing); equivalently $G$ is a multilayer or multiplex network $\{G^\ell\}$, one graph $G^\ell$ with adjacency $A^\ell(t)$ per layer on the same node set, each node copied into every layer and interslice couplings linking the copies. For a weighted graph the degree is $D_{ii}=\sum_j A_{ij}$ and the Laplacian $L=D-A$.

**\[KNOWN RESULT\]** Multilayer and multiplex networks are a standard abstraction: each layer is its adjacency matrix and interlayer couplings link node copies *\[GI refs. 5, 6\]*.

###### Edge law

**\[SETUP\]** The edge set evolves by rules for linking, sharing and grouping (if $i$ shares its cost function with $j$, a directed edge $i\to j$ annotated with that information is added; edges disappear when communication halts), $$\tag{2.6}
  \dot a_{ij} = H_{ij}\big(s_i,s_j,a_{ij},\ldots\big),$$ or by stochastic link-formation rules, so $G(t)$ is a temporal network (*\[GI §5\]* writes the rule $H(a_{ij},s_i,s_j)$). An edge carries the weight $w_{ij}$ of (2.4), a history log, a coupling strength and copies of shared agent variables: a strategy $p_i$ shared by $i$ with $j$ is edge data entering $j$’s next decision.

###### Groups and hypergraphs

**\[SETUP\]** A group acting in concert is a hyperedge $h\in\mathcal{H}\subseteq\mathcal{P}(V)$ of a hypergraph $(V,\mathcal{H})$ *\[GI ref. 6\]*, with a group payoff $U_h(\{s_i:i\in h\})$, in general non-separable. **\[KNOWN RESULT\]** By Sklar’s theorem any multivariate joint utility decomposes into marginals linked by a copula. **\[SETUP\]** Practically each hyperedge is a complete subgraph in a layer of its own; in the multiplex view group membership is a community across layers.

###### Information propagation

**\[SETUP\]** Information (costs, strategies, history) propagates along $G(t)$; the canonical model is graph diffusion of an informational state $s_i^{\mathrm{info}}$ (a strategic variable or belief), $$\tag{2.7}
  \dot s_i^{\mathrm{info}} = \sum_{j\in N_i(t)} a_{ij}(t)\,\big(s_j^{\mathrm{info}}-s_i^{\mathrm{info}}\big),$$ i.e. $\dot s^{\rm info}=-L\,s^{\rm info}$ with the Laplacian of the current weighted graph *\[GI ref. 4\]*; rumour-spreading and consensus models are admitted in its place, and the overview’s consensus term $-\sum_j W_{ij}(x_i-x_j)$ (Section 3.6) is (2.7) with $a_{ij}=W_{ij}$. Links form preferentially between agents close on $M$, an edge may make $i$ move toward $j$, and proximity on $M$ may trigger new edges. **\[KNOWN RESULT\]** Spectral graph theory (Laplacian eigenvalues) is the tool for diffusion and consensus on the network *\[GI ref. 4\]*.

### 2.7 The coupled geometry equation and the three couplings *\[GI §4\]*

**\[SETUP\]** *Geometry $\leftrightarrow$ agents.* The travel cost between $x_i$ and $x_j$ is a function of the geodesic distance $d_g(x_i,x_j)$ and of the curvature along the path; curvature creates “obstacles” (narrow passageways). Conversely each agent sources or sinks curvature and field values through a Dirac mass at its position, $$\tag{2.8}
  tial_t g = -2\,\operatorname{Ric}(g) + \kappa\sum_{i}\delta_{x_i(t)},\qquad
  tial_t\phi = D\,\Delta_g\phi + S\big(\phi,\{x_i\}\big),$$ i.e. (2.3) with $\alpha T_{\rm agents}=\kappa\sum_i\delta_{x_i}$ and (2.1) with reaction term $S$ (the source uses $\kappa$ both here and for the information coefficient $\kappa_i$; the index tells them apart — editorial).

**\[SETUP\]** *Geometry $\leftrightarrow$ network.* Linking rule $a_{ij}(t)>0$ only if $d_g(x_i,x_j)<R$, or weights decreasing in distance, $w_{ij}\propto f(d_g(x_i,x_j))$; conversely heavily linked paths (agents sharing travel routes) lower the effective distance, mimicking a deformation of the metric. *Agents $\leftrightarrow$ network.* The strategic update $\dot s_i=F_i(s_i,\{s_j:j\in N_i\})$ contains the adjacency explicitly and $\dot a_{ij}$ depends on $s_i,s_j$ through (2.6); a strategic agreement may be “locked” by forming an edge. *Group cooperation (copula).* A group $h$ optimises a joint, typically non-additive utility $U_h(s_h)$ over its combined states; each hyperedge is assigned a parameterised joint utility or consensus strategy, and for a two-agent coalition $U_{ij}(s_i,s_j)$ is a copula linking the marginal utilities, capturing the correlation between the two objectives.

### 2.8 The hybrid extension *\[GI-H; GI-X §Hybrid dynamics\]*

**\[SETUP\]** *\[GI\]* already calls (2.9) a hybrid dynamical system and lets agents jump along geodesics. The extension paper *\[GI-H\]* (*Extended geometric–informational multi-agent system with hybrid frames and complex dynamics*, April 2025) makes the frame itself switchable; the overview *\[GI-X §Hybrid dynamics\]* supplies the market reading and the hybrid-automaton vocabulary *\[GI-X refs. 3, 4\]*.

**Definition 2.6** **(Hybrid frame).** **\[SETUP\]** The system is a hybrid dynamical system on the state space $$\tag{2.10}
  X = M\times S,$$ $M$ the (possibly time-varying) manifold of Definition 2.1 and $S$ a discrete *mode* set indexing frame configurations. Each mode $s\in S$ has its own manifold $M_s$ with its own topology, Riemannian metric $g_s$ and field variables $\phi_s$ (potentials, information functions). In mode $s$ the agents evolve continuously on $M_s$ by the smooth dynamics $$\tag{2.11}
  \dot x = f_s(x,u,t),$$ until an event triggers a jump to a mode $s'\neq s$. At that instant the manifold switches to $M_{s'}$ — the triple $(M_s,g_s,\phi_s)\to(M_{s'},g_{s'},\phi_{s'})$, altering distances and field values — and a reset map reassigns the agent states to the new geometry, $$\tag{2.12}
  x^{+} = \Phi_{s\to s'}\big(x^{-}\big),\qquad \Phi_{s\to s'}:M_s\to M_{s'} .$$

**\[SETUP\]** This is a piecewise-smooth or switching flow on manifolds, formally switched-system theory on manifolds: differential equations on each $M_s$ for the continuous evolution, the jump map for the discrete reconfiguration — the “reset maps” of hybrid automata or the “jump conditions” of impulsive systems *\[GI-H §3\]*. The overview writes the flow split into a field part and an agent part, $$\tag{2.13}
  \dot x_{\mathrm{field}} = F\big(x_{\mathrm{field}},x_{\mathrm{agents}}\big),\qquad
  \dot x_{i,\mathrm{agent}} = f_i\big(x_{i,\mathrm{agent}},u_i,x_{\mathrm{field}}\big),$$ deterministic or stochastic, $u_i$ the control (the source’s typesetting of the second line is broken and is reconstructed here — editorial) *\[GI-X\]*: drift–diffusion of market indicators, physical field laws, an agent moving along a trajectory while accumulating reward or cost, wealth evolving with portfolio value, a robot moving at a velocity.

###### Events and what jumps

**\[SETUP\]** Events are time triggers or threshold crossings *\[GI-H §3\]* (scheduled events or guard conditions in *\[GI-X\]*; earnings, policy and rebalances in *\[FS\]*). A jump may change the *topology* of the frame — a hole created, filled or removed, regions splitting or merging, a change of genus — or its *geometry* abruptly — a metric discontinuity, the appearance of an obstacle. If the topology changes, algebraic topology updates the global invariants; if only the metric changes, the jump is a rescaling $g_s\to g_{s'}$ and distances shift abruptly *\[GI-H §3\]*. Named reset maps: a hole created or filled — $\Phi$ projects each point to its nearest counterpart on the new manifold; a hole removed — $\Phi$ maps its boundary points smoothly onto the new interior region; a region disconnecting — $\Phi$ assigns each agent to the nearest remaining component. In the market reading *\[GI-X\]* the field jumps are a sudden price gap, a regime change in which a new layer or rule activates, a news release that revalues many assets at once; the agent jumps are entering or leaving the market, a strategy-regime switch (“bullish” to “bearish” on a trigger), an abrupt change in holdings from a stop-loss order.

###### Value functions and links at a jump

**\[SETUP\]** A value (cost) function $V_s(x)$ on $M_s$ may become discontinuous under a jump. The rule given is to “carry over” the function, $$\tag{2.14}
  V_{s'}\big(\Phi_{s\to s'}(x)\big) = V_s(x),$$ re-initialising the cost on $M_{s'}$ through $\Phi$; in optimal-control terms this imposes boundary conditions on the value functions at events, after which the agents recompute gradients or policies with the new $V_{s'}$. Informational links rewire likewise: where connectivity depended on geodesic distance in $M_s$ (2.4), the new $M_{s'}$ implies recalculated distances and an updated adjacency, so the network graph is redefined at the jump, as in switching topologies of consensus algorithms *\[GI-H §1, §3\]* — in the words of *\[FS\]*, the reset maps “carry value functions and re-wire network links when topology/metrics change”.

**Example 2.7** **(Bouncing ball; jump diffusion; news event).** **\[KNOWN RESULT\]** The classic hybrid system is the bouncing ball: it falls under gravity (flow) and at impact its velocity reverses sign and shrinks in magnitude (jump) *\[GI-X refs. 19, 20\]*; the financial analogue is a jump-diffusion price model, itself a hybrid system *\[GI-X ref. 21\]*. **\[SETUP\]** The framework extends the jump from one price to the whole frame and all agent states: a news event jumps the field (every agent’s valuation of an asset) and the agents jump to new states — some drop the asset, others buy the dip *\[GI-X\]*.

#### 2.8.1 Discrete modes and guards *\[GI-H §1, §3; GI-X\]*

**Definition 2.8** **(Hybrid automaton).** **\[KNOWN RESULT\]** The overall system is a hybrid automaton with (1) continuous state variables (field and agent continuous states), (2) discrete modes (agent modes and field modes), (3) a flow function for each mode, (4) invariant conditions for the flows, (5) jump or reset maps, (6) guard conditions for the jumps *\[GI-X ref. 18\]*; a discrete mode variable tracks which dynamics are active *\[GI-X ref. 17\]*.

**\[SETUP\]** In *\[GI-H\]* the discrete states are the mode set $S$ of (2.10), the flow functions the $f_s$ of (2.11), the reset maps the $\Phi_{s\to s'}$ of (2.12), the guards the time triggers and threshold crossings; the agents’ own strategy modes of *\[GI-X\]* are further discrete coordinates. *Execution:* the system flows while the invariants hold; when a guard is met (a field threshold crossed, a scheduled time reached) a jump updates the states instantly and possibly switches mode. *Multi-timescale:* fast flows and slow jumps (or the reverse) coexist — high-frequency price oscillations are flows, low-frequency regime changes (bull to bear) jumps; an agent has fast control loops (continuous trading) and slow decision updates (a daily rebalancing jump); one strategy layer runs continuously at microsecond scale (market making) while another triggers discrete position shifts on daily news *\[GI-X ref. 22\]*. The implementation uses a small-step integrator plus an event queue (Listing 3.1); *\[FS\]* works in discrete time throughout, the jumps switching “modes”. **\[HYPOTHESIS\]** *\[GI-X\]* asserts that hybrid-control tools (stability analysis, verification) apply to the agent–field system, *\[GI-H\]* that stability analysis for complex switched systems covers its complex-valued agents; neither carries such an analysis out.

#### 2.8.2 Complex and composite states *\[GI-H §1–§2; GI-X §Complex states\]*

**\[SETUP\]** *Composite states.* Agent states are composite and variable: coordinates are appended on joining a group (a membership index) or entering a region (a local-field variable), $s_i\in S_i(t)$ *\[GI §2\]*; the mode $s\in S$ of (2.10) is a further discrete coordinate; *\[FS\]* lets the utilities and constraints on the agents graph “be extended to complex-valued states when phase/reliability matters”.

**Definition 2.9** **(Complex-valued states).** **\[SETUP\]** Each agent state $x_i$ may lie in $\mathbb{C}^n$ or on a complex manifold (a Riemann surface, say, as configuration space), with dynamics given by complex-valued differential equations, $$\tag{2.15}
  \dot z = F(z,u),\qquad z\in\mathbb{C},$$ capturing amplitude and phase at once; equivalently $x=a+ib$ is split into two real layers $(a,b)$ with coupled dynamics. Utility functions, coupling matrices and fields may be complex-valued. Real flows thus become complex flows, differentiated by Wirtinger calculus so that the flow on $\mathbb{C}^n$ or on the complex manifold is well defined *\[GI-H §1–§2\]*.

**\[SETUP\]** Three readings of $z=x+iy$ are given *\[GI-H §2\]*: *phase-coded* — $\arg z$ a phase, $\lvert z\rvert$ an amplitude or reliability (amplitude and phase of a signal, or a primary value $x$ and a secondary “polarity” $y$); *two-layer* — $\Re z$ and $\Im z$ as parallel real states with coupling; *quantum-like* — $z$ a probability amplitude in a simplified quantum model of decision-making. Agents process such states by complex algebra, splitting real and imaginary parts or operating on $z$ directly; an update rule may use complex back-propagation, each agent running a small complex-valued neural network (CVNN) on $(\Re z,\Im z)$ so that phase information is learned and propagated; complex utilities or couplings then handle interference and oscillatory synchronisation. **\[KNOWN RESULT\]** Directed complex-valued multi-agent systems (DCVMASs) have been studied in containment and consensus problems with time delays and attacks — complex agent states, control laws driving all agents to the convex hull of the leaders in the complex plane, observer states and stability analysis for complex switched systems — and CVNNs succeed on “wave-typed” and frequency-domain tasks *\[GI-H §2; no citation given there\]*.

**\[SETUP\]** The overview’s version is the phase-coded reading with a quantum gloss: the agent state as a wavefunction $$\tag{2.16}
  \Psi = A\,e^{i\theta},$$ magnitude $A$ = confidence or intensity, phase $\theta$ = timing or cyclical alignment; in finance the real part the observable state, the imaginary part hidden momentum or cyclical factors, or the pair modelling oscillatory decision-making; interference and oscillation, a “superposition of intentions” or of strategies with a phase relation, probabilistic and oscillatory dynamics mirroring quantum-like behaviour *\[GI-X ref. 5\]*. As a tool: position and momentum combine into one complex dimension; complex eigenvalues mark oscillatory modes (oscillatory trading, seasonal cycles); a normalised complex state space carries extra structure (complex projective space); outputs (actions, realised profits) remain real *\[GI-X\]*. **\[KNOWN RESULT\]** Quantum finance applies quantum-mechanical models to financial theory *\[GI-X ref. 8\]*, and the Black–Scholes equation has been related to a Schrödinger equation *\[GI-X ref. 9\]*. **\[HYPOTHESIS\]** *\[GI-X\]* calls the approach “speculative”; that complex states capture phase-dependent phenomena in multi-agent systems is untested in all three sources.

### 2.9 Analysis tools stated in the source *\[GI §5–§7\]*

**\[SETUP\]** The source names, without applying any of them, the tools that fit each layer (Table 2.1); the least-action and HJB formulation is developed in the overview (Section 3.3 and Section 3.5). **\[OPEN\]** As “new analytical results” it lists the existence of equilibria on curved spaces and stability under network change *\[GI §8\]*; neither is attempted.

**Table 2.1.** (continued)

| Tool | What the source says it would do | Layer |
|---|---|---|
| Tool | What the source says it would do | Layer |
| Equilibria and stability | Nash equilibria of the game; Lyapunov functions; eigenvalue analysis of the coupled ODE/PDE | agents + fields |
| Spectral graph theory | Laplacian eigenvalues for diffusion and consensus *\[GI ref. 4\]* | network |
| Geometric analysis | curvature bounds, geodesic convexity | manifold |
| Mean-field limit | $N\to\infty$: PDEs for the density $\rho(x,t)$, HJB/Fokker–Planck, mean-field games on manifolds *\[GI ref. 7\]* | agents $\to$ field |
| Variational principle | a global cost functional with geometry terms and agent utilities; study its descent | whole system |
| Fibre bundle view | base $M$; fibre over $x$ = the agents at or near $x$ with their connection subgraph; base and fibre evolve coupled | manifold + network |
| Manifold of networks | the space of adjacency matrices on $N$ nodes as a manifold on which $A(t)$ evolves; product with $(M,g)$; network geometry *\[GI ref. 2\]* | network |
| Higher-order networks | simplicial complexes beyond hypergraphs | network |
| Algebraic topology | persistent homology for evolving coverage holes in $M$; cohomology and bundle theory for the network–topology interplay | manifold + network |
| Game-theoretic generalisations | differential games, replicator dynamics, evolutionary games on networks; a mean-field game on $M$ with density and value-function PDEs *\[GI ref. 7\]* | agents |
| Information geometry | an information manifold of distributions of agent states or network configurations; Fisher information metric and divergences quantify information flow | network + agents |

### 2.10 The simulation framework in five steps *\[GI §6\]*

**\[SETUP\]** The source’s recipe combines agent-based modelling with numerical PDE solvers on manifolds and network-evolution algorithms:

1.  *Discretise the manifold.* Represent $M$ by a mesh or coordinate grid; compute the discrete metric, Laplacian and curvature by finite elements or finite differences.

2.  *Represent the field.* Initialise $\phi_k$ on the mesh; time-step (2.1) by implicit Euler or splitting schemes, with the agent feedback.

3.  *Track agents.* Keep an array of agent states; integrate $\dot x_i=v_i$ along the mesh and the other components of (2.5) with an ODE integrator (Runge–Kutta); compute decisions by gradient descent or a game-theoretic solver at each step.

4.  *Update the network.* Apply the linking rules (2.4), (2.6) to add or remove edges in a dynamic adjacency list; update edge attributes; propagate information by a diffusion step with $L=D-A$, (2.7).

5.  *Loop.* Update $(g,\phi)$, then the agents, then the network, keeping consistency (agent motion on $M$ uses the latest geometry).

Implementation: a PDE library for geometry and fields, a graph library for the dynamic network, an agent-based platform for the agents; for large $N$ the continuum approximation, a density $\rho(x,t)$ with a continuity or Fokker–Planck equation coupled to the geometry *\[GI ref. 7\]*. The overview’s loop (Listing 3.1) is this recipe with the event queue of Section 2.8.1 inserted.

### 2.11 Application domains named *\[GI §8\]*

**\[SETUP\]** The source instantiates the layers in seven domains (Table 2.2); none is worked out. **\[KNOWN RESULT\]** Multi-agent systems have been applied to online trading, disaster response, surveillance and social modelling *\[GI ref. 8\]*. **\[HYPOTHESIS\]** The source’s own summary — the framework “generalizes known structures (Riemannian geometry, dynamic networks, multi-agent games) into a unified setting” and provides “both a precise mathematical model and a simulation platform” — is a claim; the platform half awaits the code of Section 3.7.

**Table 2.2.** (continued)

| Domain | Manifold $M$ / field $\phi$ | Network $G$ | Cost, groups |
|---|---|---|---|
| Domain | Manifold $M$ / field $\phi$ | Network $G$ | Cost, groups |
| Social and economic | geographic region (a city map) | social or communication overlay; multilayer ties (family, work, online) | trade: minimise cost, maximise profit under spatial constraints |
| Robotics and swarms | terrain; obstacles and curvature set the motion cost | ad-hoc wireless network carrying shared maps and tasks | cooperative games for coverage or target search |
| Epidemiology and mobility | spatial region; travel time sets physical contact rates | contact network for disease spread | vaccination strategies as agent utilities |
| Ecology | landscape; resources $\phi(x)$ | social or predator–prey networks | compete for (cost) or share (cooperate) resources |
| Transportation | road surface; spatial road graph | traffic-information network (V2V) | travel time; car-following coalitions |
| Computational biology | curved membrane; chemical diffusion | cell–cell signalling network | resource use; clusters |
| Distributed computing | metric space of latency distances | communication overlay | latency and throughput |

### 2.12 Status *\[GI, GI-H\]*

**Table 2.3.** (continued)

| Statement | Tag | Where tested |
|---|---|---|
| Statement | Tag | Where tested |
| Frame $(M,g(t),\{\phi_k\})$, agent state, $W(t)$, $G(t)$ (Definition 2.1, Definition 2.3, Definition 2.4 and Definition 2.5) | **\[SETUP\]** | definitions; not testable as such |
| Ricci flow (2.2); Laplacian $L=D-A$; multilayer networks; Sklar’s theorem; hybrid automaton; bouncing ball, jump diffusion | **\[KNOWN RESULT\]** | quoted, GI refs. 1, 4–6, GI-X refs. 17–21 |
| Field diffusion (2.1); sourced Ricci flow (2.3), (2.8) | **\[SETUP\]** | no simulation in the source |
| Agent ODE (2.5); edge law (2.6); belief diffusion (2.7); the full system (2.9) | **\[SETUP\]** | market instance in Part III and Part IV |
| Hybrid frame $X=M\times S$ (2.10); mode flows (2.11); reset map (2.12); carry-over (2.14); link rewiring *\[GI-H\]* | **\[SETUP\]** | regime/jump handling in Part III |
| Complex flows (2.15), three readings of $z$, CVNN agents *\[GI-H\]* | **\[SETUP\]** | no simulation in the source |
| DCVMAS consensus/containment results; CVNNs on frequency-domain tasks | **\[KNOWN RESULT\]** | cited without reference in *\[GI-H §2\]* |
| Complex states (2.16) capture phase-dependent phenomena | **\[HYPOTHESIS\]** | untested; “speculative” in *\[GI-X\]* |
| Hybrid-control stability and verification apply; complex switched-system stability applies | **\[HYPOTHESIS\]** | untested |
| Existence of equilibria on curved spaces; stability under network change | **\[OPEN\]** | not attempted |
| Five-step simulation recipe (Section 2.10) | **\[PLAN\]** | no code in the source |

## Chapter 3: The extended overview *\[GI-X\]*

> **What this chapter establishes**
>
> The overview *\[GI-X\]* restates the frame of Chapter 2 in the language of markets — the field is a landscape of value layers, traders are agents moving on it — and adds what the first source leaves implicit: the agent’s objective as a cost functional (3.1); the field as a potential driven by the agent density (3.3); optimality as a least-action principle whose coupled form is the mean-field-game system (3.4); the information layer as consensus coupling; a modular simulation loop with an event queue (Listing 3.1); learning rules, calibration and a phased plan with two analytical benchmarks. It is a conceptual document: every statement is a modelling choice, a quoted result or an untested claim.

### 3.1 The field as a layered landscape *\[GI-X §Field structure\]*

**\[SETUP\]** The field is the manifold of Definition 2.1 read as a landscape with peaks and valleys: curvature represents how values or costs change across it *\[GI-X ref. 1\]*; a point is a state (an asset’s price and other attributes); gradient and curvature at the point say how steep or favourable the environment is in each direction. The manifold carries *layers*, variables stacked on the same manifold of asset states — fundamental value, market sentiment, volatility *\[GI-X ref. 2\]*; *\[FS\]* fixes the order used in Part III, fundamental $\to$ financial conditions $\to$ information/sentiment $\to$ interaction/price, the gaps between layers diagnosing sentiment, liquidity and mispricing. Between events the field changes continuously (diffusion, price drift); at instants it jumps (shocks, regime shifts, crashes, policy changes): the flow and jump maps of Section 2.8.

### 3.2 Agent attributes and the coupling structure *\[GI-X §Agent definition\]*

**\[SETUP\]** An agent is an autonomous decision-making entity (trader, robot, participant) on the field; its attributes refine Definition 2.3.

- *State variables*: position on the field (which asset or location; velocity or momentum across it), internal features (capital, strategy parameters), some components complex-valued (Section 2.8.2).

- *Actions and control*: continuous (a direction of motion, a portfolio allocation) or discrete (switching strategy mode, entering or exiting a market); the action set is the agent’s control authority.

- *Cost/value function* $J$, (3.1): running plus terminal cost over a horizon, depending on trajectory, actions, field state and other agents — distance travelled (effort) plus the “height” of the field (price paid, risk endured) along the path; high curvature or a steep gradient costs more.

- *Strategy/policy* $\pi(a\,|\,s)$ from states and available information to a distribution over actions; deterministic or stochastic, fixed or learned (reinforcement learning); the goal is the control path that extremises the objective functional.

- *Information coefficient*: a scalar for the agent’s information advantage, e.g. the correlation between its private signals and actual outcomes (**\[KNOWN RESULT\]** the information coefficient of quantitative finance measures an alpha model’s predictive correlation *\[GI-X ref. 6\]*); it modulates cost or strategy (better information, lower cost) and the agent’s influence on others, and is the $\kappa_i$ of Definition 2.3.

- *Coupling structure*: (1) coupled cost terms (competition for one resource, crowding; in mean-field games every cost depends on the aggregate distribution *\[GI-X ref. 7\]*); (2) coupled dynamics (collisions, influence fields; one agent’s trades move the price field for the others); (3) information coupling through the network (Section 3.6). A coupling matrix $C_{ij}$ weights how agent $j$’s action enters agent $i$’s cost — fully cooperative (shared cost or reward), adversarial (one’s gain is another’s loss) or mixed; on the cost side $C_{ij}$ plays the role of $w_{ij}$ in (2.4).

### 3.3 The cost functional *\[GI-X §Variational principles\]*

**\[SETUP\]** Agent $i$ chooses a trajectory $x_i(t)$ and a control $u_i(t)$ that minimise $$\tag{3.1}
  J_i=\int_{t_0}^{T} L_i\big(x_i(t),u_i(t),t\big)\,\mathrm{d}t+\Phi_i\big(x_i(T)\big),$$ $L_i$ the running cost (Lagrangian), $\Phi_i$ the terminal cost. The field enters through $L_i$ (or the agent’s Hamiltonian); the named instance is $$\tag{3.2}
  L(x,u,t)=f(x)+\tfrac{1}{2}\lvert u\rvert^2,$$ $f$ a field-dependent cost (large on hills, small in valleys), $\tfrac{1}{2}|u|^2$ the control effort; the optimal policy moves toward valleys along a steepest-descent or geodesic path. Equivalently a Riemannian metric weighted by the field makes “distance” cumulative cost, and a cost-minimising agent travels along its geodesics. **\[KNOWN RESULT\]** The necessary conditions for (3.1) are the Euler–Lagrange equations, or Pontryagin’s minimum principle with Hamiltonian dynamics for state and costate; the Hamilton–Jacobi–Bellman equation of control is the analogue of the Hamilton–Jacobi equation of mechanics, and solving it gives the value function, the minimised action *\[GI-X ref. 23\]*.

### 3.4 The field PDE and the field–agent loop *\[GI-X §Field–agent interaction\]*

**\[SETUP\]** *Field on agents.* The field is a potential, a scalar $V(x)$ (value or cost intensity at $x$): an agent is drawn downhill in $V$ and away from high-curvature regions that signal instability or risk; gradient and curvature guide optimal movement *\[GI-X ref. 10\]*. In a market a steep gradient of the price field is a strong trend, prompting trend-following (with the gradient) or contrarian action (against it); a bowl-shaped region (local minimum of cost) is a basin in which it is optimal to stay — an equilibrium price. **\[KNOWN RESULT\]** This is the potential-field method of robotics: obstacles carry high potential, goals low *\[GI-X ref. 11\]*.

**\[SETUP\]** *Agents on the field.* Collective action modifies the field (many buyers push the price field up); the field obeys a PDE with a source term from the agent density, $$\tag{3.3}
  tial_t V(x,t)=D\,\Delta V(x,t)+G\big(m(x,t)\big),$$ $m(x,t)$ the agent density, $D$ a diffusion coefficient, $G$ an influence function (raising $V$ under excess demand) — (2.1) with $V\equiv\phi$, $m\equiv\rho$, $G\equiv f$ and the flat Laplacian for $\Delta_g$ (editorial identification). **\[KNOWN RESULT\]** The coupling is that of mean-field games: Lasry and Lions’ theory yields a Hamilton–Jacobi–Bellman equation for the agent’s value function, containing $m$, and a Fokker–Planck (continuity) equation for $m$, containing the drift of the HJB-optimal agents *\[GI-X refs. 12, 7\]*; the consistent coupling is a Nash equilibrium. **\[SETUP\]** In words: an agent “reads” the field to act, the collective movement reshapes the field, which feeds back — particles in a potential that the particles themselves generate.

**Example 3.1** **(The order book as a liquidity field).** **\[SETUP\]** The order book is a field of liquidity: traders see gaps or liquidity hills and place orders accordingly; the orders change the landscape (filling gaps, creating new ones). The framework treats order-book depth as part of the field and orders as field modifications *\[GI-X\]*; the worked market versions are in Part III and Part IV (editorial pointer).

### 3.5 The action principle *\[GI-X §Variational principles\]*

**\[SETUP\]** Agents — and the field, if it optimises a potential — follow variational principles as in classical mechanics: the chosen trajectory makes the action, the cumulative cost (3.1), stationary. For one agent on a line with Lagrangian $L=\tfrac{1}{2} m\dot x^2-V(x)$, $V$ a field potential (the cost of being at $x$), $$\tag{3.4}
  \delta J_i[x_i,u_i]=0
  \quad\Longrightarrow\quad
  m\ddot x+V'(x)=0\qquad\big(L=\tfrac{1}{2} m\dot x^2-V(x)\big),$$ so the agent accelerates toward decreasing $V$ — with $V$ minus a utility, toward increasing utility. With many agents and a $V$ that evolves with their distribution, the coupled Euler–Lagrange or Hamilton equations recover the mean-field-game PDEs in the continuum limit: the HJB equation is the stationarity of each agent’s action, the Fokker–Planck equation the consistency of the distribution *\[GI-X refs. 12, 7\]*; optimal policies are stationary points of an action *\[GI-X ref. 23\]*.

**\[SETUP\]** *Coupled problems.* With several agents the optimality concept is an equilibrium (Nash) or a social optimum. **\[KNOWN RESULT\]** A *potential* mean-field game derives from one potential functional that all agents collectively minimise *\[GI-X ref. 24\]*. **\[SETUP\]** Otherwise each agent solves its own calculus-of-variations problem, coupled through the field; the field may itself minimise an energy functional given boundary conditions; in cooperative settings or a planner’s problem agents and field derive from one unified action, in competitive settings each agent optimises given the others; in both the first variation of a path vanishes at the optimum, giving adjoint equations.

**\[SETUP\]** *Link to classical mechanics.* Agent state $\leftrightarrow$ generalised coordinate; action integral $\leftrightarrow$ physical action; cost $\leftrightarrow$ Lagrangian (negative utility); field $\leftrightarrow$ potential-energy landscape. **\[HYPOTHESIS\]** Noether’s theorem “might conceptually” apply: a symmetry of the cost yields a conserved quantity — without explicit time dependence the value function is time-invariant along optimal trajectories apart from discounting. **\[KNOWN RESULT\]** Financial and economic processes have been framed in Lagrangian terms, e.g. volatility as a field with physics-like equations of motion *\[GI-X ref. 25\]*; the Hamiltonian form suits numerics and the path-integral analogy. **\[PLAN\]** Uses named: path-integral methods to compute optimal controls; variational reinforcement learning that parameterises a policy and extremises a performance functional; the principle as a check that the coupled equations arise from a coherent objective rather than ad hoc.

### 3.6 The information layer: protocols, coalitions, consensus *\[GI-X §Information layer\]*

**\[SETUP\]** The information layer is the graph $G$ of Definition 2.5 read as the localised or private channels, against the field as the global medium (prices visible to all). An edge from $A$ to $B$ with weight $w$ — the information coupling coefficient, the strength or reliability of the link — means that $B$’s decision rule incorporates $A$’s action with influence $w$; the weights form the coupling matrix (adjacency) in the state updates or costs, encoding one trader mimicking another (leader–follower) or an informational advantage whose actions disseminate new information *\[GI-X refs. 13, 14\]*. Four aspects:

- *Communication protocols.* What is broadcast to neighbours (posted prices, quotes, signals) and the topology (complete graph, small-world, clusters). **\[SETUP\]** A fully connected network is the classical efficient-market assumption, all agents sharing information instantly (common knowledge); a sparse or modular network allows information asymmetry and clusters with shared beliefs not known to others.

- *Group dynamics and coalitions.* Communities are explicit teams optimising a joint cost or emergent herding; a group with a shared value function is a meta-agent; agents with nearly identical costs and strong internal communication form one cohesive sub-system (institutional investors vs. retail traders).

- *Coupling matrices.* $W$ for weights, $L$ for the Laplacian; a consensus interaction adds $-\sum_j W_{ij}(x_i-x_j)$ to agent $i$’s dynamics, pulling its state toward its neighbours’ average — (2.7) — for a shared estimate of value or converging price expectations *\[GI-X refs. 15, 16\]*. **\[KNOWN RESULT\]** The algebraic connectivity (Laplacian eigenvalues) sets how fast consensus emerges *\[GI-X ref. 16\]*.

- *Shared cost structures.* Agents sharing part of their cost (a team of trading bots minimising a collective risk) form a distributed-optimisation problem with a common cost component (team mean-field games, cooperative control); in fully competitive settings the layer serves exploitation — high-frequency agents watching others’ orders to react first.

**\[HYPOTHESIS\]** Asserted without test: rapid information sharing dampens arbitrage opportunities; information silos lead to non-equilibrium behaviour or arbitrage pockets; the layer carries information cascades, gossip networks and leader–follower dynamics. The implicit coupling through the field (prices) and the explicit one through the graph together determine the system’s behaviour.

### 3.7 The computational loop *\[GI-X §Computational implementation\]*

**\[SETUP\]** *Modular architecture.* Five modules: a *field module* (grid or mesh; finite differences or finite elements update the field each step, manage the layers, compute gradient and curvature); an *agent module* (object- or data-oriented, synchronous or asynchronous, vectorised where agents share dynamics; each agent queries the field module for local values and the information module for neighbour states); an *information/network module* (adjacency list with message broadcast, up to a communication-protocol simulation; NetworkX, or graph neural networks for learned communication); an *event scheduler* or hybrid manager (a discrete-event loop over the time-stepped simulation: a priority queue of next event times — next news arrival, next strategy switch — whose handlers execute the jump (2.12) in the field and agent modules); a *learning/optimisation module* (training loops, exploration–exploitation scheduling, policy updates; Stable Baselines or RLlib with the field simulation as environment).

```
initialize field_state, agent_states, t = 0
event_list = initialize_events() # scheduled jumps
while t < T_final:
    dt = get_time_step(t, next_event_time)
    # Continuous evolution
    field_state = field_state + field_dynamics(field_state, agent_states)*dt
    for each agent in agents:
        obs_field = field_module.sense(agent.position)
        obs_neighbors = info_module.get_neighbors_state(agent.id)
        action = agent.policy(obs_field, obs_neighbors)       # decide action
        agent.state = agent.state + agent.dynamics(action, field_state)*dt # evolve agent
    t = t + dt
    # Check for events
    if t >= next_event_time:
        event = event_list.pop()    # get the scheduled event
        execute_event(event, field_state, agent_states) # apply jump changes
        update next_event_time from event_list
```

**\[SETUP\]** The loop is explicit Euler for field and agents with the step chosen so that events are hit exactly; adaptive time-stepping is needed if the field equations are stiff or if high- and low-frequency dynamics must be balanced. It is the five-step recipe of Section 2.10 with the event queue inserted; *\[FS\]* gives the same step in market terms — update data and features, propagate value across the graph (diffusion plus source terms), update agent states, close the feedback loop.

### 3.8 Learning rules *\[GI-X §Computational implementation, §Future directions\]*

**\[PLAN\]** *Reinforcement learning.* Agents learn policies by value-based or policy-gradient methods, the simulator returning rewards (negative costs) each step; offline in simulation (strategies that transfer) or online during the run. Multi-agent algorithms named: independent Q-learning, MADDPG, QMIX, by competitive vs. cooperative setting; against the dimensionality and non-stationarity of many learners, mean-field multi-agent RL and curriculum learning; deep policies take the geometry as input — graph neural networks for the information layer, CNNs or mesh-based networks for the field.

**\[PLAN\]** *Hierarchical (multi-scale) control* *\[GI-X ref. 22\]*. A high-level policy sets a slow-changing objective or mode (“momentum trading today” vs. “mean reversion”); a low-level policy, possibly another RL agent, optimises minute-to-minute actions in that style; the levels run on a coarse and a fine time grid, synchronised occasionally, with reward shaping or constraints so that the fast layer does not ignore the slow layer’s intent. (*\[FS\]*’s business-level controller — multi-objective OR plus hierarchical RL passing targets and limits down and KPIs back up — is the top of this hierarchy; Part VII — editorial pointer.)

**\[OPEN\]** *Uncertainty and Bayesian learning.* The framework as stated is model-driven; the extension named is uncertainty quantification — field dynamics with random coefficients, agent beliefs updated by Bayesian learning, agents that start without knowing the shape of the field or payoff landscape and learn it from observations (bandit or Bayesian RL embedded in the geometric field). This adds an information state per agent, treatable as part of the complex state or as an additional field, implemented by particle filters or belief-state updates, or approximated by neural networks predicting the field.

### 3.9 Numerical scheme, calibration and performance *\[GI-X §Computational implementation\]*

**\[PLAN\]** *Calibration and validation.* Match moments of the simulation output to historical data (simulated vs. real return distribution; simulated vs. empirical agent wealth distribution); many runs with an optimiser over the parameters; approximate Bayesian computation (ABC) or ensemble Kalman filters treating the simulator as a generative model. *\[GI-X §Future directions\]* restates this as an inverse problem, or as RL in which the model parameters are the “policy” tuned until simulated output matches reality, after a sensitivity analysis of which parameters (field curvature, network connectivity, …) move the outcomes. *\[FS\]* names the reported metrics: RMSE/CRPS for statistical calibration; PnL, Sharpe/Sortino, drawdown, CVaR for economic performance; ablations by layer, engine and jump modelling.

**\[PLAN\]** *Performance.* Vectorised operations and GPUs (all agent updates in a batch); within a step the agent updates are embarrassingly parallel given field and neighbour information, so agents distribute across cores or nodes; optimised PDE libraries (PETSc) and model reduction for the field; very frequent jumps approximated by an equivalent diffusion; for huge $N$ a mean-field approximation evolving a distribution instead of every agent; for a huge state space Monte Carlo agents sampling the field effect instead of discretising the whole field.

**\[PLAN\]** *Tooling and scale.* HyEQ (MATLAB/Simulink) for hybrid equations; Mesa (Python), Repast or custom Python/C++ for agent-based simulation; OpenAI-Gym-style environments for RL; visualisation (the field as a changing heat-map with agents as moving points, network animations). Start simple — a 1D field and a handful of agents — and add dimensions, agents and realism one at a time, verifying each addition, so that the result is a laboratory in which hypotheses about agent behaviour or field structure are toggled and their effects observed. Scale: containerise and run on a cluster or cloud with distributed libraries (a market with 10,000 agents; many scenarios in parallel); publish as an open-source platform with pluggable decision models (behavioural biases) and field dynamics (climate models) *\[GI-X §Future directions\]*.

### 3.10 Information geometry and the other mathematical connections *\[GI-X §Mathematical connections\]*

###### Differential geometry

**\[HYPOTHESIS\]** Curvature in a market manifold may indicate instability or arbitrage: regions where small moves cause large changes in cost. **\[SETUP\]** The manifold formulation is coordinate-independent. *Information geometry*: the distribution of agents or of signals is a point on a statistical manifold, so distances or divergences between the information states of agents are defined, and an information metric can be chosen under which the shortest path in information space is the most efficient route to informational consensus; with the Fisher information metric and divergences of Table 2.1 this is all the sources say — no entropy term is written in any of them (editorial note). **\[KNOWN RESULT\]** Information geometry has been applied to dynamics on graphs and hypergraphs (dual structures, gradient flows) *\[GI-X refs. 26, 27\]*.

###### Quantum dynamics

**\[SETUP\]** Complex states (Section 2.8.2) and the least-action form parallel the path-integral formulation (Feynman’s sum over exponentiated action); linearised dynamics may yield Schrödinger-type equations, as Black–Scholes does *\[GI-X ref. 9\]*; an agent’s probability of being in a state could evolve like a wavefunction under the field’s forces, and complex strategy amplitudes could hold superposed strategies that “collapse” to an action only when needed. **\[KNOWN RESULT\]** Quantum game theory admits superposed strategies *\[GI-X ref. 28\]*; quantum agent-based models and quantum reinforcement learning are being explored, with possible speed-ups on quantum hardware *\[GI-X refs. 5, 29\]*. **\[HYPOTHESIS\]** Entanglement is loosely analogous to agents whose strategies are correlated through the information network beyond classical correlation; the source stresses that these are analogies, not literal quantum behaviour.

###### Game theory and mean-field games

**\[KNOWN RESULT\]** Mean-field game theory treats games with many agents through aggregate effects, with existence and characterisation of equilibria by the coupled HJB–Fokker–Planck system *\[GI-X refs. 30, 12, 7\]*. **\[SETUP\]** The framework is an MFG generalised in three ways — complex states, an explicit information network (breaking the symmetric, anonymous interaction of the mean field), hybrid dynamics — and, with few agents, a differential game in a geometric space. Nash equilibria, Pareto optima, network games and cooperative game theory for coalitions apply; equilibrium conditions come from PDEs or variational inequalities derived from each agent’s first-order conditions.

###### Partial differential equations

**\[SETUP\]** The continuum limit gives HJB–FP; without it a density of agents still has an evolution equation; the field obeys heat- or wave-type PDEs — for a price distribution across assets, a diffusion term (random fluctuations) plus a drift from excess demand; information flow is a graph PDE/ODE (the heat equation on the graph Laplacian, (2.7)); the swarm of agents is a fluid with continuity equations, whose optimal control has Eulerian and optimal-transport (Wasserstein) readings; the hybrid part gives switching PDEs or free boundaries at mode changes. Families named: Hamilton–Jacobi (value functions), Fokker–Planck/Kolmogorov forward (densities), reaction–diffusion (non-linear interaction sources), jump conditions (boundary or initial conditions reset at events); they answer whether a steady-state agent distribution exists and is stable. **\[KNOWN RESULT\]** The MFG-PDE literature informs calibration and solution *\[GI-X refs. 31, 32\]*.

### 3.11 Examples and application areas *\[GI-X §Applications\]*

**\[SETUP\]** Five application areas (Table 3.1); all describe what a calibrated model would do, none is run. **\[KNOWN RESULT\]** Agent-based modelling is an established tool for market complexity (heterogeneity, interaction rules, adaptation) *\[GI-X refs. 34, 36\]* and for volatility dynamics, liquidity crises and bubble formation *\[GI-X ref. 33\]*. **\[HYPOTHESIS\]** Asserted strengths: feedback loops and emergent, out-of-equilibrium phenomena — a slight policy change propagating through agent decisions to reshape the field; one agent with a high information coefficient causing a cascade; flash crashes, which diffusive models miss; coordination of autonomous systems without central control. **\[PLAN\]** Adoption path: calibrate to known incidents or patterns, then use the model predictively or prescriptively.

**Table 3.1.** (continued)

| Area | Instantiation and examples in the source |
|---|---|
| Area | Instantiation and examples in the source |
| Quantitative trading and market simulation | a price field over the whole economy (multiple assets, yield curves as fields) instead of one time series; market ecology (value investors, momentum traders, arbitrageurs) as agent types with distinct costs; RL trading agents competing to the Nash equilibrium of a trading mean-field game; stress tests, new regulations or trading rules, multi-horizon strategies tried in the simulator before deployment |
| Portfolio and risk optimisation | field regions = portfolio configurations, height = risk or loss; the agent moves to low-risk, high-return regions; forward-looking indicators in the information field; shocks as field jumps with rebalancing (dynamic asset allocation); systemic risk: institutions as agents, interest rates or default probabilities as field, panic contagion on the network, bank runs and liquidity freezes, a market maker of last resort as stabiliser |
| Hybrid physical–economic systems | smart grid: voltages and frequencies flow by circuit laws, producers, consumers and operators bid and switch sources (discrete), a demand spike = field jump, load shedding = agent action, grid protocols = information layer; autonomous transport: traffic as field, vehicles as agents with time/fuel cost, V2V as information layer, a road closure = field jump, rerouting = agent jump |
| Robotics and swarm intelligence | robots in a physical field they modify (drone turbulence, warehouse configuration), communicating for collision avoidance and task allocation; a variational principle for minimal-energy swarm goals; drones extinguishing a wildfire whose spread is a PDE field |
| Econophysics and policy modelling | farmers choosing crops on fields of soil fertility and price signals; epidemics with infection risk as field and social networks shaping behaviour (COVID-19 as a hybrid system); lockdowns or stimulus payments as discrete events, policies adjusted in simulation |

### 3.12 Open questions and the phased plan *\[GI-X §Future directions\]*

**\[PLAN\]** *Start with simplified models.* A 2D or 3D state space and few agents; real states only; no information layer (all agents see the global state) — an optimal-control or mean-field-game problem in simple geometry with analytical solutions in special cases; then add complex components, the information network and hybrid jumps one at a time, to isolate what each contributes.

**\[OPEN\]** *Analytical benchmarks.* Two special cases to solve exactly and reproduce in code: (a) a one-dimensional static field with identical agents and quadratic cost, whose Nash equilibrium should be derivable explicitly (possibly a known mean-field-game result); (b) a fully connected symmetric information network, under which agents have common information and the outcome should match the mean-field-game solution from PDE theory *\[GI-X ref. 30\]*. Neither is solved in the source.

**\[OPEN\]** *AI for complexity management.* Neural surrogates for the field dynamics or the aggregate agent effect in place of a slow PDE solver; meta-learning for faster agent learning (a learned representation of the field state); large language models or symbolic regression to find simplified descriptions or invariants in simulation logs.

**\[PLAN\]** *Collaboration, dissemination, visualisation.* Control theorists for hybrid stability and existence-of-equilibrium proofs, economists for interpretation, machine-learning experts for calibration and high-dimensional solution; publish parts in domain venues (the geometric view of market agents to a finance journal, hybrid stability to a control conference); interactive tools showing manifold, agents and network synchronised, and a human-in-the-loop run in which a user injects an event (“what if the Fed raises rates by 1% now?”) and watches the agents respond — the source’s closing image is a “virtual sandbox for quantitative research and strategic model-building”.

**\[OPEN\]** *The open questions, collected:* existence of equilibria on curved spaces and stability under network change *\[GI §8\]*; hybrid stability and verification (Section 2.8.1); whether complex states add modelling power (Section 2.8.2); the two benchmarks above; identifiability of the many parameters under calibration (Section 3.9).

### 3.13 Cross-check against the one-page summary *\[FS\]* (editorial)

*\[FS\]* summarises the programme as “a layered market-graph + risk-aware control framework”; Table 3.2 maps each of its components to where it is stated in this Part or worked out later. **\[HYPOTHESIS\]** Its closing claim — that unifying networked state, layered valuation, hybrid dynamics and Bellman-style control “explains and exploits” contagion, volatility clustering and liquidity crises while improving drawdown control and implementation realism — is untested here.

**Table 3.2.** (continued)

| Component | Content as stated in *\[FS\]* | Where |
|---|---|---|
| Component | Content as stated in *\[FS\]* | Where |
| Thesis | assets, agents, information and trading frictions co-evolve; macro conditions and microstructure shape each other through feedback loops | (2.9); Chapter 5 |
| Assets-and-markets knowledge graph | nodes = instruments carrying fundamentals (sector, currency, earnings, credit); edges = listings, index membership, correlations/causal ties, derivative links; carries diffusion/contagion of information and shocks | not in GI/GI-X/GI-H, whose graph has agents as nodes; Chapter 5 and Chapter 9 |
| Agents graph | information sharing, competition, coalitions; utilities and constraints on the graph; complex-valued states when phase/reliability matters | Section 2.6, Section 3.6 and Section 2.8.2 |
| Rule/constraint layer | — | Chapter 5 |
| Multi-layer value surface | fundamental $\to$ financial conditions $\to$ information/sentiment $\to$ interaction/price; layer gaps diagnose sentiment, liquidity, mispricing; discretised over the asset network | Section 3.1; Chapter 4 and Chapter 5 |
| Discrete-time dynamics | update data/features; propagate value (diffusion + source terms); update agents; close the loop | Listing 3.1, (3.3) |
| Hybrid jumps | earnings, policy, rebalances switch modes; reset maps carry value functions and re-wire links | (2.12), (2.14) |
| Decision architecture | Strategy–Prediction–Risk/Validation stack; Bellman control on reward $-$ loss giving $\pi^{*}$ with look-ahead; Stackelberg variants for other agents | Section 3.3; Chapter 4 and Chapter 9 |
| Portfolio and risk engines | forecasting suite (statistical to deep/sequence models and Monte Carlo), regime detectors, risk core (VaR/CVaR, concentration, EVT, scenario what-ifs), guardrails; directives to strategies and execution | Section 3.11; Chapter 24 |
| Microstructure layer | supply–demand and market impact; inventory, imbalance, liquidity shocks feed back into state and risk | Example 3.1; Part III |
| Business-level controller | multi-quarter objectives via multi-objective OR + hierarchical RL; targets and limits down, KPIs back | Section 3.8; Chapter 24 |
| Data, evaluation, outputs | inputs: macro, price/options, depth, news/sentiment; metrics: RMSE/CRPS, PnL, Sharpe/Sortino, drawdown, CVaR; ablations by layer, engine, jump modelling; deliverables: learned value surfaces on the market graph, risk-aware policies with regime/jump handling, reproducible code and backtests across asset classes | Section 3.9; Chapter 25 and Chapter 30 |

###### References the sources cite

*\[GI\]*: 1 Ricci flow (Wikipedia); 2 arXiv:1910.06258, *A simple differential geometry for networks*; 3, 8 Multi-agent system (Wikipedia); 4 Laplacian matrix (Wikipedia); 5, 6 *The structure and dynamics of multilayer networks* (PMC7332224); 7 *Computational mean-field games on manifolds*, arXiv:2206.01622. *\[GI-X\]* (superscripts as in the source): 1, 5, 10, 23, 25, 29, 33, 35 DayTrading.com, *Geometric mechanics in finance*; 2, 22, 37 *Deep thoughts* (the author’s own file); 3, 4, 17–21 Hybrid system (Wikipedia); 6 PyQuant News, the information coefficient; 7, 12, 30 Ryzhik (2018), mean-field game notes; 8, 9 Quantum finance (Wikipedia); 11 Activeloop, potential fields; 13, 14 *Knowledgebase* (the author’s own file); 15 *Coordination of multi-agent systems on interacting physical and …* (Systems & Control Letters); 16 *Adaptive connectivity control in networked multi-agent systems* (PLOS ONE); 24 Benamou, Carlier, Santambrogio, *Variational mean field games*; 26, 27 Kobayashi et al. (2024), *Information geometry of dynamics on graphs and hypergraphs*; 28 Quantum game theory (Wikipedia); 31 *Analysis and numerical approximation of mean field game PDEs* (Oxford); 32 arXiv:1911.09441, analytically solvable mean-field games; 34, 36 SmythOS, agent-based modelling in finance. *\[GI-H\]* gives no reference list (it cites work on complex-valued multi-agent systems and complex-valued neural networks without reference). Listed as the sources give them, not re-verified (editorial).

### 3.14 Status *\[GI-X\]*

**Table 3.3.** (continued)

| Statement | Tag | Where tested |
|---|---|---|
| Statement | Tag | Where tested |
| Layered landscape, agent attributes, $C_{ij}$, policy $\pi(a\|s)$, information coefficient (Section 3.1 and Section 3.2) | **\[SETUP\]** | definitions |
| Cost functional (3.1), running cost (3.2), cost-weighted metric | **\[SETUP\]** | instantiated in Part III and Part IV |
| Field PDE (3.3); field–agent feedback loop; order book as liquidity field | **\[SETUP\]** | Part III; no run in the source |
| Euler–Lagrange/Pontryagin/HJB; Lasry–Lions HJB–FP; potential MFG; algebraic connectivity; potential-field method; IC of quant finance; quantum finance and games; ABM literature | **\[KNOWN RESULT\]** | quoted, GI-X refs. 6, 7, 9, 11, 12, 16, 23, 24, 28–36 |
| Action principle (3.4) and its coupled MFG form | **\[SETUP\]** | not solved in the source |
| Curvature indicates instability or arbitrage; Noether-type conserved quantities | **\[HYPOTHESIS\]** | untested |
| Information sharing dampens arbitrage; silos create arbitrage pockets; cascades, gossip, leader–follower | **\[HYPOTHESIS\]** | untested |
| Entanglement $\approx$ network-correlated strategies | **\[HYPOTHESIS\]** | untested, called an analogy |
| Feedback loops and emergence explain flash crashes, contagion, volatility clustering, liquidity crises *\[GI-X, FS\]* | **\[HYPOTHESIS\]** | untested here; cf. Table 30.2 |
| Simulation loop Listing 3.1; modules; RL and hierarchical control; calibration (moments, ABC, EnKF); performance and tooling | **\[PLAN\]** | no code in the source |
| Benchmarks (1D static quadratic; fully connected network $=$ MFG); AI surrogates; uncertainty and Bayesian learning; equilibria on curved spaces | **\[OPEN\]** | not attempted |

# Part III: The market model

## Chapter 4: Market dynamics model *\[MD-1, MD-2\]*

> **What this chapter establishes**
>
> The two “Initial draft” documents (May 2025) define the abstract environment that every later market model instantiates: a rule set in three tiers, a time-varying graph whose edges are moving objects with state $\Theta_e$, a discretised surface carrying evaluation, propagation and interaction layers, and $N$ agents with states $s_i$, utilities $U_i$ and a stochastic interaction graph $W(t)$. MD-1 writes the discrete-time update equations, the global transition $X(t+1)=T(\cdot)$ and the Bellman equation with its backward-induction algorithm for a fully informed agent. MD-2 contains MD-1 verbatim and adds the reward-minus-loss objective, the Strategy–Prediction–Risk/Validation stack, a graph episodic memory with decay and recall, and the seven-step operating loop. Nothing in either draft is calibrated, simulated or tested; every statement is a modelling choice or a quoted result.

### 4.1 The environment *\[MD-1 §1\]*

**\[SETUP\]** Time is discrete, $t=0,1,2,\dots$ The environment consists of (1) a hierarchy of rules governing dynamics and constraints, (2) a time-varying graph $G(t)=(V,E(t))$ whose edges represent moving objects (“particles”), (3) a discretised geometrical surface (lattice or mesh) on which values and fields evolve in several layers, and (4) a set of agents with states and utility functions. The only difference between the two drafts is that MD-2 reproduces MD-1 (§1–3) word for word and appends §4–8; MD-1 is therefore cited for the environment and the Bellman layer, MD-2 for everything from the reward-minus-loss objective onwards.

**Definition 4.1** **(Rules hierarchy).** **\[SETUP\]** $R=\{r_1,r_2,\dots\}$ is a structured set of rules (invariants, probabilistic transition rules, constraints) at several tiers; each rule $r$ maps conditions on agents, objects or the environment to outcomes, possibly stochastic. *Tier 1* rules enforce conservation laws or feasibility constraints; *Tier 2* rules govern probabilistic state transitions (if event $E$ occurs, the object state updates according to $P(\cdot\mid E)$); *Tier 3* rules define the outcomes of interactions among objects or agents.

**\[KNOWN RESULT\]** Hierarchical rule-based environments of this kind are the declarative rule-based agent models of Lotzmann & Meyer, cited in both drafts and again in WP §5.

###### Object graph

**\[SETUP\]** Nodes of $V$ encode discrete space–time positions (events); an object moving from node $i$ at $t$ to node $j$ at $t+1$ is a directed edge from $(i,t)$ to $(j,t+1)$, so that “nodes = events, edges = particles” as in physical universe graphs (the draft writes “vertice” for edge throughout). $E(t)$ is the edge set at $t$. Each edge $e\in E(t)$ carries a state vector and moves by a displacement $v_e(t)$ that the rules or the physics determine, possibly at random: $$\tag{4.1}
\Theta_e(t)=\bigl(\mathrm{pos}_e(t),\ \mathrm{val}_e(t),\ \tau_e,\ \dots\bigr),\qquad
\mathrm{pos}_e(t+1)=\mathrm{pos}_e(t)+v_e(t),$$ where $\mathrm{pos}_e(t)$ is the spatial position (node location), $\mathrm{val}_e(t)$ the internal value or state and $\tau_e$ the type or category. Edges move, are created or destroyed according to the rules (a collision rule may remove two edges and create one). **\[KNOWN RESULT\]** This is the interaction-network convention in which nodes and edges represent objects and relations.

###### Discretised surface and layers

**\[SETUP\]** The spatial domain is discretised into nodes $i\in V_{\mathrm{space}}$ with coordinates $x_i$ (lattice or triangular mesh). On it live several “information” layers: the *evaluation layer* $E$, a scalar field $E_i(t)$ at each site (local evaluation or utility density: resource levels, reward potential, other signals); the *propagation layer* $P$, a matrix of weights $P_{ij}$ governing how values diffuse between neighbouring sites (a graph Laplacian); and the *interaction layer* $I$, which captures how agents or objects at neighbouring sites interact (collision effects, communication). Together they form a multilayer network on the same nodes. **\[KNOWN RESULT\]** Multilayer networks are a standard tool of complex-systems modelling.

###### Agents

**\[SETUP\]** $A=\{1,\dots,N\}$ is the agent set. Agent $i$ has a state $s_i(t)$ (location on the surface, internal variables) and an action space $A_i$, follows (a) general rules (physical laws, system-wide constraints) and (b) agent-specific rules (strategic preferences, class-based behaviours), and maximises a utility $U_i(t)$ (or minimises a loss $L_i$); agents may act individually or form teams. Influence between agents is a time-varying weighted adjacency $W(t)=[w_{ij}(t)]$ with $w_{ij}(t)$ stochastic and time-varying, each pair $(i,j)$ being a possibly random communication or influence link whose graph may change every step. **\[KNOWN RESULT\]** This is the setting of network game theory and multi-agent dynamic games.

**Remark 4.2** **(Reading of the four components — editorial).** The whitepaper (Chapter 5) keeps all four components and renames them: the object graph becomes the assets-and-markets graph, $W(t)$ becomes the agents graph, the single evaluation layer becomes the four value layers of (4.4), and the three tiers of Definition 4.1 are kept with market content (Section 5.4). Three symbols are overloaded in the drafts and are left as written: $E(t)$ is both the edge set and the evaluation-field vector in (4.4); $A_i$ is both the action space of agent $i$ and, in (4.4), the set $A_i(t)$ of agents at site $i$; and the environment state is $X(t)$ in MD-1 but $S_t$ from MD-2 §4 onwards.

### 4.2 Time-evolving equations *\[MD-1 §2\]*

**\[SETUP\]** The global state at $t$ is $X(t)=(S(t),E(t),s_i(t))$: $S(t)$ all surface-layer values, $E(t)$ all object-edge states, $s_i(t)$ the agent states.

###### Object dynamics

**\[SETUP\]** The state vector of every edge follows a discrete update driven by its own state, its neighbours $e'\sim e$, the surface and noise $\xi_e(t)$, with $f_e$ a possibly nonlinear encoding of the rules: $$\tag{4.2}
\Theta_e(t+1)=f_e\bigl(\Theta_e(t),\ \{\Theta_{e'}(t):e'\sim e\},\ S(\cdot,t),\ \xi_e(t)\bigr).$$ Concretely the internal value grows or decays with the local surface value, $\eta_e(t)$ being noise: $$\tag{4.3}
\mathrm{val}_e(t+1)=\mathrm{val}_e(t)+\Delta t\cdot g_e\bigl(\mathrm{val}_e(t),\ \mathrm{pos}_e(t),\ S(\mathrm{pos}_e(t),t)\bigr)+\eta_e(t).$$ Appearance and disappearance of edges is likewise rule-driven (the collision rule of Section 4.1).

###### Surface (field) dynamics

**\[SETUP\]** With $L$ the discrete (graph) Laplacian of the surface grid, $D$ a diffusion coefficient and $F_{\mathrm{source}}(t)$ the sum of contributions from objects and agents, the evaluation layer diffuses and receives sources; per site, $N(i)$ are the neighbours of $i$, each object $e$ at $i$ injects $\alpha_e(t)$ (a resource deposit) and each agent $k\in A_i(t)$ at $i$ injects $\beta_{i,k}(t)$ (information or consumption). The whitepaper (WP §6) replaces the single evaluation field by four value layers per asset, each arrow meaning “informs or sets a baseline for”; the chain is displayed here once as the third line, with its layer definitions and inter-layer rules in Section 5.5: $$\begin{aligned}
E(t+1)&=E(t)+\Delta t\bigl(DLE(t)+F_{\mathrm{source}}(t)\bigr),\notag\\
E_i(t+1)&=E_i(t)+\Delta t\Bigl[D\!\!\sum_{j\in N(i)}\!\bigl(E_j(t)-E_i(t)\bigr)+\!\!\sum_{e:\,e\text{ at }i}\!\!\alpha_e(t)+\!\!\sum_{k:\,k\in A_i(t)}\!\!\beta_{i,k}(t)\Bigr],\tag{4.4}\\
V^{(\mathrm{fundamental})}(i,t)&\to V^{(\mathrm{financial})}(i,t)\to V^{(\mathrm{info})}(i,t)\to V^{(\mathrm{market})}(i,t)\quad\text{\textit{[WP §6]}}.\notag
\end{aligned}$$ The sum $\sum_j(E_j-E_i)$ is the discrete Laplace operator on the grid; similar equations govern the other layers if needed (propagation weights may adapt). **\[SETUP\]** In the whitepaper’s reading (WP §6) the diffusion term is how a fundamental change at one asset “bleeds” into connected assets at a speed set by the coefficient, and the source terms are agent actions that add value (a government bailout raising many fundamentals at once).

###### Agent dynamics

**\[SETUP\]** Agent $i$ chooses $a_i(t)\in A_i$; its state updates by general and agent-specific rules (position on the surface, wealth from consumed resources captured by $S$) and its utility by an instantaneous reward $r_i$ (the negative of a loss), which covers agent–environment and agent–agent interaction: $$\begin{aligned}
s_i(t+1)&=G_i\bigl(s_i(t),\ S(\cdot,t),\ \{s_j(t)\}_{j\neq i},\ a_i(t),\ \{a_j(t)\}_{j\neq i}\bigr),\tag{4.5}\\
U_i(t+1)&=U_i(t)+r_i\bigl(s_i(t),\ S(\cdot,t),\ a_i(t),\ \{a_j(t)\}_{j\neq i}\bigr),\notag
\end{aligned}$$ where $r_i$ may depend on the weighted neighbour sum $\sum_j w_{ij}(t)s_j(t)$ (communication or influence through the stochastic, time-varying $w_{ij}(t)$).

###### Global transition

**\[SETUP\]** Collecting the above, the state evolves as a generally stochastic dynamical system under $R$, with $\zeta(t)$ the random disturbances: $$\tag{4.6}
X(t+1)=T\bigl(X(t),\ a_1(t),\dots,a_N(t),\ \zeta(t)\bigr),$$ a high-dimensional Markov chain, or a game when several agents choose actions. *(Editorial.)* Equation (4.6) is the drafts’ only statement of market clearing: all agents’ actions enter one transition map simultaneously. The whitepaper decomposes $T$ into the seven-step loop of Section 5.6, in which a Tier-3 matching step sets $V^{(\mathrm{market})}(t+1)$.

### 4.3 Optimal policy of a fully informed agent *\[MD-1 §3; MD-2 §4, §7\]*

**\[SETUP\]** If agent $i$ observes the global state $X(t)$ and knows all rules, its problem is a Markov decision process. Let $V_i(X,t)$ be the maximum expected future utility from state $X$ at time $t$, $\gamma\in(0,1]$ a discount factor ($\gamma=1$ up to horizon $T$ in the undiscounted finite-horizon case), $r_i(X,a_i)$ the immediate reward and the expectation over the next state $X'$ given $(X,a_i)$, the other agents’ actions being folded into the environment or assumed known. MD-2 §4 restates the same condition on an environment state $S_t$ (all agent positions, object states and features on a graph $G=(V,E)$) with known transitions $P(S_{t+1}\mid S_t,A_t)$ and known policies of the other agents, and with the reward written as monetary reward minus monetary loss, $R-L$: $$\begin{aligned}
V_i^{*}(X,t)&=\max_{a_i\in A_i}\Bigl\{r_i(X,a_i)+\gamma\,\mathbb{E}\bigl[V_i^{*}(X',t+1)\bigm| X,a_i\bigr]\Bigr\}\quad\text{\textit{[MD-1 §3]}},\notag\\
V^{*}(s)&=\max_{a}\sum_{s'}P(s'\mid s,a)\bigl[R(s,a,s')-L(s,a,s')+\gamma V^{*}(s')\bigr]\quad\text{\textit{[MD-2 §4]}},\tag{4.7}\\
\pi(s)&=\operatorname*{arg\,max}_a\sum_{s'}P(s'\mid s,a)\bigl[R-L+\gamma V(s')\bigr].\notag
\end{aligned}$$ **\[KNOWN RESULT\]** Equation (4.7) is the discrete-time Bellman optimality condition; it embodies backward induction and its correctness follows from Bellman’s optimality principle.

###### Objective

**\[SETUP\]** With $R_t$, $L_t$ the reward and loss at step $t$ and $0<\gamma\le1$ ($\gamma=1$ for a finite horizon), the agent maximises cumulative monetary reward minus loss; the formal policy of MD-2 §7 is the maximiser of the same functional written along the policy: $$\begin{aligned}
J(\pi)&=\mathbb{E}\Bigl[\sum_{t=0}^{T}\gamma^{t}\,(R_t-L_t)\Bigr],\tag{4.8}\\
\pi^{*}&=\operatorname*{arg\,max}_{\pi}\ \mathbb{E}\Bigl[\sum_{t=0}^{T}\gamma^{t}\bigl(R(S_t,\pi(S_t))-L(S_t,\pi(S_t))\bigr)\Bigr].\notag
\end{aligned}$$ **\[SETUP\]** Because the agent is fully informed the problem is a known MDP, or a leader–follower (Stackelberg) game when the other agents’ responses are considered: the agent is a leader that selects an action anticipating that the followers best-respond, and the expectation in (4.8) is computed exactly, with no exploration uncertainty. All performance is measured in cumulative monetary terms; no higher moment or risk metric beyond the two scalars enters.

###### Dynamic programming

**\[KNOWN RESULT\]** MD-1 solves (4.7) by backward induction (Listing 4.1): at each $t$ and $X$ every action is scored by immediate reward plus discounted expected continuation under $P(X'\mid X,a_i)$, the maximiser is recorded as $\pi(t,X)$ and the maximum as $V[t,X]$; in the infinite-horizon case the Bellman update is iterated to convergence. **\[SETUP\]** The framework and the algorithm are stated to be independent of the particular rules, graph, surface discretisation and utilities, so that the same difference equations and policies apply to physics, economics and game-theoretic domains.

```
Initialize: for all terminal states X, set V[T+1, X] = 0.
For t = T down to 0 do:
    For each possible global state X:
        For each admissible action a_i of agent i:
            Compute immediate reward r = r_i(X, a_i).
            Compute expected next-state value:
                V_next = 0
                for each possible next state X':
                    V_next += P(X' | X, a_i) * V[t+1, X']
            TotalVal = r + gamma * V_next
        End for
        Choose a_i that maximizes TotalVal.
        Set V[t, X] = max_{a_i} TotalVal.
        Record policy pi(t, X) = argmax_{a_i} TotalVal.
    End for
End for
Return policy pi(.).
```

### 4.4 The three-part decision system *\[MD-2 §5\]*

**\[SETUP\]** The policy is organised into a *Strategy System*, a *Prediction System* and a *Risk/Validation System*; the Strategy System uses the other two to select actions.

###### Strategy System

**\[SETUP\]** Given $S_t$ and candidate actions $a$, with $\hat S_{t+1}$ the predicted next state, $\hat R(a)$, $\hat L(a)$ the predicted reward and loss and $V$ the value-to-go (initialised or computed recursively), the strategy scores and selects $$\tag{4.9}
Q(S_t,a)=\mathbb{E}\bigl[\hat R(a)\bigr]-\mathbb{E}\bigl[\hat L(a)\bigr]+\gamma\,\mathbb{E}\bigl[V(S_{t+1})\bigr],\qquad a^{*}=\operatorname*{arg\,max}_a Q(S_t,a),$$ which is exactly the Bellman optimal policy for an MDP with reward $R-L$; when the other agents’ reactions are predictable it is a Stackelberg-style optimisation of the leader payoff, and no exploration is needed because the agent is fully informed. *(Editorial.)* $Q$ in (4.9) is a one-step look-ahead score evaluated with the Prediction System, not a temporal-difference (Q-learning) update: the drafts contain no learning rule; adaptation enters first as the whitepaper’s learning rule (Table 5.1) and the Framework summary’s hierarchical RL (Table 5.3).

###### Prediction System

**\[SETUP\]** A modular, model-agnostic forecasting module: input $S_t$ (and possibly a planned $a$), output $\hat S_{t+1}$ or expected future rewards and losses, by machine-learning models, statistical estimators, simulators or expert rules (a learned world model, a time-series forecaster for market prices, game-theoretic predictors of other agents’ policies). The Strategy System queries it for $\hat R$, $\hat L$ given a candidate action; no specific predictor is prescribed, so that any state-of-the-art model can be plugged in to forecast the consequences of each action sequence.

###### Risk and Validation System

**\[SETUP\]** A strictly binary utility structure: only the expected monetary reward and the expected monetary loss of a plan count, i.e. the agent cares only about $R-L$. Variance, conditional value-at-risk, Sharpe ratio and all other risk metrics are explicitly excluded; the system is a final check that expected profit exceeds expected cost. Thresholds or guards are allowed (discard plans whose expected loss exceeds a tolerance) but no penalty beyond the loss itself is added: a risk-neutral criterion in terms of statistical moments. *(Editorial.)* The Framework summary (Table 5.3) reverses this choice and installs VaR/CVaR, concentration and EVT in a risk core; the contradiction is recorded for Section 29.3.

### 4.5 Graph-based memory and recall *\[MD-2 §6\]*

**Definition 4.3** **(Episodic memory graph).** **\[SETUP\]** The agent stores past decision paths $(s_0,a_0,r_0),(s_1,a_1,r_1),\dots$ as a directed graph $M$ whose nodes are visited states $s$ (or state–action pairs $(s,a)$) and whose directed edges $s_t\to s_{t+1}$ (or $(s_t,a_t)\to(s_{t+1},a_{t+1})$) record the transitions of every trajectory; each edge or node carries a weight such as a visit count or a value. In the Levelled Graph Episodic Memory (LeGEM) form each subgraph $\phi^i_t$ with nodes $\Psi$ and edges $\Xi$ belongs to timestep $t$ and the memory is $\phi^i_0,\dots,\phi^i_{T-1}$; in practice all episodes are compressed into a single growing graph in which trajectories share nodes and edges.

**\[SETUP\]** *Update.* Each observed trajectory is appended (nodes and edges added, visit counts incremented). Unused parts decay: an edge weight $w$ is multiplied by $\alpha<1$ per time step of non-use, or by $\exp(-\lambda\Delta t)$, so that old paths fade; with a capacity limit the least recently used entries are removed, as an LRU cache (the episodic RL controller that replaces the oldest dictionary entry). **\[KNOWN RESULT\]** Agents that forget old episodic memories can perform better because forgetting “reduces the influence of outdated information and infrequently visited states” (neuroscience-inspired RL, cited by MD-2).

**\[SETUP\]** *Recall.* At each decision point the agent matches $S_t$ (or the recent history) against stored state-nodes: an episodic controller computes a similarity (Euclidean or graph distance) between the representation of $S_t$ and all memory keys, selects the entry of minimal distance and uses its action–return values as a candidate policy, “jumping” to follow the rest of a stored successful trajectory (case-based planning). The simplest scheme keeps each visited state as a key with an array of action-value returns, appended or updated on each visit; on recall a softmax over the stored returns gives the action probabilities. MD-2’s “Figure 2” (storage mode (A): states as dictionary keys mapping to value-arrays of action returns; retrieval mode (B): the current state compared to stored keys, the closest key’s array retrieved, softmax over it) exists only as caption text; the PDF contains no image.

### 4.6 Algorithmic outline: the operating loop *\[MD-2 §8\]*

**\[PLAN\]** Seven steps are executed at each $t$, then the loop closes:

1.  *State observation*: observe the full $S_t$ (positions of all agents and objects); the state is exact.

2.  *Prediction*: for each feasible $a\in A(S_t)$ estimate $\hat S_{t+1}$ and $\hat R(a)=R(S_t,a,\hat S_{t+1})$, $\hat L(a)=L(S_t,a,\hat S_{t+1})$; optionally roll out $\hat S_{t+1:t+H}$ over a horizon $H$.

3.  *Risk evaluation*: compute $\mathbb{E}[\hat R(a)-\hat L(a)]$; discard or penalise actions with unacceptable loss; no variance or CVaR.

4.  *Strategy selection*: $Q(S_t,a)$ and $a^{*}$ by (4.9); with other agents modelled this is the Stackelberg step with followers’ responses known.

5.  *Act and observe*: execute $a^{*}$, observe $S_{t+1}$ and the realised $R_t$, $L_t$; update environment values.

6.  *Memory update*: append $(S_t,a^{*},R_t)$; add or reinforce the edge $S_t\xrightarrow{a^{*}}S_{t+1}$, increment its count, multiply all other weights by $\alpha<1$, evict LRU entries if capacity is limited.

7.  *Memory recall*: search memory for nodes within a small distance of $S_{t+1}$; on a good match retrieve that path’s next actions and values and, if it yields higher reward, follow the recalled trajectory in place of the current sub-trajectory.

*Loop*: $t\leftarrow t+1$ and repeat from step 1 until the horizon or termination. **\[KNOWN RESULT\]** MD-2 cites, by URL domain only (arxiv.org, openreview.net, gibberblot.github.io, proceedings.mlr.press, researchgate.net, frontiersin.org), standard MDP theory and Stackelberg game concepts for the strategy logic, episodic-memory methods for the memory graph and the forgetting results for the decay; neither draft has a bibliography.

### 4.7 Status *\[MD-1, MD-2\]*

*(Editorial.)* The drafts contain no data pipeline, no calibration, no simulation plan, no number and no figure; the first data-pipeline and calibration stubs are the “Model” sketch of TMRW_first (Section 5.8) and the first simulation plan is the whitepaper’s market gym (Section 5.7). The only open issue the drafts themselves raise is the exclusion of all risk metrics beyond $R-L$ (Section 4.4).

| Statement | Tag | Where tested |
|---|---|---|
| Environment = three-tier rules + object graph + layered surface + agents, Section 4.1 | **\[SETUP\]** | not testable as stated; instantiated in market terms in Chapter 5 |
| Object, value, surface, agent and global updates (4.1)–(4.6) | **\[SETUP\]** | no simulation in the sources |
| Fully informed agent: Bellman optimality (4.7), backward induction Listing 4.1 | **\[KNOWN RESULT\]** | standard result, quoted |
| Objective $\mathbb{E}\sum\gamma^t(R_t-L_t)$ (4.8), Stackelberg reading | **\[SETUP\]** | — |
| Risk-neutral criterion: variance, CVaR, Sharpe excluded | **\[SETUP\]** | reversed in FS (Table 5.3); contradiction recorded for Section 29.3 |
| Prediction System model-agnostic, any predictor pluggable | **\[SETUP\]** | — |
| Forgetting old episodic memories improves performance | **\[KNOWN RESULT\]** | quoted (frontiersin.org), not reproduced |
| Memory recall lets the agent jump to a stored trajectory with higher reward | **\[HYPOTHESIS\]** | no test defined |
| Full-information assumption | **\[SETUP\]** | assumption of the drafts only; no partial-information variant here |

## Chapter 5: The whitepaper, the framework summary and the first theoretic proposal *\[WP, WP-M, FS, BP §1\]*

> **What this chapter establishes**
>
> The whitepaper (October 2025) re-expresses the drafts’ environment in market terms: an assets-and-markets graph, an agents graph, the three-tier rule system read also as objectives, constraints and variational principles, a four-layer value surface (fundamental, financial, information, market) and a seven-step time loop with reflexive feedback; its one written application is the “market gym” for AI strategies. The copy `TMRW_first` appends a sketch (WP-M): a data-pipeline stub and a force/Lagrangian/least-action analogy ending in $P_{t+1}=P_t+\mathit{Drift}+\mathit{Feedback}+\mathit{MR}+\mathit{Shock}+\mathit{dissipation}$. The Framework summary condenses the same architecture and adds risk engines and a business-level controller; the business plan’s first theoretic proposal restates it as five fields on a Riemannian manifold of assets with six agent types and hybrid jumps. All of it is setup; no number is measured.

### 5.1 Architecture and global state *\[WP §1–2, §7\]*

**\[SETUP\]** The market environment consists of (1) an *assets-and-markets graph* (instruments, venues, correlations, fundamental metadata), (2) an *agents graph* (traders and institutions with group affiliations, shared incentives and interaction links), (3) a *hierarchical rule-based system* (risk minimisation, concentration limits, return maximisation), (4) a *discretised multi-layer value surface* over the asset graph, and (5) an explicit *time dimension* along which all layers co-evolve. Formally, in discrete steps $t=0,1,2,\dots$ (milliseconds, minutes or days in implementation), $$\tag{5.1}
X(t)=\bigl\{G_{\mathrm{assets}}(t),\ G_{\mathrm{agents}}(t),\ V_{\mathrm{surface}}(t),\ S_{\mathrm{agents}}(t)\bigr\},\qquad R:\ X(t)\mapsto X(t+1),$$ where $G_{\mathrm{assets}}(t)$ holds the asset nodes, their attributes (fundamental values etc.) and the coupling edges at $t$; $G_{\mathrm{agents}}(t)$ the agent nodes and interaction edges; $V_{\mathrm{surface}}(t)$ the four value layers of every asset; and $S_{\mathrm{agents}}(t)$ the internal agent states (holdings, cash, strategy state). The two graphs are coupled by the rules: agents act on the market, the market state feeds back; the rule layer encodes global principles (conservation laws, no-arbitrage) and agent-specific objectives and constraints (utility maximisation, risk limits). **\[HYPOTHESIS\]** Top-down influences (fundamentals, regulation) and bottom-up effects (collective trading) in tandem are claimed to reproduce contagion, herding, bubbles and crashes, volatility clustering from herding, liquidity crises from network contagion and macro regime shifts; the paper’s Figures 1–2 are declared placeholders and no simulation is reported. *(Editorial.)* Equation (5.1) is (4.6) with the state split by component; the correspondence of names is in Remark 4.2.

### 5.2 Assets and markets graph *\[WP §3\]*

**\[SETUP\]** Nodes are assets or asset entities (stocks, bonds, commodities, currencies, indexes, derivative contracts) and venue nodes. Edges are of three kinds: (i) *listing and trading* edges from an asset to the exchanges on which it trades, so that a halt on one venue affects the asset globally; (ii) *hierarchical or compositional* edges for index or ETF membership and subsidiary–parent equity (all S&P 500 constituents link to the index node; moves propagate both ways through index arbitrage and passive flows); (iii) weighted *correlation and causation* edges, positive for co-moving equities (industry, common macro factors), negative for inverse relations (stocks vs. bonds in some regimes), a statistical encoding rather than a causal claim. Each node carries static metadata (sector, currency, country, fundamental ratios) and time-varying fundamentals (earnings, yield, growth, credit rating). **\[KNOWN RESULT\]** Financial knowledge graphs (corporate filings linked to industry, executives, risk factors, market data), correlation networks in risk management and network models of systemic risk (the financial system as a network of contracts and correlations) are the cited precedents. **\[SETUP\]** Propagation on the graph: if asset $A$’s price jumps, connected assets move proportionately to the edge weight (spillover by arbitrage or reallocation), the graph-Laplacian diffusion of (4.4); an earnings surprise shifts the index, re-rates sector peers and moves the asset’s futures consistently. **\[PLAN\]** An AI agent may traverse the graph (all assets related to oil) and adjust its portfolio on an oil shock, which a purely statistical model would miss.

### 5.3 Agents graph *\[WP §4\]*

**\[SETUP\]** Nodes are traders, institutional investors, market makers, banks, hedge funds and algorithmic systems. Edges: *communication or information sharing* (analysts in one firm, retail investors on a social network; weight = degree of influence or strategy correlation); *competitive or adversarial* relations (HFT firms racing, repeated games, bidding wars); *common ownership or group membership* (a group node or a clustered subgraph; aligned incentives = shared profit and loss and risk management, represented by full connectivity or a star topology with the fund manager at the centre); *leader–follower* edges directed from leader to follower with an influence strength (a central bank or a famous investor). Each agent carries a state (positions, capital, risk tolerance, strategy parameters, sentiment, memory of past events) and a utility $U_i(t)$ or loss $L_i$: a hedge fund’s expected profit minus a risk penalty, a market maker’s earned spread minus inventory holding costs. The graph is dynamic: a time-varying adjacency $W(t)$ with $W_{ij}(t)$ the influence of agent $j$ on agent $i$ (the drafts’ $w_{ij}(t)$, now with a stated direction), a dynamic networked game of arbitrary structure rather than the fully mixed population of prior multi-agent finance. **\[HYPOTHESIS\]** The graph is claimed to generate herding (a private-signal buying spree spreads to neighbours, giving endogenous trends or bubbles), cluster dynamics (a cluster of quant funds with similar models suffering a “quant meltdown” while a retail cluster acts on other information) and leader effects (policy announcements, large fund moves). **\[SETUP\]** An agent’s information comes from (1) private signals or state (its own model or fundamental analysis), (2) market observations (prices, volume: the link to the assets graph), (3) neighbours in the agent graph (a direct signal or inferred sentiment), which admits social learning; **\[KNOWN RESULT\]** networked agents can coordinate or reach equilibria different from the isolated case, and one random trade can cascade into many (an information cascade amplifying volatility). **\[SETUP\]** Trading implicitly links an agent node to an asset node; a bipartite agent–asset layer (who holds what) exposes concentration risk, portfolio overlap and crowded trades, as in network stress tests where a common holding transmits a fire sale. The agents graph is the stage for multi-agent reinforcement learning or game-theoretic analysis with each agent an autonomous optimiser.

### 5.4 Rule-based dynamic system *\[WP §5\]*

**\[SETUP\]** The rules are the laws of motion of the financial world, structured in the three tiers of Definition 4.1. Tier 1 (invariants and feasibility): cash conservation (every buyer’s spend is a seller’s receipt), share conservation (total shares fixed unless issuance or buyback is modelled explicitly), no negative cash beyond a credit limit, a trade needs a buyer and a seller, and no-arbitrage conditions enforced by arbitrage agents as near-invariants. Tier 2 (probabilistic transitions): the exogenous background physics drawn from econometric models (prices follow a diffusion or mean-reverting process when no trades occur; news arrives by a probability law and alters fundamentals). Tier 3 (interaction and outcome): order-book clearing, auction outcomes, agent-to-agent reactions, institutional mechanisms (circuit breakers). Precedence within a step is Tier 1, then Tier 2, then Tier 3, so an agent cannot violate a hard constraint. Every rule is a mapping from conditions to outcomes with possible randomness, $r:(\mathit{agentstate},\mathit{marketstate})\mapsto\mathit{actiondistribution}$, i.e. a policy for a class of agents.

**\[SETUP\]** Rules read as optimisation: *objectives* (a portfolio manager rebalances to maximise expected return minus $\lambda$ times the variance of return, the Markowitz objective, subject to constraints; a market maker minimises inventory risk plus a penalty for unfulfilled order flow; the rule is that the agent takes the optimising action, deterministically or with exploration); *constraints* (at most $X\%$ in one asset; capital requirements “if losses exceed $Y$, de-lever”; a Value-at-Risk cap that prevents or scales down a position; forced liquidation on a margin call), encoded as overriding hard rules or as penalty terms; and *variational principles*: **\[HYPOTHESIS\]** in an efficient market with risk-neutral pricing the market “minimises free energy” with free energy the exploitable arbitrage profit, moving to the equilibrium of fewest arbitrage opportunities (an energy minimum); agents collectively maximise utility (an equilibrium rather than one optimisation); a price-formation rule could be derived from maximising a social-welfare function or minimising overall trading “stress”. **\[KNOWN RESULT\]** Even simple declarative rule sets produce complex dynamics in the ABM literature (Lotzmann & Meyer). **\[PLAN\]** Rules are switchable (continuous trading vs. call auction, presence of agent types, a transaction tax) so the model is a sandbox for scenario analysis, and their parameters (reaction speeds, risk thresholds) are to be tuned to historical data or plausible scenarios. Table 5.1 lists every rule the whitepaper states.

**Table 5.1.** The example rules of the whitepaper, in the paper’s own categories and numbers *\[WP §5–7\]*.

| Rule | Category (WP) | Statement |
|---|---|---|
| Price update | Tier 3 example | net buy volume $>0$: price ticks up; net sell: down; magnitude proportional to the imbalance (linear price impact; market clearing with slippage) |
| Risk limit | hard constraint | any portfolio’s VaR stays below a threshold; a breaching action forces a position reduction (sell holdings) |
| Diversification | constraint | no single asset above 10% of the portfolio; automatic partial selling when price moves grow a position |
| Trend-following agent | agent rule | if the information-adjusted price exceeds the fundamental by more than $X\%$ and is rising, buy more; if below by $Y\%$, sell (momentum objective, implicit fundamentals constraint) |
| Market-maker agent | agent rule | keep the price near the information-adjusted value: deviation $+\delta$ $\Rightarrow$ supply liquidity (sell); $-\delta$ $\Rightarrow$ buy; minimise deviation, capture spread |
| Information shock | propagation | news moves asset $A$’s fundamental by $\Delta$: over the next $N$ steps $A$’s info value moves to the new fundamental with a decay factor; correlated assets adjust by a fraction of $\Delta$ set by the correlation weights |
| Learning/adaptation | agent rule | if utility falls below expectation for $Q$ periods, the agent switches strategy or adjusts parameters with some probability (evolutionary dynamics) |
| Earnings surprise | Tier 2 | surprise of $+X\%$: with 80% probability the fundamental shifts up proportionally |
| Daily returns | Tier 2 | each asset’s daily return has mean zero and volatility sigma unless pushed by other forces |
| Order-book clearing, opening auction | Tier 3 | matching orders trade at the trade price and volumes are deducted; the opening price is the equilibrium of an auction mapping all orders to one clearing price |
| Neighbour reaction | Tier 3 | if $A$ and $B$ are connected and $A$’s trade is large enough, $B$ adjusts her position (mimicking or hedging) |
| Circuit breaker | Tier 3 | if volatility exceeds a threshold the exchange halts trading for 5 minutes |
| Transaction tax (scenario) | interaction rule | a tax of $X\%$ is deducted from the proceeds of each trade |
| Value-investor trigger | agent rule (§7) | if the market price is below the fundamental by more than 20%, buy |
| Reflexivity | step-5 rule (§7) | if the price drops more than $X$ with no known news, reduce the info-layer value for the others (hidden information) |
| Loss-induced risk aversion | step-4 rule (§7) | an agent that lost a lot of money becomes more risk-averse in its utility or policy |

### 5.5 The multi-layer value surface *\[WP §6\]*

**\[SETUP\]** Over the asset graph lie (at least) four overlays, one value concept each (Table 5.2), formalised as the fields $V^{(\mathrm{fundamental})}(i,t)$, $V^{(\mathrm{financial})}(i,t)$, $V^{(\mathrm{info})}(i,t)$, $V^{(\mathrm{market})}(i,t)$ attached to asset $i$ and chained as in (4.4): $V_i^{(\mathrm{financial})}$ may equal $V_i^{(\mathrm{fundamental})}$ adjusted by a function of interest rates and volatility; $V_i^{(\mathrm{info})}$ starts from $V_i^{(\mathrm{financial})}$ and adds a multiplier or additive term from textual analysis or recent returns; $V_i^{(\mathrm{market})}$ is set by the trading dynamics. In the signal-processing analogy the fundamental is the low-frequency signal, information adds medium-frequency news jumps and interaction adds high-frequency microstructure noise; over long horizons the price gravitates to the fundamental but at any time may be off by the sum of layers 2–4. The surface is discretised on asset nodes and time steps: a table with one row per asset and columns fundamental, financial-adjusted, info-adjusted, market price at each $t$ (or a 2D asset plane with a vertical valuation axis). Its updates are the diffusion-plus-source equations of (4.4).

**Table 5.2.** The four value layers *\[WP §6\]*.

| Layer (field) | Content | Drivers, speed |
|---|---|---|
| Fundamental $V^{(\mathrm{fundamental})}$, $F_i(t)$ | intrinsic worth: discounted cash flows, book value, fair value given economic conditions; the price long-term investors believe the asset should trade at; set by a fundamental model or exogenously (the drafts’ evaluation layer) | earnings reports, economic data, structural change; slow |
| Financially adjusted $V^{(\mathrm{financial})}$ | fundamental adjusted for interest (discount) rates, inflation, liquidity premium, required risk premia; output of classical pricing models (option pricing, CAPM); lower rates raise it above the raw fundamental, illiquidity or high risk lowers it (an asset worth 100\$ fundamentally) | macro-financial indicators, risk appetite |
| Information-adjusted $V^{(\mathrm{info})}$ | adds news, sentiment, momentum and transient informational advantages: the price if all agents instantly and rationally processed the latest information; short-term fair value | earnings surprises, analyst upgrades, geopolitical news, social media; more volatile |
| Interaction-adjusted $V^{(\mathrm{market})}$ (market price) | the actual transaction price after order execution, supply–demand imbalance, strategic trading and constraints (not everyone can trade at once, liquidity needs); market impact and transient price pressure; overshoots when many buy at once, undershoots under a large seller | microstructure; fastest |

**\[SETUP\]** Inter-layer rules: *financial adjustment* (a change in rates $r(t)$ moves every $V_i^{(\mathrm{financial})}$ in proportion to its duration or rate sensitivity; a VIX spike lowers it for risky assets); *information update* (a news event shifts $V_i^{(\mathrm{info})}$ by a delta, e.g. $+5\%$, and every connected asset $j$ by $\mathit{correlation}_{\mathit{weight}}\cdot5\%$, information diffusion over the graph); *convergence* ($V_i^{(\mathrm{info})}$ drifts back to $V_i^{(\mathrm{financial})}$ in the absence of shocks, a mean-reversion process); *market price formation* ($V_i^{(\mathrm{market})}$ tends to $V_i^{(\mathrm{info})}$, exceeds it temporarily under a buy imbalance, with $\alpha$ a speed of adjustment to the info value and $\beta$ translating order flow into price impact, so that without imbalance the price moves gradually to the info value and pressure subsides and mean-reverts). **\[OPEN\]** The equation for the market price formation rule is missing from the source: the text reads “Mathematically, one could write:” and continues with the description of $\alpha$ and $\beta$ (verified on the PDF page); only the two parameters are defined. The agent-level form of this rule is (5.2).

**\[SETUP\]** Diagnostics: a jump in $V_i^{(\mathrm{market})}$ is a fundamental change if $V^{(\mathrm{fundamental})}$ and all layers above it moved, a technical sell-off if only $V^{(\mathrm{market})}$ fell below $V^{(\mathrm{info})}$ with $V^{(\mathrm{info})}$, $V^{(\mathrm{financial})}$ unchanged; a value-investor agent buys when $V^{(\mathrm{market})}$ is far below $V^{(\mathrm{fundamental})}$; a large market–info gap signals a liquidity crunch or exuberant trading; an ETF price vs. its net asset value is a market–fundamental gap; agents may trade the gap or read sentiment from the info–fundamental gap (“price vs. fair value”, “fundamentals vs. technicals” made formal). **\[KNOWN RESULT\]** An AI model fusing macro-index data with micro-stock data reduced prediction error by over 36% for a stock like Apple compared with micro data alone (study cited without a name in WP §6), which the paper takes as support for the layered macro–micro approach.

### 5.6 Temporal evolution and layer interactions *\[WP §7\]*

**\[SETUP\]** At each step the state (5.1) advances by seven ordered updates: (1) *apply exogenous changes* (fundamental news into the fundamental layer; asset-graph changes such as an IPO, a delisting or a new correlation; agent-graph changes such as entry or shifted links); (2) *determine agent actions* (each agent observes the state, possibly partially, and decides orders, portfolio adjustments or signals by its rules or objective, in the RL reading $\pi_i$ outputs the action; a one-shot game if agents anticipate each other, simpler if they react to the state); (3) *match and settle* (orders enter the order book or matching engine, Tier-3 rules clear the market, conflicting or excess orders are curtailed; output: updated holdings and $V^{(\mathrm{market})}(t+1)$); (4) *update agent states* (cash, portfolios, unrealised P&L, capital and risk metrics; adaptation such as loss-induced risk aversion); (5) *recompute derived values* (the fundamental layer from exogenous data, the info layer from fundamentals plus observed sentiment or momentum, the financial layer if rates moved; shocks propagated through the asset graph; a large move without news is itself information, the reflexivity rule of Table 5.1); (6) *enforce constraints* (Tier-1 invariants rechecked, rounding imbalances corrected, leverage breaches met by margin-call liquidation now or at the next start); (7) *proceed* to $t+1$. Tier-2 randomness and random agent decisions make repeated runs a distribution of outcomes. Agents may use $V^{(\mathrm{info})}-V^{(\mathrm{market})}$ as a trigger. The state-update functions of the drafts, (4.2) and (4.5), become, for an asset price with cross-impact from graph neighbours $j\sim i$, order flow and noise $\eta$, and for a portfolio with a pure accounting update (buy 10 shares of $A$: the holding of $A$ rises by 10 if filled, cash falls accordingly): $$\begin{aligned}
\mathrm{price}_i(t+1)&=\mathrm{price}_i(t)+g\bigl(\mathrm{price}_i(t),\ V_i^{(\mathrm{info})}(t),\ \{\mathrm{price}_j(t):j\sim i\},\ \mathit{orderflow}_i(t)\bigr)+\eta,\tag{5.2}\\
\mathit{portfolio}_i(t+1)&=h\bigl(\mathit{portfolio}_i(t),\ \mathit{actions}_i(t),\ \mathit{prices}(t+1)\bigr),\notag
\end{aligned}$$ where the form of $g$ encodes the rules (price impact, mean reversion). **\[SETUP\]** Time scales: prices move in milliseconds, fundamentals quarterly; either a fine step with rare slow events, or sub-stepping with an inner order-book loop inside an outer daily loop, the rule hierarchy layering fast and slow rules.

### 5.7 Applications *\[WP §8.1\]*

**\[PLAN\]** The model is a simulated market (“market gym”) in which AI agents are trained and evaluated: not i.i.d. returns or single-agent optimisation but interacting agents, regime shifts on news and cascading network effects. A reinforcement-learning agent maximising profit would have to learn sector underpricing relative to fundamentals with hedges, or anticipate a competitor’s price impact; with a belief system or a knowledge graph of agent types it becomes multi-agent RL approximating a Stackelberg leader–follower problem (Section 4.3). **\[KNOWN RESULT\]** Microsoft Research’s MarS engine emulates order flow and microstructure with generative models, a “large market model (LMM)” reproducing order-level and macro-level behaviour to train on synthetic but realistic data where history is scarce. **\[PLAN\]** A calibrated model would generate panics, fundamentally supported bull runs, sector rotations and liquidity squeezes; what-if analysis of a strategy under crowding (many agents with the same strategy, via the agents graph) or a new regulation (a changed rule) is stress-testing beyond backtesting and limits overfitting to simplistic assumptions. **\[OPEN\]** The abstract announces two further applications (advanced risk modelling with systemic risk and contagion; macro–micro integration) and a conclusion; the whitepaper’s text ends after §8.1 and these are unwritten.

### 5.8 The model sketch *\[WP-M\]*

**\[PLAN\]** The copy `TMRW_first` adds, after §8.1, a section “Model” with four numbered items: (1) a *data framework*: data in-take (a “MSFT” intake), data clean-up (remove N/A, timestamps etc.), data normalisation/denoising (average prices, moving averages, logarithmic prices), followed by the placeholders “Note: I would like to describe something here” and “Caveat! And give a warning here”; (2) “calibrate …”; (3) and (4) empty. **\[OPEN\]** Items 2–4 are blank in the source.

**\[HYPOTHESIS\]** The sketch then states the market model as mechanics. The total force is a sum of forces, Newton’s law holds for it, the Lagrangian is kinetic minus potential, and the market Lagrangian is written as a sum of forces of two kinds (the sketch writes a plus sign between the two sums while defining $L=\mathit{Kin}-\mathit{Pot}$; the sign is left as written): $$\tag{5.3}
F(t)=\sum_{i=0}^{n}F_i(t),\qquad \sum\vec F=m\vec a,\qquad L=\mathit{Kin}-\mathit{Pot},\qquad
L(t)=\underbrace{\sum_{i=0}^{n}F_i(t)}_{\mathit{Kinetic}}+\underbrace{\sum_{j=0}^{m}F_j(t)}_{\mathit{Potential}}.$$ The action over the horizon $t_1$ to $t_2$ is $$\tag{5.4}
S=\int_{t_1}^{t_2}L(q,\dot q,t)\,\mathrm{d}t,$$ “going from $A$ to $B$ with position $q$ and $\dot q$, hence we are calculating the expected lagrangian between those points $A=q$ and $B=\dot q$” (the sketch’s own identification of the endpoints). The path is found by the calculus of variations, a tiny change of path giving zero change of action, which yields the Euler–Lagrange equation: $$\tag{5.5}
\delta S=0,\qquad \frac{tial}{tial t}\Bigl(\frac{tial L}{tial\dot q_i}\Bigr)-\frac{tial L}{tial q_i}=0.$$ **\[KNOWN RESULT\]** The analogy given is the Lagrangian of a relativistic charge, “relativistic kinetic energy, electric potential and magnetic vector potential”, $$\tag{5.6}
L=\bigl((\gamma-1)mc^{2}\bigr)-\bigl(q\phi-q(A\cdot v)\bigr),$$ written as kinetic energy minus potential with the relativistic kinetic energy $(\gamma-1)mc^2$ in place of the standard $-mc^2/\gamma$ term. **\[SETUP\]** Under the heading “market model” the price update is decomposed as $$\tag{5.7}
P_{t+1}=P_t+\mathit{Drift}+\mathit{Feedback}+\mathit{MR}+\mathit{Shock}+\mathit{dissipation},$$ where $\mathit{MR}$ is not expanded in the source (read as mean reversion — editorial); **\[OPEN\]** the sketch ends at the heading “Drift” and defines none of the five terms.

**Remark 5.1** **(Seed of the least-action formulation — editorial).** Equations (5.4)–(5.5) are the first appearance in the corpus of the principle that later carries the market model: the least-action formulation of Conjecture 4 (Chapter 9) and the action of the geometric framework (3.4) (Chapter 3), which supply the Lagrangian the sketch leaves as a sum of forces. A plausible reading of (5.7) is the market-price layer of (4.4) written term by term: $\mathit{Drift}$ and $\mathit{MR}$ the convergence rule, $\mathit{Feedback}$ the reflexivity rule, $\mathit{Shock}$ the information-shock rule and $\mathit{dissipation}$ its decay factor (Table 5.1); this mapping is ours, not the sketch’s.

### 5.9 Framework summary *\[FS\]*

**\[SETUP\]** The one-page “Layered Market-Graph + Risk-Aware Control Framework” condenses the whitepaper and, in three places, goes beyond it (hybrid jumps, a risk core, a business-level controller); Table 5.3 holds all of it.

**Table 5.3.** Components of the Framework summary *\[FS\]*.

| Component | Content as stated |
|---|---|
| Thesis | markets are a coupled, time-varying system in which assets, agents, information and trading frictions co-evolve; represented by (i) an assets-and-markets knowledge graph, (ii) an agents graph, (iii) a rule/constraint layer, (iv) a multi-layer value surface (fundamental $\to$ financial-conditions $\to$ information/sentiment $\to$ interaction/price), evolving jointly through feedback loops so that macro conditions and microstructure shape each other |
| Assets graph | nodes = instruments; edges = listings, membership (index–constituent), correlation/causal ties, derivative links; nodes carry fundamentals (sector, currency, earnings, credit); supports diffusion/contagion of information and shocks |
| Agents graph | links = information sharing, competition, coalitions; utilities and constraints live on the graph; states extendable to complex values when phase or reliability matters |
| Layered value surface | per asset and time: fundamental, financially adjusted, info-adjusted, interaction/price layers; gaps diagnose sentiment, liquidity and mispricing; discretised over the asset network for estimation and visualisation |
| Dynamics | discrete time; each step updates data/features, propagates value across the graph (diffusion + source terms), updates agent states and closes the feedback loop; discrete *hybrid jumps* (earnings, policy, rebalances) switch system modes with reset maps that carry value functions and re-wire links when topology or metrics change (equation (2.12)) |
| Decision architecture | modular Strategy–Prediction–Risk/Validation stack (Section 4.4); Bellman control on reward $-$ loss giving $\pi^{*}$ with look-ahead (equation (4.8)); Stackelberg variants for other agents |
| Portfolio and risk engines | forecasting suite (statistical through deep/sequence models and Monte Carlo), regime detectors, a risk core (VaR/CVaR, concentration, EVT, scenario what-ifs) informing allocation and guardrails; outputs and directives flow to strategies and execution, closing the control loop |
| Microstructure and interaction layer | the interaction/price layer carries supply–demand and market-impact effects so that execution choices (inventory, imbalance, liquidity shocks) feed back into state and risk |
| Business-level controller | a top “enterprise” layer sets multi-quarter objectives and constraints via a central optimiser (multi-objective OR + hierarchical RL), passing targets and limits to portfolio and trading layers; results and KPIs feed back for learning (Section 24.2) |
| Data, evaluation, outputs | ingests macro, price/options, depth and news/sentiment data; reports statistical calibration (RMSE/CRPS), economic performance (PnL, Sharpe/Sortino, drawdown, CVaR) and ablations by layer, engine and jump modelling; deliverables (i) learned layered value surfaces on the market graph, (ii) risk-aware control policies with regime/jump handling, (iii) reproducible code and backtests across asset classes |
| Why it matters | unifying networked state, layered valuation, hybrid dynamics and Bellman-style control explains and exploits contagion, volatility clustering and liquidity crises while improving drawdown control and implementation realism |

**\[PLAN\]** Every line of Table 5.3 from “Portfolio and risk engines” downwards is an intention: no engine, metric or deliverable is reported as built or measured in FS. *(Editorial.)* The risk core contradicts the drafts’ exclusion of variance and CVaR (Section 4.4); the hybrid jumps and complex-valued states are the GI-H extension (Chapter 3).

### 5.10 The first theoretic proposal: five layers *\[BP §1\]*

**\[SETUP\]** The business plan opens with a “streamlined summary of our geometric–informational multi-agent model of financial markets”, intended as the blueprint for an optimal investment policy: stocks, bonds, derivatives, currencies and cryptocurrencies are modelled in a multi-layered field with specialised agent roles. The *financial field* is a manifold whose points are states of instruments, each coordinate an asset type with attributes (price, volatility, maturity); a Riemannian metric encodes distances and the cost of moving capital between assets (transaction costs, liquidity impact; the metric of Chapter 2). Five fields are overlaid on it (Table 5.4); the field evolves continuously with incremental price and valuation changes and jumps discretely at earnings reports, policy announcements and shocks, hybrid-system theory modelling flows and jumps to simulate crashes and regime shifts. BP §1 writes no equation: the manifold, metric, SDEs, PDEs and reset maps are named, and the layer objectives are stated in words exactly as in Table 5.4.

**Table 5.4.** The five layers of the first theoretic proposal and the six agent types that act on them *\[BP §1\]*.

| Layer | Content and objective as stated |
|---|---|
| 1\. Intrinsic value | fundamental metrics: earnings, cash flows, credit quality, token utility; the bedrock of valuation, influenced by agents performing fundamental analysis |
| 2\. Goodwill and budget | intangible factors: brand value, regulatory capital requirements, risk budgets; also investor capital allocations and leverage |
| 3\. Sentiment and news | market sentiment, social-media signals, macroeconomic news; evolves quickly and drives short-term moves; better-informed agents exploit it, their advantage quantified by an information coefficient |
| 4\. Interaction | order flow and trader interactions: order-book imbalances, correlations between instruments, network contagion; market-microstructure models and agent-based order-book simulations live here |
| 5\. Observed price | the traded price after integrating fundamental value, sentiment and interaction; deviates from intrinsic value through risk premia, speculation or liquidity constraints |
| Agent type | Layer, objective, information set |
| Fundamental analysts, value investors | layer 1; buy undervalued securities and hold until value is realised (the specialised analysts and risk managers of TradingAgents) |
| Sentiment and technical analysts | layer 3; NLP on news and social media, indicators on price and volume (the “Bull and Bear researcher agents” of TradingAgents) |
| Derivative and bond specialists | options, futures, bonds under rates, implied volatility, credit spreads, callable features; coordinates include maturity and convexity; jumps at coupon dates and expiries |
| Cryptocurrency traders | on-chain data, network activity, token economics; valued on market price and approximated fundamentals (multi-agent RL crypto simulations) |
| Market-making and HFT agents | layer 4; provide liquidity continuously and earn the bid–ask spread; execute in milliseconds |
| Risk management agents | monitor exposures, value-at-risk and stress scenarios; adjust leverage and hedges to keep risk within the budget layer (TradingAgents’ risk-management team) |

**\[SETUP\]** Each agent has an internal state (cash, positions, risk limits) and decision rules; some use complex state variables encoding magnitude and phase (cyclical behaviour; observable price vs. hidden momentum); agents interact through the information network, sharing signals, forming coalitions or competing. The *information network* is a graph whose nodes are agents or instruments and whose edges are information flow, trading relationships or derivative links, with one layer for price correlations, one for communication and one for derivative exposures; the *asset dependency network* links derivatives to underlyings, bonds through interest-rate curves and cryptocurrencies through blockchain interoperability, so that a credit event hits bonds and credit default swaps together; hypergraphs may represent multi-party contracts or portfolios; news and rumours spread by the diffusion and consensus processes of the framework (equation (2.7)), and in MAS trading systems specialised agents debate before executing. *Hybrid dynamics*: continuous evolution (Brownian motion of prices, drift from rates and dividends, gradual fundamentals) by SDEs or PDEs on the manifold; discrete jumps at earnings, central-bank decisions, index rebalancing, option expirations and regulatory changes by reset maps that update agent states and manifold geometry (equation (2.12)); agents adjust across events (risk managers cut exposure before a Federal Reserve announcement, HFT agents re-tune quoting before macro releases).

**\[KNOWN RESULT\]** Applications and the evidence BP §1 cites for them: (1) stock-market simulations, virtual trading floors of thousands of agents exhibiting bubbles and crashes; (2) portfolio management across asset classes, BlackRock’s Aladdin as an MAS-principled platform; (3) automated trading, HFT firms executing at microsecond speed, and the TradingAgents study in which specialised LLM-powered agents collaborating through debates improved returns and Sharpe ratios; (4) predicting market trends from simulated heterogeneous agents, JPMorgan’s DeepX as a comparable system; (5) crypto markets, multi-agent RL calibrated to real price data emulating microstructure across bull and bear regimes. **\[OPEN\]** Challenges stated: calibration and data (estimating the manifold geometry and the fundamental and sentiment layers needs high-quality data across asset classes; LLM sentiment must be validated); computational complexity (thousands of agents on a multi-layer manifold with hybrid events need efficient and parallel algorithms); regulatory and ethical constraints (market rules, systemic risk, manipulation; governance and risk controls in the agent design); interpretability for executives (visualising the manifold and networks). The section closes by pointing to the business plan and “the accompanying 61-page technical proposal” (Chapter 24).

### 5.11 Status *\[WP, WP-M, FS, BP §1\]*

| Statement | Tag | Where tested |
|---|---|---|
| Five-component architecture, global state (5.1); graphs, tiers, rules of Table 5.1 | **\[SETUP\]** | not simulated in WP |
| Graphs plus rules reproduce herding, contagion, bubbles, crashes, volatility clustering, liquidity crises | **\[HYPOTHESIS\]** | no run; Figures 1–2 placeholders |
| Four value layers disentangle fundamental, financial, informational and interaction moves | **\[HYPOTHESIS\]** | diagnostic use proposed, untested in WP |
| Market price formation rule ($\alpha$, $\beta$) | **\[OPEN\]** | equation blank in source |
| Market “minimises free energy” = exploitable arbitrage | **\[HYPOTHESIS\]** | untested; a variational principle, cf. Section 5.8 |
| Macro+micro fusion cut prediction error by over 36% (Apple) | **\[KNOWN RESULT\]** | quoted, unnamed study |
| MarS (Microsoft Research) large market model | **\[KNOWN RESULT\]** | quoted |
| Market gym, what-if and crowding stress tests | **\[PLAN\]** | — |
| Risk and macro–micro applications, conclusion | **\[OPEN\]** | unwritten in WP |
| Data pipeline (MSFT intake, clean-up, normalisation), calibration | **\[PLAN\]** | items 2–4 blank (WP-M) |
| Market as least-action system (5.4)–(5.5) | **\[HYPOTHESIS\]** | carried into Chapter 9 and Chapter 3 |
| Price decomposition (5.7) | **\[SETUP\]** | terms undefined in source |
| FS engines, controller, metrics, deliverables (i)–(iii) | **\[PLAN\]** | none built in FS |
| BP §1: five layers, six agent types, hybrid flows and jumps | **\[SETUP\]** | no equation in BP §1 |
| TradingAgents debate improves returns and Sharpe; Aladdin, DeepX, calibrated crypto MARL | **\[KNOWN RESULT\]** | quoted |
| Calibration, complexity, regulation, interpretability | **\[OPEN\]** | stated challenges |

# Part IV: The five conjectures

## Chapter 6: Conjecture 1: path switching *\[C1\]*

> **What this chapter establishes**
>
> Conjecture 1 (“Dynamic reallocation between strategies under model updates”, December 2025) poses the transition problem of a single-asset book when the model is updated: a legacy strategy $\pi^{(1)}$ chosen under model $M_1$ holds $\theta^{(1)}_{T_2}$ when an event at $T_2$ makes a new model $M_2$ and strategy $\pi^{(2)}$ the better belief, and the book must reach the target path $\theta^{(2)}_t$ by $T_3$ under transaction costs, liquidity constraints and risk limits. The source fixes the mixture $\theta_t=(1-w_t)\theta^{(1)}_t+w_t\theta^{(2)}_t$, $w_t\in[0,1]$, the objective $\min\mathbb{E}[\mathcal{L}+\mathcal{C}]$ over Monte Carlo paths of $M_2$, and three requirements: shortest or most coherent adjustment, constraints respected throughout, dynamic consistency. No solution is offered; NB-08 widens it to a sequence of update times $T_k$ and asks for a framework or an algorithm. Status: conjecture; toy test in `tmrw_lab`.

### 6.1 Setting: one asset, a family of models, a menu of strategies *\[C1 §Problem description\]*

**\[SETUP\]** A single risky asset has price process $(S_t)_{t\in[0,T]}$ observed at discrete times $0=t_0<t_1<\dots<t_N=T$. Given are a family of models $\{M_k\}_{k\ge1}$ for the asset dynamics, each able to generate Monte Carlo scenario paths, and a finite collection of trading strategies $\{\pi^1,\dots,\pi^K\}$ (mean-reversion, trend-following, etc.); for each strategy $\pi^k$ and model $M_k$ one obtains a position process $(\theta^{(k)}_t)_{t\in[0,T]}$ (number of units held) and the associated P&L along a given price path.

**Initial phase, regime 1 on $[0,T_1]$.** At $t_0=0$ choose an initial model $M_1$ (e.g. mean-reverting) and simulate a family of paths $\{X^{(1,i)}_t\}_{i=1}^{M}$, $t\in[0,T_1]$. Using these paths and a given objective (expected utility, risk-adjusted return, drawdown, etc.), select a “best” strategy $\pi^{(1)}$ (e.g. a mean-reversion strategy) and trade its position process $(\theta^{(1)}_t)_{t\in[0,T_1]}$. Ex post, once realised prices on $[0,T_1]$ are known, the fit of both $M_1$ and $\pi^{(1)}$ to the realised path is assessed via some loss function $L_1$.

**Model update and regime change, event at $T_2$.** At $T_2\in(T_1,T)$ a significant event or new information arrives (macro shock, regime shift, structural break). $M_1$ and $\pi^{(1)}$ are no longer believed “optimal” beyond $T_2$; a new model $M_2$ (e.g. a trend-following regime) and a new strategy $\pi^{(2)}$ with position process $(\theta^{(2)}_t)_{t\in[T_2,T_3]}$ are adopted, $T_3>T_2$ being the time by which the transition is intended to be complete. Starting from the realised price $S_{T_2}$, a new set of paths $\{X^{(2,j)}_t\}_{j=1}^{N}$, $t\in[T_2,T_3]$, is simulated under $M_2$ and the candidate positions of $\pi^{(2)}$ are obtained from them.

### 6.2 The transition problem *\[C1 §The transition problem\]*

**\[OPEN\]** On $[T_2,T_3]$ the book holds $\theta^{(1)}_{T_2}$, implied by $\pi^{(1)}$, and wishes to move gradually to the trajectory $(\theta^{(2)}_t)_{t\in[T_2,T_3]}$ implied by $\pi^{(2)}$; trading is subject to frictions (transaction costs, liquidity constraints, risk limits). The informal goal is an algorithm or mathematical framework that prescribes, at each intermediate time $t_k\in[T_2,T_3]$, $k=0,1,\dots$, the allocation between the old and the new strategy, equivalently the position $\theta_{t_k}$, such that

1.  the trajectory $(\theta_{t_k})_k$ is in some sense the “shortest” or most coherent adjustment from the old regime to the new one (minimal cumulative trading cost, minimal deviation from the new optimal position, or minimal path-wise distortion);

2.  risk and capital constraints are respected throughout the transition;

3.  the procedure is dynamically consistent: revisited at an intermediate $t_k$ with updated information, its prescription from $t_k$ to $T_3$ coincides with the restriction of the original plan.

### 6.3 Concrete formulation *\[C1 §More concrete formulation\]*

**\[SETUP\]** Let $\theta^{(1)}_t$ be the “legacy” position (e.g. mean-reversion) and $\theta^{(2)}_t$ the “target” position (e.g. trend-following). A control process $w_t\in[0,1]$ on $[T_2,T_3]$ is the fraction of capital allocated to the new regime, so that the actual position is $$\tag{6.1}
\theta_t=(1-w_t)\,\theta^{(1)}_t+w_t\,\theta^{(2)}_t,\qquad t\in[T_2,T_3].$$ Given a loss functional $\mathcal{L}(\{\theta_t\},\{\theta^{(2)}_t\})$ measuring deviation from the new “optimal” strategy and a cost functional $\mathcal{C}(\{\theta_t\})$ capturing transaction costs, turnover and risk, the problem is to find an admissible control $w_t$ (or discrete actions at $t_1,\dots,t_n$) that minimises $$\tag{6.2}
\mathbb{E}\big[\mathcal{L}+\mathcal{C}\big]\quad\text{over the simulated paths }\{X^{(2,j)}\}\text{ and/or under }M_2,
\quad\text{subject to trading and risk constraints.}$$

**Conjecture 6.1** **(C1: dynamic reallocation under a model update).** **\[CONJECTURE\]** There is a rule for $w_t$ in (6.1), minimising (6.2) on the paths of $M_2$, whose trajectory is the shortest or most coherent adjustment from $\theta^{(1)}$ to $\theta^{(2)}$, respects the risk and capital constraints throughout $[T_2,T_3]$ and is dynamically consistent in the sense of requirement 3. The source states the problem and the three requirements; the existence of such a rule is the open claim.

### 6.4 What NB-08 adds *\[NB-08 §Conjecture 1\]*

NB-08 restates the problem under the title “Dynamic reallocation between strategies under path switching” (area: stochastic processes, path stitching, strategy reallocation; models written $\mathcal{M}_k$) with the motivation that no algorithm fits every market, at best one fits most for a while, so the practical question is at what speed, with what inventory adjustments, under which cost and liquidity constraints, and while staying dynamically consistent, the move is made. It widens the statement to a sequence of pairs $(\mathcal{M}_1,\pi^{(1)}),(\mathcal{M}_2,\pi^{(2)}),\dots$ with simulated paths and realised prices at update times $0<T_1<T_2<T_3<\dots$, and asks for either (1) a mathematical framework (a loss functional, a cost functional and a notion of the “shortest” or most coherent adjustment between position paths) or (2) an explicit algorithm that, at each update time $T_k$, outputs a dynamically consistent sequence of positions $\theta_{t_1},\dots,\theta_{t_n}$ or allocations on $[T_k,T_{k+1}]$, path-wise coherent, cost-efficient and robust across Monte Carlo scenarios. It drops the explicit objective (6.2) and the ex-post loss $L_1$ in favour of the three-way trade-off (closeness to $\theta^{(2)}_t$, trading costs and turnover, risk and capital constraints). **\[LOG\]** Status in NB-08: the website statement was updated to cover the whole transition path under frictions and risk limits, not only a model switch; a PDF with the full setup (the present \[C1\]) accompanied the announcement. Small-scale instance: switching between making, taking and hedging regimes (Chapter 15, Chapter 17).

### 6.5 Proposed test (editorial)

**\[PLAN\]** The statement defines its own test: simulate $\{X^{(2,j)}\}$ from $S_{T_2}$ under $M_2$, evaluate $\mathbb{E}[\mathcal{L}+\mathcal{C}]$ for candidate schedules $w$ (instantaneous switch $w\equiv1$, linear ramp, cost-optimal ramp, dynamic-programming solution on the discrete grid) and check requirements 1–3, in particular that re-solving from $t_k$ reproduces the restriction of the plan. The toy `tmrw_lab/conjectures/` (path switching) runs this on synthetic paths with a planted answer; see Appendix E. No number is quoted here.

**Remark 6.2** **(Where it sits in the programme — editorial).** C1 is the hybrid jump of the geometric–informational framework seen from the book: the event at $T_2$ is a mode switch with a reset map (equation (2.12)), and C1 asks for the continuous relaxation that replaces an instantaneous reset of the position. In the market-dynamics model the position process and the Bellman recursion (equation (4.2), equation (4.7)) supply the loss and the dynamic consistency; requirement 3 is Bellman’s principle, so the discrete-action form of (6.2) is a finite-horizon stochastic control problem on the simulated paths. In the operating plan it is the rebalancing rule of the strategy layer (Section 24.4).

## Chapter 7: Conjecture 2: central pricing *\[C2\]*

> **What this chapter establishes**
>
> Conjecture 2 (“The Central Pricing Problem”, December 2025) extends the Central Price Problem to $N>3$ interacting assets (underlyings with options $A^{*}$ and swaps $\tilde A$) with explicit microstructure and mean-field effects. Five assumptions fix the information set $\mathcal{I}_T$ with a participant distribution $m_T\in\mathcal{P}(\mathcal{X})$, the split $P^{(i)}_{T+1}=\alpha^{(i)}_TI^{(i)}_T+(1-\alpha^{(i)}_T)H^{(i)}_T+\varepsilon^{(i)}_{T+1}$ into immediate and historical terms, an impact rule with toy $\phi^{(i)}=\sqrt{q^{(i)}}$ and the coupling of prices with $m_t$. Conjectured: central-price maps $F_T$ with sub-Gaussian error and confidence-region maps $\mathcal{C}_T$ with coverage $1-\delta$ over $H\ge5$ steps exist and beat random-walk and constant-volatility baselines. Status: conjecture; toy with conformal regions.

### 7.1 Setup and Assumptions 1–5 *\[C2 §Setup; Assumptions 1–5\]*

**\[SETUP\]** Fix an integer $N>3$ of traded assets with (mid-)price processes $\{P^{(i)}_t\}_{t\ge0}$, $i\in\{1,\dots,N\}$, on the grid $0=t_0<t_1<\dots<t_T<t_{T+1}<\dots$, prices known for $t_k\le T$ and unknown for $t_k>T$; $\mathbf{P}_t:=(P^{(1)}_t,\dots,P^{(N)}_t)^{\top}$. Concretely: an underlying $A$ with option $A^{*}$ and swap $\tilde A$, another $B$ with $B^{*}$, $\tilde B$, and in general $A,B,C,D,\dots$ with derivatives $A^{*},\tilde A,B^{*},\tilde B,\dots$; assets may be related through payoff structure (underlying–derivative), sector or factor exposure, common fundamentals, or purely through flow and correlation.

**Assumption 7.1** **(C2 Assumption 1: information set and observables).** **\[SETUP\]** At time $T$ the modeller observes $\mathcal{I}_T$ including at least (1) the joint price and volume history $\{(\mathbf{P}_{t_k},\mathbf{V}_{t_k}):k=0,\dots,T\}$, $\mathbf{V}_{t_k}$ the traded volumes or order-flow statistics of all $N$ assets at $t_k$; (2) cross-sectional and cross-asset features (empirical return correlation matrices, realised volatilities, liquidity measures, regime indicators extracted from the joint history); (3) fundamental data (financial statements, sector/industry classifications, macroeconomic indicators), at least for the issuers of a subset of the assets; (4) aggregate information about other participants as a (possibly approximate) distribution over their states, $m_T\in\mathcal{P}(\mathcal{X})$, $\mathcal{P}(\mathcal{X})$ the probability measures on a suitable state space $\mathcal{X}$ (inventory, risk limits, trading style, latency).

**Assumption 7.2** **(C2 Assumption 2: immediate vs historical dependence).** **\[SETUP\]** For each asset $i$ and time $T$ the one-step-ahead price admits the decomposition $$\tag{7.1}
P^{(i)}_{T+1}=\alpha^{(i)}_T\,I^{(i)}_T+\big(1-\alpha^{(i)}_T\big)H^{(i)}_T+\varepsilon^{(i)}_{T+1}
\qquad\text{[C2 eq.\ (1)]},$$ $I^{(i)}_T$ an immediate impact term, measurable w.r.t. the short-horizon order-book state and flow around $T$; $H^{(i)}_T$ a historical dynamics term, measurable w.r.t. the longer-horizon price/volume/fundamental history up to $T$; $\alpha^{(i)}_T\in[0,1]$ a (possibly random) weight of immediate versus historical effects, varying in time and across assets; $\varepsilon^{(i)}_{T+1}$ mean-zero noise (under an appropriate physical or risk-neutral measure) for the residual unpredictable variation, assumed small in a sense to be made precise (sub-Gaussian, or bounded conditional variance).

**Assumption 7.3** **(C2 Assumption 3: structure of the historical component).** **\[SETUP\]** $H^{(i)}_T$ is a measurable functional of $\mathcal{I}_T$; it may depend on past prices $\{P^{(j)}_{t_k}:0\le k\le T,\ 1\le j\le N\}$, cross-asset and cross-derivative correlations, volatility and liquidity regimes (from realised volatility, bid–ask spreads, depth, etc.), macro/fundamental signals from financial statements and economic data, and medium- to long-horizon features (drift, mean reversion, factor loadings), and may encode the stylised facts: partial mean reversion after extreme returns or all-time highs/lows; reversion towards fundamentals (valuation ratios); persistent drift components over longer horizons.

**Assumption 7.4** **(C2 Assumption 4: structure of the immediate impact).** **\[SETUP\]** $I^{(i)}_T$ is a functional of the short-horizon order-book state and flow around $T$: incoming market and limit orders (sizes, sides, time priority), the limit-order-book shape (depth at each price level, imbalance), observed behaviour of other agents (clustering of aggressive trades, herding). An order of price $p^{(i)}$ and size (or normalised volume) $q^{(i)}$ submitted by the modeller at $T$ shifts the mid-price of asset $i$ by the impact rule $$\tag{7.2}
\mathrm{mid}^{(i)}_{T+}=\mathrm{mid}^{(i)}_T+\big(p^{(i)}-\mathrm{mid}^{(i)}_T\big)\,
\phi^{(i)}\big(q^{(i)},\mathcal{I}_T\big)\quad\text{[C2 eq.\ (2)]},\qquad
\phi^{(i)}\big(q^{(i)},\mathcal{I}_T\big)=\sqrt{q^{(i)}}\ \text{ (toy specification)};$$ more refined impact functions (concave in volume, state-dependent) are allowed and encouraged.

**Assumption 7.5** **(C2 Assumption 5: mean-field interaction).** **\[SETUP\]** Other participants are modelled collectively via $m_T$; their joint behaviour feeds back into prices through both $H^{(i)}_T$ and $I^{(i)}_T$, so for a given policy of the modeller the evolution of $\mathbf{P}_t$ is coupled with that of $m_t$: a mean-field interaction in the sense of mean-field games or mean-field control.

### 7.2 Central price, confidence regions and the conjecture *\[C2 §Central Price and Confidence Regions; Conjecture 1; Remark 1\]*

**\[SETUP\]** Given $\mathcal{I}_T$ and $m_T$, the central price map and, for a fixed horizon $H\ge5$, the confidence-region map are $$\tag{7.3}
F_T:(\mathcal{I}_T,m_T)\longmapsto\widehat{\mathbf{P}}_{T+1}:=\big(\widehat P^{(1)}_{T+1},\dots,\widehat P^{(N)}_{T+1}\big)^{\top},
\qquad
\mathcal{C}_T:(\mathcal{I}_T,m_T)\longmapsto\mathcal{R}_T\subset\mathbb{R}^{N\times H},$$ $\widehat P^{(i)}_{T+1}$ a model-based estimate of $P^{(i)}_{T+1}$ (the conditional expectation or a robust location functional), $\mathcal{R}_T$ a confidence set for the joint future paths $\{\mathbf{P}_{T+1},\mathbf{P}_{T+2},\dots,\mathbf{P}_{T+H}\}$.

**Conjecture 7.6** **(C2 Conjecture 1: Central Price Problem, multi-asset extension).** **\[CONJECTURE\]** Under Assumptions 1–5 and realistic market conditions there exist (1) a non-trivial, empirically calibratable family of central price maps $F_T$ such that for each asset $i$ the error $P^{(i)}_{T+1}-\widehat P^{(i)}_{T+1}$ is statistically small (e.g. sub-Gaussian with variance bounded uniformly in $T$) and the estimates are practically useful for trading, market-making or risk management; (2) a family of confidence-region maps $\mathcal{C}_T$, $H\ge5$, such that $(\mathbf{P}_{T+1},\dots,\mathbf{P}_{T+H})\in\mathcal{R}_T$ with probability at least $1-\delta$ for a prescribed level $0<\delta<1$, the coverage holding with empirical accuracy out of sample on realistic markets. Equivalently: an empirically testable mapping from historical dynamics (prices, volumes, correlations, volatility and liquidity regimes, fundamentals) and immediate impact (order-book state, flows, participant positions, the modeller’s own trades) to short-term central prices $\widehat{\mathbf{P}}_{T+1}$ and medium-horizon confidence regions $\mathcal{R}_T$ for a system of $N\ge4$ interacting assets, with non-trivial predictive power beyond naive baselines (random walk, constant-volatility models).

**Remark 1 of the source (unified pricing framework).** **\[OPEN\]** Special interest is reserved for solutions embedding the construction in one framework covering simultaneously the market-maker’s very short-horizon pricing and inventory-control problem, the high-frequency trader’s short- to medium-horizon alpha and execution problem, and the medium- to long-term asset-pricing and portfolio-allocation problem, under common assumptions linking microstructure (order-book mechanics, impact, immediacy), participant behaviour and mean-field interactions, and longer-term price formation, drift and risk premia, making explicit how (7.1) and (7.2) (or their generalisations) propagate from tick-by-tick to daily, weekly or longer horizons.

**Test plan (editorial).** **\[PLAN\]** The conjecture carries its own pass/fail criteria: (i) calibrate $F_T$ and $\mathcal{C}_T$ on $N\ge4$ assets including an underlying–derivative pair; (ii) check that the one-step error is sub-Gaussian with variance bounded uniformly in $T$; (iii) check out-of-sample coverage of $\mathcal{R}_T$ at $1-\delta$ over $H\ge5$ steps; (iv) beat the random-walk and constant-volatility baselines; (v) show use in trading, market-making or risk management. The toy `tmrw_lab/conjectures/` builds $\mathcal{R}_T$ as conformal regions (“central price + conformal regions”), so (iii) is its first check; see Appendix E. No number is quoted here.

### 7.3 What NB-08 adds *\[NB-08 §Conjecture 2\]*

NB-08 restates C2 (area: pricing, market microstructure, mean-field effects) with the motivation that “price” is where microstructure, behaviour and macro collide and that pricing is a mean-field problem: “you are part of the crowd you are trying to model”. It uses the grid $0=t_0<\dots<t_T$ only; says of (7.1) that the weights “always sum to one”; gives the information set as three items (the full joint price and volume history, the issuers’ financial statements and fundamentals, the aggregate positions of other participants), without the cross-sectional features or the measure $m_T$; writes the impact rule in words, $\text{new mid}=\text{current mid}+
(\text{your price}-\text{current mid})\cdot\sqrt{\text{order volume}}$, “a toy model”; and puts the stylised facts (large buy orders pushing prices upward, short-horizon supply–demand imbalances, mean reversion around local extremes “while still allowing for a persistent long-horizon drift”) into the immediate term, where \[C2\] places them in $H^{(i)}_T$ (Assumption 7.3). Its statement asks for “a statistically significant and practically accurate formula (or class of models)” for the central or immediate price at $T+1$ and for “confidence intervals (or more general confidence sets)” over $t=T+1,\dots,T+H$, $H\ge5$, $i=1,\dots,N$, with “empirically valid coverage probabilities (‘reasonable accuracy’)”, without the sub-Gaussian error or the level $\delta$; its research note names the three problems of Remark 1 as the market maker’s very short-horizon pricing problem, the high-frequency trading pricing problem and the medium- to long-term asset pricing problem. **\[LOG\]** Status in NB-08: formalised on the website with a multi-asset setup, explicit impact terms and a mean-field element linking the three. Small-scale instance: estimating a fair value for quoting (Chapter 15, Chapter 16).

**Remark 7.7** **(Where it sits in the programme — editorial).** C2 is the valuation layer of the market model (equation (4.3), equation (4.4)) restated as an estimation problem with the modeller inside the crowd: the $\alpha$-weighted split of immediate and historical terms is the two-time-scale value surface, the impact rule is the price coupling of the GI framework (equation (2.4)), $m_T$ the mean-field state of Aggregation Theory (equation (11.34)). Its one-asset, one-step instance is the fair value of the quoting rules (Section 15.4); the order-flow imbalance and square-root impact of the matching-rule tests (equation (13.14), Section 13.5.5) are measured pieces of $I^{(i)}_T$. It is the only one of the five with a quantitative acceptance criterion in its statement.

## Chapter 8: Conjecture 3: stealth-optimal distribution *\[C3\]*

> **What this chapter establishes**
>
> Conjecture 3 (“The Stealth-Optimal Execution Distribution”, December 2025) asks how a signal’s notional $Q$ (e.g. 1,000,000 USD) should be spread over time $[0,\tau]$, trade size and up to $N_{\max}=100$ accounts so as to minimise both detectability and cost. Schedules are discrete $\{(t_k,q_k)\}$ or a density $\varphi$; five ingredients fix a concave footprint $g(x)\approx c\sqrt{x}$, the split $Q=\sum Q_i$, a proportional cost $k\%$ with optional discount $c\%$, cross-impact of opposite flow and a finite market memory with account recycling. Functionals $J_{\mathrm{stealth}}\ge0$ and $J_{\mathrm{cost}}=\mathbb{E}[C]$ give a constrained problem ($J_{\mathrm{cost}}\le\kappa$) and a scalarised one $J_\lambda$, $\lambda\in(0,1)$; conjectured: a minimiser $\pi^\star\in\Pi$ exists. Four open problems: well-posedness, structure, algorithms against TWAP/VWAP/Almgren–Chriss, robustness. Status: conjecture; a solution to the initial statement is credited to L. M. Zorzi Chiarioni (NB-08).

### 8.1 Problem and set-up *\[C3 §Problem description; §Problem set-up; §Execution schedules\]*

**\[OPEN\]** The conjecture arose from discussions with other systematic trading founders. Capital accumulates behind a strategy with strong performance; as it scales, typical order and average position sizes grow and firms routinely observe a deterioration of returns, a significant part of which is adverse market impact and loss of execution stealth: *market impact* (how much our orders move prices against us) and *execution stealth* (how detectable our footprint and intent become) are two aspects of one effect. Large, obvious orders (a single multi-million buy sweep) (1) push the order book and short-term imbalance in an unfavourable direction and (2) leave a footprint other firms learn from and exploit; over time this is alpha decay: competitors infer the strategy, trade ahead of it or “vulture” around it via sandwich-like behaviour. The goal is to characterise and, if possible, construct *stealth-optimal execution distributions*: a way to spread an order across time, size and accounts that maximises stealth and minimises slippage/cost.

**\[SETUP\]** An alpha fires at $t=0$ and prescribes a net position change of notional $Q>0$ (for example $Q=1{,}000{,}000$ USD) to be executed over $\mathcal{T}:=[0,\tau]$, from the signal time to a hard limit $\tau>0$; $Q$ is the order of this one signal, not the portfolio inventory, and the strategy may trigger many times, to build a position into a favourable opportunity or to reduce one into a profit-taking region. A schedule is modelled in two alternative ways, $\mathcal{E}$ denoting either: $$\tag{8.1}
\begin{gathered}
\text{discrete: }\ \mathcal{E}_{\mathrm{disc}}:=\{(t_k,q_k)\}_{k=1}^{K},\quad 0\le t_k\le\tau,\quad
\sum_{k=1}^{K}q_k=Q\quad(q_k\text{ the signed notional of trade }k);\\
\text{continuous: }\ \varphi:[0,\tau]\to\mathbb{R}\ \text{ a measurable order-size density},\quad
\int_0^{\tau}\varphi(t)\,\mathrm{d}t=Q.
\end{gathered}$$

### 8.2 Microstructure assumptions *\[C3 §Microstructure assumptions\]*

**Assumption 8.1** **(C3 microstructure ingredients 1–5).** **\[SETUP\]** The functional forms are deliberately left flexible.

1.  *Impact/stealth trade-off (square-root visibility).* There is an increasing, concave $g:[0,\infty)\to[0,\infty)$ with $\mathrm{footprint}(q)\propto g(|q|)$ and $g(x)\approx c\sqrt{x}$, $c>0$, on the relevant scale; executing the full $Q$ at time 0 produces a near-maximal footprint, very small slices (e.g. 10 USD) negligible incremental footprint.

2.  *Account-splitting constraint.* $Q=\sum_{i=1}^{N}Q_i$ with $N\le N_{\max}$, each account $i$ following its own schedule $\mathcal{E}^{(i)}$; for concreteness $N_{\max}=100$. This rules out the degenerate split over infinitely many infinitesimal accounts.

3.  *Execution cost/slippage.* Each trade incurs a base cost at a proportional rate $k\%$ (spread, immediate slippage, explicit fees) plus a market-impact component consistent with $g$; $C(\mathcal{E})$ is the resulting (random) total cost over $[0,\tau]$ and $J_{\mathrm{cost}}(\mathcal{E}):=\mathbb{E}[C(\mathcal{E})]$ its expectation under the chosen price/microstructure model. Optionally, fee schedules discount larger tickets: proportional costs shrink by a factor $c\%$ as order size increases.

4.  *Cross-impact and opposite flow.* Buy and sell trades of similar magnitude in overlapping windows may partially offset each other’s impact: a non-additive dependence of $J_{\mathrm{cost}}$ on the path of order flow.

5.  *Market memory/recycle rate.* The market and counterparties have a finite memory horizon for order flow: beyond some time scale, or after account recycling, older activity is less informative about current intent. Toy model: in each calendar month up to $N_{\max}$ new accounts may be opened, each with a “stealth bonus” decaying with its cumulative traded volume; encoded in a stealth functional $J_{\mathrm{stealth}}(\mathcal{E})$, higher meaning more detectable.

### 8.3 Functionals, objective and the conjecture *\[C3 §Stealth and cost functionals; Conjecture 1\]*

**\[SETUP\]** On the space $\Pi$ of admissible policies $\pi=\{\mathcal{E}^{(i)}\}_{i=1}^{N}$ satisfying the constraints above, the two functionals (higher $J_{\mathrm{stealth}}$: more detectable, less stealthy; $J_{\mathrm{cost}}$: expected total slippage plus execution cost) and the source’s example, with $q^{\mathrm{tot}}(t)$ the instantaneous net order flow across all accounts at $t$, are $$\tag{8.2}
J_{\mathrm{stealth}}(\pi)\ge0,\qquad J_{\mathrm{cost}}(\pi):=\mathbb{E}[C(\pi)],\qquad
J_{\mathrm{stealth}}(\pi)=\mathbb{E}\Big[\int_0^{\tau}\Psi\big(q^{\mathrm{tot}}(t)\big)\,\mathrm{d}t\Big],\quad
\Psi(x)\approx c\sqrt{|x|}.$$ One then studies either the purely constrained formulation or the scalarised objective, $$\tag{8.3}
\text{(a)}\ \ \min_{\pi\in\Pi}J_{\mathrm{stealth}}(\pi)\ \text{ s.t. }J_{\mathrm{cost}}(\pi)\le\kappa;
\qquad
\text{(b)}\ \ \min_{\pi\in\Pi}J_\lambda(\pi),\quad
J_\lambda(\pi):=\lambda J_{\mathrm{cost}}(\pi)+(1-\lambda)J_{\mathrm{stealth}}(\pi),\ \ \lambda\in(0,1).$$

**Conjecture 8.2** **(C3 Conjecture 1: stealth-optimal execution distributions).** **\[CONJECTURE\]** Under a reasonable microstructure model satisfying Assumption 8.1, and for any admissible $J_{\mathrm{stealth}},J_{\mathrm{cost}}$ of the type described, there exists at least one policy $\pi^\star\in\Pi$ that is stealth-optimal: (1) for a given cost tolerance $\kappa$ it minimises $J_{\mathrm{stealth}}$ over all policies with $J_{\mathrm{cost}}\le\kappa$, or (2) for a given $\lambda\in(0,1)$ it minimises $J_\lambda$ over $\Pi$. In particular $\pi^\star$ induces an optimal joint distribution of execution times $\{t^{(i)}_k\}$, trade sizes $\{q^{(i)}_k\}$ and account splits $\{Q_i\}_{i=1}^{N}$, $N\le N_{\max}$, that (1) maximises execution stealth (minimal information leakage or detectability of the strategy) and (2) simultaneously minimises expected slippage and total execution cost relative to the alpha’s target price path, subject to $t\in[0,\tau]$, $\sum_k q^{(i)}_k=Q_i$ for each account $i$, $\sum_{i=1}^{N}Q_i=Q$ and $N\le N_{\max}$.

### 8.4 Open problems and the algorithm sought *\[C3 §Open problems and challenges\]*

**\[OPEN\]** (1) *Well-posedness*: under what regularity and compactness assumptions on $J_{\mathrm{stealth}}$, $J_{\mathrm{cost}}$ and $\Pi$ does a minimiser $\pi^\star$ exist, and when is it unique up to natural symmetries? (2) *Structural properties*: in parametric models (square-root impact with linear fees), does an optimal policy show time-smoothing of order flow, bounded per-trade sizes and a non-trivial optimal number of active accounts $N^\star\in\{1,\dots,N_{\max}\}$? (3) *Constructive algorithms*: given an alpha signal, a total notional $Q$, a horizon $\tau$ and constraints $(N_{\max},k,c,\dots)$, produce an approximately stealth-optimal policy $\hat\pi$ and compare it on realistic data with TWAP/VWAP and Almgren–Chriss-type schedules. (4) *Robustness*: sensitivity of $\pi^\star$ to mis-specification of impact, memory and fee parameters; policies robust across a family of plausible microstructure models.

> **The algorithm sought: its interface as the sources fix it (editorial arrangement)**
>
> **\[PLAN\]** Input: alpha signal, $Q$, $\tau$, $(N_{\max},k,c,\dots)$, the memory/recycle state of the accounts. Steps: (i) choose $N\le N_{\max}$ active accounts, fresh ones carrying the undecayed stealth bonus of ingredient 5; (ii) split $Q=\sum_iQ_i$; (iii) choose each $\mathcal{E}^{(i)}$ so that the net flow $q^{\mathrm{tot}}$ minimises $J_\lambda$ in (8.3) (or $J_{\mathrm{stealth}}$ under $J_{\mathrm{cost}}\le\kappa$), netting opposite flow (ingredient 4); (iv) benchmark against TWAP/VWAP and Almgren–Chriss. The sources specify this interface and ask for the algorithm; none is given. The toy `tmrw_lab/conjectures/` (stealth schedule) runs step (iii) for the square-root model (Appendix E).

### 8.5 What NB-08 adds *\[NB-08 §Conjecture 3\]*

NB-08 restates C3 (area: execution, market impact, stealth) with two further motivation sentences: performance decays because of the strategy’s own size, not because the signal stopped working, so execution design sits alongside inventory control, risk management and alpha discovery as a core problem. It writes the footprint directly as $\mathrm{footprint}(q)\propto\sqrt{|q|}$ without $g$, the base cost as “a fixed rate of $k\%$”, the recycle toy as “up to 100 fresh accounts can be created per month”, and the statement without the functionals: under a model with a square-root-type impact and detectability relationship, optional cross-impact between opposing flows, $N\le100$ accounts and size-dependent transaction costs, there exists an optimal joint distribution of times, sizes and account splits (up to 100 accounts) maximising stealth and minimising expected slippage and cost, subject to $t\in[0,\tau]$, $\sum_kq_k=Q$ (or $\int_0^\tau\varphi=Q$) and $N\le100$. Its challenge has three parts: formulate the optimisation (a detectability functional, an impact and cost model, market-memory dynamics); prove existence and, where possible, uniqueness; design algorithms that split $Q$ across up to 100 accounts and allocate each account’s flow over time. **\[LOG\]** Status in NB-08: the conjecture drew particular interest from other founders; Lorenzo M. Zorzi Chiarioni has written a solution to the initial problem statement (QB: “to the initial version”); that solution is not among the sources. Small-scale instance: inventory skew and execution scheduling (Section 15.4, Chapter 18).

**Remark 8.3** **(Where it sits in the programme — editorial).** C3 is the execution layer of the operating plan (Section 24.5). Its square-root footprint is the square-root impact law of the large-order analysis (Section 13.5.5); the account split $\{Q_i\}$ is the first appearance of the “groupings” that Conjecture 5 puts into the utility; the inventory skew of the notes (Section 15.4) is its $N=1$, single-schedule version. Stealth and cost are two functionals of the same net flow $q^{\mathrm{tot}}$: the conjecture says the Pareto front of $(J_{\mathrm{cost}},J_{\mathrm{stealth}})$ is attained inside the admissible class, not that the two objectives coincide.

## Chapter 9: Conjecture 4: the full market model *\[C4\]*

> **What this chapter establishes**
>
> Conjecture 4 (“Existence of Optimal Strategies in the Full Multi-Layer Market Model”, December 2025; working title “Conjecture X” in NB-08) asks whether a best strategy, or an equilibrium profile, exists once the market is a hybrid-geometric multi-agent system. The state is $X_t=(S_t,E_t,\{s_i(t)\}_{i=1}^N)$: multi-layer value surfaces, evolving edges, agent states; agent $i$ maximises $J_i=\mathbb{E}[\int_0^\tau(\mathcal{R}_i-\mathcal{L}_i)\,\mathrm{d}t]$ under four assumptions (hybrid flows with reset maps, graph coupling $W(t)$, bounded Lipschitz Markov rewards, compact measurable action sets). Conjectured: a single-agent optimum exists and is Markov/feedback or a least-action policy on $M$, and a Nash or mean-field equilibrium (HJB–Fokker–Planck on $M$) exists. NB-08 gives the discounted discrete-time form and a constructive version. Five open problems; five illustrative figures (Figure 9.1). Status: conjecture; toys for hybrid MDP, MFG fixed point and least action.

### 9.1 Problem *\[C4 §Problem description\]*

**\[OPEN\]** The conjecture arises from the study of multi-layer hybrid markets at Tomorrow Capital Research and concerns the interaction between strategy optimality, agent interactions and market microstructure in a fully coupled geometric and informational environment. Given a market modelled as a dynamic manifold with interacting agents, layered valuations and hybrid (continuous + discrete) dynamics, it is natural to ask whether a best possible strategy (or equilibrium profile) exists for an agent or a set of agents. Each agent’s decisions influence, and are influenced by, (a) the evolving multi-layer value surfaces (fundamental $\to$ financial $\to$ informational $\to$ interaction/price), (b) other agents through information and interaction graphs, and (c) hybrid jumps, discrete events (earnings, policy changes, liquidity shocks) that alter the state space. Practical experience in systematic trading suggests optimal strategies are often not straightforward because of the feedback loops between agents and the market, time-varying correlations and hybrid jumps; a rigorous framework for the existence and characterisation of optimal policies is therefore of central importance.

### 9.2 Set-up and assumptions *\[C4 §Problem set-up; §Hybrid-geometric microstructure assumptions; §Optimal policy / equilibrium functional\]*

**\[SETUP\]** The global state of the market at time $t$ and the controls are $$\tag{9.1}
X_t=\big(S_t,\,E_t,\,\{s_i(t)\}_{i=1}^{N}\big),\qquad a_i(t)\in A_i(X_t),$$ $S_t$ the multi-layer surface values of assets, $E_t$ the evolving edges (asset and agent relationships), $s_i(t)$ the state vectors of agents $i=1,\dots,N$ (positions, strategies, information coefficients). Each agent optimises over the horizon $[0,\tau]$ $$\tag{9.2}
J_i(\pi_1,\dots,\pi_N)=\mathbb{E}\Big[\int_0^{\tau}\mathcal{R}_i\big(X_t,a_i(t),\{a_j(t)\}_{j\ne i}\big)
-\mathcal{L}_i\big(X_t,a_i(t),\{a_j(t)\}_{j\ne i}\big)\,\mathrm{d}t\Big],
\qquad J_i(\pi^{*})=\sup_{\pi\in\Pi_i}J_i(\pi),$$ $\mathcal{R}_i$ the reward and $\mathcal{L}_i$ the loss determined by the market’s layered dynamics, agent interactions and hybrid events; the right-hand equality is the single-agent optimality asked for below.

**Assumption 9.1** **(C4 hybrid-geometric microstructure assumptions 1–4).** **\[SETUP\]** (1) *Hybrid dynamics*: the state evolves continuously on the manifold $M$ but is subject to discrete jumps via well-defined reset maps; flow maps and jump maps satisfy regularity conditions ensuring well-posed evolution. (2) *Agent interactions*: coupling is mediated by weighted information and interaction graphs, represented by dynamic adjacency matrices $W(t)$, possibly dependent on geometric distances and state variables. (3) *Reward and loss structure*: $\mathcal{R}_i$ and $\mathcal{L}_i$ are bounded, Markov in $(X_t,a_i(t))$ and Lipschitz-continuous with respect to the relevant metrics on $M$ and $S_i$. (4) *Admissible action sets*: each $A_i(X_t)$ is compact and measurable for all $t$.

**\[SETUP\]** With $\Pi_i$ the admissible policies of agent $i$ and $\Pi=\Pi_1\times\dots\times\Pi_N$, a *geometric-optimal policy* is a mapping $\pi_i^{*}:X_t\mapsto a_i(t)\in A_i(X_t)$ maximising $J_i$ given the other agents’ policies; a profile $(\pi_1^{*},\dots,\pi_N^{*})$ is an equilibrium if no agent can improve $J_i$ unilaterally.

### 9.3 The existence conjecture *\[C4 Conjecture 1; §Open problems and challenges\]*

**Conjecture 9.2** **(C4 Conjecture 1: hybrid-geometric optimal strategies).** **\[CONJECTURE\]** Under Assumption 9.1: (1) *single-agent version*: there exists at least one admissible policy $\pi^{*}\in\Pi_i$ with $J_i(\pi^{*})=\sup_{\pi\in\Pi_i}J_i(\pi)$, which can be chosen as either a Markov/feedback policy depending only on the current state $X_t$ or a variational/geometric policy following a least-action trajectory on the manifold $M$; (2) *multi-agent/mean-field extension*: there exists at least one equilibrium profile $(\pi_1^{*},\dots,\pi_N^{*})$, a Nash equilibrium in feedback strategies or a mean-field equilibrium solving a coupled HJB–Fokker–Planck system on $M$ consistent with the hybrid jumps.

**\[OPEN\]** **Open problems.** (1) *Well-posedness*: which regularity and compactness assumptions guarantee existence (and possibly uniqueness) of $\pi^{*}$ or of the equilibrium profile? (2) *Structural properties*: are optimal strategies geodesic, layered across time-scales, or decomposable across strategy/prediction/risk modules? (3) *Constructive algorithms*: can convergent numerical schemes (dynamic programming, policy iteration, actor-critic, or RL) compute $\pi^{*}$ in practice? (4) *Robustness*: how sensitive are optimal policies to mis-specification of hybrid dynamics, information graphs, or reward/loss parameters? (5) *Scaling and multi-agent complexity*: how do properties change as $N\to\infty$, and what is the mean-field limit?

<figure>
![](figures/conj4_value_surface.jpg)
![](figures/conj4_mfg_interactions.jpg)
![](figures/conj4_hybrid_jumps.jpg)
<p><br />
![](figures/conj4_agent_network.jpg)</p>
![](figures/conj4_asset_edges.jpg)
<figcaption>The five illustrations of the Conjecture 4 statement <em>[C4 Figures 1–2]</em>, schematic, not data; the PDF’s Figure 1 is (a), (b), (c) and its Figure 2 is (a), (d), (e), both captioned “key components influencing agent strategies in the hybrid-geometric multi-layer market model”. (a) Four value layers of one asset (1 fundamental, 2 financial, 3 informational, 4 interaction/price), value evolving upward, news and sentiment feeds entering layer 3, market buy/sell marks on the price curve. (b) About a hundred simulated agent trajectories <em>X</em><sub><em>t</em></sub>, <em>t</em> ∈ [0,100], around a dashed mean field, with the final distribution and its mean at <em>t</em> = <em>T</em>. (c) A price path over a “market state space” grid deformed at an earnings beat (positive shock), a policy tightening (negative shock) and a liquidity shock (disorderly event). (d) Three agent groups, A institutional investors, B retail traders, C market makers, with information-share links (solid strong, dashed weak). (e) Exchange hubs (NYSE: AAPL, TSLA, MSFT, NVDA, AMD; Binance: BTC, ETH, TRX, pairs BTC–ETH, ETH–TRX) and a US-government-bond hub (Bond A 2.5%, Bond B 3.1%, Bond D 1.8%, Bond D 4.0%); NVDA and Bond D are repeated as drawn.</figcaption>
</figure>

### 9.4 What NB-08 adds *\[NB-08 §Conjecture 4\]*

NB-08 restates C4 (area: hybrid geometry, mean-field games, optimal control) under the working title “Conjecture X”, motivated by “is the market a Markov decision process, or a hybrid geometric system?” (most reinforcement learning in finance assumes the former, the framework the latter), with a four-part model: a time-varying market and asset graph with a value surface; a network of interacting agents with utilities and information links; a rule hierarchy governing the dynamics; most generally a geometric hybrid frame with continuous flows and discrete jumps. In the simplified, finite, fully discrete version a fully informed agent faces a Markov decision process and Bellman theory guarantees an optimal policy computable by dynamic programming; the question is whether this survives an infinite-dimensional state (fields plus agents), hybrid time (flows plus jumps) and game-theoretic or mean-field interaction. Its single-agent form is discrete and discounted on $X=M\times S$ ($M$ a possibly time-varying manifold, $S$ the discrete modes or frames), for a distinguished “Tomorrow” agent with controls $a_t\in A(X_t)$: $J(\pi)=\mathbb{E}\big[\sum_{t=0}^{T}\gamma^{t}\big(R(X_t,\pi(X_t))-L(X_t,\pi(X_t))\big)\big]$, $0<\gamma\le1$; under natural regularity (well-posed flows and jump maps on $M\times S$; compact, measurable $A(x)$; $R,L$ bounded or suitably integrable and Markov in state and action) an optimal admissible $\pi^{*}$ with $J(\pi^{*})=\sup_\pi J(\pi)$ exists, Markov/feedback or variational/geometric (a least-action trajectory, the solution of an HJB or Euler–Lagrange system of the full model); a stronger, constructive version asks for $\pi^{*}$ as the limit of a convergent sequence of algorithms (value iteration, policy iteration or actor-critic) in the same market simulator. Multi-agent: each agent has $J_i(\pi_1,\dots,\pi_N)$ over the same hybrid geometric field, coupled through prices, fields and information graphs, and under suitable compactness, continuity and monotonicity a Nash equilibrium in feedback strategies or a mean-field game equilibrium (coupled HJB and Fokker–Planck on the manifold) exists. What counts as a solution: an existence theorem for the single agent beyond the finite discretised MDP “already covered in the drafts”; a constructive characterisation (an HJB equation on $M\times S$, or a provably convergent DP or RL scheme); equilibrium existence for the multi-agent or mean-field case; extra credit for structure (geodesic policies, layering across time-scales, decomposition across the strategy, prediction and risk modules). **\[LOG\]** Status in NB-08: “no problem PDF has been released”; the website description was the only public statement (QB: “deliberately”); the December 2025 PDF \[C4\] supersedes this (editorial). Small-scale instance: the reinforcement-learning and control toolkit (Chapter 21).

**Remark 9.3** **(Where it sits in the programme — editorial).** C4 is the existence question for the whole of Parts II–III: $X_t$ is the geometric–informational state (fields, graphs, agents) with hybrid jumps and reset maps (Chapter 2, equation (2.12)); the least-action policy is the action functional of the extended framework (equation (3.4)); the finite MDP case “already covered in the drafts” is the Bellman recursion of the market model (equation (4.7)); the mean-field equilibrium is that of Aggregation Theory (equation (11.30), equation (11.34)). The toys (hybrid MDP, MFG fixed point, least action; Appendix E) check the three structured classes on finite instances; they cannot decide existence in the infinite-dimensional model, which remains open.

## Chapter 10: Conjecture 5: the final problem *\[C5, NB-08\]*

> **What this chapter establishes**
>
> Conjecture 5 (“The Final Problem”; area: portfolio, optimisation, multiscale) is stated in NB-08 and in the website/LinkedIn text kept in QB: a firm-wide portfolio $A$ with capital $V$ is decomposed into components $X$ (pods, risk books, execution policies, desks, regions, horizons), each with a local state, local constraints and a local objective, while the firm optimises a global objective; conjectured: one implementable multiscale principle, a single rule or variational framework, yields a configuration that is globally and locally optimal at once, uniformly across layers, within all risk budgets and stable under feedback. The working notes compress the principle into five bullets (highest expected utility; cost and groupings; minimise free energy = risk; maximise conserved energy = return; is it variational?), written here as the objective (10.1). Status: conjecture; toy “bilevel firm”. The part closes with the status table of all five.

### 10.1 The problem *\[NB-08 §Conjecture 5; QB §Conjecture 5\]*

**\[SETUP\]** Modern financial firms are hierarchies of decision makers, firm $\to$ portfolio $\to$ strategy $\to$ execution; each layer has its own objectives, constraints and key performance indicators, yet all act on the same market and the same pool of capital. Fix a single firm-wide portfolio $A$ with total capital $V$, trading a universe of assets with features (prices, returns, volatilities, liquidity, funding, fundamentals, microstructure attributes). $A$ is decomposed into internal components: strategy pods and sub-portfolios; risk and hedging books; execution and routing policies; further sub-components (desks, regions, time horizons). Each component $X$ in the hierarchy (the symbol is QB’s) controls a local state (positions, risk exposures, cash, inventory), faces its own constraints (risk limits, turnover, liquidity, leverage, drawdown, stealth, capital budget) and optimises a local objective functional (Sharpe ratio, PnL, risk-adjusted return, tracking error, execution cost). The firm optimises a global objective over the full configuration: long-horizon risk–return, drawdown and survival probabilities, capital efficiency, systemic risk.

**\[OPEN\]** **Problem.** Specify a mathematical framework (objective, constraints, decision rules) that, given the hierarchical decomposition of the firm, the feature set of all traded assets and strategies, and the evolving market state and information flow, produces a configuration of decisions (capital allocations, positions, risk limits, execution policies) that is simultaneously *globally optimal* for the firm-wide objective (risk–return, survival, capital efficiency) and *locally optimal* for every component and sub-component, given its constraints and its local view of the environment: the same capital and information must support a configuration in which the whole portfolio $A$ is optimal inside the market and each internal piece of $A$ is optimal inside its own local neighbourhood of constraints and interactions. The working notes’ label for the same problem is “several products and strategies under shared limits” (NB-08 and the notes’ README).

**Conjecture 10.1** **(C5: The Final Problem *\[NB-08 §Conjecture 5; QB\]*).** **\[CONJECTURE\]** There exists a principled, implementable multiscale optimisation principle, a single rule or a variational framework, that maps the full state of the market and the firm (prices, returns, risks, liquidity, fundamentals, correlations and hierarchical structure) into such a configuration of decisions, and that (i) applies uniformly across layers (firm, portfolio, strategy, execution), (ii) respects all local constraints and risk budgets, and (iii) yields configurations that are stable under feedback from market dynamics and from the actions of other agents. The challenge is to write the principle down explicitly and to show that, under realistic assumptions on markets and constraints, its solutions are simultaneously globally and locally optimal in the sense above.

### 10.2 The principle in the working notes *\[QB §The final problem; NB-08 §Working notes\]*

The raw bullets (QB, verbatim, spelling included) and NB-08’s cleaned form (“Toward a variational principle (Conjecture 5)”: action, choose the one with the highest expected utility; utility takes cost and groupings into account; minimise free energy, read as risk; maximise conserved energy, read as return; certain properties are needed to drive the dynamics, not yet specified; open question: is this a variational principle?) are the only statement of the principle itself:

> **The final problem.** – Action : Highest expected utility – Utility takes into account cost and groupings – Minimize free energy(risk) – Maximumize conserved energy(return) – Certain properties to play dynamics. Variational principle???

**\[SETUP\]** Written as an objective (editorial transcription; the symbols are not in the sources): let $a=(a_X)_X$ be the configuration, $a_X$ the decision of component $X$ in its constraint set $K_X$ (risk limits, turnover, liquidity, leverage, drawdown, stealth, capital budget), $\mathcal{G}$ the grouping of $A$ into components, $E^{\mathrm{cons}}_X$ the conserved energy (return), $F_X$ the free energy (risk), $c_X$ the cost, and $U_X$ the utility; then the five bullets and the conjecture read $$\tag{10.1}
\begin{gathered}
U_X(a):=E^{\mathrm{cons}}_X(a)-F_X(a)-c_X(a;\mathcal{G}),\qquad
a^{*}_X\in\operatorname*{arg\,max}_{a_X\in K_X}\mathbb{E}\big[U_X(a_X,a^{*}_{-X})\,\big|\,\text{local view of }X\big]\ \ \text{for every }X,\\
a^{*}\in\operatorname*{arg\,max}_{a\in K_A}\mathbb{E}\big[U_A(a)\big],\qquad
\text{\textbf{[CONJECTURE]}}\ \ \text{one }a^{*}\text{ satisfies both, and }\delta\mathcal{S}[a^{*}]=0\text{ for a single functional }\mathcal{S},
\end{gathered}$$ stable under the feedback $a\mapsto$ market $\mapsto a$. Line 1 is “action = highest expected utility” with “cost and groupings” in the utility (local optimality); line 2 is global optimality and then the “variational principle???” of the bullets; the “certain properties to play dynamics” are the unspecified conditions on the market under which the stationary point is attained.

### 10.3 How it fits the wider framework *\[NB-08 §Conjecture 5; QB (LinkedIn text)\]*

**\[PLAN\]** The principle is expected to be variational, akin to energy minimisation, and builds on three pieces of the multi-layer framework: *asset and agent graphs*, to capture the diffusion of shocks and information; *hybrid control*, to handle regime switches and boundary conditions at jumps; *risk-aware Bellman control*, which drives action selection through a unified prediction, strategy and risk stack. It is called the Final Problem because it is the concluding issue in constructing a (“truly”) self-learning financial architecture; solutions using hybrid dynamics and layered value surfaces have been proposed internally, and the post asks “who else is looking at the market through this lens” (QB). NB-08’s small-scale instances are several products and strategies under shared limits and the multi-layer architecture (Chapter 20, Chapter 22); the toolkit note adds that risk-aware Bellman control is one of its three building blocks (Chapter 21). NB-08 points to the public statements of all five at `lnkd.in/dPKxZcKc`. Adjacent in the same working notes, not part of C5: the product ideas *ToE* (a min–max strategy: find the trend, find where $dX=0$, check whether $d^2X$ is negative or positive) and *TMRW* (“expand, establish, excel”).

### 10.4 Open questions *\[NB-08; editorial\]*

**\[OPEN\]** From the sources: (1) is the principle a variational principle at all, and for which functional $\mathcal{S}$ (the sources’ “???”); (2) which “properties” of the market are needed to drive the dynamics (not yet specified); (3) write the principle down explicitly; (4) prove simultaneous global and local optimality under realistic assumptions; (5) stability under feedback from the market and from other agents. Editorial: (6) which quantities are “conserved” (add exactly across components) and which are “free” (do not), since the answer fixes the two energies in (10.1); (7) whether local optimality is a Nash condition between components or the lower level of a bilevel programme, which decides whether (ii) and (iii) of Conjecture 10.1 can hold together. The file in the source set named “The final problem” is the April 2025 hybrid-frames paper (Chapter 2) and is not a source for this chapter.

**Remark 10.2** **(C5 as the bilevel form of the matching rule — editorial).** The matching rule of Aggregation Theory (Section 13.3) says which quantities of a whole are sums of its parts and by how much the others differ: value and return match exactly (Proposition 13.6); volatility is sub-additive, the gap being the internal motion, the dispersion between the parts (Theorem 13.13); each level of a hierarchy moves energy from collective to internal, never back (Theorem 13.11). Read on a firm, “maximise conserved energy (return)” maximises the quantity that matches exactly across the hierarchy and “minimise free energy (risk)” manages the one that does not, whose gap is the relative motion of the components; the “groupings” in the utility are the partition of $A$ into components. C5 is therefore the matching rule turned into a bilevel optimisation, the firm at the upper level and the components at the lower, with the matching parameters of Chapter 14 (collective share $\kappa$, normalised gap) as the quantities a solution must control. The toy “bilevel firm” in `tmrw_lab/conjectures/` (Appendix E) is this reading on a two-level synthetic firm; Section 23.4 gives the working-notes side.

### 10.5 Status of the five conjectures *\[C1–C4, NB-08, QB\]*

| Conjecture | Statement | Tag | Where tested |
|---|---|---|---|
| C1 path switching (Chapter 6) | A rule for $w_t$ in (6.1) minimising $\mathbb{E}[\mathcal{L}+\mathcal{C}]$ that is the shortest coherent adjustment, respects the constraints and is dynamically consistent. | **\[CONJECTURE\]** | Path-switching toy: candidate $w$ schedules on simulated $M_2$ paths; re-solve check. |
| C2 central pricing (Chapter 7) | Calibratable $F_T$ with sub-Gaussian error and $\mathcal{C}_T$ with coverage $1-\delta$ over $H\ge5$ for $N\ge4$ assets, beating random-walk and constant-volatility baselines. | **\[CONJECTURE\]** | Central price + conformal regions toy: coverage of $\mathcal{R}_T$, baselines. |
| C3 stealth-optimal distribution (Chapter 8) | A minimiser $\pi^\star\in\Pi$ of $J_\lambda$, or of $J_{\mathrm{stealth}}$ under $J_{\mathrm{cost}}\le\kappa$, over times, sizes and $N\le N_{\max}=100$ accounts. | **\[CONJECTURE\]** a solution to the initial statement credited (NB-08), not in the sources | Stealth-schedule toy: square-root model; benchmark vs TWAP/VWAP/Almgren–Chriss. |
| C4 full market model (Chapter 9) | A single-agent optimum (Markov/feedback or least action on $M$) and a Nash or mean-field equilibrium (HJB–Fokker–Planck on $M$) under Assumption 9.1. | **\[CONJECTURE\]** | Hybrid MDP, MFG fixed point and least-action toys (finite instances only). |
| C5 the final problem (Chapter 10) | One multiscale (variational) principle gives a configuration globally and locally optimal, uniform across layers, within risk budgets, stable under feedback. | **\[CONJECTURE\]** | Bilevel-firm toy: two-level synthetic firm under shared limits. |

# Part V: Aggregation theory

## Chapter 11: Aggregation theory: the original setup *\[AT-0\]*

> **What this chapter establishes**
>
> The original 54-page document (July 2026) sets the aggregation programme up: agents with a finite action library choose by a softmax rule under partial information, the population is a measure that evolves by a mean-field or Fokker–Planck law, the total system value is a stock that is contested (zero-sum transfers) or injected, and mergers of populations add measures and values but not equilibria. A market layer defines a causal equilibrium estimator at four time scales with three empirical hypotheses (restoration, migration, cross-scale coherence) and one Bitcoin experiment. Appendix B states the central research object: the scale-dependent equilibrium $\mathfrak{E}_\Delta=(f^{\star,\Delta},\pi^{\star,\Delta},J^{\star,\Delta},\tau_\Delta)$ and its response to mergers. The hindsight tests of Chapter 14 later refuted the restoration hypothesis as stated.

### 11.1 Introduction *\[AT-0 §1\]*

**\[SETUP\]** Many complex systems consist of simple local interactions whose effects aggregate into larger structures (emergent convergence, emergent behaviour): orders matching inside a financial market; particles interacting inside a physical environment; animals competing for resources inside an ecosystem; individuals allocating attention across an information network. The central question of the document is:

> Can a common interaction principle describe the system at several scales, with the observed differences arising primarily from aggregation, granularity and changing equilibrium conditions?

**\[HYPOTHESIS\]** In a financial market, supply and demand need not balance around a constant price; the estimated equilibrium may migrate as information, inventory, liquidity and agent behaviour change. For particles the analogue is the conservation between potential and kinetic energy, with the system approaching a minimum-energy configuration.

### 11.2 Conceptual decomposition *\[AT-0 §2\]*

The theory is divided into (the source says four, lists three) connected components.

#### 11.2.1 External ontology *\[AT-0 §2.1\]*

**\[SETUP\]** The external description specifies the environment in which interaction occurs; the agents or elements it contains; the rules governing their possible interactions; and the mechanism by which local interactions aggregate.

#### 11.2.2 Equilibrium and settlement path *\[AT-0 §2.2\]*

**\[SETUP\]** The estimator identifies the changing central state around which matching, displacement and restoration occur: in a market an *estimated* equilibrium price rather than a fixed one; in a physical system the trajectory of the system’s conserved energy (the settled energy and its kinetic movements).

#### 11.2.3 Agent control *\[AT-0 §2.3\]*

**\[SETUP\]** Each element observes only its accessible part of the system and selects actions intended to improve its own objective. Standing assumption: elements do not “choose” their actions; the action is predefined by a vast past series of events, so each action carries a probability distribution. Outcomes are uncertain between rewards and costs, and each agent has a decision equation. Information ratio 1 means the agent views everything, between 0 and 1 parts of everything, 0 only its own actions; agents may be correlated in information, cost–reward and actions. (The source asks here whether actions are “a normal or uniform distribution with each number referring to an action in the library”; Section 11.3.2 answers it.) The first draft of the objects is $$\begin{gathered}
m_N(t)=\frac1N\sum_{j=1}^{N}\delta_j(t),\qquad
X_i(t+1)\sim P_\theta\big(\mathrm{d}x'\mid X_i(t),a_i(t),m_N(t)\big),\tag{11.1}\\
u_i(t)=R\big(X_i(t),a_i(t),X_i(t+1),m_N(t)\big)-C\big(X_i(t),a_i(t),X_i(t+1),m_N(t)\big),\tag{11.2}\\
O_i(T)=\int_{t_0}^{T}\big(R_i(t)-C_i(t)\big)\mathrm{d}t,\tag{11.3}\\
J_i(\pi_i,\pi_{i-1})=\mathbb{E}_\pi\Big[\int_{t_0}^{T}\big(R_i(t)-C_i(t)\big)\mathrm{d}t+G(X_i(t),m_T)\,\Big|\,I_i(t)\Big],
\tag{11.4}
\end{gathered}$$ with $P_\theta$ the transition law, $u_i$ the unrealised and $O_i(T)$ the realised (ex-post) reward, $\pi_i$ the policy, $G$ a terminal reward or cost and $I_i(t)$ the information available to the agent. Only probabilities are known to each agent at $t$; collectively at $T+1$ the outcome is known for sure (the particle picture: an agent at $(X,Y,Z)$ moving to $(X+1,Y+1,Z+1)$ gains or loses energy by an exact amount). **System.** As $N\to\infty$, $m_N(t)$ is approximated by $m(t)$; given the population policy $\pi(t)(\mathrm{d}a\mid x,m_t)$, $$m(t+1)\cdot(\mathrm{d}x')=\int_{\mathcal{X}}\int_{\mathcal{A}}P_\theta(\mathrm{d}x'\mid x,a,m(t))\,\pi(t)(\mathrm{d}a\mid x,m(t))\,m(t)\,\mathrm{d}x
\tag{11.5}$$ (take agents distributed as $m_t$, assign actions by $\pi_t$, propagate through the transition law). The particle model and its collective distribution are $$\begin{gathered}
\mathrm{d}X_i(t)=b(X_i(t),a_i(t),m(t))\,\mathrm{d}t+\sigma(X_i(t),a_i(t),m(t))\,\mathrm{d}W_i(t),\tag{11.6}\\
\frac{tial m(t)}{tial t}=-\nabla\cdot\big[b(x,\alpha(t,x),m(t))\,m(t)\big]
+\frac12\sum_{j,k}\frac{tial^2}{tial x_jtial x_k}\big[(\sigma\sigma^{T})_{jk}\,m(t)\big].
\tag{11.7}
\end{gathered}$$ The source asks for an equation of the collective cost–reward and of the collective dynamics (“is this a mean field game?”): Section 11.3.7 and Section 11.18.

**Aggregations (the value picture).** **\[HYPOTHESIS\]** If the entire system holds a fixed value $C$ from $t_0$, every agent fights for its share: costs and rewards over all agents sum to the constant $C$ over any period, with stochastic activity over who holds what share, a best policy for holding or gaining a share, and various equilibria for various configurations. If instead the value fluctuates, the agents change behaviour: the cost–reward stays close to equilibria in periods until value changes make it diverge, which opens many policies while keeping approximately the same optimal policies within stable periods. Value divides into utilised value ($C_{\mathrm{util}}$, the integral of value over $t_0$ to $T$, for which agents can optimise freely) and unutilised value ($C_{\mathrm{unutilised}}$, for which optimising is not possible). Changes in behaviour should equal the subtractions or additions of value in that time frame. End goal: merging two or more systems between $t_a$ and $t_b$ should be the expression of all agents with initially separate systems and all agents in one system with the summed value.

### 11.3 Initial idea: agents, actions, information, value *\[AT-0 §3\]*

#### 11.3.1 Agents *\[AT-0 §3.1\]*

**\[SETUP\]** $N$ agents with state and population measure $$\begin{gathered}
X_i(t)=(x_i(t),y_i(t),z_i(t))\in\mathbb{R}^3,\qquad
\mu_N(t)=\frac1N\sum_{i=1}^{N}\delta_{X_{i,\tau(i)}(t)},\\
\tau_i=(\text{information quality, reward parameters, cost parameters, action set, group}),
\end{gathered}
\tag{11.8}$$ where $\tau_i$ is the agent’s type (information, preferences, capabilities). The type-agnostic population measure on initial agent value, $m_N(t)_{\mathrm{value}}=\frac1N\sum_{i=1}^N
\delta_{\mathrm{value}}(X_i(t))$, is illustrated in Figure 11.1; types are illustrated by “poor”, “lower middle”, “middle”, “high” income earners, giving four population distributions with respect to value.

<figure>
![](figures/agg3_value_distribution.png)
![](figures/agg3_four_types.png)
<figcaption>The simulated value measures of <em>[AT-0 §3.1]</em>: (a) type-agnostic <em>m</em><sub><em>N</em></sub>(<em>t</em>)<sub>value</sub>; (b) the four-type illustration. Synthetic data; no numbers from these figures are used elsewhere.</figcaption>
</figure>

#### 11.3.2 Actions *\[AT-0 §3.2\]*

**\[SETUP\]** An action and its outcome are different random objects, $A_i(t)\sim\pi_i(t)$ and $X_i(t+1)\sim P_\theta(\cdot\mid X_i(t),A_i(t),m_N(T))$: $\pi_i(t)$ is the distribution used to choose, $P_\theta$ the distribution of the outcome; an agent can choose deterministically while the outcome stays uncertain. **Finite action library.** With $K$ actions, movement in three dimensions for example, $$\mathcal{A}_i=\{a_{i,1},a_{i,2},a_{i,3},\dots,a_{i,k}\},\qquad
\mathcal{A}_i=\{(0,0,0),(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)\},
\tag{11.9}$$ the action distribution is categorical, $A_i(t)\sim\mathrm{Categorical}(p_{i1}(t),\dots,p_{iK}(t))$ with $p_{ik}(t)=\pi_i(t)(a_{ik}\mid\mathcal{F}_i(t))$, $\sum_{k=1}^K p_{ik}(t)=1$. The numbers $1,\dots,K$ are labels only and must not be drawn from a normal distribution. The uniform policy $p_{ik}(t)=1/K$ chooses without preference (useful for exploration, not normally optimal). The common probabilistic choice rule is softmax, with deterministic limit $$p_{ik}(t)=\frac{\exp\big(Q_i(t,a_{ik})/\tau\big)}{\sum_{l=1}^{K}\exp\big(Q_i(t,a_{il})/\tau\big)},
\qquad
A_i^*(t)=\operatorname*{arg\,max}_{a\in\mathcal{A}_i}Q_i(t,a)\ \ (\tau\to0),
\tag{11.10}$$ where $Q_i(t,a)$ is the estimated value of action $a$ and $\tau$ controls randomness. **Continuous actions.** If $A_i(t)\in\mathbb{R}^d$ a Gaussian policy $A_i(t)\sim\mathcal{N}(\mu_i(\mathcal{F}_i(t)),\Sigma_i(\mathcal{F}_i(t)))$ may be appropriate; for bounded actions a truncated Gaussian, beta or transformed Gaussian is preferable.

#### 11.3.3 Information and beliefs *\[AT-0 §3.3\]*

**\[SETUP\]** A scalar information ratio is descriptive only; the rigorous object is an observation process. With full system state $S(t)=(E(t),X_1(t),\dots,X_N(t),m_N(t))$, $E(t)$ the environment, $$\begin{gathered}
Y_i(t)\sim Q_{\rho_i}(\mathrm{d}y\mid S(t)),\qquad \rho_i\in[0,1],\qquad
Q_1(\mathrm{d}y\mid S(t))=\delta_{S(t)}(\mathrm{d}y),\qquad Q_0(\mathrm{d}y\mid S(t))=Q_0(\mathrm{d}y),\tag{11.11}\\
\mathcal{F}_i(t)=\sigma\big(Y_i(0\!:\!t),A_i(0\!:\!t-1),U_i(1\!:\!t),X_i(0\!:\!t)\big),\qquad
B_i(t,\mathrm{d}s,\mathrm{d}\theta)=\mathbb{P}\big(S(t)\in\mathrm{d}s,\theta\in\mathrm{d}\theta\mid\mathcal{F}_i(t)\big),\tag{11.12}\\
B_i(t+1)=\mathfrak{B}_i\big(B_i(t),A_i(t),Y_i(t+1),U_i(t+1)\big),\qquad
\pi_i(t)(\mathrm{d}a\mid X_i(t),B_i(t)),\tag{11.13}
\end{gathered}$$ where $\rho_i=1$ is full information and $\rho_i=0$ an observation independent of the global state; $\mathcal{F}_i(t)$ is the information history, $B_i$ the belief about the unobserved system, $\mathfrak{B}_i$ a Bayesian or learned update, and the policy depends on beliefs rather than on the true $m_t$ when the agent cannot observe it.

#### 11.3.4 Two kinds of uncertainty *\[AT-0 §3.4\]*

**\[SETUP\]** *Physical uncertainty*: even an all-informed observer cannot know the future shock, $X_i(t+1)=F_\theta(X_i(t),A_i(t),m_N(t),E(t),\xi_i(t+1),\xi_0(t+1))$ with $\xi_i$ agent-specific and $\xi_0$ a common environmental shock. *Informational uncertainty*: the system may be deterministic conditional on the full state, $X_i(t+1)=F_\theta(S(t),A_i(t))$, but the agent does not observe $S(t)$ and predicts $$\widehat{P}_i(t)(B\mid A)=\int\mathbf{1}\{F_\theta(s,a)\in B\}\,B_i(t,\mathrm{d}s,\mathrm{d}\theta).
\tag{11.14}$$ The statement “with all environmental information we could calculate the exact result” corresponds to the second case.

#### 11.3.5 Rewards and the decision equation *\[AT-0 §3.5\]*

**\[SETUP\]** The one-step net payoff, unrealised at $t$ and realised at $t+1$, and its conditional expectation are $$\begin{gathered}
U_i(t+1)=r_i(X_i(t),A_i(t),X_i(t+1),m_N(t))-c_i(X_i(t),A_i(t),X_i(t+1),m_N(t)),\\
\bar U_i(t+1)=\mathbb{E}[U_i(t+1)\mid\mathcal{F}_i(t),A_i(t)=a].
\end{gathered}
\tag{11.15}$$ With time steps the objective is a sum, and the optimal policy is a best response: $$J_i(t,\pi_i,\pi_{-i})=\mathbb{E}\Big[\sum_{s=t}^{T-1}\beta(s-t)\,U_i(s+1)+\beta(T-t)\,G_i(X_i(T),m(T))\,\Big|\,\mathcal{F}_i(t)\Big],
\qquad \pi_i^*\in\operatorname*{arg\,max}_{\pi_i}J_i(t,\pi_i,\pi_{-i}),
\tag{11.16}$$ Corrections to the draft (11.4): $\pi_{-i}$ (all policies except $i$’s) rather than $\pi_{i-1}$; $G_i(X_i(T),m(T))$ is a terminal reward; condition on the complete history $\mathcal{F}_i(t)$. In belief-state form the decision equation is the Bellman equation $$V_i(t,b)=\max_{a\in\mathcal{A}_i}\Big\{\bar U_i(b,a,m(t))+\beta\,\mathbb{E}\big[V_i(t+1,B_i(t+1))\mid B_i(t)=b,A_i(t)=a\big]\Big\}.
\tag{11.17}$$

#### 11.3.6 Correlated agents *\[AT-0 §3.6\]*

**\[SETUP\]** Correlation enters through common observations, common environmental shocks, communication, similar reward and cost functions, direct coordination, and network relationships. A continuous-time model separates individual and common noise: $$\begin{gathered}
\mathrm{d}X_i(t)=b_i(X_i(t),A_i(t),m(t))\mathrm{d}t+\sigma_i(X_i(t),A_i(t),m(t))\mathrm{d}W_i(t)+\sigma_{i,0}(X_i(t),A_i(t),m(t))\mathrm{d}B(t),\tag{11.18}\\
\mathrm{d}\langle X_i,X_j\rangle(t)=\sigma_{i,0}(\sigma_{i,0})^{\top}\mathrm{d}t\ \ (i\ne j),\qquad
m(t)=\mathcal{L}\big(X_i(t)\mid\mathcal{F}_0(t)\big),\tag{11.19}
\end{gathered}$$ with $\mathcal{F}_0(t)$ the common-information filtration: with common noise the mean field is itself random, the deterministic Fokker–Planck equation (11.7) applies only without common noise, and strong group or network correlations may require a multi-population, graphon or network mean-field game.

#### 11.3.7 Correct collective dynamics *\[AT-0 §3.7\]*

**\[SETUP\]** For a homogeneous population the discrete-time mean-field evolution is, for every measurable $B\subseteq\mathcal{X}$ (equivalently in $\mathrm{d}x'$ form), and when information and types differ the population state must carry beliefs and types: $$\begin{gathered}
m(t+1,B)=\int_{\mathcal{X}}\int_{\mathcal{A}}P_\theta(B\mid x,a,m(t))\,\pi(t,\mathrm{d}a\mid x,m(t))\,m(t)\,\mathrm{d}x,\\
m(t+1,\mathrm{d}x')=\int_{\mathcal{X}}\int_{\mathcal{A}}P_\theta(\mathrm{d}x'\mid x,a,m(t))\,\pi(t,\mathrm{d}a\mid x,m(t))\,m(t)\,\mathrm{d}x,\\
\mu_N(t)=\frac1N\sum_{i=1}^{N}\delta\big(X_i(t),B_i(t),\tau_i\big),
\end{gathered}
\tag{11.20}$$ because two agents at the same physical position can act differently owing to different beliefs.

#### 11.3.8 Collective cost–reward *\[AT-0 §3.8\]*

**\[SETUP\]** The average collective objective, and its homogeneous mean-field limit, are $$\begin{gathered}
\mathcal{W}_N(\boldsymbol\pi)=\mathbb{E}\Big[\sum_{t=0}^{T-1}\beta(t)\frac1N\sum_{i=1}^{N}U_i(t+1)+\frac1N\sum_{i=1}^{N}G_i(X_i(T),m(T))\Big],\tag{11.21}\\
\mathcal{W}_N(\boldsymbol\pi)=\mathbb{E}\Big[\sum_{t=0}^{T-1}\beta(t)\int_{\mathcal{X}}\int_{\mathcal{A}}\bar u(x,a,m(t))\,\pi(t,\mathrm{d}a\mid x,m(t))\,m(t)\,\mathrm{d}x
+\int_{\mathcal{X}}g(x,m(T))\,m(t)(\mathrm{d}x)\Big].\tag{11.22}
\end{gathered}$$ In a mean-field game the welfare is measured, not maximised (each agent maximises $J_i$); in mean-field control a planner solves $\sup_\pi\mathcal{W}(\pi)$ subject to the collective population dynamics.

#### 11.3.9 Fixed total system value *\[AT-0 §3.9\]*

**\[SETUP\]** A stock of value is distinguished from a flow of rewards. With $q_i(t)$ the value held by agent $i$ and $q_0(t)$ the unutilised value, $$\begin{gathered}
\mathcal{C}(t)=q_0(t)+\sum_{i=1}^{N}q_i(t),\qquad \mathcal{C}(t)=C\ \text{for every }t\ \text{(fixed value)},\\
\sum_{i=1}^{N}q_i(t)=C\ \text{(all utilised)},\qquad
\sum_{i=1}^{N}\big(q_i(t+1)-q_i(t)\big)=0\ \text{(internal transfers)}.
\end{gathered}
\tag{11.23}$$ Holdings sum to $C$, changes in holdings sum to zero, and the integral of rewards does *not* automatically sum to $C$. If the payoff is the change in holdings, $U_i(t+1)=q_i(t+1)-q_i(t)$, then $\sum_{i=1}^N U_i(t+1)=0$: a zero-sum transfer game. A simple fixed-prize contest uses instead $$p_i(\mathbf a(t))=\frac{\phi_i(a_i(t))}{\sum_{j=1}^{N}\phi_j(a_j(t))},\qquad
R_i(t)=C\,p_i(\mathbf a(t)),\qquad \sum_i R_i(t)=C,
\tag{11.24}$$ so the gross reward is constant-sum while the net payoff after action costs generally is not (the source leaves the displayed expression after “But after action costs” blank). If $C$ stays fixed while $N\to\infty$ each ordinary agent’s share tends to zero; a non-degenerate mean-field limit needs $C_N=N\bar C$ or normalised relative shares.

#### 11.3.10 Utilised and unutilised value *\[AT-0 §3.10\]*

**\[SETUP\]** The decomposition and the capture constraint are $$C_t=C_t^{\mathrm{util}}+C_t^{\mathrm{unutil}},\qquad C_t^{\mathrm{util}}=\sum_i q_i(t),\qquad
g_i(t)\ge0,\ \ \sum_i g_i(t)\le C_t^{\mathrm{unutil}},
\tag{11.25}$$ with $g_i(t)$ the value captured from the unutilised pool; if that value is currently impossible to capture, $g_i(t)=0$ for every feasible action, and knowledge of it affects behaviour only if agents believe it may become accessible later. For a changing system value use the budget equation and its consequence $$C(t+1)=C(t)+A(t)-D(t)+\varepsilon_0(t+1),\qquad
\sum_i\Delta q_i(t)=A(t)-D(t)-\Delta C_t^{\mathrm{unutil}},
\tag{11.26}$$ $A(t)$ newly created or introduced value, $D(t)$ destroyed or removed value, $\varepsilon_0$ a common shock.

#### 11.3.11 Stable policy regimes *\[AT-0 §3.11\]*

**\[SETUP\]** A change in value does not imply $\Delta a_i^*=\Delta C$ (different units); the comparative-static response is $\Delta a_i^*=\frac{tial a_i^*}{tial C}\Delta C$. For a finite action library the region in which action $a^{(k)}$ is optimal is $$\mathcal{R}_k=\Big\{(b,m,C):\ Q(b,a^{(k)},m,C)\ge Q(b,a^{(l)},m,C)\ \ \forall l\Big\}.
\tag{11.27}$$ **\[HYPOTHESIS\]** As long as $(b,m,C)$ stays inside $\mathcal{R}_k$ the same policy remains optimal; a sufficiently large change in system value crosses the boundary into another policy region. This is the precise meaning of the stable periods and regime changes of the value picture in Section 11.2.3.

#### 11.3.12 Merging systems *\[AT-0 §3.12\]*

**\[SETUP\]** With $K$ initially separate systems (population $N_k$, distribution $m_k(t)$, value $C_k(t)$), $N=\sum_{k=1}^K N_k$ and $\lambda_k=N_k/N$, the accounting level is $$m_{\mathrm{merge}}(t)=\sum_{k=1}^{K}\lambda_k m_k(t),\qquad
c_{\mathrm{merge}}(t)=\sum_{k=1}^{K}C_k(t),\qquad
\mu_{\mathrm{merge}}(t)=\sum_{k=1}^{K}\lambda_k\big(m_k(t)\otimes\delta_k\big),
\tag{11.28}$$ the last retaining the original system labels. With $\Gamma_{kl}(t)\in[0,1]$ the degree of interaction between systems $k$ and $l$, an agent of system $k$ responds to the effective population $$\Gamma_{kl}(t)=\begin{cases}0 & t<t_a,\ k\ne l\\ \gamma_{kl}(t) & t_a\le t\le t_b\\ 1 & t>t_b\end{cases},\qquad
\tilde m_k(t)=\frac{\sum_{l=1}^{K}\Gamma_{kl}(t)\lambda_l m_l(t)}{\sum_{l=1}^{K}\Gamma_{kl}(t)\lambda_l},\qquad
\tilde m_k(t)=m_{\mathrm{merge}}(t)\ \ (t>t_b),
\tag{11.29}$$ and more generally $c_{\mathrm{merge}}(t)=\sum_{k}C_k(t)+S(t)-K(t)$ with $S$ synergy or newly accessible value and $K$ integration costs or destroyed value. **\[HYPOTHESIS\]** Population and endowment are weighted sums, but the resulting equilibrium generally is not: once cross-system interactions become possible every agent may change policy and the population must converge to a new fixed point, $$\pi^*=\operatorname{BestResponse}(\mu^*,C^*),\qquad \mu^*=\Phi(\pi^*,\mu^*,C^*).
\tag{11.30}$$

### 11.4 The merger event *\[AT-0 §4\]*

**\[SETUP\]** Cohort $A$ exists from $t_0$ with unnormalised measure $\nu_A(t)=\sum_{i\in A}\delta_{Z_i(t)}$, where the augmented state $Z_i(t)=(X_i(t),q_i(t),B_i(t),\tau_i)$ contains physical state, value, beliefs and type. At $t_a$ cohort $B$ joins: $$\begin{gathered}
\nu(t_a^+)=\nu_A(t_a^-)+\nu_B(t_a),\qquad N(t_a^+)=N_A+N_B,\qquad
m(t_a^+)=\frac{N_A m_A(t_a^-)+N_B m_B(t_a)}{N_A+N_B},\\
C(t_a^+)=C_A(t_a^-)+C_B(t_a)+S_{AB}-K_{AB},\qquad A\leftrightarrow B,\\
\pi_A^{*,\mathrm{before}}\ne\pi_A^{*,\mathrm{after}},\qquad \pi_B^{*,\mathrm{before}}\ne\pi_B^{*,\mathrm{after}},\qquad
\varepsilon(A\cup B)\ne\varepsilon(A)+\varepsilon(B),
\end{gathered}
\tag{11.31}$$ $S_{AB}$ synergy or newly accessible value, $K_{AB}$ merger or integration costs. The addition is only the initial condition; the important change is that cross-interactions $A\leftrightarrow B$ become possible, so policies change and the equilibrium of the combined system must be recalculated from the combined population, value and interaction structure.

#### 11.4.1 Three different meanings of “merger” *\[AT-0 §4.1\]*

**\[SETUP\]** *Population injection* $\nu^+=\nu^-+\nu^{\mathrm{new}}$ (a stream of traders arrives, or two populations begin sharing an environment); *interaction and mixing* through a cross-interaction operator $\mathcal{Q}_{AB}(f_A,f_B)$ (particle collisions, order matching, information transfer, competition, resource exchange); *coarse-graining* $\{Z_1,\dots,Z_n\}\to Y_g=\mathcal{A}(\{Z_i:i\in g\})$, replacing many agents by a group-level description. Two rivers meet through injection and mixing; describing the result as one fluid is coarse-graining.

#### 11.4.2 A unified mesoscopic equation *\[AT-0 §4.2\]*

**\[SETUP\]** With $f_r(t,z)$ the density of agents of type or cohort $r$, $$\frac{tial f_r}{tial t}=-\nabla_z\cdot\big[b_r(z,\alpha_r^*,\mathbf f(t),C(t))f_r\big]
+\frac12\nabla_z\nabla_z:\big[D_r(z,\alpha_r^*,\mathbf f(t),C(t))f_r\big]
+\sum_s\mathcal{Q}_{rs}(f_r,f_s)+S_r^{\mathrm{in}}-S_r^{\mathrm{out}},
\tag{11.32}$$ $b_r$ controlled movement, trends and mean reversion; $D_r=\sigma_r\sigma_r^{\top}$ individual uncertainty; $\mathcal{Q}_{rs}$ interactions between populations; $S^{\mathrm{in}}$ arriving agents or value; $S^{\mathrm{out}}$ exit, cancellation or destruction; $\alpha_r^*$ the optimal policy of type $r$; $\mathcal{Q}_{AB}=0$ before $t_a$. (Restated with equation numbers as (B.14–B.15).)

### 11.5 Mathematical setting *\[AT-0 §5\]*

**Definition 11.1** **(AT-0 Definition 5.1: Aggregation system).** **\[SETUP\]** At time $t$ an aggregation system is $$\mathfrak{S}_t=(\mathcal{E}_t,\mathcal{I}_t,\mathcal{R}_t,\mathcal{G}_t,\mathrm{Agg}),\qquad
x_i(t)\in\mathcal{X},\qquad u_i(t)\in\mathcal{U}_i,
\tag{5.1--5.3}\tag{5.1--5.3}$$ with $\mathcal{E}_t$ the environment, $\mathcal{I}_t=\{1,\dots,N_t\}$ the agents, $\mathcal{R}_t$ the interaction rules, $\mathcal{G}_t$ the interaction network, $\mathrm{Agg}$ the family of aggregation operators; each agent has a state $x_i(t)$ and selects a control $u_i(t)$.

In a financial market $x_i$ may contain wealth, inventory, beliefs, risk limits and outstanding orders, and $u_i$ order placement, cancellation, price, quantity or portfolio allocation; in a physical system $x_i$ mass, charge, spin, energies, position and kinetics, and $u_i$ attractions, emissions, absorptions or scatterings; in ecological or social systems $x_i$ resources, emotions, beliefs, relations and health, and $u_i$ behaviours, conversations, focus, actions.

### 11.6 Multiscale aggregation *\[AT-0 §6\]*

**\[SETUP\]** The initial market experiments use the time scales and observation counts $$\mathcal{H}=\{4,16,64,256\}\ \text{minutes},\qquad n_h=\frac{h}{\Delta t},
\tag{6.1--6.2}\tag{6.1--6.2}$$ $\Delta t$ the base sampling interval (Table 11.1).

**Table 11.1.** Time scales used in the initial experiments (source Table 1) *\[AT-0 §6\]*.

| Scale $h$ | One-minute observations | One-second observations |
|---|---|---|
| 4 minutes | 4 | 240 |
| 16 minutes | 16 | 960 |
| 64 minutes | 64 | 3840 |
| 256 minutes | 256 | 15360 |

**Definition 11.2** **(AT-0 Definition 6.1: Scale-specific state).** **\[SETUP\]** For $h\in\mathcal{H}$ the aggregate state is $X_t^{(h)}=\mathrm{Agg}_h\big(\{x_i(s):i\in\mathcal{I}_s,\ t-h<s\le t\}\big)$ (6.3).

**Conjecture 11.3** **(AT-0 Conjecture 6.2: Scale-invariant interaction principle).** **\[CONJECTURE\]** There exists a common interaction map $\mathcal{M}$ such that the dynamics at scale $h$ can be represented as $$X_{t+1}^{(h)}=\mathcal{M}\big(X_t^{(h)},\theta_h,\varepsilon_{t+1}^{(h)}\big),
\tag{6.4}\tag{6.4}$$ where the functional interaction principle is common across scales while the effective parameters $\theta_h$ change with aggregation and granularity. (Status in Chapter 14: the aggregation identities are scale-invariant, the dynamical laws are not — exponents differ by domain; editorial.)

### 11.7 Changing equilibrium *\[AT-0 §7\]*

**\[SETUP\]** With $P_t$ the observed price, $y_t=\log P_t$ (7.1), a general causal equilibrium estimator at scale $h$ is a convex combination of past log prices, $$\widehat q_t^{(h)}=\sum_{k=0}^{n_h-1}w_{t,k}^{(h)}\,y_{t-k},\qquad
w_{t,k}^{(h)}\ge0,\quad\sum_{k=0}^{n_h-1}w_{t,k}^{(h)}=1,
\tag{7.2--7.3}\tag{7.2--7.3}$$ with weights from a moving average, exponential weighting, local regression or an adaptive causal estimator.

**Definition 11.4** **(AT-0 Definition 7.1: Equilibrium displacement).** **\[SETUP\]** The displacement, its standardised form ($s_t^{(h)}$ a causal local scale estimate), and the equilibrium velocity and acceleration at scale $h$ are $$d_t^{(h)}=y_t-\widehat q_t^{(h)},\qquad
z_t^{(h)}=\frac{d_t^{(h)}}{s_t^{(h)}+\epsilon},\qquad
v_t^{(h)}=\widehat q_t^{(h)}-\widehat q_{t-1}^{(h)},\qquad
a_t^{(h)}=v_t^{(h)}-v_{t-1}^{(h)}.
\tag{7.4--7.7}\tag{7.4--7.7}$$

**Proposition 11.5** **(AT-0 Proposition 7.2: Consistency of conditional equilibria).** **\[PROVED\]** Suppose the fine-scale information set contains the coarse-scale one, $\mathcal{F}_t^{(h_2)}\subseteq\mathcal{F}_t^{(h_1)}$, and the equilibria are conditional expectations of a future settlement value $Y$, $q_t^{(h_j)}=\mathbb{E}[Y\mid\mathcal{F}_t^{(h_j)}]$. Then $$\mathbb{E}\big[q_t^{(h_1)}\mid\mathcal{F}_t^{(h_2)}\big]=q_t^{(h_2)}.
\tag{7.8}\tag{7.8}$$

*Proof.* Tower property of conditional expectation. (Chapter 14 reports it as proved and held on data: exact merging of additive and mergeable quantities; editorial.) $\square$

### 11.8 The agent control problem *\[AT-0 §8\]*

**\[SETUP\]** Agent $i$ seeks an admissible control $u_i$ and follows a controlled state equation: $$\begin{gathered}
u_i^*\in\operatorname*{arg\,max}_{u_i\in\mathcal{U}_i}\mathbb{E}\Big[\int_t^{T}e^{-\rho(s-t)}\big(\Pi_i(s)-\lambda_i\mathcal{R}_i(s)-\kappa_i\mathcal{C}_i(s)\big)\mathrm{d}s+\Phi_i(x_i(T))\Big],\\
\mathrm{d}x_i(t)=b_i\big(x_i(t),u_i(t),m_t,\widehat q_t\big)\mathrm{d}t+\sigma_i(t)\,\mathrm{d}W_i(t),
\end{gathered}
\tag{8.1--8.2}\tag{8.1--8.2}$$ $\Pi_i$ reward or profit, $\mathcal{R}_i$ risk, $\mathcal{C}_i$ interaction or transaction cost, $\Phi_i$ terminal value, $m_t$ the aggregate distribution of agents, $\widehat q_t$ the estimated equilibrium.

### 11.9 Empirical hypotheses *\[AT-0 §9\]*

Statuses are those assigned in Chapter 14 (Table “the original framework inside the general one”).

**Hypothesis 11.6** **(AT-0 Hypothesis 9.1: Restoration toward equilibrium).** **\[REFUTED AS STATED\]** Large absolute displacement is followed by movement toward the scale-specific equilibrium; the corresponding restoring-move statistic is positive when the move is toward the estimated equilibrium: $$\mathbb{E}\big[d_{t+H}^{(h)}-d_t^{(h)}\mid d_t^{(h)}\big]\,d_t^{(h)}<0,\qquad
R_{t,H}^{(h)}=-d_t^{(h)}\big(d_{t+H}^{(h)}-d_t^{(h)}\big).
\tag{9.1--9.2}\tag{9.1--9.2}$$ Status assigned in Chapter 14: refuted as stated — restoration measured against a moving-average equilibrium is mechanical (Part I Theorem 6.1 there); what survives is a small short-horizon reversal below trading costs.

**Hypothesis 11.7** **(AT-0 Hypothesis 9.2: Equilibrium migration).** **\[OPEN\]** Supply–demand pressure $f_t^{(h)}$ predicts movement in the estimated equilibrium, $$\mathbb{E}\big[\widehat q_{t+H}^{(h)}-\widehat q_t^{(h)}\mid f_t^{(h)}\big]\ne0.
\tag{9.3}\tag{9.3}$$ Status assigned in Chapter 14: open — needs a dynamic test.

**Hypothesis 11.8** **(AT-0 Hypothesis 9.3: Cross-scale coherence).** **\[MEASURED\]** When equilibrium velocities agree across scales, directional price movement is more persistent; when the scales disagree, turbulence or restoration becomes more likely. Scale coherence is $$C_t=\frac{1}{|\mathcal{H}|}\sum_{h\in\mathcal{H}}\operatorname{sign}\big(v_t^{(h)}\big),
\tag{9.4}\tag{9.4}$$ $C_t=1$ complete directional agreement, values near zero disagreement. Status assigned in Chapter 14: measured, as the collective share $\kappa$ and the agreement statistics there.

### 11.10 Statistical tests *\[AT-0 §10\]*

**\[SETUP\]** Restoration is tested by the regression and one-sided test, migration by a second regression ($Z_t$ controls): $$\Delta_H d_t^{(h)}=\alpha_h+\beta_h d_t^{(h)}+\gamma_h^{\top}Z_t+\varepsilon_{t+H},\qquad
H_0:\beta_h\ge0,\ \ H_1:\beta_h<0,\qquad
\Delta_H\widehat q_t^{(h)}=\alpha_h+\gamma_h f_t^{(h)}+\delta_h^{\top}Z_t+\eta_{t+H}.
\tag{10.1--10.3}\tag{10.1--10.3}$$ **\[PRACTICE\]** The empirical process distinguishes (1) exploratory structural diagnostics, (2) chronological walk-forward validation, (3) final out-of-sample evaluation; random train–test shuffling is not used for time-series evaluation.

### 11.11 Python experiments *\[AT-0 §11\]*

**Experiment 11.9** **(AT-0 Experiment 11.1: Initial Bitcoin experiment).** **\[REFUTED AS STATED\]** For each $h\in\{4,16,64,256\}$: (1) estimate the causal equilibrium; (2) calculate displacement, velocity and acceleration; (3) construct supply–demand and turbulence features; (4) define forward labels without look-ahead leakage; (5) run the hypothesis regressions; (6) evaluate predictions using walk-forward windows. Status: the hindsight test of Chapter 14 showed the restoration label of Section 11.12 to be mechanical (slopes within 0.022 of a random walk on 132,480 BTC minutes); the experiment’s result tables are Table 11.3, Table 11.4, Table 11.5, Table 11.6 and Table 11.7.

The source’s template for recording a Python experiment (its Listing 1, “Example multiscale hypothesis test”) and the instruction for including external files:

``` python
scale = 64
horizon = 60

frame = make_hypothesis_frame(
    features,
    scale=scale,
    horizon=horizon
)

results = run_hypothesis_tests(frame)
print(results)
```

### 11.12 Practical implementations *\[AT-0 §12\]*

**\[SETUP\]** The section is a set of working definitions with the author’s own annotations. The forecast is a linear model on 18 standardised features (baseline coefficient $\beta_0$, one coefficient per feature of the “plus_flow” list), built on one-minute bars $(O_t,H_t,L_t,C_t,V_t)$: $$\begin{gathered}
S(t),\qquad \widehat R_{t,t+60}=\beta_0+\sum_{j=1}^{18}\beta_j\tilde x_{j,t},\qquad
p_t=\log(C_t),\quad r_t=p_t-p_{t-1},\quad w=64,\ h=60,\\
Y_t^{(h)}=p_{t+h}-p_t=\log\Big(\frac{C_{t+h}}{C_t}\Big),\qquad
\hat\mu=\mathbb{E}[Y_t^{(h)}\mid F_t],\\
E_t=\lambda p_{t-1}+(1-\lambda)E_{t-1},\qquad D_t=p_t-E_t,\qquad
Y_t^{(h)}=E_{t+h}+D_{t+h}-D_t,
\end{gathered}
\tag{11.33}$$ where $\hat\mu$ estimates the average correct return, $E_t$ is the equilibrium as a lagged exponential moving average of log price, $D_t$ the standard displacement and the last line the “corrected equilibrium for each scale”. **\[REFUTED AS STATED\]** The author’s annotations in the source reject the EMA definition and the corrected-equilibrium label as wrong (errors attributed to an AI assistant); Chapter 14 proves why (the moving average makes $Y$ depend on $D_t$ mechanically). Here $C_t$ is the close price, not the system value of Section 11.3.11 (editorial).

### 11.13 Results *\[AT-0 §13\]*

The source’s §13 (13.1 Descriptive results, 13.2 Hypothesis-test results, 13.3 Walk-forward performance) contains headings only; its six floating tables (source Tables 2–7, printed inside Appendix B) are the only results and are reproduced here with every number. All are hindsight diagnostics on the dataset of Table 11.2; the consolidated Bitcoin study is in Subappendix D.1 (editorial).

**Table 11.2.** Bitcoin dataset used in the initial empirical study (source Table 2) *\[AT-0 §13\]*.

| Property | Description |
|---|---|
| Instrument | BTC/USDT |
| Market | Binance spot market |
| Data source | Crypto market-data feed |
| Sampling interval | One-minute closed bars |
| Sample period | 1 January 2026 00:00 UTC – 13 July 2026 19:59 UTC |
| Observations | 279,120 (dataframe index 0 to 279,119; all bars marked closed) |
| Recorded fields | Timestamp, open, high, low, close and volume |
| Unavailable fields | Spread and real volume |

**Table 11.3.** Outcomes conditional on standardised equilibrium displacement $z_t$ (source Table 3) *\[AT-0 §13\]*. Returns in basis points, rates in percent. The bin counts sum to 804,838 and do not match the 279,120-row dataframe of Table 11.2; the source says it must state before publication whether these diagnostics use a longer sample, pooled assets, pooled scales or another transformed dataset.

| $z_t$ interval | $N$ | Mean return | Relative return | Restoration | Settlement | Settlement hit |
|---|---|---|---|---|---|---|
|   |   | (bps) | (bps) | (%) | (%) | (%) |
| $(-\infty,-2.0]$ | 80481 | 0.799 | 30.478 | 81.65 | 30.17 | 89.39 |
| $(-2.0,-1.0]$ | 126194 | -0.472 | 15.863 | 63.41 | 25.34 | 93.79 |
| $(-1.0,-0.5]$ | 91648 | -0.325 | 8.053 | 40.24 | 22.97 | 97.35 |
| $(-0.5,0.0]$ | 99966 | -0.003 | 2.819 | 14.45 | 21.88 | 99.23 |
| $(0.0,0.5]$ | 101024 | -0.225 | -3.032 | 15.23 | 22.11 | 99.27 |
| $(0.5,1.0]$ | 95956 | -0.197 | -8.693 | 42.57 | 23.35 | 97.13 |
| $(1.0,2.0]$ | 131955 | -0.446 | -16.102 | 65.72 | 25.45 | 93.59 |
| $(2.0,\infty)$ | 77614 | -1.560 | -28.449 | 83.11 | 29.97 | 88.89 |

**Table 11.4.** Dependence diagnostics across equilibrium scales $h$ and forecast horizons $H$ (source Table 4) *\[AT-0 §13\]*. Information coefficients compare the future return $r$ with displacement $d$, flow pressure $f$ and equilibrium velocity $v$; negative values mean positive state values go with lower subsequent returns.

| $h$ (min) | $H$ (min) | IC$(d,r)$ | IC$(f,r)$ | IC$(v,r)$ | Extreme restoration (%) | Settlement hit (%) |
|---|---|---|---|---|---|---|
| 4 | 5 | -0.0234 | -0.0164 | -0.0218 | 67.56 | 66.65 |
| 4 | 15 | -0.0225 | -0.0197 | -0.0195 | 67.47 | 96.11 |
| 4 | 60 | -0.0176 | -0.0177 | -0.0149 | 67.22 | 99.97 |
| 4 | 240 | -0.0105 | -0.0091 | -0.0086 | 66.67 | 100.00 |
| 16 | 5 | -0.0342 | -0.0274 | -0.0285 | 69.39 | 43.99 |
| 16 | 15 | -0.0399 | -0.0385 | -0.0353 | 70.90 | 84.25 |
| 16 | 60 | -0.0293 | -0.0296 | -0.0241 | 70.62 | 99.96 |
| 16 | 240 | -0.0166 | -0.0167 | -0.0145 | 69.97 | 100.00 |
| 64 | 5 | -0.0351 | -0.0222 | -0.0232 | 64.13 | 17.92 |
| 64 | 15 | -0.0440 | -0.0303 | -0.0286 | 68.95 | 48.06 |
| 64 | 60 | -0.0367 | -0.0243 | -0.0242 | 71.34 | 91.96 |
| 64 | 240 | -0.0248 | -0.0137 | -0.0176 | 71.13 | 100.00 |
| 256 | 5 | -0.0280 | -0.0096 | -0.0083 | 58.58 | 4.38 |
| 256 | 15 | -0.0370 | -0.0147 | -0.0152 | 63.11 | 16.78 |
| 256 | 60 | -0.0358 | -0.0145 | -0.0217 | 69.20 | 53.06 |
| 256 | 240 | -0.0292 | -0.0096 | -0.0198 | 71.47 | 93.15 |

**Table 11.5.** Standardised coefficients for the 64-minute feature model (source Table 5) *\[AT-0 §13\]*: predicted basis-point change for a one-standard-deviation increase in each feature, conditional on the others; ordered by absolute magnitude.

| Feature | Coeff. (bps) | Feature | Coeff. (bps) |
|---|---|---|---|
| Return | -1.690 | Semivolatility balance | -0.309 |
| Equilibrium velocity | 0.966 | Cross-scale direction agreement | 0.134 |
| Realised volatility | 0.662 | Volume ($z$)-score | -0.132 |
| Episode age | -0.620 | Flow pressure | 0.097 |
| Path efficiency | 0.539 | Displacement ($z$)-score | -0.089 |
| Equilibrium acceleration | 0.419 | Episode efficiency | -0.033 |
|   |   | Cross-scale velocity dispersion | -0.005 |

**Table 11.6.** Chronological out-of-sample comparison of nested feature models (source Table 6) *\[AT-0 §13\]*. $N=11{,}972$ observations for every model; direction edge is relative to the majority-class accuracy of 50.2673%; a negative $R_0^2$ means the model does not beat the zero-return benchmark under squared-error loss.

| Model | $R_0^2$ | Dir. accuracy (%) | Dir. edge (pp) | Spearman IC | Pearson $r$ | Calibration slope |
|---|---|---|---|---|---|---|
| Trend only | -0.0031 | 50.5763 | 0.3091 | 0.0125 | -0.0027 | -0.0503 |
| Plus equilibrium | -0.0063 | 50.8938 | 0.6265 | 0.0141 | 0.0004 | 0.0050 |
| Plus flow | -0.0079 | 51.4200 | 1.1527 | 0.0205 | 0.0025 | 0.0271 |
| Plus volatility | -0.0174 | 50.8019 | 0.5346 | 0.0100 | 0.0136 | 0.0933 |
| Full multiscale | -0.0497 | 50.6849 | 0.4176 | 0.0055 | 0.0153 | 0.0641 |

**Table 11.7.** Conditional outcomes by equilibrium-motion and flow-pressure state (source Table 7) *\[AT-0 §13\]*. The neutral-state row holds one observation, retained for completeness only and to be omitted from formal inference.

| Motion state | Flow state | $N$ | Future return (bps) | Restoring move (bps) | Restoration (%) | Settlement hit (%) |
|---|---|---|---|---|---|---|
| Contracting | Opposes displacement | 23365 | 0.210 | 13.204 | 59.44 | 93.76 |
| Contracting | Supports displacement | 46462 | -2.437 | 16.331 | 63.41 | 93.07 |
| Expanding | Opposes displacement | 71499 | -0.791 | 16.531 | 67.10 | 93.72 |
| Expanding | Supports displacement | 274958 | -0.038 | 23.783 | 74.79 | 91.16 |
| Neutral | Supports displacement | 1 | 31.396 | 23.652 | 100.00 | 100.00 |

**\[MEASURED\]** Read together (editorial): the information coefficients are negative at every $(h,H)$ and largest in magnitude for $h=64$, $H=15$ (IC$(d,r)=-0.0440$); extreme-bin restoration rates are 81.65% and 83.11%; out of sample the best nested model (plus flow) reaches 51.42% direction accuracy with $R_0^2=-0.0079$, so no model beats the zero-return benchmark. These are the numbers that Chapter 14 later explains as the mechanical restoration of a moving average.

### 11.14 Limitations and open questions *\[AT-0 §14\]*

**\[OPEN\]** The principal unresolved questions: whether equilibrium is identifiable from price and volume alone; whether the aggregation rule is genuinely invariant across scales; how interaction rules change under different market regimes; whether apparent restoration survives transaction costs; how agent feedback changes the estimated settlement path.

### 11.15 Conclusion *\[AT-0 §15\]*

**\[PLAN\]** The document is an initial framework connecting local matching, multiscale aggregation, changing equilibrium and agent control; the next stage is to refine each conjecture into a precise mathematical statement and connect each empirical hypothesis to a reproducible Python test (done in Chapter 12 and Chapter 14; editorial).

### 11.16 Appendix A: Notation *\[AT-0 App. A\]*

| Symbol | Meaning | Symbol | Meaning |
|---|---|---|---|
| $\mathcal{E}_t$ | Environment | $d_t^{(h)}$ | Displacement from equilibrium |
| $\mathcal{I}_t$ | Set of agents | $v_t^{(h)}$ | Equilibrium velocity |
| $\mathcal{R}_t$ | Interaction rules | $a_t^{(h)}$ | Equilibrium acceleration |
| $\mathrm{Agg}_h$ | Aggregation operator at scale $h$ | $f_t^{(h)}$ | Supply–demand pressure |
| $P_t$ | Observed price | $C_t$ | Cross-scale coherence |
| $\widehat q_t^{(h)}$ | Estimated equilibrium at scale $h$ |   |   |

### 11.17 Appendix B: Population mergers and multiscale system equilibria *\[AT-0 App. B\]*

**\[SETUP\]** The framework is broader than a mean-field game: at the microscopic level strategic agents solve stochastic control problems under partial information; at the mesoscopic level the population is a kinetic or mean-field distribution; at sufficiently large spatial and temporal scales it may admit a deterministic hydrodynamic or aggregate description. Passive elements (physical particles) need not solve an optimisation problem; strategic agents choose policies to optimise their individual cost–reward functionals; both are studied in one aggregation framework.

#### 11.17.1 Initial population *\[AT-0 B.1\]*

**\[SETUP\]** Population $A$ enters at $t_0$; the augmented state of agent $i\in A$, the unnormalised empirical measure, its mass and the probability distribution are $$Z_{i,t}=(X_{i,t},q_{i,t},B_{i,t},\tau_i)\in\mathcal Z,\qquad
\nu_t^A=\sum_{i\in A}\delta_{Z_{i,t}},\qquad
N_A(t)=\nu_t^A(\mathcal Z),\qquad
m_t^A=\frac{\nu_t^A}{N_A(t)},
\tag{B.1--B.4}\tag{B.1--B.4}$$ ($X$ physical state, $q$ value held, $B$ belief state, $\tau$ type). The unnormalised measure is required because $m_t^A$ does not retain the total number of agents.

#### 11.17.2 Entry and merger of a second population *\[AT-0 B.2\]*

**\[SETUP\]** Population $B$ enters at $t_a>t_0$: $$\begin{gathered}
\nu_{t_a^+}=\nu_{t_a^-}^A+\nu_{t_a}^B,\qquad
N(t_a^+)=N_A(t_a^-)+N_B(t_a),\\
m_{t_a^+}=\frac{N_A(t_a^-)\,m_{t_a^-}^A+N_B(t_a)\,m_{t_a}^B}{N_A(t_a^-)+N_B(t_a)},\qquad
C_{t_a^+}=C_{t_a^-}^A+C_{t_a}^B+S_{AB}-K_{AB},
\end{gathered}
\tag{B.5--B.8}\tag{B.5--B.8}$$ $S_{AB}$ value created through synergy or newly available interactions, $K_{AB}$ merger, integration or dissipation costs. **\[HYPOTHESIS\]** The addition gives only the initial post-merger state; once cross-population interactions are introduced, optimal policies and population dynamics change, so for the equilibrium operator $\mathcal E(\cdot)$ $$\mathcal E(A\cup B)\ne\mathcal E(A)+\mathcal E(B).
\tag{B.9}\tag{B.9}$$

#### 11.17.3 Three forms of aggregation *\[AT-0 B.3\]*

**\[SETUP\]** Three mathematically different operations: $$\begin{gathered}
\text{injection: } \nu^+=\nu^-+\nu^{\mathrm{new}};\qquad
\text{interaction and mixing: } \mathcal{Q}_{AB}(f_A,f_B);\\
\text{coarse-graining: } \{Z_i:i\in g\}\longmapsto Y_g=\mathcal{A}_g(\{Z_i:i\in g\}).
\end{gathered}
\tag{B.10--B.12}\tag{B.10--B.12}$$ Injection changes the composition, interaction changes the dynamics, coarse-graining changes the scale at which the system is represented.

#### 11.17.4 Controlled kinetic population dynamics *\[AT-0 B.4\]*

**\[SETUP\]** With $f_r(t,z)$ the unnormalised density of type or population $r=1,\dots,R$ and $\mathbf f_t=(f_1(t,\cdot),\dots,f_R(t,\cdot))$ (B.13), the controlled kinetic dynamics are $$\begin{aligned}
\frac{tial f_r}{tial t}={}&-\nabla_z\cdot\big[b_r(z,\alpha_r^\star,\mathbf f_t,C_t)f_r\big]
+\frac12\sum_{k,\ell}\frac{tial^2}{tial z_ktial z_\ell}\big[(D_r)_{k\ell}(z,\alpha_r^\star,\mathbf f_t,C_t)f_r\big]\\
&+\sum_{s=1}^{R}\mathcal{Q}_{rs}(f_r,f_s)+S_r^{\mathrm{in}}-S_r^{\mathrm{out}},
\qquad D_r=\sigma_r\sigma_r^{\top},
\end{aligned}
\tag{B.14--B.15}\tag{B.14--B.15}$$ where $b_r$ is controlled movement, interaction drift, trend following, mean reversion and dissipation; $D_r$ individual or environmental uncertainty; $\mathcal{Q}_{rs}$ pairwise interactions, collisions, transactions or order matching; $S_r^{\mathrm{in}}$ entering agents or value; $S_r^{\mathrm{out}}$ exit, cancellation or destruction; $\alpha_r^\star$ the optimal policy of type $r$. Before $A$ and $B$ merge the cross-interaction vanishes, and a gradual merger is $$\mathcal{Q}_{AB,t}=0\ (t<t_a),\qquad \mathcal{Q}_{AB,t}=\gamma_{AB}(t)\,\mathcal{Q}_{AB},\qquad
\gamma_{AB}(t)=\begin{cases}0, & t<t_a,\\ \gamma(t)\in[0,1], & t_a\le t\le t_b,\\ 1, & t>t_b,\end{cases}
\tag{B.16--B.18}\tag{B.16--B.18}$$ $t_a$ the beginning of the merger, $t_b$ complete integration.

#### 11.17.5 Strategic and distributional equilibrium *\[AT-0 B.5\]*

**\[SETUP\]** Strategic agents satisfy the best-response condition; for fixed environmental conditions and system value a stationary distribution satisfies the stationary kinetic equation; the equilibrium of the complete strategic system is the coupled pair: $$\begin{gathered}
\alpha_r^\star\in\operatorname{BR}_r(\mathbf f^\star,C^\star),\\
0=-\nabla_z\cdot\big[b_r(z,\alpha_r^\star,\mathbf f^\star,C^\star)f_r^\star\big]
+\frac12\sum_{k,\ell}\frac{tial^2}{tial z_ktial z_\ell}\big[(D_r)_{k\ell}(z,\alpha_r^\star,\mathbf f^\star,C^\star)f_r^\star\big]
+\sum_{s=1}^{R}\mathcal{Q}_{rs}(f_r^\star,f_s^\star)+S_r^{\mathrm{in},\star}-S_r^{\mathrm{out},\star},\\
\alpha_r^\star\in\operatorname{BR}_r(\mathbf f^\star,C^\star),\qquad
0=\text{transport}+\text{diffusion}+\text{interaction}+\text{entry}-\text{exit}.
\end{gathered}
\tag{B.19--B.21}\tag{B.19--B.21}$$ The first condition is strategic, the second distributional; physical particles satisfy only the distributional condition. If a central planner chooses policies to maximise collective welfare, (B.19) is replaced by a mean-field control problem.

#### 11.17.6 Equilibrium currents *\[AT-0 B.6\]*

**\[SETUP\]** The population current of type $r$ and the current form of the population equation are $$_k=b_{r,k}(t,z)f_r(t,z)-\frac12\sum_\ell\frac{tial}{tial z_\ell}\big[(D_r)_{k\ell}(t,z)f_r(t,z)\big],\qquad
\frac{tial f_r}{tial t}=-\nabla_z\cdot J_r+\sum_s\mathcal{Q}_{rs}(f_r,f_s)+S_r^{\mathrm{in}}-S_r^{\mathrm{out}};
\tag{B.22--B.23}\tag{B.22--B.23}$$ a detailed-balance equilibrium has $tial_t f_r=0$, $J_r=0$ (B.24); a non-equilibrium steady state has $tial_t f_r=0$, $J_r\ne0$ (B.25). **\[HYPOTHESIS\]** The latter permits continuing internal movement, transactions and resource transfers under a stationary aggregate distribution and is likely the more relevant concept for rivers, gases with external forcing, order books and financial markets.

#### 11.17.7 Stability and post-merger relaxation *\[AT-0 B.7\]*

**\[SETUP\]** With $\mathbf f_{AB}^\star$ the new post-merger equilibrium, write $\mathbf f_t=\mathbf f_{AB}^\star+\delta\mathbf f_t$ (B.26) and linearise: $$\frac{tial\delta\mathbf f_t}{tial t}=\mathcal{A}_{\mathbf f_{AB}^\star}\delta\mathbf f_t+F_t^{\mathrm{merger}}+F_t^{\mathrm{shock}},
\qquad
\big\|\mathbf f_t-\mathbf f_{AB}^\star\big\|\le K\exp\Big(-\frac{t-t_a}{\tau_{AB}}\Big)\big\|\mathbf f_{t_a^+}-\mathbf f_{AB}^\star\big\|,
\tag{B.27--B.28}\tag{B.27--B.28}$$ $\mathcal{A}_{\mathbf f_{AB}^\star}$ the linearised evolution operator, whose eigenvalues characterise the local behaviour: negative real parts mean reversion and dissipation; positive real parts instability or trend amplification; non-zero imaginary parts oscillatory adjustment; eigenvalues near zero slow or metastable behaviour. **\[HYPOTHESIS\]** (B.28) holds if the equilibrium is exponentially stable, with $\tau_{AB}$ the characteristic relaxation time of the combined system.

#### 11.17.8 Hierarchical coarse-graining *\[AT-0 B.8\]*

**\[SETUP\]** Partition the agents into groups $g$ with group state, group population measure and hierarchy $$\begin{gathered}
Y_{g,t}=\big(N_{g,t},C_{g,t},\overline X_{g,t},\Sigma_{g,t},J_{g,t}\big),\qquad
M_t^{G}=\sum_g w_g\,\delta_{Y_{g,t}},\\
\{Z_i\}_{i=1}^{N}\xrightarrow{\ \mathcal{A}_1\ }\{Y_g\}_{g=1}^{G}\xrightarrow{\ \mathcal{A}_2\ }\{Y_G\}_{G=1}^{H}\xrightarrow{\ \mathcal{A}_3\ }\text{macroscopic field},
\end{gathered}
\tag{B.29--B.31}\tag{B.29--B.31}$$ $\overline X_{g,t}$, $\Sigma_{g,t}$ the group mean and covariance, $J_{g,t}$ its aggregate current. **\[HYPOTHESIS\]** Representing a group by a lower-dimensional macrostate is justified when its internal relaxation time is much smaller than the interaction time between groups, $$\tau_{\mathrm{within}}\ll\tau_{\mathrm{between}};
\tag{B.32}\tag{B.32}$$ otherwise the internal distribution cannot be discarded without losing information needed to predict future dynamics — the closure problem (resolved for linear dynamics in Section 12.13; editorial).

#### 11.17.9 From stochastic agents to deterministic fields *\[AT-0 B.9\]*

**\[KNOWN RESULT\]** Under exchangeability, weak dependence, finite variance and the absence of dominant agents the empirical distribution may converge to a mean-field limit with fluctuations of order $N^{-1/2}$; with common noise and common-information filtration $\mathcal{F}_t^0$ the limit is the conditional law, random before the common shock is realised: $$m_t^N\xrightarrow[N\to\infty]{\text{a.s.}}m_t,\qquad
m_t^N=m_t+\frac{1}{\sqrt N}\Xi_t+o_p\big(N^{-1/2}\big),\qquad
m_t=\mathcal{L}\big(X_{i,t}\mid\mathcal{F}_t^0\big).
\tag{B.33--B.35}\tag{B.33--B.35}$$ Individually uncertain behaviour may thus generate an approximately deterministic aggregate field; common shocks, correlated information, herding and major agents may preserve aggregate stochasticity.

#### 11.17.10 Scale-dependent equilibrium *\[AT-0 B.10\]*

**\[SETUP\]** With $\Phi_\Delta$ the population evolution operator over an interval of length $\Delta$, an equilibrium at scale $\Delta$ is a fixed point with a scale-$\Delta$ best response: $$\mathbf f_{t+\Delta}=\Phi_\Delta(\mathbf f_t;\pi_t,C_t),\qquad
f^{\star,\Delta}=\Phi_\Delta\big(f^{\star,\Delta};\pi^{\star,\Delta},C^{\star,\Delta}\big),\qquad
\pi^{\star,\Delta}\in\operatorname{BR}_\Delta\big(f^{\star,\Delta},C^{\star,\Delta}\big).
\tag{B.36--B.38}\tag{B.36--B.38}$$ **\[PROVED\]** A one-step fixed point is a fixed point at every integer scale, $\Phi_1(f^\star)=f^\star\Rightarrow\Phi_\Delta(f^\star)=f^\star$ (B.39); the converse need not hold: $\Phi_{100}(f)=f$ (B.40) may be a periodic trajectory returning after 100 steps. To distinguish stationary from cyclic behaviour define the state–action occupation measure and the scale-dependent behavioural equilibrium $$\Gamma_t^\Delta(\mathrm{d}z,\mathrm{d}a)=\frac{\int_t^{t+\Delta}\nu_s(\mathrm{d}z)\,\pi_s(\mathrm{d}a\mid z)\,\mathrm{d}s}{\int_t^{t+\Delta}N_s\,\mathrm{d}s},\qquad
\Gamma_t^\Delta\approx\Gamma_{t+\Delta}^\Delta.
\tag{B.41--B.42}\tag{B.41--B.42}$$

#### 11.17.11 Interpretation across systems *\[AT-0 B.11\]*

**\[KNOWN RESULT\]** Gas particles and water molecules illustrate the passage from microscopic particle dynamics to kinetic and hydrodynamic equations without solving reward–cost problems; market participants are partially informed strategic agents. For physical systems the large-scale variables are moments of a kinetic density $f(t,x,v)$, $$\rho(t,x)=\int_{\mathbb{R}^d}f(t,x,v)\,\mathrm{d}v,\qquad
\rho(t,x)u(t,x)=\int_{\mathbb{R}^d}v\,f(t,x,v)\,\mathrm{d}v,
\tag{B.43--B.44}\tag{B.43--B.44}$$ which under conservation, local-equilibrium and closure assumptions satisfy Euler- or Navier–Stokes-type equations. **\[SETUP\]** For markets the analogous aggregates are buy-order density, sell-order density, order-flow velocity, liquidity, imbalance and transaction value; their macroscopic equations must be derived from the matching, cancellation and information laws, not assumed identical to fluid equations.

#### 11.17.12 Central research object *\[AT-0 B.12\]*

**\[SETUP\]** The central object is the response of a scale-dependent equilibrium to population mergers, value changes, information changes and cross-system interactions, $$\mathfrak{E}_\Delta=\big(f^{\star,\Delta},\pi^{\star,\Delta},J^{\star,\Delta},\tau_\Delta\big),
\tag{B.45}\tag{B.45}$$ equilibrium distribution, policy, current and characteristic relaxation time. **\[OPEN\]** The principal question is how $\mathfrak{E}_\Delta(A\cup B)$ (B.46) is related to the separate pre-merger equilibria $\mathfrak{E}_\Delta(A)$ and $\mathfrak{E}_\Delta(B)$ (B.47), and whether the relation stays consistent under aggregation from agents to groups and from groups to macroscopic fields. (Chapter 14: equilibria are emergent, not additive — open at the level of dynamics; editorial.)

### 11.18 Appendix C: Mean field game formulas *\[AT-0 App. C\]*

**\[KNOWN RESULT\]** The mean-field game system (Hamilton–Jacobi equation (1), Kolmogorov–Fokker–Planck equation (2), initial and terminal conditions) is $$\begin{gathered}
-tial_t u-\nu\Delta u+H(x,Du,m)=0\quad\text{in }(0,T)\times\mathbb{R}^d,\\
tial_t m-\nu\Delta m-\operatorname{div}\big(H_p(x,Du,m)\,m\big)=0\quad\text{in }(0,T)\times\mathbb{R}^d,\\
m(0)=m_0,\qquad u(x,T)=G(x,m(T))\quad\text{in }\mathbb{R}^d.
\end{gathered}
\tag{11.34}$$ An average agent controls its movement $\alpha$ to influence the population’s location, $\mathrm{d}X_s=b(X_s,\alpha_s,m(s))\mathrm{d}s+\sqrt{2\nu}\,\mathrm{d}B_s$, $\nu$ a parameter and $B$ a standard Brownian motion, and minimises the expected cost over $[0,T]$ with running cost $L$ and terminal cost $G$; the value function at $(t,x)$ is $$\mathcal C=\mathbb{E}\Big[\int_0^T L(X_s,\alpha_s,m(s))\mathrm{d}s+G(X_T,m(T))\Big],\qquad
u(t,x)=\inf_a\mathbb{E}\Big[\int_t^T L(X_s,\alpha_s,m(s))\mathrm{d}s+G(X_T,m(T))\Big],
\tag{11.35}$$ tracked by the Hamilton–Jacobi equation, with optimal action $\alpha^*(x,t)=D_pH(x,m,Du)$. Agents are small and cannot single-handedly change the population, so each adapts the optimal control and the population moves accordingly — a Nash equilibrium in which all agents respond to the others’ strategies; the optimal control then yields the Kolmogorov–Fokker–Planck equation.

#### 11.18.1 “Navier stokes”: the programme statement *\[AT-0 C.1\]*

**\[PLAN\]** The subsection carries no fluid equations; it states the three questions and the method of the rigorous layer (Chapter 12). *Individual*: how a single agent holding part of the information chooses actions to optimise an uncertain stream of rewards net of costs. *Collective*: which deterministic equations govern the population’s distribution and aggregate cost–reward as $N$ grows, and how a conserved or fluctuating total value shapes the competition. *Cross-scale*: how descriptions compose — one-step into long-horizon behaviour, single agents into groups, separate systems into merged systems — and which equilibrium concepts survive each aggregation. The organising analogy is the hydrodynamic-limit programme of statistical mechanics (molecular dynamics $\to$ kinetic description $\to$ fluid equations; two rivers merge and become the motion of a sea), with a controlled stochastic system in place of Newtonian dynamics and the mean-field limit of a game as the passage to the continuum (the source cites \[1, 2, 3\], of which only \[1\], Rózsa and Tóth on exact linear lumping, appears in its reference list; editorial). The motivating instantiation is financial: streams of traders arriving into an order-matching mechanism, competing for a value pool that is injected, contested and dissipated, exhibiting mean reversion, trends and shocks. *Method*: claims are stratified by rigour — exact statements (dynamic-programming decompositions, semigroup consistency, balance laws, conservation-by-construction mechanisms) as propositions; asymptotic statements (propagation of chaos, turnpike and averaging, smooth dependence of equilibria on aggregates) under explicit assumptions; programmatic results as target theorems; structural hypotheses as conjectures; physical correspondences (statistical ensembles, chemical potential, energy cascades) confined to remarks with no probative weight.

### 11.19 Appendix D: Notation and standing conventions *\[AT-0 App. D\]*

**\[SETUP\]** Time is primarily discrete, $t\in\{t_0,t_0+1,\dots,T\}$, with continuum analogues where they clarify structure; integrals over measures are written $\int f\,\mathrm{d}m$ or $\int f(x)\,m(\mathrm{d}x)$ interchangeably; suprema over policies are over admissible policies as defined in Section E (Chapter 12).

| Symbol | Meaning |
|---|---|
| $\mathcal{X}\subseteq\mathbb{R}^d$ | state space (agent positions; $d=3$ in the basic instance) |
| $\mathcal{A}$ | action space: finite library $\{a^{(1)},\dots,a^{(K)}\}$ or $\mathcal{A}\subseteq\mathbb{R}^p$ |
| $\mathcal{P}(\cdot)$, $\mathcal{M}_+(\cdot)$ | probability measures; finite non-negative measures |
| $X_t^i\in\mathcal{X}$ | state of agent $i$ at time $t$; $a_t^i\in\mathcal{A}$ its action |
| $m_t^N$, $m_t$ | empirical population measure; its mean-field limit |
| $\mu_t\in\mathcal{M}_+(\mathcal{X})$ | unnormalised population measure (open systems) |
| $\nu_t(\mathrm{d}x,\mathrm{d}a)=\pi_t(\mathrm{d}a\mid x)\,m_t(\mathrm{d}x)$ | joint state–action distribution |
| $P_\theta(\mathrm{d}x'\mid x,a,m)$ | transition law, parameter $\theta$ possibly unknown |
| $R,C$ | reward and cost functions; $r:=R-C$ the net reward |
| $G(x,m)$ | terminal reward or cost |
| $\mathcal{F}_t^i$ | information filtration of agent $i$ |
| $\pi^i,\pi^{-i}$ | policy of agent $i$; policies of all other agents |
| $u_t(x)$ | value function of the representative agent |
| $C_t$, $c(t)$ | aggregate value process; its release (injection) rate |
| $\varphi$ | exploitability (distance from equilibrium) |
| $W_1,W_2$ | Wasserstein distances on $\mathcal{P}(\mathcal{X})$ |

### 11.20 Status of the original setup (editorial)

**Table 11.8.** Status of the statements of *\[AT-0\]* sections 1–15 and appendices A–D, with where each is tested.

| Statement | Tag | Where tested / resolved |
|---|---|---|
| Agent model, actions, softmax, beliefs, Bellman (§3.1–3.5) | **\[SETUP\]** | made rigorous in Chapter 12 (Sections E–F) |
| Collective dynamics, welfare, Fokker–Planck (§2.3, 3.7–3.8) | **\[SETUP\]** | Chapter 12 (Section G) |
| Fixed value, contest, zero-sum transfers (§3.9–3.10) | **\[SETUP\]** | Chapter 12 (Section I); additivity of value exact in Chapter 14 |
| Stable policy regimes $\mathcal{R}_k$ (§3.11) | **\[HYPOTHESIS\]** | untested |
| Merger: measures and values add, equilibria do not (§3.12, §4, B.2, B.9) | **\[HYPOTHESIS\]** | Chapter 14: open at the level of dynamics |
| Definition 5.1, 6.1, 7.1 | **\[SETUP\]** | — |
| Conjecture 6.2 (scale-invariant principle) | **\[CONJECTURE\]** | Chapter 14: identities yes, laws no |
| Proposition 7.2 (tower property) | **\[PROVED\]** | held on data (Chapter 14) |
| Hypothesis 9.1 (restoration) | **\[REFUTED AS STATED\]** | Chapter 14, Part I Theorem 6.1 |
| Hypothesis 9.2 (migration) | **\[OPEN\]** | needs a dynamic test |
| Hypothesis 9.3 (cross-scale coherence) | **\[MEASURED\]** | Chapter 14, collective share $\kappa$ |
| Experiment 11.1 and the §12 label $Y=E_{t+h}+D_{t+h}-D_t$ | **\[REFUTED AS STATED\]** | author’s annotation; Chapter 14 |
| Tables 2–7 (Bitcoin diagnostics) | **\[MEASURED\]** | hindsight only; Subappendix D.1 |
| Kinetic equation (B.14), currents (B.22–B.25) | **\[SETUP\]** | model class, Chapter 13 two-sided matching |
| Relaxation bound (B.28), closure condition (B.32) | **\[HYPOTHESIS\]** | linear case proved in Chapter 12 |
| Mean-field limit and fluctuations (B.33–B.35), MFG system (C) | **\[KNOWN RESULT\]** | quoted |
| Central object $\mathfrak E_\Delta$ and its merger response (B.45–B.47) | **\[OPEN\]** | the programme’s question |

## Chapter 12: Aggregation theory: the rigorous layer *\[AT-0 §E–W\]*

> **What this chapter establishes**
>
> The rigorous layer of AT-0 restates the setup of Chapter 11 as a controlled stochastic system of $N$ exchangeable, partially informed agents (§E–F), passes to the mean-field limit (§G), fixes the equilibrium concepts—mean field game, mean field control, exploitability $\varphi(t)$ (§H)—and makes value conservation structural through a contest or an exchange mechanism (§I). It then adds common noise (§J), open systems with their two balance laws (§K), the fluid form and the three resolutions of fluctuations (§L), temporal blocks with the window $\tau_{\mathrm{relax}}\ll\Delta\tau\ll\tau_{\mathrm{drive}}$ (§M), mergers as quenches and the hierarchy tower (§N), steady states and the quasipotential landscape (§O) and an eight-item programme (§P). Its one proved result is the lumping theorem (§Q–W): $y=Cz$ of $\dot z=Az$ closes exactly iff $A(\ker C)\subseteq\ker C$.

Equations carry the document’s own numbers; the source’s letter–number is printed in grey beside each display, or named in the sentence introducing it, and every proposition, definition and remark keeps its source number in its title. The notation is that of AT-0 §D (summarised in Chapter 11): $\mathcal{X}\subseteq\mathbb{R}^d$ states, $\mathcal{A}$ actions (a finite library or $\mathcal{A}\subseteq\mathbb{R}^p$), $\mathcal{P}(\cdot)$ and $\mathcal{M}_+(\cdot)$ probability and finite measures, $r:=R-C$ the net reward, $G$ the terminal term, $\mathcal{F}^i_t$ the filtration of agent $i$, $C_t$ and $c(t)$ the aggregate value process and its release rate, $\varphi$ exploitability, $W_1,W_2$ Wasserstein distances; time is discrete, $t\in\{t_0,\dots,T\}$, with continuum analogues where they clarify structure, and all suprema over policies are over admissible policies. The source stratifies its claims by rigour (exact statements as propositions; asymptotic statements under explicit assumptions; programmatic results as target theorems; structural hypotheses as conjectures; physical correspondences confined to remarks, carrying no probative weight); the status tags here follow that stratification (editorial).

### 12.1 The finite-agent model *\[AT-0 §E\]*

#### 12.1.1 States, empirical measure, dynamics *\[AT-0 §E.1\]*

**\[SETUP\]** There are $N$ agents with states $X^i_t\in\mathcal{X}$. The empirical population measure, the mean-field-coupled transition law and its diffusion (particle) form are $$\begin{gathered}
m^N_t=\frac1N\sum_{j=1}^N\delta_{X^j_t},\quad\text{\textit{[E.1]}}\tag{12.1}\\
X^i_{t+1}\sim P_\theta\big(\mathrm{d}x'\,\big|\,X^i_t,\,a^i_t,\,m^N_t\big),\quad\text{\textit{[E.2]}}\tag{12.2}\\
\mathrm{d}X^i_t=b\big(X^i_t,a^i_t,m_t\big)\,\mathrm{d}t+\sigma\big(X^i_t,a^i_t,m_t\big)\,\mathrm{d}W^i_t,\quad\text{\textit{[E.3]}}\tag{12.3}
\end{gathered}$$ with $(W^i)_{i\le N}$ independent (idiosyncratic) Brownian motions; common-noise extensions are in §J. The dependence on $m^N_t$ carries all interaction between agents at the level of dynamics, and $\theta$ indexes a family of models: the transition probabilities themselves may be unknown to the agents and to the modeller (Remark 12.1).

#### 12.1.2 Information *\[AT-0 §E.2\]*

**\[SETUP\]** Agent $i$ observes through a filtration nested between the trivial extreme of self-observation and full observation, $$\sigma\big(X^i_{t_0:t},\,a^i_{t_0:t}\big)\ \subseteq\ \mathcal{F}^i_t\ \subseteq\ \mathcal{F}_t,\quad\text{\textit{[E.4]}}\tag{12.4}$$ $\mathcal{F}_t$ the full system filtration. The informal *information ratio* $\rho_i\in[0,1]$ interpolates between the two ends of (12.4): $\rho_i=0$ is the left end (own trajectory only), $\rho_i=1$ the right end (everything). The quantitative version replaces the ratio by a channel capacity: the action may depend on the payoff-relevant state $S_t$ only through a channel of bounded mutual information, $$I\big(S_t;\,a^i_t\big)\ \le\ \kappa_i,\quad\text{\textit{[E.5]}}\tag{12.5}$$ with the behavioural consequence in Proposition 12.3. Agents may be correlated—in information (overlapping filtrations), in noise, and in randomised actions (shared randomisation devices); each is a form of common noise (§J).

#### 12.1.3 Rewards, outcomes and the decision functional *\[AT-0 §E.3\]*

**\[SETUP\]** The one-step (unrealised, ex-ante random) net reward of agent $i$ and its realised (ex-post) accumulation over a horizon are $$\begin{gathered}
u^i_t=R\big(X^i_t,a^i_t,X^i_{t+1},m^N_t\big)-C\big(X^i_t,a^i_t,X^i_{t+1},m^N_t\big),\quad\text{\textit{[E.6]}}\tag{12.6}\\
O^i(T)=\sum_{t=t_0}^{T-1}u^i_t\qquad\Big(\text{continuum: }O^i(T)=\int_{t_0}^{T}\big(R_i(t)-C_i(t)\big)\,\mathrm{d}t\Big).\quad\text{\textit{[E.7]}}\tag{12.7}
\end{gathered}$$ The dependence of $R$ and $C$ on $m^N_t$ carries the interaction at the level of payoffs; §I makes it structural through a conservation law. Each agent evaluates policies by the conditional expected outcome plus a terminal term, $$J^i\big(\pi^i,\pi^{-i}\big)=\mathbb{E}^{\pi}\Bigg[\sum_{t=t_0}^{T-1}u^i_t+G\big(X^i_T,m^N_T\big)\ \Bigg|\ \mathcal{F}^i_{t_0}\Bigg],\quad\text{\textit{[E.8]}}\tag{12.8}$$ $\pi^{-i}$ the policies of all other agents, the expectation under the law induced by $(\pi^i,\pi^{-i},P_\theta)$. Admissibility is the essential constraint: agent $i$ may only use policies adapted to its own filtration, $$\pi^i_t\ \text{ is }\ \mathcal{F}^i_t\text{-measurable for every }t.\quad\text{\textit{[E.9]}}\tag{12.9}$$ Partial information thus restricts the *policy*, not merely the conditioning in (12.8). An agent with a strict sub-filtration acts on a belief: its effective state is the pair $(X^i_t,\hat m^i_t)$, $\hat m^i_t$ its filtered estimate of the population (and of the aggregate value process), and the filtering recursion becomes part of the dynamics. Heterogeneous information classes yield one decision problem *per class*, all coupled through the same population measure.

**Remark 12.1** **(E.1: Unknown transition probabilities).** **\[SETUP\]** When $\theta$ is unknown three regimes are distinguished: (i) *learning*—agents (or the modeller) estimate $\theta$ from interaction, the domain of mean-field reinforcement learning (Perrin et al., 2020); (ii) *ambiguity*—optimisation against a worst case over a model class (robust mean field games); (iii) *aggregate uncertainty*—the unknown randomness is common to all agents, which is common noise (§J) rather than estimable idiosyncratic structure.

### 12.2 Policies and the representation of actions *\[AT-0 §F\]*

**Definition 12.2** **(F.1: Policy).** **\[SETUP\]** A policy of agent $i$ is a probability kernel from information to actions: for each $t$ a map $\pi^i_t(\,\cdot\mid\mathcal{F}^i_t)\in\mathcal{P}(\mathcal{A})$, measurable in the sense of (12.9); actions are sampled $a^i_t\sim\pi^i_t$. No distributional family is forced by the model: uniform and Gaussian laws are parametrisations or limits of the kernel, not primitives.

###### Finite action library

**\[SETUP\]** With $\mathcal{A}=\{a^{(1)},\dots,a^{(K)}\}$ a policy is a point in the simplex $\Delta^{K-1}$ for each information state $s$, canonically parametrised in Gibbs (softmax) form—the rule of equation (11.10) given its rigorous seat: $$\pi_\tau\big(a^{(k)}\,\big|\,s\big)=\frac{\exp\{Q(s,a^{(k)})/\tau\}}{\sum_{j=1}^{K}\exp\{Q(s,a^{(j)})/\tau\}},\quad\text{\textit{[F.1]}}\tag{12.10}$$ $Q(s,a)$ the expected net reward-to-go of action $a$, $\tau>0$ a temperature. The two limits recover the naive candidates: $\tau\to\infty$ gives the uniform distribution on the library (no information used); $\tau\to0$ gives the deterministic maximiser $a=\operatorname*{arg\,max}_aQ(s,a)$, i.e. the classical feedback control $a=\alpha(t,x,m)$. In the energy reading of the model (12.10) weights actions by Boltzmann factors $\propto e^{-\Delta E(a)/\tau}$.

**Proposition 12.3** **(F.2: Information capacity implies logit choice).** **\[KNOWN RESULT\]** An agent maximising expected reward subject to the mutual-information constraint (12.5), with Shannon cost of information, optimally randomises according to a multinomial logit (softmax) rule of the form (12.10), with temperature determined by the shadow price of capacity (Sims, 2003; Matějka and McKay, 2015). Hence $\kappa_i=0$ forces state-independent (e.g. uniform) play, $\kappa_i=\infty$ permits full maximisation, and intermediate capacities yield intermediate temperatures. Entropy-regularised mean field games have (12.10) as their *exact* equilibrium policy class.

###### Continuous actions

**\[SETUP\]** With $\mathcal{A}\subseteq\mathbb{R}^p$ (e.g. an intended displacement in $\mathbb{R}^3$) the standard parametrisation is Gaussian, $a\sim\mathcal{N}\big(\mu_\vartheta(s),\Sigma_\vartheta(s)\big)$, the deterministic feedback recovered as $\Sigma\to0$.

**Remark 12.4** **(F.3: Why randomise at all).** **\[KNOWN RESULT\]** (i) With finite libraries equilibria may exist only in mixed strategies (relaxed controls); (ii) randomisation implements exploration when $\theta$ is unknown; (iii) a randomisation device *shared* across agents produces exactly the correlated actions of §E—correlation across agents is common noise in the action layer.

### 12.3 The mean-field limit: collective dynamics and collective value *\[AT-0 §G\]*

**Assumption 12.5** **(G.1: Mean-field regularity).** **\[SETUP\]** Agents are exchangeable; initial states are i.i.d. with law $m_{t_0}$; noises are idiosyncratic (independent across agents); $b,\sigma$ (or $P_\theta$), $R$, $C$, $G$ are continuous and Lipschitz in $(x,a)$ and in $m$ with respect to $W_1$ or $W_2$.

**Proposition 12.6** **(G.2: Propagation of chaos—individually random, collectively determinate).** **\[KNOWN RESULT\]** Under Assumption 12.5 and a fixed population policy profile, $m^N_t\to m_t$ weakly, almost surely, as $N\to\infty$, where $(m_t)$ is the deterministic flow (12.11); moreover any fixed $k$ agents become asymptotically independent with common law $m_t$ (Sznitman, 1991; Carmona and Delarue, 2018). Each agent’s trajectory remains stochastic; the population’s evolution does not. This is the precise content of the statement in Chapter 11 that outcomes are only probabilistic agent-by-agent at time $t$ yet certain in aggregate at $t+1$—valid *as stated* only for idiosyncratic randomness; under common noise it holds conditionally (§J).

#### 12.3.1 Collective dynamics *\[AT-0 §G.1\]*

**\[KNOWN RESULT\]** In discrete time, with population policy $\pi_t(\mathrm{d}a\mid x)$, the mean-field flow obeys the mean-field Chapman–Kolmogorov (McKean–Vlasov) update for Borel $B\subseteq\mathcal{X}$; in the diffusion form (12.3) with feedback $a=\alpha(t,x,m_t)$ its continuum limit is the Fokker–Planck (forward Kolmogorov) equation (the equation of equation (11.7)): $$\begin{gathered}
m_{t+1}(B)=\int_{\mathcal{X}}\int_{\mathcal{A}}P_\theta\big(B\,\big|\,x,a,m_t\big)\,\pi_t(\mathrm{d}a\mid x)\,m_t(\mathrm{d}x),\quad\text{\textit{[G.1]}}\tag{12.11}\\
\frac{tial m_t}{tial t}=-\nabla\cdot\Big[b\big(x,\alpha(t,x),m_t\big)\,m_t\Big]+\frac12\sum_{j,k}\frac{tial^2}{tial x_jtial x_k}\Big[\big(\sigma\sigma^{\top}\big)_{jk}\,m_t\Big].\quad\text{\textit{[G.2]}}\tag{12.12}
\end{gathered}$$ Operationally: distribute agents by $m_t$, assign actions by $\pi_t$, propagate through $P_\theta$.

#### 12.3.2 Collective cost–reward *\[AT-0 §G.2\]*

**Definition 12.7** **(G.3: Collective value functional).** **\[SETUP\]** With $\nu_t(\mathrm{d}x,\mathrm{d}a)=\pi_t(\mathrm{d}a\mid x)\,m_t(\mathrm{d}x)$ the joint state–action distribution, the collective functional is (source equation G.3) $$\begin{multlined}
\mathcal{O}(T)=\sum_{t=t_0}^{T-1}\int_{\mathcal{X}}\!\int_{\mathcal{A}}\!\int_{\mathcal{X}}(R-C)(x,a,x',m_t)\,P_\theta(\mathrm{d}x'\mid x,a,m_t)\,\nu_t(\mathrm{d}x,\mathrm{d}a)\\[-2pt]
+\int_{\mathcal{X}}G(x,m_T)\,m_T(\mathrm{d}x).
\end{multlined}\tag{12.13}$$

**Proposition 12.8** **(G.4: Law of large numbers for the collective value).** **\[PROVED\]** Under Assumption 12.5, $\frac1N\sum_{i=1}^{N}O^i(T)\longrightarrow\mathcal{O}(T)$ almost surely as $N\to\infty$; under common noise the convergence holds conditionally on the common filtration. Proof: combine Proposition 12.6 with (12.6)–(12.7) (the proof rests on the quoted Proposition 12.6).

### 12.4 Equilibrium concepts *\[AT-0 §H\]*

#### 12.4.1 The individual problem given a flow *\[AT-0 §H.1\]*

**\[KNOWN RESULT\]** Given a deterministic flow $(m_t)_{t_0\le t\le T}$ the representative agent’s value function solves the backward Bellman recursion (source H.1; the recursion of equation (11.17)), whose continuum analogue is the Hamilton–Jacobi–Bellman equation (source H.2): $$\begin{gathered}
u_t(x)=\sup_{a\in\mathcal{A}}\int_{\mathcal{X}}\Big[(R-C)(x,a,x',m_t)+u_{t+1}(x')\Big]P_\theta(\mathrm{d}x'\mid x,a,m_t),\qquad u_T(\cdot)=G(\cdot,m_T),\tag{12.14}\\
-\frac{tial u}{tial t}=\sup_{a\in\mathcal{A}}\Big\{b(x,a,m_t)\cdot\nabla u+\tfrac{1}{2}\operatorname{tr}\big[\sigma\sigma^{\top}(x,a,m_t)\,D^2u\big]+(R-C)(x,a,m_t)\Big\}.\tag{12.15}
\end{gathered}$$

#### 12.4.2 Mean field game and mean field control *\[AT-0 §H.2\]*

**Definition 12.9** **(H.1: Mean field game equilibrium).** **\[SETUP\]** A pair $(\pi^*,m^*)$ is a mean field game equilibrium if (i) *optimality*: $\pi^*$ attains (12.14) given the flow $(m^*_t)$; and (ii) *consistency*: $(m^*_t)$ is generated from $m_{t_0}$ by (12.11) under $\pi^*$. Condition (i)+(ii) is the fixed point whose finite-$N$ content is a Nash equilibrium of the $N$-player game (Lasry and Lions, 2007; Huang, Malhamé and Caines, 2006); it formalises equation (11.30).

**Definition 12.10** **(H.2: Mean field control).** **\[SETUP\]** The planner’s problem is to maximise the collective functional (12.13) directly over population policies $\pi$. Its optimality system differs from Definition 12.9: the planner internalises the effect of the control on $m_t$; selfish agents do not.

**Remark 12.11** **(H.3: Price of anarchy).** **\[KNOWN RESULT\]** The gap $\mathcal{O}^{\mathrm{MFC}}(T)-\mathcal{O}^{\mathrm{MFG}}(T)\ge0$ measures the collective cost of decentralised optimisation and is itself a diagnostic of the system’s configuration.

#### 12.4.3 Distance from equilibrium *\[AT-0 §H.3\]*

**Definition 12.12** **(H.4: Exploitability).** **\[SETUP\]** Given a current population profile $(\pi_t,m_t)$, $$\varphi(t)=\sup_{\pi'}J\big(\pi';(m_s)_{s\ge t}\big)-J\big(\pi;(m_s)_{s\ge t}\big)\ \ge\ 0,\quad\text{\textit{[H.3]}}\tag{12.16}$$ the maximal gain available to a single deviating agent. The equilibrium set is $\{\varphi=0\}$; $\varphi(t)$ is the running diagnostic used throughout §M–O to track the system’s distance from equilibrium as it is driven (Perrin et al., 2020).

### 12.5 Conserved value: contest and exchange *\[AT-0 §I\]*

**\[HYPOTHESIS\]** The structural hypothesis is that the system carries a total value: at $t_0$ a stock $C_{t_0}$, over time a release (injection) rate $c(t)$, with $\int_{t_0}^{T}c(t)\,\mathrm{d}t=C_{\mathrm{util}}$ the utilised value over the horizon and $C_{\mathrm{unutil}}$ a known but non-capturable remainder (the fixed total and the utilised/unutilised split of Chapter 11).

**Definition 12.13** **(I.1: Aggregate balance identity).** **\[SETUP\]** The reward–cost pair $(R,C)$ is *value-conserving with release $c$* if, identically in $(m_t,\pi_t)$ (source I.1), $$\int_{\mathcal{X}}\int_{\mathcal{A}}\mathbb{E}_{x'\sim P_\theta(\cdot\mid x,a,m_t)}\Big[(R-C)(x,a,x',m_t)\Big]\,\nu_t(\mathrm{d}x,\mathrm{d}a)=c(t).\tag{12.17}$$ The strictly fixed pot is the case $c\equiv0$: every agent’s gain is another agent’s loss. Two canonical mechanisms satisfy (12.17) *by construction*, and they generate different collective mathematics.

###### Contest (share-of-the-pot)

**\[SETUP\]** Released value is allocated in proportion to a contest success function evaluated against the aggregate (the contest of equation (11.24)): $$R\big(x,a;\nu_t\big)=\frac{f(x,a)}{\displaystyle\int_{\mathcal{X}\times\mathcal{A}}f(\tilde x,\tilde a)\,\nu_t(\mathrm{d}\tilde x,\mathrm{d}\tilde a)}\;c(t).\quad\text{\textit{[I.2]}}\tag{12.18}$$

**Proposition 12.14** **(I.2: Conservation by construction).** **\[PROVED\]** Under (12.18), $\int R\,\mathrm{d}\nu_t=c(t)$ identically, for every population configuration: shares sum to the released value by definition. The pot may equivalently be funded endogenously by the agents’ own costs, $c(t)=\int C\,\mathrm{d}\nu_t$, in which case (12.17) holds with zero net release.

**\[KNOWN RESULT\]** Equation (12.18) is a Tullock contest with a continuum of players (Tullock, 1980). Its denominator runs through the joint distribution of states *and controls* $\nu_t$, which places the model in the extended mean field game / mean-field-of-controls class (Gomes and Saúde, 2014; Cardaliaguet and Lehalle, 2018)—one step beyond the vanilla setting of §H.

###### Exchange (kinetic)

**\[KNOWN RESULT\]** Alternatively value moves in pairwise encounters that conserve each pair’s total. The collective equation then carries a Boltzmann-type collision operator rather than a pure drift–diffusion, and connects to the kinetic wealth-exchange models of econophysics, where conserved pairwise exchange alone—with no optimisation—already produces Boltzmann–Gibbs distributions of holdings (Drăgulescu and Yakovenko, 2000).

**Remark 12.15** **(I.3: Statistical ensembles).** **\[SETUP\]** Fixed agent number and fixed total value is the microcanonical ensemble: total energy fixed, individual energies fluctuating. Fixed agents with a stochastic value process $C_t$ (§J) is canonical: a system coupled to a value reservoir. Fluctuating agent number *and* value (§K) is grand canonical, with the free-entry condition playing the role of the chemical potential. (A physical correspondence: by the source’s own stratification it organises intuition and carries no probative weight.)

**Remark 12.16** **(I.4: Utilised and unutilised value).** **\[HYPOTHESIS\]** Only $c(t)=\dot C_{\mathrm{util}}$ enters the allocation mechanism (12.18). $C_{\mathrm{unutil}}$ never appears in current rewards, yet it moves behaviour *today* through expectations of future release: an anticipation (option-value) channel operating through the information structure of §E.

### 12.6 The value process as common noise *\[AT-0 §J\]*

**\[KNOWN RESULT\]** Let the aggregate value follow a stochastic process $C_t$ (equivalently a stochastic release rate $c_t$) adapted to a common filtration $\mathcal{F}^0_t$ observed—fully or partially—by the agents (the common-noise term of equation (11.20)). Then (i) Proposition 12.6 holds *conditionally* on $\mathcal{F}^0$: the population flow $(m_t)$ is a random measure flow, deterministic given the value path; “collectively certain” becomes “certain conditional on the aggregate drivers”. (ii) Equilibrium objects become functions of the aggregate state: policies $\alpha(t,x,m,C)$, value functions $u(t,x,m,C)$; the natural analytic home is the master equation on the enlarged state space $(x,m,C)$ (Cardaliaguet, Delarue, Lasry and Lions, 2019).

**Assumption 12.17** **(J.1: Lasry–Lions monotonicity).** **\[SETUP\]** The payoff coupling $F(x,m)$ satisfies $$\int_{\mathcal{X}}\big(F(x,m_1)-F(x,m_2)\big)\,\mathrm{d}(m_1-m_2)(x)\ \ge\ 0\qquad\text{for all }m_1,m_2\in\mathcal{P}(\mathcal{X})$$ (crowd-aversion; congestion-type couplings).

**Proposition 12.18** **(J.2: Uniqueness and smooth comparative statics).** **\[KNOWN RESULT\]** Under Assumption 12.17 (and standing regularity) the equilibrium of Definition 12.9 is unique for each value level, and the equilibrium map $C\mapsto(\pi^*,m^*)$ is continuous—differentiable where the master equation is classically solvable—so that $tial_C(\pi^*,m^*)$ exists. Small value injections move behaviour smoothly, and in the direction of the added value (Lasry and Lions, 2007; Cardaliaguet et al., 2019). This is the precise form of the postulate of Chapter 11 that behavioural change should track value added: a theorem *under monotonicity*, not a free assumption.

**Remark 12.19** **(J.3: Non-monotone couplings—multiplicity and regime breaks).** **\[HYPOTHESIS\]** Imitation, momentum and crowd-seeking couplings violate Assumption 12.17. Then equilibria may be multiple, the map $C\mapsto(\pi^*,m^*)$ can jump, and hysteresis appears: quasi-stable behaviour within ranges of $C$, discontinuous reconfiguration when $C$ exits them. This is the desirable regime for modelling breaks, and the microstructure behind the landscape of §O.

### 12.7 Open systems: entry, exit and balance laws *\[AT-0 §K\]*

#### 12.7.1 Unnormalised dynamics with sources and sinks *\[AT-0 §K.1\]*

**\[SETUP\]** When agents join and leave, mass is not conserved: work with the unnormalised measure $\mu_t\in\mathcal{M}_+(\mathcal{X})$, agent count $M(t)=\mu_t(\mathcal{X})$ and shape $\bar m_t=\mu_t/M(t)$. The forward equation acquires a source and a sink (source K.1), $$\frac{tial\mu_t}{tial t}=-\nabla\cdot(b\,\mu_t)+\frac12\sum_{j,k}tial^2_{jk}\Big[\big(\sigma\sigma^{\top}\big)_{jk}\,\mu_t\Big]+\eta_{\mathrm{in}}(t,\mathrm{d}x)-\lambda_{\mathrm{out}}\big(t,x,\mu_t\big)\,\mu_t,\tag{12.19}$$ $\eta_{\mathrm{in}}$ the arrival flux and $\lambda_{\mathrm{out}}$ a per-agent exit hazard; in discrete time $\mu_{t+1}=\iint(1-\lambda_{\mathrm{out}})\,P_\theta\,\pi_t\,\mu_t+\eta_{\mathrm{in}}$.

#### 12.7.2 Endogenous flux: stopping and free entry *\[AT-0 §K.2\]*

**\[KNOWN RESULT\]** Exit is optimally chosen when leaving beats continuing: the Bellman recursion (12.14) acquires an obstacle (source K.2), $$u_t(x)=\max\Big\{\psi_t(x),\ \sup_{a}\int\Big[(R-C)(x,a,x',m_t)+u_{t+1}(x')\Big]P_\theta(\mathrm{d}x'\mid x,a,m_t)\Big\},\tag{12.20}$$ $\psi$ the outside option; the exit region is $E_t=\{x:u_t(x)=\psi_t(x)\}$ and $\lambda_{\mathrm{out}}$ is determined *inside* the equilibrium (mean field games of optimal stopping: Bertucci, 2018; Carmona, Delarue and Lacker, 2017). Entry is the mirror image: a free-entry condition $$u_t\big(x_{\mathrm{entry}}\big)=\kappa\quad\text{\textit{[K.3]}}\tag{12.21}$$ —agents flow in until the value of entering equals the entry cost—pins the arrival flux. The stationary version of (12.19)–(12.21), with constant in/out flux and stationary $\mu^*$, is the mean-field form of stationary industry equilibrium with turnover (Hopenhayn, 1992).

**Remark 12.20** **(K.1: Chemical potential).** **\[SETUP\]** Condition (12.21) is the economic realisation of the chemical potential of the grand canonical ensemble (Remark 12.15): the marginal value of an additional agent is equalised with the outside option, and particle number adjusts until it is.

#### 12.7.3 Mass and value balance *\[AT-0 §K.3\]*

**\[SETUP\]** Augment the state with a holdings coordinate $w$, so states are $(x,w)\in\mathcal{X}\times\mathbb{R}$ and system value is the first moment $V_{\mathrm{sys}}(t)=\int w\,\mu_t(\mathrm{d}x\,\mathrm{d}w)$.

**Proposition 12.21** **(K.2: Balance laws as moment equations).** **\[PROVED\]** Integrating (12.19) against $1$ and against $w$: $$\begin{aligned}
\dot M(t)&=\eta_{\mathrm{in}}(t,\mathcal{X}\times\mathbb{R})-\int\lambda_{\mathrm{out}}\,\mathrm{d}\mu_t,\quad\text{\textit{[K.4]}}\tag{12.22}\\
\dot V_{\mathrm{sys}}(t)&=c(t)+\int w\,\eta_{\mathrm{in}}(t,\mathrm{d}x\,\mathrm{d}w)-\int w\,\lambda_{\mathrm{out}}\,\mu_t(\mathrm{d}x\,\mathrm{d}w).\quad\text{\textit{[K.5]}}\tag{12.23}
\end{aligned}$$ Injected value, plus endowments carried in by entrants, minus holdings carried out by leavers. The conservation identity (12.17) is the closed-system special case of (12.23). Proof: direct integration; the internal reallocation terms (contest or exchange) integrate to $c(t)$ by Proposition 12.14. Equations (12.22)–(12.23) are the two collective equations of the framework at the slow scale: a continuity equation for agents and a continuity equation for value.

### 12.8 Hydrodynamic form and fluctuation theory *\[AT-0 §L\]*

#### 12.8.1 The equilibrium as a fluid *\[AT-0 §L.1\]*

**\[KNOWN RESULT\]** Take the quadratic benchmark: dynamics $\mathrm{d}X_t=a_t\,\mathrm{d}t+\sigma\,\mathrm{d}W_t$ and net reward $r(x,a,m)=-\tfrac{1}{2}|a|^2-F(x,m)$ (effort cost plus population coupling). The equilibrium system of Definition 12.9 reads (source L.1; the forward–backward pair of equation (11.34)) $$\left\{\begin{aligned}
&tial_tu+\frac{\sigma^2}{2}\Delta u+\frac12|\nabla u|^2=F(x,m_t),&\qquad&u(T,\cdot)=G(\cdot,m_T),\\
&tial_tm-\frac{\sigma^2}{2}\Delta m-\nabla\cdot\big(m\,\nabla u\big)=0,&\qquad&m(t_0,\cdot)=m_{t_0},
\end{aligned}\right.\tag{12.24}$$ with optimal drift $a^*=\nabla u$. **\[PROVED\]** Define the population velocity field $v_t:=\nabla u_t$. Taking the gradient of the first equation in (12.24), the pair $(m,v)$ satisfies $$\begin{aligned}
tial_tm+\nabla\cdot(m\,v)&=\frac{\sigma^2}{2}\Delta m&&\text{(continuity)},\quad\text{\textit{[L.2]}}\tag{12.25}\\
tial_tv+(v\cdot\nabla)\,v&=\nabla F(x,m_t)-\frac{\sigma^2}{2}\Delta v&&\text{(momentum / Bernoulli)}.\quad\text{\textit{[L.3]}}\tag{12.26}
\end{aligned}$$ The coupling $F$ plays the role of a pressure term; the noise level $\sigma^2/2$ plays the role of a viscosity. Together with the mass and value balances (12.22)–(12.23) the fluid triple—continuity, momentum, energy—is complete. With $\sigma=0$, (12.25)–(12.26) is exactly the Benamou–Brenier fluid formulation of optimal transport (Benamou and Brenier, 2000). Two merging agent populations are, in this representation, two density blobs with distinct velocity potentials flowing into one another.

**Remark 12.22** **(L.1: Potential flow; orientation of the viscous term).** **\[PROVED\]** Since $v=\nabla u$ the equilibrium flow is curl-free: vanilla mean field games produce potential flow, with no vorticity and no vortex-stretching turbulence. **\[HYPOTHESIS\]** Turbulent phenomenology in this framework arises instead from equilibrium multiplicity (Remark 12.19), common noise and merger quenches (§N). The viscous term in (12.26) enters with the sign opposite to Navier–Stokes: the value function is transported *backward* in time, and (12.26) is a backward viscous Burgers equation; well-posedness is supplied by the coupled forward–backward system (12.24), not term-by-term.

#### 12.8.2 Which randomness dies, and which survives *\[AT-0 §L.2\]*

**\[KNOWN RESULT\]** Idiosyncratic randomness disappears at three successive resolutions, $$m^N_t\ \approx\ m_t+\frac{1}{\sqrt N}\,G_t,\qquad\mathbb{P}\big(m^N\approx\text{atypical path}\big)\ \asymp\ e^{-N\,I[\mathrm{path}]},\quad\text{\textit{[L.4]}}\tag{12.27}$$ where (i) *law of large numbers*: $m^N\to m$ (Proposition 12.6); (ii) *central limit theorem*: the fluctuation field $G_t$ is Gaussian, solving a linear SPDE of Ornstein–Uhlenbeck type around the mean-field flow; (iii) *large deviations*: exponentially rare excursions are governed by a Dawson–Gärtner rate functional $I$ (Dawson and Gärtner, 1987). **\[HYPOTHESIS\]** Common randomness—the value process, merger timings, shared shocks—survives *every* level of aggregation: the macroscopic system is deterministic only conditional on its aggregate drivers, and unconditionally remains a low-dimensional stochastic system. Molecular chaos vanishes in the ocean; weather still moves it. This is why markets do not become deterministic as participation grows: the cascade annihilates idiosyncratic noise only.

### 12.9 Temporal aggregation and multiscale structure *\[AT-0 §M\]*

#### 12.9.1 Blocks, options and exact composition *\[AT-0 §M.1\]*

**\[SETUP\]** Partition the horizon, $t_0=\tau_0<\tau_1<\dots<\tau_L=T$, with block lengths $\Delta\tau_k=\tau_{k+1}-\tau_k$ (e.g. 100 micro-steps at $\tau_1$, 200 at $\tau_2$; uniformity is not required). A *macro-action* on block $k$ is not a single action but a policy segment, an *option* in the semi-Markov sense (Sutton, Precup and Singh, 1999), and the block transfer operator is the composition of one-step updates (12.11): $$\varpi^{(k)}=\big(\pi_t\big)_{\tau_k\le t<\tau_{k+1}},\qquad\qquad m_{\tau_{k+1}}=\Phi_k\big(m_{\tau_k},\varpi^{(k)}\big).\quad\text{\textit{[M.1, M.2]}}\tag{12.28}$$

**Proposition 12.23** **(M.1: Semigroup consistency across aggregation levels).** **\[PROVED\]** For $\tau_a<\tau_b<\tau_c$, $\Phi_{[\tau_a,\tau_c]}=\Phi_{[\tau_b,\tau_c]}\circ\Phi_{[\tau_a,\tau_b]}$. Consequently aggregating two 100-step blocks and aggregating one 200-step block directly produce identical laws: coarse-grained descriptions at different levels are automatically consistent, provided the full state is retained. Proof: Chapman–Kolmogorov.

**Proposition 12.24** **(M.2: Block dynamic programming; equilibrium invariance).** **\[KNOWN RESULT\]** The decision functional (12.8) decomposes exactly over blocks, $$J=\sum_{k=0}^{L-1}\mathbb{E}\Big[\sum_{t=\tau_k}^{\tau_{k+1}-1}u^i_t\Big]+\mathbb{E}\big[G(X^i_T,m_T)\big],\quad\text{\textit{[M.3]}}\tag{12.29}$$ by additivity of the sum and the tower property, and Bellman’s recursion holds at the block level with the option library (12.28). If the macro library contains *all* micro policy segments, the macro game is a re-parametrisation of the micro game and their equilibria coincide. Proof: dynamic programming (omitted in the source).

**Remark 12.25** **(M.3: Restricted macro-libraries).** **\[HYPOTHESIS\]** Restricting the macro library to a few named behaviours (“accumulate”, “hold”, “unwind”) makes the macro equilibrium a projection of the micro equilibrium. The approximation error is operational and measurable: it is bounded by the micro-scale exploitability (12.16) of the best policy representable in the restricted library.

#### 12.9.2 Asymptotic closure: turnpike, averaging and the block-length window *\[AT-0 §M.2\]*

**Assumption 12.26** **(M.4: Timescale separation).** **\[SETUP\]** At frozen aggregates $(M,V_{\mathrm{sys}},C)$ the fast layer—the mean field game of §G–H—is ergodic with spectral gap $\rho>0$ (relaxation time $\tau_{\mathrm{relax}}\sim1/\rho$), and the slow drivers (entry, exit, value flux) move on a timescale $\tau_{\mathrm{drive}}\gg\tau_{\mathrm{relax}}$; set $\varepsilon=\tau_{\mathrm{relax}}/\tau_{\mathrm{drive}}$.

**Proposition 12.27** **(M.5: Turnpike and averaged slow dynamics).** **\[KNOWN RESULT\]** Under Assumption 12.5, Assumption 12.17 and Assumption 12.26: (i) within a long block the time-dependent equilibrium remains within $O(e^{-\rho s})$ of the ergodic (stationary) equilibrium at the frozen aggregates, except in boundary layers at the block edges (turnpike property; Cardaliaguet, Lasry, Lions and Porretta, 2012); (ii) the slow variables $(M,V_{\mathrm{sys}},C,\text{low moments of }\bar m)$ follow, to leading order in $\varepsilon$, an autonomous effective equation whose coefficients are averages of (12.22)–(12.23) over the fast layer’s quasi-stationary law (stochastic averaging; Pavliotis and Stuart, 2008).

**Remark 12.28** **(M.6: Choosing the block length; adaptive coarse-graining).** **\[HYPOTHESIS\]** Proposition 12.27 is valid precisely when the block length sits in the window $$\tau_{\mathrm{relax}}\ \ll\ \Delta\tau_k\ \ll\ \tau_{\mathrm{drive}}:\quad\text{\textit{[M.4]}}\tag{12.30}$$ long enough for internal equilibration, short enough that agents and value have not materially fluxed within the block. As drives slow the window widens and coarser blocks (e.g. $100\to200$) remain legitimate: the aggregation level may—and should—adapt to the state of the drivers.

**Remark 12.29** **(M.7: Adiabatic tracking of equilibrium).** **\[HYPOTHESIS\]** In the regime of Assumption 12.26 exploitability satisfies $\varphi(t)=O(\varepsilon)$: the system tracks the moving equilibrium quasi-statically. Spikes of $\varphi$ mark exactly the departures—quenches (§N) and bifurcations (Remark 12.19)—and $\varphi(t)$, computed block by block, is the practical time series for “keeping track of the system equilibrium as time progresses” (the changing equilibrium of Section 11.7).

**\[HYPOTHESIS\]** The two halves of the multiscale programme fuse here: *within* a block, agent number and value are quasi-static and the micro mean field game runs at fixed aggregates; *across* blocks, the balance laws (12.22)–(12.23) are the macro dynamics—a two-layer architecture, fast game, slow conservation laws. The hypothesis under which each fluid-level description *closes* (local equilibrium, in kinetic-theory language) is the same hypothesis as the temporal window (12.30): one assumption, appearing horizontally in time and vertically in scale.

### 12.10 Mergers, hierarchy and cross-scale consistency *\[AT-0 §N\]*

#### 12.10.1 Mergers as quenches *\[AT-0 §N.1\]*

**Definition 12.30** **(N.1: Merger event).** **\[SETUP\]** Systems $A$ and $B$, with populations $\mu^A,\mu^B$, values $V_A,V_B$ and interaction kernels $W_A,W_B$, merge at time $t_a$ (the merger rule of equation (11.31)): $$\mu_{t_a}=\mu^A_{t_a^-}+\mu^B_{t_a^-},\qquad V_{t_a}=V_A+V_B,\qquad W\leftarrow W_{A\cup B},\quad\text{\textit{[N.1]}}\tag{12.31}$$ followed by relaxation toward the equilibrium of the merged system. In physics language, a quench: an abrupt change of system parameters. The out-of-equilibrium transient—the mixing layer where two rivers meet—is, in the instrumentation of Definition 12.12, an exploitability spike decaying at the spectral-gap rate of Assumption 12.26.

**Remark 12.31** **(N.2: Anticipated versus surprise mergers).** **\[SETUP\]** If agents know $t_a$ in advance there is a single game with time-varying structure: the backward equation (12.14) runs through the merger with a jump in coefficients, and pre-merger behaviour already prices the event in. If the merger is a surprise there are two games glued at $t_a$ by their state: the pre-merger equilibrium is computed under beliefs the event falsifies, and the value function is re-solved backward from $T$ with the new data. Announced and unannounced events are different equilibrium objects.

#### 12.10.2 Additivity: what merging preserves, and what it does not *\[AT-0 §N.2\]*

**Proposition 12.32** **(N.3: Value additivity).** **\[PROVED\]** Under the balance laws (12.22)–(12.23) and the merger rule (12.31), total value is additive: the merged system carries $V_A+V_B$ plus subsequent net flux, and aggregate realised rewards account accordingly over any $[t_a,t_b]$. Proof: bookkeeping; immediate from Proposition 12.21.

**Proposition 12.33** **(N.4: Behavioural additivity—sufficient conditions).** **\[KNOWN RESULT\]** The merged system’s equilibrium coincides with the superposition of the two separate equilibria in each of the following regimes, and in general in no others: (i) *exact*—the post-merger coupling is block-diagonal (agents of one system never enter the other’s rewards or transitions; in graphon language the merged interaction graphon is disconnected); (ii) *approximate*—cross-coupling of size $\epsilon$ yields equilibria within $O(\epsilon)$ of superposition, by stability of the fixed point under Assumption 12.17; (iii) *in distribution*—the interaction is purely through normalised shares (as in (12.18) with scale-invariant $f$) and the two populations are statistically identical, so the merged system is a rescaled copy of each part. Outside (i)–(iii) merging changes every agent’s coupling (in the contest form, the denominator of (12.18)) and behaviour does not superpose, even though value does (Proposition 12.32). References: Caines and Huang (2021); Parise and Ozdaglar (2023).

#### 12.10.3 The hierarchy tower *\[AT-0 §N.3\]*

**\[SETUP\]** As mergers cascade—agents into groups, groups into massive groups—the description variable climbs a tower: a point in $\mathcal{X}$; a measure in $\mathcal{P}(\mathcal{X})$; a measure over measures in $\mathcal{P}(\mathcal{P}(\mathcal{X}))$; and so on, each level’s “players” being the aggregates of the level below. The master equation, already posed on measure space (Cardaliaguet et al., 2019), is the natural (if heavy) home; a graphon on the current population tracks the merger genealogy—who merged with whom, and how strongly the residual couplings bind (Caines and Huang, 2021).

**Definition 12.34** **(N.5: Hierarchically consistent equilibrium).** **\[SETUP\]** Let $\mathcal{A}_\ell$ denote the aggregation (coarse-graining) map from level $\ell$ to level $\ell+1$, and $\operatorname{BR}_\ell$ the equilibrium (best-response fixed point) map at level $\ell$. A family $\{(\pi^{(\ell)},m^{(\ell)})\}_\ell$ is a hierarchically consistent equilibrium if each level is an equilibrium given the aggregates of the level above, and each level’s aggregates are generated by the level below: $$\mathcal{A}_\ell\circ\operatorname{BR}_\ell=\operatorname{BR}_{\ell+1}\circ\mathcal{A}_\ell\qquad\text{for every level }\ell.\quad\text{\textit{[N.2]}}\tag{12.32}$$

**Assumption 12.35** **(N.6: Closure across scales).** **\[SETUP\]** (i) Timescale separation holds level-by-level (Assumption 12.26 at each $\ell$); (ii) monotonicity holds level-by-level (Assumption 12.17 at each $\ell$), so each fixed point is unique and stable; (iii) couplings at level $\ell+1$ depend on level $\ell$ only through quantities that survive $\mathcal{A}_\ell$ (aggregation-measurable couplings); otherwise the macro game is not autonomous and (12.32) cannot close.

**Conjecture 12.36** **(Target theorem: the hierarchically consistent equilibrium).** **\[CONJECTURE\]** Under Assumption 12.35 a hierarchically consistent equilibrium exists, is unique, and is the limit of the finite-$N$, finite-level system as populations grow and timescales separate; moreover the commuting condition (12.32) holds with $O(\varepsilon)$ error when separation is finite. Establishing this—the precise hypotheses and the convergence mode—is the central mathematical objective of the programme. (The source states it in prose after Assumption 12.35; its own cross-reference to it in §P, “Target Theorem ??”, is unresolved — editorial.)

### 12.11 Equilibria of the full system: steady states, cascades and landscapes *\[AT-0 §O\]*

“Equilibrium” means three different things in this architecture; the taxonomy of §O.1–O.3 keeps them distinct (the regimes of Section 11.3.11 are the informal version).

#### 12.11.1 Non-equilibrium steady states *\[AT-0 §O.1\]*

Because value flows *through* the open system—injected at the top, contested in the middle, dissipated by costs and exits at the bottom—the honest long-run object is not a detailed-balance equilibrium but a steady state carrying stationary fluxes.

**Definition 12.37** **(O.1: Non-equilibrium steady state (NESS)).** **\[SETUP\]** A stationary configuration $(\mu^*,\nu^*,\pi^*)$ of the open system (12.19)–(12.21) with time-independent, generically nonzero throughputs: constant entry and exit fluxes balancing in (12.22), and constant value injection balancing dissipation in (12.23). A river at “equilibrium” is steadily flowing, not still.

**Conjecture 12.38** **(O.2: Value cascade).** **\[CONJECTURE\]** In a NESS with injection at large (aggregate) scale and dissipation at small (agent) scale, the value flux across intermediate scales is constant over an inertial range—an economic analogue of the Kolmogorov energy cascade (Kolmogorov, 1941). To be tested in the model, not asserted: the candidate observable is the scale-decomposed value flux implied by (12.23) under the hierarchy of §N.

#### 12.11.2 The landscape: basins, trends, activated transitions *\[AT-0 §O.2\]*

**\[KNOWN RESULT\]** With non-monotone couplings (Remark 12.19) the system possesses multiple steady states, and the global picture becomes geometric. Fluctuations of order $1/\sqrt N$ (equation (12.27)) explore a basin; exponentially rare excursions cross between basins, with rates governed by the Freidlin–Wentzell quasipotential $W$ constructed from the large-deviation rate functional (Freidlin and Wentzell, 2012; Dawson and Gärtner, 1987): for the expected residence time in a basin whose exit barrier has quasipotential difference $\Delta W$, $$\mathbb{E}\big[\tau_{\mathrm{exit}}\big]\ \asymp\ e^{N\,\Delta W}.\quad\text{\textit{[O.1]}}\tag{12.33}$$ **\[HYPOTHESIS\]** Equation (12.33) is the punctuated-equilibrium signature: deterministic behaviour on ordinary timescales, rare violent reconfiguration on exponential ones.

#### 12.11.3 Phenomenology dictionary *\[AT-0 §O.3\]*

**\[SETUP\]** Table 12.1 is the source’s dictionary from market phenomena to the dynamical objects of this layer.

**Table 12.1.** Phenomenology dictionary *\[AT-0 §O.3\]*: each market phenomenon and the dynamical object of the rigorous layer that names it.

| **Market phenomenon** | **Dynamical object** |
|---|---|
| Mean reversion | relaxation inside a basin of attraction |
| Trend-following | motion along an unstable direction of positive feedback |
| Shock (exogenous) | quench: merger, value event (12.31) |
| Shock (endogenous) | noise-activated basin transition (12.33) |
| Regime | basin / NESS of Definition 12.37 |
| Regime stability | quasipotential barrier $\Delta W$; window (12.30) |
| Announced vs. surprise events | Remark 12.31 |
| Crowding / price impact | mean-field-of-controls coupling (12.18) |
| Distance from equilibrium | exploitability time series $\varphi(t)$ |

**\[PLAN\]** The full-system equilibrium story therefore has a statics and a dynamics. The *statics*: existence, multiplicity and stability of hierarchically consistent steady states across configurations—the map from (populations, values, interaction structure) to the set of NESS; it requires fixed-point and monotonicity theory. The *dynamics*: the transition structure between them—quench responses, basin geometry, quasipotential barriers, cascade paths; it requires fluctuation and large-deviation theory.

### 12.12 Research programme *\[AT-0 §P\]*

**\[PLAN\]** Eight items, in the source’s order; none is reported as executed in AT-0, whose results section is empty (editorial; the tests later run are in Chapter 14).

1.  **Mechanism selection.** Derive the collective equations for the contest (12.18) and exchange (kinetic) mechanisms separately; characterise when they are distinguishable from aggregate data.

2.  **Endogenous versus exogenous flux.** Solve the open-system equilibrium with stopping/free entry (12.20)–(12.21); compare with exogenously driven flux scenarios; quantify the feedback of the slow layer through the value function.

3.  **Cross-scale consistency.** Prove the target theorem (Conjecture 12.36; the source’s reference reads “Target Theorem ??”) under Assumption 12.35; identify the minimal aggregation-measurable coupling class.

4.  **Merger calculus.** Sharpen Proposition 12.33: rates in $\epsilon$ for regime (ii); necessary conditions; the graphon-editing formalism for partial mergers.

5.  **Learning under unknown $\theta$.** Mean-field reinforcement learning for the extended game (fictitious play across levels); convergence of $\varphi(t)$ to $0$ as both a learning and an equilibration diagnostic.

6.  **Landscape estimation.** Estimate basins and the quasipotential $\Delta W$ from simulated and empirical trajectories; test the (12.33) scaling.

7.  **Cascade test.** Formalise and test Conjecture 12.38: define the scale-decomposed value flux and measure it across the hierarchy.

8.  **Numerics.** A two-layer scheme: a fast-layer equilibrium solver (fictitious play / forward–backward iteration on (12.14)+(12.11)) nested inside slow-layer integration of (12.22)–(12.23), with block length adapted by (12.30).

### 12.13 Aggregation and exact closure: the lumping theorem *\[AT-0 §Q–W\]*

**\[SETUP\]** Sections Q–W of AT-0 are a second, self-contained start (“Q start”). Many systems can be described at several levels of resolution—individual orders contribute to market activity, interactions among individuals to population behaviour, microscopic physical interactions to macroscopic observables—and the question is under which mathematical conditions a detailed description admits a reduced description of its collective behaviour. The recurrence of mathematical structures across applications motivates the investigation: a shared equation form is a basis for comparison, while establishing a common *mechanism* requires explicit assumptions and derivations. The linear results below establish conditions for exact reduction within a specified model class (exact linear reduction, or *lumping*; Rózsa and Tóth, 2004); **\[OPEN\]** subsequent extensions must specify how interactions generate collective observables, when reduced equations remain exact, and when additional variables, memory or controlled approximations are required, and the scope of any broader unification across market, population and physical systems remains to be established.

#### 12.13.1 Linear microscopic dynamics *\[AT-0 §Q–R\]*

**\[SETUP\]** Let $z:I\to\mathbb{R}^n$ be a differentiable state trajectory on a time interval $I\ni0$, with components $z(t)=(z_1(t),\dots,z_n(t))^{\top}$ and $\dot z(t)=\mathrm{d}z(t)/\mathrm{d}t=(\dot z_1(t),\dots,\dot z_n(t))^{\top}$. A constant-coefficient linear system has the form $$\dot z(t)=Az(t),\qquad A=\begin{bmatrix}a_{11}&a_{12}&\cdots&a_{1n}\\a_{21}&a_{22}&\cdots&a_{2n}\\\vdots&\vdots&\ddots&\vdots\\a_{n1}&a_{n2}&\cdots&a_{nn}\end{bmatrix},\qquad\text{equivalently}\quad\dot z_i(t)=\sum_{j=1}^{n}a_{ij}z_j(t),\ \ i=1,\dots,n.$$ Each row of $A$ forms a weighted sum of the current state components; the entries $a_{ij}$ are numerical coefficients, not differentiation operations—the derivative is taken on the left-hand side. The system is *autonomous* (no explicit dependence on time on the right-hand side) and *linear* (the rate is a linear function of the current state); these are distinct properties, since an autonomous equation can also be nonlinear. An arbitrary differentiable trajectory need not satisfy a constant-coefficient linear system: $\dot z=Az$ is an assumption about the dynamics, to be justified for the system under consideration. The reduced state is $y(t)=Cz(t)$ with $C\in\mathbb{R}^{k\times n}$ constant, of full row rank, $1\le k<n$. The central question is whether the retained variables determine their own evolution: does a constant $B\in\mathbb{R}^{k\times k}$ exist such that $\dot y(t)=By(t)$ for every microscopic initial condition $z(0)\in\mathbb{R}^n$?

#### 12.13.2 Aggregation, exact closure and the kernel condition *\[AT-0 §T, §W\]*

**\[SETUP\]** An aggregation is a map from the detailed state to a chosen reduced state; in the linear setting $y=Cz$, a map from $\mathbb{R}^n$ to $\mathbb{R}^k$ which need not permit reconstruction of the original state. Because $C$ is constant, $\dot y=C\dot z=CAz$, whereas a proposed closed linear equation $\dot y=By$ gives $\dot y=BCz$. These agree for every microscopic state precisely when $$CA=BC.$$ In $CAz$ the microscopic evolution is evaluated before aggregation; in $BCz$ the state is aggregated before its reduced rate is evaluated. The purpose of exact closure is to preserve the evolution of the chosen aggregate; it does not require preserving every detail of the microscopic state. The kernel of $C$, $\ker C=\{v\in\mathbb{R}^n:Cv=0\}$, consists of the state differences that the aggregation cannot detect: $Cz=C\tilde z\iff z-\tilde z\in\ker C$.

**Theorem 12.39** **(W.1: Exact linear closure criterion).** **\[PROVED\]** Let $A\in\mathbb{R}^{n\times n}$ and $C\in\mathbb{R}^{k\times n}$ be constant, with $C$ of full row rank. The following statements are equivalent:

1.  there exists a constant $B\in\mathbb{R}^{k\times k}$ such that $y=Cz$ satisfies $\dot y=By$ for every solution of $\dot z=Az$ and every initial state;

2.  there exists a constant $B$ satisfying $CA=BC$;

3.  $A(\ker C)\subseteq\ker C$.

When these statements hold, $B$ is unique. (AT-0 §X cites Rózsa and Tóth, 2004, Theorems 1 and 4, for the intertwining and kernel-invariance conditions in abstract spaces.)

*Proof.* (1)$\Rightarrow$(2): differentiating $y=Cz$ and evaluating at time $0$ gives $CAz(0)=BCz(0)$; since $z(0)$ is arbitrary, $CA=BC$. (2)$\Rightarrow$(1): every microscopic solution satisfies $\dot y=C\dot z=CAz=BCz=By$. (2)$\Rightarrow$(3): for arbitrary $v\in\ker C$, $C(Av)=CAv=BCv=B0=0$, so $Av\in\ker C$. (3)$\Rightarrow$(2): for any $y\in\mathbb{R}^k$ choose $z$ with $Cz=y$ (possible because $C$ has full row rank) and define $By:=CAz$; if $Cz=C\tilde z$ then $z-\tilde z\in\ker C$, and invariance implies $CA(z-\tilde z)=0$, so the definition is independent of the choice of microscopic representative. It defines a linear map $B$ with $BCz=CAz$ for every $z$, hence $BC=CA$. Uniqueness: if $B_1C=B_2C=CA$, surjectivity of $C$ gives $B_1y=B_2y$ for every $y\in\mathbb{R}^k$, therefore $B_1=B_2$. $\square$

**Example 12.40** **(R–S: Sine and cosine—a linear evolution law that does not reduce).** **\[PROVED\]** Take $z(t)=(\sin t,\ \cos t)^{\top}$. Differentiation gives $$\dot z(t)=\begin{bmatrix}\cos t\\-\sin t\end{bmatrix}=\underbrace{\begin{bmatrix}0&1\\-1&0\end{bmatrix}}_{A_{\mathrm{rot}}}\begin{bmatrix}\sin t\\\cos t\end{bmatrix}.$$ The chosen components are closed under differentiation—each derivative is a constant linear combination of the components already present—which establishes a linear evolution law for the two-component state but does not yet reduce its dimension.

*Reconstruction from one scalar* (S.1). A representation $z(t)=v\,h(t)$ with constant real $v=(v_1,v_2)^{\top}$ would place every state on the fixed line spanned by $v$. The sine–cosine trajectory does not lie on such a line: $z(0)=(0,1)^{\top}$ and $z(\pi/2)=(1,0)^{\top}$ are linearly independent, so no constant vector $v$ and scalar function $h$ give the representation for all times. Such reconstruction can work on a restricted state set: $z(t)=(e^{-t},\,2e^{-t})^{\top}=(1,2)^{\top}\,h(t)$ with $h(t)=e^{-t}$ lies on a known line, so one scalar determines both components—but this provides no reconstruction for arbitrary initial states in $\mathbb{R}^2$. A unit-circle trajectory can also be described by an angular variable, $z(t)=(\sin\theta(t),\ \cos\theta(t))^{\top}$: a nonlinear reconstruction on a restricted state set, rather than multiplication by a constant vector.

*Keeping sine alone* (S.2). Retain only $y(t)=\sin t$, $C=\begin{bmatrix}1&0\end{bmatrix}$. Then $\dot y(t)=\cos t$, which knowing $y$ does not determine: at $t=0$ and $t=\pi$ the retained value is $y=0$ but the derivatives are $1$ and $-1$. No single-valued first-order autonomous equation $\dot y=G(y)$ describes this scalar trajectory for all times. The matrix criterion detects the same problem: for a scalar $B=(b)$, $CA_{\mathrm{rot}}=\begin{bmatrix}0&1\end{bmatrix}$ and $BC=\begin{bmatrix}b&0\end{bmatrix}$ cannot be equal. Although $y$ satisfies $\ddot y=-y$, this second-order equation requires both $y(0)$ and $\dot y(0)$: writing one second-order equation has not reduced the number of state variables from two to one.

**Example 12.41** **(U: Supply and demand imbalance—exact closure and what it discards).** **\[PROVED\]** Let $S(t)$ and $D(t)$ be comparable supply and demand quantities (same units, price reference and horizon), $z=(S,D)^{\top}$, with posited dynamics—time units chosen so that the coefficients have these values; an empirical application would need to justify them from observations or a market mechanism— $$\dot S=-2S+D,\qquad\dot D=S-2D,\qquad\text{i.e.}\quad\dot z=A_{\mathrm{sym}}z,\quad A_{\mathrm{sym}}=\begin{bmatrix}-2&1\\1&-2\end{bmatrix}.$$ Define the imbalance $y=S-D$ (positive $y$ means excess supply), $C=\begin{bmatrix}1&-1\end{bmatrix}$. Differentiating the aggregate, $\dot y=\dot S-\dot D=(-2S+D)-(S-2D)=-3S+3D=-3(S-D)=-3y$, so the reduced matrix is $B=(-3)$; the matrix verification is $CA_{\mathrm{sym}}=\begin{bmatrix}-3&3\end{bmatrix}=(-3)\begin{bmatrix}1&-1\end{bmatrix}=BC$, and the exact aggregate equation is $\dot y=-3y$, $y(t)=y(0)e^{-3t}$.

*What information is discarded* (U.1). The detailed states $z^{(1)}(0)=(5,3)^{\top}$ and $z^{(2)}(0)=(50,48)^{\top}$ both have imbalance $y(0)=2$; their total quantities differ substantially, yet under the specified dynamics both have the same future imbalance $y(t)=2e^{-3t}$. The discarded information is the total $q=S+D$, with $\dot q=-q$, $q(t)=q(0)e^{-t}$; reconstruction requires both, $S=(q+y)/2$, $D=(q-y)/2$. The imbalance alone does not recover the total quantity, but the total quantity is unnecessary for predicting imbalance within this model. A link from imbalance to price changes would require a separately specified mechanism and empirical validation.

*Generalising the example* (U.2). For $\dot S=-\alpha S+\beta D$, $\dot D=\beta S-\alpha D$: $\dot y=-(\alpha+\beta)\,y$ for $y=S-D$ and $\dot q=-(\alpha-\beta)\,q$ for $q=S+D$; when $\alpha>\beta\ge0$ both decay for positive time (the numerical example is $\alpha=2$, $\beta=1$). The symmetry of the two interaction rules makes the difference and the sum evolve independently. Kernel check (§W): for the imbalance map, $\ker C=\{(s,s)^{\top}:s\in\mathbb{R}\}$—an equal change in supply and demand leaves the imbalance unchanged—and $A_{\mathrm{sym}}(s,s)^{\top}=(-s,-s)^{\top}\in\ker C$, as Theorem 12.39(3) requires.

**Example 12.42** **(V: Imbalance need not close—a counterexample).** **\[PROVED\]** Keep the same aggregation $y=S-D$ but change the microscopic dynamics to $\dot S=-S$, $\dot D=-2D$, so $A_{\mathrm{asym}}=\operatorname{diag}(-1,-2)$. Now $\dot y=-S+2D$: for the two initial states above the imbalance is again $2$, but $\dot y^{(1)}\big|_{t=0}=-5+2(3)=1$ and $\dot y^{(2)}\big|_{t=0}=-50+2(48)=46$. The same initial aggregate has different derivatives, so no first-order autonomous equation depending only on $y$ describes the aggregate for all microscopic initial conditions. In terms of the total, $\dot y=(q-3y)/2$: the discarded variable $q$ affects the imbalance rate. The matrix calculation gives $CA_{\mathrm{asym}}=\begin{bmatrix}-1&2\end{bmatrix}$ and $BC=\begin{bmatrix}b&-b\end{bmatrix}$, equal for no scalar $b$; in kernel form, $CA_{\mathrm{asym}}(s,s)^{\top}=s$, nonzero whenever $s\neq0$, so previously invisible differences affect the retained rate. Defining an aggregate is therefore a separate step from proving that its dynamics close.

**Corollary 12.43** **(W.2: Exact aggregate prediction and information loss).** **\[PROVED\]** Under the equivalent conditions of Theorem 12.39 the aggregate solution is $y(t)=e^{Bt}Cz(0)$, and the microscopic and aggregate flows satisfy $Ce^{At}=e^{Bt}C$: two initial states with the same aggregate have the same aggregate trajectory. However, when $k<n$, rank–nullity gives $\dim(\ker C)=n-k>0$, so $C$ is not injective on $\mathbb{R}^n$ and arbitrary microscopic states cannot be uniquely reconstructed from $y$. Exact closure preserves the dynamics of the chosen observable while permitting loss of microscopic information. **\[OPEN\]** The precise starting question for further work: which observables retain enough information for their own evolution, and which additional variables or approximation terms are needed when exact closure fails? (The source states W.2 as a subsection; the corollary framing is editorial.)

**Remark 12.44** **(Where the lumping theorem sits in the programme — editorial).** Sections Q–W carry no reference to §E–P and use their own notation; they answer, in the one setting where it can be answered exactly, the question that Assumption 12.35(iii) poses in general—when couplings at the coarse level depend on the fine level only through what survives aggregation. The kernel condition $A(\ker C)\subseteq\ker C$ is the linear, deterministic instance of “aggregation-measurable couplings”, and Theorem 12.39 is the only statement of AT-0 that the source proves in full. AT-0 §X lists one reference (Rózsa and Tóth, 2004); the reference lists of all sources are collected in Appendix G.

### Status of the rigorous layer

**Table 12.2.** Status of the statements of AT-0 §E–W (editorial summary of the tags above; numbers in brackets are the source’s).

| **Statement** | **Tag** | **Where tested / proved** |
|---|---|---|
| Finite-agent model, information, decision functional (E.1–E.9); policies (F.1); mechanisms (I.1–I.2); open-system dynamics (K.1–K.3); blocks (M.1–M.2); merger rule (N.1); hierarchy (N.2); NESS (O.1) | **\[SETUP\]** | definitions; not testable as such |
| Logit choice under capacity (F.2); propagation of chaos (G.2); Bellman/HJB (H.1–H.2); uniqueness under monotonicity (J.2); optimal-stopping and free-entry equilibria; fluid form (L.1); fluctuation resolutions (L.4); turnpike and averaging (M.5); behavioural additivity (N.4); quasipotential law (O.1) | **\[KNOWN RESULT\]** | quoted from the literature cited in the text |
| Conservation by construction (I.2); balance laws (K.4–K.5); continuity–momentum pair (L.2–L.3); semigroup consistency (M.1); value additivity (N.3); curl-free flow (L.1) | **\[PROVED\]** | elementary, in the source |
| Lumping theorem (W.1), its corollary (W.2) and the three examples (R–V) | **\[PROVED\]** | full proof in §12.13 |
| Anticipation channel (I.4); multiplicity and hysteresis (J.3); restricted-library error bound (M.3); block window (M.6); adiabatic tracking $\varphi=O(\varepsilon)$ (M.7); two-layer closure; survival of common noise; punctuated equilibrium | **\[HYPOTHESIS\]** | untested in AT-0 |
| Target theorem (hierarchical consistency); value cascade (O.2) | **\[CONJECTURE\]** | programme items 3 and 7 |
| Research programme items 1–8 | **\[PLAN\]** | none executed in AT-0 |
| Which observables close when lumping fails | **\[OPEN\]** | posed in §W.2 |

## Chapter 13: The matching rule *\[AT-II\]*

> **What this chapter establishes**
>
> Part II of Aggregation Theory (working draft, October 2026) fixes the setup of the programme and adds one layer, the *matching rule*: additive quantities match exactly across any grouping (Proposition 13.6); squared quantities split exactly into a collective and an internal part (the König split, Theorem 13.9), and the internal share can only grow up a hierarchy (Theorem 13.11); non-additive properties differ from the sum of the parts by the internal motion, with a sign fixed by the property—invariant mass is superadditive (Theorem 13.12), volatility subadditive (Theorem 13.13), and for gravitating groups the internal motion measures the binding mass (Known result 13.14). The matching parameters $\kappa,\gamma,\Upsilon,\tau,H$ are set out for six domains (Table 13.3). The second half prepares the dynamics of the parts (Section 13.5), the quantum analogy made exact (Section 13.5.4) and the two-sided matching programme (Section 13.6).

### 13.1 Introduction *\[AT-II §1\]*

#### 13.1.1 Where the evidence stands *\[AT-II §1.1\]*

Part I proved its results within stated model classes and checked them numerically; notebooks 01–04 then confronted them with real data, including a confirmation run on data that no earlier test had touched. Table 13.1 and Figure 13.1 summarise what is established. Three findings shape this part.

1.  **\[MEASURED\]** *Every exact statement held exactly on real data.* Bars, order-flow imbalance, binned book imbalance, four-momentum and stellar momentum all aggregate without error: the exact layer of the theory is sound.

2.  **\[MEASURED\]** *The noise in real aggregates is not independent.* Trade counts, volume and volatility have exponents $H\approx0.8$–$0.9$, not $\tfrac{1}{2}$. A market-wide move takes about five seconds to reach all coins, and order-book information lasts about forty seconds. These are the numbers that decide how fast a “mean” becomes clear (Part I, Proposition 1).

3.  **\[MEASURED\]** *The whole is not the sum of its parts, in a measurable way.* In all 832 ATLAS four-lepton events the composite mass exceeds the sum of the two pair masses (median gap 17%). Stellar groups lose collective motion level by level up the hierarchy (Figure 13.1a).

**Remark 13.1** **(What “Part I” and “the original document” refer to — editorial).** “Part I” (the three propositions made precise, with notebooks 01–04) is not itself among the compendium’s source documents; its results are restated, together with the later tests, in Chapter 14, and the Part I numbers quoted here (Props. 3.11–3.14, 4.3, Thms. 3.5, 4.2, 5.3, 6.1, Hyp. 4.6, Proposition 1) are kept as the source gives them. “The original document” is the setup of Chapter 11 (rigorous layer in Chapter 12); its equation and proposition numbers (B.2, B.9, B.14, B.27, B.29, B.31, N.3, Conjecture 6.2, Section 3.9) are quoted as the source quotes them.

**Table 13.1.** What the data have established so far (notebooks 01–04, run on real data); every row is a hindsight measurement *\[AT-II Table 1\]*.

| Statement | Data | Result | Tag |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Exact identities (Part I, Prop. 3.11, Lemma 3.16, Prop. 3.12) | Binance, Tardis, CMS, ATLAS, Gaia | all exact to floating-point precision | **\[MEASURED\]** EMA “restoration” is mechanical (Part I, Thm. 6.1) | 132,480 BTC minutes | slopes within 0.022 of the random-walk value | **\[MEASURED\]** A small reversal exists | Jan–Jun 2026, 10 coins, fixed in advance | rank IC $-0.035$ to $-0.087$ at 5–60 min; BTC $z=-10.8$; 10/10 coins. Break-even cost 0.3–3.3 bp round trip, against 10 bp | **\[MEASURED\]** Noise exponent $H$ | same | returns 0.46–0.50; volume 0.81–0.87; $\lvert \text{returns}\rvert$ 0.81–0.89; trade counts 0.87–0.92 | **\[MEASURED\]** Propagation (Part I, Prop. 4.3) | same | correlation 0.745 at 1 min, 0.82 at 15 min; $\tau\approx5$ s; BTC leads | **\[MEASURED\]** Micro information decays (Part I, Hyp. 4.6) | 3 Tardis days | $R^2$ gain from the book peaks at 0.050 (5 s) and falls to half its 1-second value by about 42 s | **\[MEASURED\]** Hierarchy and grouping (Part I, Props. 3.12–3.14) | 169,740 Gaia stars | internal share $0.63\to0.80$; phase-space groups last 8.9 Myr against 0.05 Myr | **\[MEASURED\]** Composite mass | 832 ATLAS events | whole $\ge$ sum of parts in every event; median gap 17% | **\[MEASURED\]** |

![Measured so far [AT-II Figure 1]. (a) Gaia: internal share rises up the tower. Internal share of kinetic energy at each level of the Gaia hierarchy, from the 169k single stars through groups of the five nearest, then five of those, and so on (33k, 6,790, 1,358, 272, 55, 11, 3 and 1 groups): 0 → 0.63 → 0.77 → 0.80, then flat at 0.80. (b) The collective needs time to appear. Mean pairwise correlation of ten coins (Jan–Jun 2026) against the return interval Δ in minutes, from 0.745 at 1 min to about 0.82 at 15 min and 0.84 at one day, with the fit ρ∞Δ/(Δ+τ), ρ∞ = 0.813, τ ≈ 5 s. (c) Micro information lasts about 40 s (three independent Tardis days): R2 gain from the book against horizon in seconds (peak 0.050 at 5 s) and the imbalance IC divided by 10; the dotted line marks where the gain is half its 1-second value,  ≈ 42 s. (d) How fast noise averages out (ten coins): exponent H of returns (0.46–0.50), volume (0.81–0.87), |returns| (0.81–0.89) and trade count (0.87–0.92); $H=\tfrac{1}{2}$ (dotted) is independent noise.](figures/part2_measured.png)

*Measured so far [AT-II Figure 1]. (a) Gaia: internal share rises up the tower. Internal share of kinetic energy at each level of the Gaia hierarchy, from the 169k single stars through groups of the five nearest, then five of those, and so on (33k, 6,790, 1,358, 272, 55, 11, 3 and 1 groups): 0 → 0.63 → 0.77 → 0.80, then flat at 0.80. (b) The collective needs time to appear. Mean pairwise correlation of ten coins (Jan–Jun 2026) against the return interval Δ in minutes, from 0.745 at 1 min to about 0.82 at 15 min and 0.84 at one day, with the fit ρ∞Δ/(Δ+τ), ρ∞ = 0.813, τ ≈ 5 s. (c) Micro information lasts about 40 s (three independent Tardis days): R2 gain from the book against horizon in seconds (peak 0.050 at 5 s) and the imbalance IC divided by 10; the dotted line marks where the gain is half its 1-second value,  ≈ 42 s. (d) How fast noise averages out (ten coins): exponent H of returns (0.46–0.50), volume (0.81–0.87), |returns| (0.81–0.89) and trade count (0.87–0.92); $H=\tfrac{1}{2}$ (dotted) is independent noise.*

#### 13.1.2 What this part does *\[AT-II §1.2\]*

The programme runs in four stages; this part covers the first two and prepares the last two.

1.  *Setup* (Section 13.2). Units, weights, groups and the hierarchy, written so that every object of the original document has a precise counterpart.

2.  *Matching* (Section 13.3 and Section 13.4). What aggregates exactly, what splits, and what differs from the sum of its parts, with the matching parameters that differ between domains. Notebook 05 measures them on particle collisions, star clusters, galaxy clusters, an order book, a crypto basket and the S&P 500.

3.  *Dynamics of the parts* (Section 13.5). Forces, conservation, order-flow imbalance, the order book as a potential landscape, large orders and news, and what the quantum analogy can and cannot carry.

4.  *Two-sided matching* (Section 13.6). Simulate the micro rules, aggregate them, and require the result to reproduce the measured fingerprint of the real market: the match “from two sides”.

### 13.2 The setup *\[AT-II §2\]*

#### 13.2.1 Units *\[AT-II §2.1\]*

**Definition 13.2** **(AT-II Def. 2.1: Unit).** **\[SETUP\]** A unit $i$ carries a weight $m_i>0$, a position $x_i(t)$ in a state space $\mathcal{X}\subseteq\mathbb{R}^d$, a velocity $v_i=\dot x_i$ (or an increment $v_i=x_i(t+\Delta)-x_i(t)$ in discrete time), and an internal state $\theta_i$, which holds whatever the position does not: type, information, beliefs, policy.

Table 13.2 fixes the meaning of these symbols in each domain. The weight is what makes a unit count more or less in the aggregate: in physics it is mass, or energy for relativistic particles; in an index it is market value.

**Definition 13.3** **(AT-II Def. 2.2: Population measure).** **\[SETUP\]** The population measure is $$\nu_t=\sum_im_i\,\delta_{(x_i(t),\,v_i(t),\,\theta_i(t))},\qquad M=\nu_t(1)=\sum_im_i,\qquad \bar\nu_t=\nu_t/M :$$ $M$ is its total mass and $\bar\nu_t$ its shape.

This is the unnormalised measure of the original document (its equation B.2), extended to carry velocities and weights. The weights matter because the normalised shape forgets how much there is, as that document notes.

**Table 13.2.** The same five symbols in six domains *\[AT-II Table 2\]*.

| Domain | unit | weight $m_i$ | position $x_i$ | velocity $v_i$ | internal state $\theta_i$ |
|---|---|---|---|---|---|
| Collisions | particle | energy $E_i$ | — | $\mathbf p_i/E_i$ | species, charge |
| Stars, galaxies | star, galaxy | mass | position | velocity | age, type |
| Order book | queue at a price level | size | distance from mid | change in size (order flow) | trader mix |
| Stock index | stock | market value | log price | return | sector, beta |
| Crypto basket | coin | index weight | log price | return | — |
| Populations | cohort | head count | age | ageing (1/year) | health, hazard |

#### 13.2.2 Groups and the hierarchy *\[AT-II §2.2\]*

**Definition 13.4** **(AT-II Def. 2.3: Group state).** **\[SETUP\]** Let $\mathcal{P}$ be a partition of the units into groups $g$. For each group define $$\tag{13.1}
\begin{gathered}
M_g=\sum_{i\in g}m_i,\qquad X_g=\frac1{M_g}\sum_{i\in g}m_ix_i,\qquad \Sigma_g=\frac1{M_g}\sum_{i\in g}m_i(x_i-X_g)(x_i-X_g)^{\top},\\
P_g=\sum_{i\in g}m_iv_i,\qquad V_g=\frac{P_g}{M_g},\qquad K_g^{\mathrm{int}}=\tfrac{1}{2}\sum_{i\in g}m_i\lvert v_i-V_g\rvert^2 .
\end{gathered}$$ These are the mass, centre, momentum, *collective velocity*, spread and *internal energy*. A *hierarchy* is a chain of partitions $\mathcal{P}_0\prec\mathcal{P}_1\prec\cdots$ in which each group of $\mathcal{P}_{\ell+1}$ is a union of groups of $\mathcal{P}_\ell$, and $\mathcal{P}_0$ is the units themselves.

The group state $Y_g=(M_g,X_g,P_g,\Sigma_g,K_g^{\mathrm{int}})$ is the group state of the original document (its equation B.29, with the current $J_g=P_g$). The hierarchy is its tower of equations B.31 and N.3.

#### 13.2.3 Three kinds of quantity *\[AT-II §2.3\]*

**Definition 13.5** **(AT-II Def. 2.4: additive, mergeable, emergent).** **\[SETUP\]** A group quantity $\Phi$ is

- *additive* if $\Phi(g\cup h)=\Phi(g)+\Phi(h)$ for disjoint $g,h$;

- *mergeable* if $\Phi(g\cup h)$ is a function of $\Phi(g)$ and $\Phi(h)$ (Part I, Proposition 3.11);

- *emergent* otherwise.

<!-- -->

- *Additive:* weight, momentum, four-momentum, market value, dollar profit and loss, order flow, counts, and the system value $C$ of the original document.

- *Mergeable but not additive:* centre, collective velocity, spread and internal energy. They are recovered from the additive moments $\big(M,\sum mx,\sum mxx^{\top},\sum mv,\sum m\lvert v\rvert^2\big)$.

- *Emergent:* invariant mass as a function of the parts’ masses alone, a portfolio’s volatility as a function of its parts’ volatilities alone, equilibria and policies.

The original document already states the key fact in this language: value is additive under mergers (its Proposition N.3), but the equilibrium is not (its equation B.9, $\mathcal{E}(A\cup B)\neq\mathcal{E}(A)+\mathcal{E}(B)$). The matching rule below says by how much a non-additive whole differs, and why.

### 13.3 The matching rule *\[AT-II §3\]*

The proofs that the source collects in its Appendix A are set here directly under the statements they prove (editorial arrangement; the wording is the source’s).

#### 13.3.1 The exact part *\[AT-II §3.1\]*

**Proposition 13.6** **(AT-II Prop. 3.1: Additive quantities match exactly).** **\[PROVED\]** For any additive $\Phi$ and any group $g$ split into subgroups $h_1,\dots,h_k$, $\Phi(g)=\sum_j\Phi(h_j)$. In particular $P_g=\sum_jP_{h_j}$ and $V_g=\sum_j(M_{h_j}/M_g)\,V_{h_j}$: the collective velocity is the weight-averaged velocity of the parts.

*Proof.* Induction on the additivity identity. The second statement divides the first by $M_g$. $\square$

**Corollary 13.7** **(AT-II Cor. 3.2: An index return is the collective velocity of its stocks).** **\[PROVED\]** Let an index be $I_t=\sum_in_ip_{i,t}/D$, with share counts $n_i$ and divisor $D$ fixed between rebalancing dates. Then $$\tag{13.2}
r_{I,t}=\frac{I_t}{I_{t-1}}-1=\sum_iw_{i,t-1}\,r_{i,t},\qquad w_{i,t-1}=\frac{n_ip_{i,t-1}}{\sum_jn_jp_{j,t-1}} .$$

*Proof.* $I_t/I_{t-1}=\sum_in_ip_{i,t}\big/\sum_jn_jp_{j,t-1}=\sum_iw_{i,t-1}(1+r_{i,t})$, and the weights sum to one. $\square$

**In words.** The index return is exactly the market-value-weighted average of its stocks’ returns, weighted at yesterday’s values. When a rebuilt index fails to match, the cause is the data: stale weights, share-count changes, membership changes or float adjustments. Notebook 05 measures how quickly the match decays as the weights age.

**Remark 13.8** **(AT-II Remark 3.3: Volume).** **\[SETUP\]** Dollar volume adds exactly across the stocks of an index. An index product, such as an ETF or a futures contract, trades in a separate market; its volume is not a term in that sum. It is linked to the stocks by arbitrage, not by addition, which is why index-product volume and component volume do not “match”.

#### 13.3.2 The squared part: collective and internal motion *\[AT-II §3.2\]*

**Theorem 13.9** **(AT-II Thm. 3.4: König split).** **\[PROVED\]** For weights $m_i\ge0$ with $M=\sum_im_i>0$, any vectors $v_i$ and $V=\sum_im_iv_i/M$, $$\tag{13.3}
\sum_im_i\lvert v_i\rvert^2=M\lvert V\rvert^2+\sum_im_i\lvert v_i-V\rvert^2 .$$ Define the *collective share* $\kappa=M\lvert V\rvert^2\big/\sum_im_i\lvert v_i\rvert^2\in[0,1]$. The internal term is unchanged when every velocity is shifted by the same vector $u$. The collective term is not unchanged.

*Proof *\[AT-II App. A\]*.* Write $v_i=V+(v_i-V)$ and expand: $\sum m_i\lvert v_i\rvert^2=M\lvert V\rvert^2+2V\cdot\sum m_i(v_i-V)+\sum m_i\lvert v_i-V\rvert^2$. The middle sum is $MV-MV=0$. A common shift $v_i\mapsto v_i+u$ shifts $V$ by $u$ and leaves every $v_i-V$ unchanged. $\square$

Applied to an index, with $w_i$ the weights of Corollary 13.7 and $v_i=r_{i,t}$:

**Corollary 13.10** **(AT-II Cor. 3.5: Market temperature).** **\[PROVED\]** $\sum_iw_ir_{i,t}^2=r_{I,t}^2+D_t$, where $D_t=\sum_iw_i(r_{i,t}-r_{I,t})^2$ is the cross-sectional dispersion. Averaging over time, mean stock variance $=$ index variance $+$ mean dispersion, up to the dispersion of the mean returns (Theorem 13.13).

**In words.** On any day the stocks’ squared returns split exactly into the market’s move squared (collective) and the spread around it (internal, the market’s “temperature”). The collective share $\kappa$ is the first matching parameter. It is high when everything moves together, on crash days for instance, and low when stocks go their own ways.

**Theorem 13.11** **(AT-II Thm. 3.6: Internal share can only grow up the hierarchy).** **\[PROVED\]** If $\mathcal{P}'$ is coarser than $\mathcal{P}$, then $\sum_{G\in\mathcal{P}'}K_G^{\mathrm{int}}\ge\sum_{g\in\mathcal{P}}K_g^{\mathrm{int}}$. The difference is the internal energy of the groups’ collective motions inside their parent groups.

*Proof *\[AT-II App. A\]*.* Fix a group $G$ of $\mathcal{P}'$ made of groups $g\subseteq G$ of $\mathcal{P}$. Apply Theorem 13.9 inside each $g$ to the velocities measured relative to $V_G$: $$\sum_{i\in G}m_i\lvert v_i-V_G\rvert^2=\sum_{g\subseteq G}\Big(\sum_{i\in g}m_i\lvert v_i-V_g\rvert^2+M_g\lvert V_g-V_G\rvert^2\Big),$$ so $K_G^{\mathrm{int}}=\sum_{g\subseteq G}K_g^{\mathrm{int}}+\tfrac{1}{2}\sum_{g\subseteq G}M_g\lvert V_g-V_G\rvert^2\ge\sum_{g\subseteq G}K_g^{\mathrm{int}}$. Sum over $G$. $\square$

**In words.** Each level of aggregation moves energy from “collective” to “internal” and never back. This is the precise form of “bigger error on reiteration” in Proposition 1. On Gaia the internal share rises $0\to0.63\to0.77\to0.80$ and then stops growing (Figure 13.1a): neighbouring groups of field stars quickly become unrelated, so little further energy moves.

#### 13.3.3 When the whole is not the sum of its parts *\[AT-II §3.3\]*

**Theorem 13.12** **(AT-II Thm. 3.7: Relativistic mass is superadditive).** **\[PROVED\]** Let $p_i=(E_i,\mathbf p_i)$ be four-momenta with $E_i\ge\lvert \mathbf p_i\rvert$, and define a group’s invariant mass by $M(g)^2=\big(\sum_{i\in g}E_i\big)^2-\big\lvert\sum_{i\in g}\mathbf p_i\big\rvert^2$. For disjoint groups $g,h$, $$\tag{13.4}
M(g\cup h)-M(g)-M(h)=\big(E_g^*-M(g)\big)+\big(E_h^*-M(h)\big)\;\ge\;0,$$ where $E_g^*,E_h^*$ are the energies of $g$ and $h$ in the rest frame of $g\cup h$. Moreover $E^2=\lvert \mathbf P\rvert^2+M^2$ splits each group’s energy into a collective part $\lvert \mathbf P\rvert$, moving at $\beta=\lvert \mathbf P\rvert/E$, and an internal part $M$ that is the same in every frame.

*Proof *\[AT-II App. A\]*.* Work in the rest frame of $g\cup h$, where the total three-momentum vanishes, so $\mathbf P_g^*=-\mathbf P_h^*=:\mathbf q$. The invariant mass is the total energy in this frame: $M(g\cup h)=E_g^*+E_h^*=\sqrt{M(g)^2+\lvert \mathbf q\rvert^2}+\sqrt{M(h)^2+\lvert \mathbf q\rvert^2}$, using $E^2=M^2+\lvert \mathbf P\rvert^2$ for each subgroup. Each square root is at least the corresponding mass, which gives (13.4). A frame with zero total momentum exists whenever the total four-momentum is timelike; that holds as soon as the group contains a massive particle, or two massless particles moving in different directions. Otherwise all momenta are massless and parallel, and every mass in (13.4) is zero. $\square$

**In words.** The mass of a composite is the masses of its parts plus their motion relative to each other. A $J/\psi$ weighs 3.1 GeV, while its two muons weigh 0.21 GeV: 93% of the composite’s mass is the muons’ internal kinetic energy. Here the internal motion *adds* to the whole.

**Theorem 13.13** **(AT-II Thm. 3.8: Volatility is subadditive).** **\[PROVED\]** For returns $r_i$ with finite variance and weights $w_i\ge0$, $\sum_iw_i=1$, $$\tag{13.5}
\sigma\Big(\sum_iw_ir_i\Big)\le\sum_iw_i\,\sigma(r_i),$$ with equality if and only if all $r_i$ are increasing affine functions of one another (perfect positive correlation). Writing $\mu_i=\mathbb{E}r_i$, $\mu_I=\sum_iw_i\mu_i$ and $D=\sum_iw_i(r_i-r_I)^2$, $$\tag{13.6}
\sum_iw_i\sigma_i^2-\sigma_I^2=\mathbb{E}D-\sum_iw_i(\mu_i-\mu_I)^2 .$$

*Proof *\[AT-II App. A\]*.* The standard deviation is the $L^2$ norm of the centred variable, so (13.5) is Minkowski’s inequality applied to $\sum_iw_i(r_i-\mu_i)$. Equality in Minkowski’s inequality holds exactly for non-negative multiples, which gives the equality case. For (13.6), take expectations in Corollary 13.10: $\sum w_i(\sigma_i^2+\mu_i^2)=\sigma_I^2+\mu_I^2+\mathbb{E}D$, and $\sum w_i\mu_i^2-\mu_I^2=\sum w_i(\mu_i-\mu_I)^2$ by Theorem 13.9 applied to the means. $\square$

**In words.** An index is calmer than its stocks. The gap is the internal motion (dispersion), which cancels out of the collective. Here the internal motion *subtracts* from the whole. The two theorems are the same König split read from opposite sides: a composite particle’s rest energy *includes* the internal motion; an index’s variance *excludes* it. With equal volatilities and equal pairwise correlation $\rho$, the ratio is $\sigma_I/\sigma=\sqrt{\rho+(1-\rho)\sum w_i^2}$, which is Part I, Theorem 4.2.

**Known result 13.14** **(AT-II Known result 3.9: Virial theorem and virial masses).** **\[KNOWN RESULT\]** For a self-gravitating group in a stationary state, the time averages satisfy $2\langle K^{\mathrm{int}}\rangle+\langle W\rangle=0$, with $W=-G\sum_{i<j}m_im_j/r_{ij}$ (Spitzer, 1987). Two consequences are used here.

1.  For $N$ equal-mass members seen in projection, with line-of-sight dispersion $\sigma$ and projected separations $R_{ij}$, the virial mass is $$\tag{13.7}
    M_{\mathrm{VT}}=\frac{3\pi}{2}\,\frac{\sigma^2N^2}{G\sum_{i<j}R_{ij}^{-1}}$$ (Heisler et al., 1985). The factor $\pi/2$ is the mean of $r/R$ over random viewing angles.

2.  For a cluster with one-dimensional dispersion $\sigma$ and half-mass radius $r_h$, $M_{\mathrm{dyn}}\approx7.5\,\sigma^2r_h/G$ (Spitzer, 1987).

*Proof of the projection factor in (a) *\[AT-II App. A\]*.* For a pair at three-dimensional separation $r$ seen from a random direction, the projected separation is $R=r\sin\vartheta$ with $\cos\vartheta$ uniform on $[-1,1]$. Then $\mathbb{E}[1/R]=\frac1r\int_0^\pi\frac1{\sin\vartheta}\,\frac{\sin\vartheta}{2}\,\mathrm{d}\vartheta=\frac{\pi}{2r}$. For $N$ equal masses $m=M/N$ with isotropic dispersion $\sigma$, the virial theorem gives $3M\sigma^2=G(M/N)^2\sum_{i<j}r_{ij}^{-1}$. Replacing $\sum r_{ij}^{-1}$ by $\frac2\pi\sum R_{ij}^{-1}$ gives (13.7). $\square$

The gravitational matching parameter is $\Upsilon=M_{\mathrm{dyn}}/M_{\mathrm{visible}}$, the mass needed to hold the internal motion together divided by the mass the parts show.

- $\Upsilon\approx1$: a bound group whose parts carry its mass.

- $\Upsilon$ of a few: a bound group losing members, or with $\sigma$ inflated by unresolved binaries, which is common for open clusters.

- $\Upsilon\gg1$: either hidden mass, which is the dark matter of galaxy clusters found by Zwicky (1933) in Coma, or no binding at all, as for chance groupings of field stars.

#### 13.3.4 The rule and its parameters *\[AT-II §3.4\]*

**Proposition 13.15** **(AT-II Prop. 3.10: Matching rule).** **\[PROVED\]** For a group and its parts:

1.  additive quantities match exactly (Proposition 13.6);

2.  the second moment splits exactly into collective and internal parts, and the internal share can only grow up a hierarchy (Theorem 13.9 and Theorem 13.11);

3.  invariant mass is superadditive and volatility is subadditive. In both cases the gap vanishes exactly when the parts move together, and its size is the internal motion (Theorem 13.12 and Theorem 13.13);

4.  for a bound gravitating group, the internal motion measures the binding mass (Known result 13.14).

*Proof.* Collect the cited results. In (iii), equality in (13.4) requires $E_g^*=M(g)$ and $E_h^*=M(h)$, that is, no relative motion of $g$ and $h$. Equality in (13.5) requires perfect positive correlation, that is, zero dispersion around an affine co-movement. $\square$

The parameters that differ between domains are therefore

- the collective share $\kappa$ (or the internal share $1-\kappa$);

- the normalised gap $\gamma$, such as $(M-\sum m)/M$ for particles, or the ratio $\sigma_I/\sum w\sigma$ for indices;

- the binding ratio $\Upsilon$ for gravitating groups;

- the propagation time $\tau$ and exponent $H$ of Table 13.1.

Table 13.3 lists what each domain is expected to show and where it is measured. Notebook 05 computes every entry.

**Table 13.3.** Matching parameters across domains. The “expected” column states the prediction before notebook 05 is run on real data *\[AT-II Table 3\]*.

| System | exact part | gap between whole and parts | expected |
|---|---|---|---|
| CMS dimuons | four-momentum | $M/(m_1+m_2)$; $\beta=\lvert \mathbf P\rvert/E$ | $J/\psi$: 14.7; $\beta$ broad, $M$ sharp |
| ATLAS four leptons | four-momentum | $(M_{4\ell}-M_{12}-M_{34})/M_{4\ell}$ | $\ge0$ always; median 17% (measured) |
| Open clusters | momentum | $\Upsilon=M_{\mathrm{dyn}}/M_{\mathrm{vis}}$ | 1–5 (bound, binaries, tides) |
| Field star groups | momentum | $\Upsilon$ | $\sim10^5$ (not bound) |
| Galaxy clusters | momentum | $\Upsilon=M_{\mathrm{VT}}/M_\star$ | 30–100 or more (dark matter, gas) |
| S&P 500 | index return | $\kappa$; $\sigma_I/\sum w\sigma$ | $\kappa\approx0.2$–$0.4$; ratio 0.6–0.75 |
| Crypto basket | basket return | $\kappa(\Delta)$; $\sigma_B/\bar\sigma$ | $\kappa$ rising with $\Delta$, about $0.75\to0.8$ |
| Order book | order flow, depth | microprice relaxation $k(H)$ | $k\gg1$ for BTC, flattening after seconds |

### 13.4 When is a collective “a thing”? *\[AT-II §4\]*

The matching rule holds for any grouping, including a meaningless one. Whether a group is a real collective is a separate question with a testable answer.

**Definition 13.16** **(AT-II Def. 4.1: Coherence at a horizon).** **\[SETUP\]** A group is *coherent at horizon $T$* if its spread stays of the same order over $T$. Under free streaming the spread evolves as $$\tag{13.8}
\Sigma_g(t)=\Sigma_g(0)+t\big(\Sigma_g^{xv}+\Sigma_g^{vx}\big)+t^2\,\Sigma_g^{vv}$$ (Part I, Proposition 3.14). Coherence therefore requires a dispersal time $t_d=s/\sigma_v\gg T$, unless a binding force holds the group ($\Upsilon\approx1$).

**Definition 13.17** **(AT-II Def. 4.2: Leftover dispersion).** **\[SETUP\]** For returns $r_{i,t}$, weights $w_i$ and a grouping $\mathcal{P}$, let $\bar r_{g,t}$ be the weighted mean return of group $g$ and $\bar r_t$ that of all units. The leftover dispersion is $$\tag{13.9}
\ell(\mathcal{P})=\frac{\sum_t\sum_g\sum_{i\in g}w_i\,(r_{i,t}-\bar r_{g,t})^2}{\sum_t\sum_iw_i\,(r_{i,t}-\bar r_t)^2}\in[0,1].$$ Lower values mean that more of the motion is collective within groups. By Theorem 13.11, $1-\ell$ is the share of internal motion that the grouping captures.

**Hypothesis 13.18** **(AT-II Hyp. 4.3: Co-movement beats labels).** **\[HYPOTHESIS\]** Groupings built from joint motion (position *and* velocity for stars; co-movement clusters for stocks) have lower leftover dispersion out of sample than groupings built from labels (position alone; industry sectors).

For stars this is confirmed (**\[MEASURED\]**): phase-space groups last 8.9 Myr, while position groups last 0.05 Myr. For stocks, notebook 05 fits clusters on the first half of the sample and scores both groupings on the second half.

**Hypothesis 13.19** **(AT-II Hyp. 4.4: The collective emerges at a finite time scale).** **\[HYPOTHESIS\]** For a basket of assets that react to common news with short, unequal delays, the collective share satisfies $$\tag{13.10}
\kappa(\Delta)\approx\kappa_\infty\,\frac{\Delta}{\Delta+\tau}$$ for return interval $\Delta$, with $\tau$ of the order of the delays.

This is the Epps effect (Epps, 1979) read as an aggregation law. Notebook 04 measured the pairwise-correlation version of this curve, $\rho(\Delta)=0.813\,\Delta/(\Delta+\tau)$ with $\tau\approx5$ s on ten coins (**\[MEASURED\]** Figure 13.1b, correlation 0.745 at 1 min and 0.82 at 15 min). Notebook 05 measures $\kappa(\Delta)$ directly.

**Remark 13.20** **(AT-II Remark 4.5: The collective has its own dynamics).** **\[KNOWN RESULT\]** Aggregation changes the dynamics, as Part I, Theorem 3.5 predicts. Idiosyncratic memory cancels in the aggregate, and delays between parts create memory that no part has: cross-autocorrelation makes an index more persistent than its stocks (Lo and MacKinlay, 1990). Notebook 05 compares the index’s day-to-day autocorrelation with its stocks’, and the crypto basket’s minute-to-minute autocorrelation with its coins’.

### 13.5 The dynamics of the parts *\[AT-II §5\]*

This section prepares the third stage of the programme: the rules that move the parts, and whether those rules aggregate upwards.

#### 13.5.1 The template *\[AT-II §5.1\]*

The original document’s central equation (its B.14, equation (B.14–B.15)) is the right template. For the density $f_r(t,z)$ of agents of type $r$, $$\tag{13.11}
tial_tf_r=-\nabla\cdot(b_rf_r)+\tfrac{1}{2}\nabla\nabla:(D_rf_r)+\sum_s\mathcal Q_{rs}(f_r,f_s)+S_r^{\mathrm{in}}-S_r^{\mathrm{out}} .$$ The terms are drift (trend, mean reversion and controlled movement), diffusion (uncertainty), interaction (collisions, matching), and entry and exit. At the level of single units the same content reads $$\tag{13.12}
m_i\,\mathrm{d}v_i=\Big[F_i^{\mathrm{ext}}+\sum_{j\ne i}F_{ij}+b_i(\theta_i)-\gamma m_iv_i\Big]\mathrm{d}t+\sigma_i\,\mathrm{d}W_i ,$$ with external forces, pairwise forces, the unit’s own drive (a policy, for a strategic agent), friction and noise. For hard spheres, the route from such particle dynamics through the Boltzmann equation to fluid equations has now been made rigorous (Deng, Hani and Ma, 2025). The macro variables of that limit are exactly the additive quantities of Definition 13.5: mass, momentum and energy.

**Theorem 13.21** **(AT-II Thm. 5.1: Action and reaction close the collective velocity).** **\[PROVED\]** Under (13.12) with $F_{ij}=-F_{ji}$ and a common friction $\gamma$, $$\tag{13.13}
\mathrm{d}P_g=\Big[\sum_{i\in g}F_i^{\mathrm{ext}}+\sum_{i\in g,\;j\notin g}F_{ij}+\sum_{i\in g}b_i-\gamma P_g\Big]\mathrm{d}t+\sum_{i\in g}\sigma_i\,\mathrm{d}W_i .$$ Forces inside the group cancel exactly. For the whole system, $P$ is driven only by external forces, the units’ own drives and noise.

*Proof.* Sum (13.12) over $i\in g$. The pairs with both members in $g$ contribute $F_{ij}+F_{ji}=0$. $\square$

**In words.** If every push inside a group has an equal and opposite push back, the group’s collective velocity ignores its internal configuration. Its equation closes exactly, as for the centre of mass in Part I, Proposition 3.12. If pushes are one-sided, as with imitation or herding, where one agent reacts to another without reaction, the internal sum $\sum_{i,j\in g}F_{ij}$ no longer cancels. The collective then depends on its insides, and Part I’s memory and noise terms appear.

#### 13.5.2 Markets: what is conserved, and what is a force *\[AT-II §5.2\]*

- *Quantity is conserved.* Every trade moves $q$ units from a seller to a buyer, so $\sum_i\Delta q_i=0$. This is the original document’s conserved holdings (its Section 3.9), and the analogue of momentum conservation.

- *Prices move by unbalanced initiative.* Price does not move because shares change hands. It moves because one side crosses the spread and consumes the other side’s queue.

The net force is the *order-flow imbalance* (Cont, Kukanov and Stoikov, 2014). Over the book events $n$ in an interval, with best bid and ask prices $P_n^b,P_n^a$ and queue sizes $q_n^b,q_n^a$, $$\tag{13.14}
\begin{gathered}
e_n=\mathbf 1\{P_n^b\ge P_{n-1}^b\}\,q_n^b-\mathbf 1\{P_n^b\le P_{n-1}^b\}\,q_{n-1}^b-\mathbf 1\{P_n^a\le P_{n-1}^a\}\,q_n^a+\mathbf 1\{P_n^a\ge P_{n-1}^a\}\,q_{n-1}^a ,\\
\operatorname{OFI}=\sum_ne_n,\qquad \Delta P\approx\beta\,\operatorname{OFI}+\varepsilon,
\end{gathered}$$ and the imbalance is additive over time, so it is an exact aggregate.

**Known result 13.22** **(AT-II Known result 5.2: Order-flow imbalance law).** **\[KNOWN RESULT\]** Over short intervals, mid-price changes are close to linear in order-flow imbalance, $\Delta P\approx\beta\,\operatorname{OFI}+\varepsilon$ as in (13.14), with $\beta$ inversely proportional to the depth at the best quotes. For US stocks at 10-second intervals the fit explains about two thirds of the variance (Cont et al., 2014).

**In words.** Price change $=$ net force $\div$ inertia, where the net force is the imbalance of aggressive flow and the inertia is the resting depth. This is the first candidate “law of motion” for the parts of the order book. Notebook 01 already found that taker imbalance explains 21% of one-minute BTC return variance (**\[MEASURED\]**), and notebook 04 found that the book’s predictive gain falls to half its 1-second value within about 42 seconds.

**Hypothesis 13.23** **(AT-II Hyp. 5.3: Scale form of the original Conjecture 6.2).** **\[HYPOTHESIS\]** The order-flow law holds at every aggregation scale $h$ with the same functional form, $\Delta P^{(h)}=\beta_h\,\operatorname{OFI}^{(h)}+\varepsilon^{(h)}$. Only the coefficient $\beta_h$ changes, set by the depth that is relevant at scale $h$. This is the original document’s “scale-invariant interaction principle” (Conjecture 11.3) in testable form.

#### 13.5.3 The order book as a potential landscape *\[AT-II §5.3\]*

Cumulative bid depth below a price is a demand curve, and cumulative ask depth above it is a supply curve. Together they define a landscape for the price: mean reversion is a well; a trend is a tilt of the well by a net external force, such as news or a large order; noise is diffusion. In the simplest form the price density $\rho(p,t)$ obeys the Fokker–Planck equation of overdamped motion in a potential $U$: $$\tag{13.15}
tial_t\rho=tial_p\big(U'(p)\,\rho\big)+D\,tial_p^2\rho .$$ The book’s collective position is the *microprice* (Stoikov, 2018): the bid and ask weighted by the opposite queue sizes. Notebook 05 measures how far the mid moves relative to it at each horizon. The answer says whether the queues act as a well that the mid settles into, or as a push that carries it further.

#### 13.5.4 The quantum analogy, made exact *\[AT-II §5.4\]*

**Known result 13.24** **(AT-II Known result 5.4: Fokker–Planck as imaginary-time Schrödinger).** **\[KNOWN RESULT\]** Substituting $\rho=e^{-U/(2D)}\psi$ in (13.15) gives $$\tag{13.16}
tial_t\psi=D\,tial_p^2\psi-V_s(p)\,\psi,\qquad V_s=\frac{(U')^2}{4D}-\frac{U''}{2},$$ which is Schrödinger’s equation in imaginary time with Hamiltonian $H=-Dtial_p^2+V_s$ (Risken, 1989, ch. 5). Its ground state $\psi_0=e^{-U/(2D)}$ has eigenvalue $0$ and gives the stationary density $\rho_\infty\propto e^{-U/D}$. The other eigenvalues are the relaxation rates.

*The substitution *\[AT-II App. A\]*.* With $\rho=e^{-U/(2D)}\psi$, a direct computation gives $$tial_p(U'\rho)+Dtial_p^2\rho=e^{-U/(2D)}\Big[D\psi''-\Big(\frac{(U')^2}{4D}-\frac{U''}{2}\Big)\psi\Big]:$$ the first-derivative terms cancel. $\square$

**In words.** The “kinetic, potential and probabilistic” behaviour attributed to supply and demand is exactly what classical stochastic dynamics in a potential produces. It has mean reversion (the ground state of a well), trends (a tilted well), noise (diffusion) and an evolving probability density. That dynamics is mathematically identical to quantum mechanics in imaginary time. The eigenvalues of the operator are the relaxation times of the original document’s linearised dynamics (its B.27).

**Remark 13.25** **(AT-II Remark 5.5: What does not carry over).** **\[SETUP\]** Three features of genuine quantum mechanics have no established counterpart in markets: complex amplitudes and interference; entanglement; a fundamental uncertainty bound. Part I’s “uncertainty relation” $\Delta\cdot(\text{relative error})^2=1/\lambda$ is the statistical precision limit for counting a Poisson rate. It is not Heisenberg’s principle. With clustered arrivals the limit worsens to $(\text{relative error})^2\propto\Delta^{2H-2}$, with $H\approx0.9$ for trade counts (Table 13.1). The working rule is to use the Fokker–Planck and Langevin framework, and to claim a specifically quantum effect only with a prediction that classical stochastic dynamics cannot make.

#### 13.5.5 Large orders and news *\[AT-II §5.5\]*

**Known result 13.26** **(AT-II Known result 5.6: Square-root impact).** **\[KNOWN RESULT\]** A metaorder of total size $Q$ moves the price on average by $I(Q)\approx Y\sigma_d\sqrt{Q/V_d}$, with daily volatility $\sigma_d$, daily volume $V_d$ and $Y$ of order one. After the order ends, impact decays to roughly two thirds of its peak (Tóth et al., 2011; Bouchaud et al., 2018).

**Known result 13.27** **(AT-II Known result 5.7: Propagator and long memory).** **\[KNOWN RESULT\]** Order signs have long memory, with autocorrelation $C(\ell)\sim\ell^{-\gamma}$ and $\gamma\approx0.5$ (Lillo and Farmer, 2004). Prices nevertheless stay close to diffusive, because each trade’s impact decays as $G(\ell)\sim\ell^{-\beta}$ with $\beta\approx(1-\gamma)/2$ (Bouchaud et al., 2004).

These two results answer the question “a whale posts a big buy order: how big is the impact on the micro setup, does it revert, and does it aggregate up?”. The impact is concave in size, it partly reverts, and the persistent part is the part that aggregates. Long memory at the micro level, in the signs and in the timing of orders, is the natural candidate for the large exponents $H$ measured for trade counts and volume. Notebook 06 can test that link directly.

**Hypothesis 13.28** **(AT-II Hyp. 5.8: Whale scenario).** **\[HYPOTHESIS\]** On Binance BTC trades, the mid-price response to aggressive trades in the top 0.1% of size is concave in size and partly reverts within minutes. It matches the response predicted by a propagator fitted to ordinary trades. This is a two-sided check: an event study on the data side, and a model built from the ordinary flow on the other.

### 13.6 Two-sided matching *\[AT-II §6\]*

The original idea is to build the micro setup, simulate it, and ask whether it looks like the market; and in parallel to ask whether the market looks like the model. That idea has a standard rigorous form: the simulated method of moments and indirect inference (Duffie and Singleton, 1993; Gouriéroux, Monfort and Renault, 1993). Its ingredients are as follows.

**Definition 13.29** **(AT-II Def. 6.1: Fingerprint).** **\[SETUP\]** A fingerprint is a vector $F$ of statistics measured at several scales. For the market it contains:

- the exponents $H$ of returns, volume, volatility and trade counts;

- the variance-ratio curve;

- the emergence curve $\kappa(\Delta)$ or $\rho(\Delta)$ with its $\tau$;

- the book’s IC and $R^2$ gain against horizon, with its half-life;

- the microprice relaxation $k(H)$;

- the reversal IC and its break-even cost;

- the impact curve $I(Q)$ and its decay;

- the order-flow slope $\beta_h$ and its fit by scale;

- return kurtosis by horizon.

Notebooks 01–05 already measure most of these entries on real data. That is the “does real data look like this” side.

###### The model side

A family of micro models $\mathcal{M}_\theta$ is built from simple agents:

- noise traders arrive in clusters (Hawkes processes); the branching ratio is chosen to match the measured $H$;

- market makers quote around the microprice and manage their inventory;

- momentum traders react to recent returns;

- mean-reverting traders react to the displacement $d_t$: the original restoration hypothesis turned into an agent;

- whales execute metaorders;

- news arrives as common jumps, which are external forces.

Rule-based agents come first. The strategic agents of the original document’s mean-field game (equation (11.34)) are the long-run target, once the rule-based layer matches. Simulating $\mathcal{M}_\theta$ and computing the same statistics gives $\bar F(\theta)$.

**Definition 13.30** **(AT-II Def. 6.2: Two-sided match).** **\[SETUP\]** The estimate is $$\tag{13.17}
\hat\theta=\operatorname*{arg\,min}_\theta\;\big(\hat F-\bar F(\theta)\big)^{\top}\,W\,\big(\hat F-\bar F(\theta)\big),$$ with $W$ the inverse covariance of $\hat F$, which is estimated by block bootstrap. The match is validated when all four checks pass:

1.  *Identification.* Data simulated at a known $\theta$ recover that $\theta$.

2.  *Held-out statistics.* Statistics left out of the fit are reproduced within their sampling error.

3.  *Held-out periods.* An untouched period is reproduced.

4.  *Scenarios.* The scenario responses, a whale order (Hypothesis 13.28) and a news shock, agree with real event studies.

**In words.** A model that reproduces the statistics it was fitted to proves little. The strong test is aggregation itself. Micro rules calibrated on the book and the trades must reproduce, without further fitting, the *macro* matching parameters: the emergence curve, the exponents, the collective share. If they do, “predictable supply and demand at the micro level aggregates upwards” is no longer an intuition but a tested statement. If they do not, the mismatch shows which ingredient is missing.

### 13.7 Programme and status *\[AT-II §7\]*

Table 13.4 reproduces the source’s programme table; Table 13.5 (editorial) lists the statements of this chapter with their tags and where each is tested.

| Stage | Question | Data | Status |
|---|---|---|---|
| 1\. Setup | Units, groups, kinds of quantity | — | this part |
| 2a. Matching | Exact part, $\kappa$, gaps, $\Upsilon$ in six domains | IVV and Yahoo, Binance, Tardis, Gaia, SDSS, CMS, ATLAS | notebook 05 |
| 2b. Collectives | Hypotheses 4.3 and 4.4 (Hypothesis 13.18 and Hypothesis 13.19); collective dynamics | same | notebook 05 |
| 3a. Forces | Known result 5.2 and Hypothesis 5.3 (Known result 13.22 and Hypothesis 13.23): order-flow law across scales | Tardis, Binance trades | notebook 06 |
| 3b. Large orders | Known results 5.6 and 5.7 and Hypothesis 5.8 (Known result 13.26, Known result 13.27 and Hypothesis 13.28) | Binance aggTrades | notebook 06 |
| 3c. Landscape | Potential, microprice relaxation, eigen-relaxation times | Tardis | notebooks 05–06 |
| 4\. Two-sided | Definitions 6.1 and 6.2 (Definition 13.29 and Definition 13.30) | all of the above | after 3 |
| Population | Single ages vs bands, centroid correction (Part I, Thm. 5.3) | Human Mortality Database | notebook 04, Part E (pending) |

| Statement | Tag | Where tested |
|---|---|---|
| Additive quantities match exactly; an index return is the collective velocity of its stocks (Proposition 13.6 and Corollary 13.7) | **\[PROVED\]** **\[MEASURED\]** | exact on real data (Table 13.1); decay with ageing weights, notebook 05 |
| König split; market temperature; internal share grows up the hierarchy (Theorem 13.9, Corollary 13.10 and Theorem 13.11) | **\[PROVED\]** **\[MEASURED\]** | Gaia $0\to0.63\to0.77\to0.80$ (Figure 13.1a); $\kappa$ for the S&P 500 and the crypto basket, notebook 05 |
| Invariant mass is superadditive (Theorem 13.12) | **\[PROVED\]** **\[MEASURED\]** | 832 ATLAS events: gap $\ge0$ in every event, median 17%; CMS dimuons, notebook 05 |
| Volatility is subadditive; gap identity (Theorem 13.13) | **\[PROVED\]** | $\sigma_I/\sum w\sigma$, expected 0.6–0.75, notebook 05 |
| Virial masses and the binding ratio $\Upsilon$ (Known result 13.14) | **\[KNOWN RESULT\]** | open clusters, field groups, galaxy clusters, notebook 05 |
| Co-movement beats labels (Hypothesis 13.18) | **\[HYPOTHESIS\]** | stars confirmed (8.9 Myr vs 0.05 Myr); stocks, notebook 05 |
| The collective emerges at a finite time scale (Hypothesis 13.19) | **\[HYPOTHESIS\]** | $\rho(\Delta)$ version measured, $\tau\approx5$ s; $\kappa(\Delta)$, notebook 05 |
| The collective has its own dynamics (Remark 13.20) | **\[KNOWN RESULT\]** | autocorrelation of index vs stocks, basket vs coins, notebook 05 |
| Action and reaction close the collective velocity (Theorem 13.21) | **\[PROVED\]** | — |
| Order-flow imbalance law (Known result 13.22); scale form (Hypothesis 13.23) | **\[KNOWN RESULT\]** / **\[HYPOTHESIS\]** | 21% of 1-min BTC variance (notebook 01); across scales, notebook 06 |
| Order book as potential landscape; Fokker–Planck as imaginary-time Schrödinger (Known result 13.24) | **\[KNOWN RESULT\]** | microprice relaxation and eigen-relaxation times, notebooks 05–06 |
| Square-root impact and propagator (Known result 13.26 and Known result 13.27); whale scenario (Hypothesis 13.28) | **\[KNOWN RESULT\]** / **\[HYPOTHESIS\]** | Binance aggTrades, notebook 06 |
| Fingerprint and two-sided match (Definition 13.29 and Definition 13.30) | **\[SETUP\]** | after stage 3 |

###### References quoted by AT-II

Bouchaud, Gefen, Potters and Wyart, Fluctuations and response in financial markets: the subtle nature of ‘random’ price changes, *Quant. Finance* 4(2):176–190, 2004. Bouchaud, Bonart, Donier and Gould, *Trades, Quotes and Prices*, CUP, 2018. Cont, Kukanov and Stoikov, The price impact of order book events, *J. Financial Econometrics* 12(1):47–88, 2014. Deng, Hani and Ma, Hilbert’s sixth problem: derivation of fluid equations via Boltzmann’s kinetic theory, arXiv:2503.01800, 2025. Duffie and Singleton, Simulated moments estimation of Markov models of asset prices, *Econometrica* 61(4):929–952, 1993. Epps, Comovements in stock prices in the very short run, *JASA* 74(366):291–298, 1979. Gouriéroux, Monfort and Renault, Indirect inference, *J. Applied Econometrics* 8(S1):S85–S118, 1993. Heisler, Tremaine and Bahcall, Estimating the masses of galaxy groups, *ApJ* 298:8–17, 1985. Lillo and Farmer, The long memory of the efficient market, *Stud. Nonlinear Dyn. Econometrics* 8(3), 2004. Lo and MacKinlay, When are contrarian profits due to stock market overreaction?, *Rev. Financial Studies* 3(2):175–205, 1990. Risken, *The Fokker–Planck Equation*, 2nd ed., Springer, 1989. Spitzer, *Dynamical Evolution of Globular Clusters*, Princeton, 1987. Stoikov, The micro-price, *Quant. Finance* 18(12):1959–1966, 2018. Tóth, Lempérière, Deremble, de Lataillade, Kockelkoren and Bouchaud, Anomalous price impact and the critical nature of liquidity in financial markets, *Phys. Rev. X* 1:021006, 2011. Zwicky, Die Rotverschiebung von extragalaktischen Nebeln, *Helv. Phys. Acta* 6:110–127, 1933. Full entries are collected in Appendix G.

## Chapter 14: The collected account and the hindsight tests *\[AT-III\]*

> **What this chapter establishes**
>
> AT-III (working draft, October 2026) collects the programme in one place and tests the three propositions as the author now states them. Each has an exact core, proved in elementary form in Section 14.3 (triangle inequality, König split, $\Psi^2=H+(1-H)\bar\rho$, Jensen, cascade factorisation, mixture law, squeezing bound, linear-field split, virial sign law), and a measured part (Section 14.4, Section 14.5 and Section 14.6). Three applications follow: gravity with the expansion of space measured as a separate rule and removed (B, Section 14.7), markets from order books to indices (C, Section 14.9), the Riemann zeta function as an aggregate (D, Section 14.10). Every test matches behaviour in hindsight; none forecasts. One package runs every test and writes every number (Section 14.13). A later template reserves an application A, the dark energy, unfilled (Section 14.8).

### 14.1 Introduction: the propositions as now stated *\[AT-III §1\]*

The programme began with a framework for agents whose individual decisions add up to the motion of a whole: an order book, a market, a population (Chapter 11). Part I (Chapter 12) turned three working propositions into statements that can be proved or tested; Part II (Chapter 13) fixed the setup and added a matching rule: what a whole equals exactly, what splits into collective and internal parts, and what differs from the sum of its parts. The propositions have since been rewritten with more detail, and AT-III tests them in that form *\[AT-III §1.1\]*:

> **P1** Aggregation reduces directional speed and error or turbulence (summing by weight or priority). The example is Tesla against the S&P 500: the index has lower turbulence and smaller absolute returns, and on some days the two move in opposite directions. The proposition suggests that the index may have a lower mean and a lower deviation than its components, and that the step from quarks to atoms may halve the directional speed. It asks for these to be proved and measured for stocks, particles and gases or fluids, with their different parameters.

> **P2** Events hit units with distributions of lead–lags and impacts (as in Bouchaud’s square-root law). At the micro level the response looks logistic; at coarse scales it is squeezed into “no reaction, then all reaction at $t_0$”. Examples: a particle beam bending in a magnetic field; news hitting an order book.

> **P3** Energy is *matched*: potential with kinetic, internal with external, supply flows with demand flows, as in stationary action. What is sought is something equal to a constant, or a growth that matches the flow of resources. Internal actions are hidden and shrink at aggregate levels, so flows dominate price action. Galaxies and stars follow stationary action; the “empty void” expands per unit of empty space.

Three applications were added (the later template lists a fourth, A, with no body; Section 14.8):

- Star clusters, galaxies and beyond, with collective motion as the hypothesis, plus a separate rule: space expands with the distance between objects at an unknown speed per unit of space, which should be measured and corrected for.

- Stocks, crypto and order books, extended down to the order book.

- The Riemann zeta function, whose zeros might be found “in the same manner”: the real and imaginary parts as aggregating layers of the function.

###### What the paper does *\[AT-III §1.2\]*

\(1\) It proves the exact core of P1, P2 and P3 (Section 14.3): a triangle inequality, Koenig’s split of energy, Minkowski’s inequality with an exact identity for the turbulence ratio, Jensen’s inequality for growth, the factorisation of a cascade, a mixture law for events, a squeezing bound, an exact split of a velocity field, and the virial theorem’s sign law. (2) It measures the parameters these statements leave free, domain by domain (Section 14.4, Section 14.5 and Section 14.6), then applies the same tools to gravity and expansion (Section 14.7), markets (Section 14.9) and the zeta function (Section 14.10). (3) It places the original framework and the earlier Bitcoin study inside the general picture as special cases (Section 14.11) and ends with a status table (Table 14.17). Status labels follow Parts I and II: a Theorem, Proposition, Lemma or Corollary is proved (here **\[PROVED\]**, with the proof of the source’s Appendix A placed under the statement), a Known result is quoted with a reference (**\[KNOWN RESULT\]**), a Hypothesis is a claim to be tested (**\[HYPOTHESIS\]**).

*Numbers and where they come from.* Every number in a results table is read from `results/numbers.tex`, which the package writes (Section 14.13). A dash (–) marks a number that the run behind this copy did not produce: in the build environment only GitHub and the Python package index could be reached, so the sources marked $^{u}$ in the tables were checked on synthetic files with planted answers and fill in on the next run (**\[PENDING RUN\]** in this chapter). Results from the author’s earlier runs of notebooks 01–04 are quoted as fixed numbers and labelled as such. In the build environment the package ran on real data for the earlier checks, the zeta function to height $10^6$, 1,701 supernova light curves, COVID-19 in 3,256 US county series and 201 country series, world GDP, twenty housing markets, a simulated gas, a particle beam, 2,938 nuclei, 15 hadrons and 832 ATLAS events; stars, clusters, galaxies, stocks, crypto, order books, winds, storms and the ocean were tested against synthetic data with planted answers *\[AT-III abstract\]*.

###### The short answer *\[AT-III §1.3\]*

Table 14.1 is the source’s Table 1; every entry is repeated with its context in Section 14.4, Section 14.5, Section 14.6, Section 14.7, Section 14.9 and Section 14.10.

**Table 14.1.** The propositions in their new form: what is exact, what is measured, and the verdict so far *\[AT-III Tab. 1\]*. Row A is the later template’s addition, with an unfilled body (Section 14.8).

|   | Exact (proved) | Measured (hindsight) |
|---|---|---|
| P1 | Speed ratio $\varphi\le1$, collective share $\kappa\le\varphi^2\le1$, turbulence ratio $\Psi\le1$ with $\Psi^2=H+(1-H)\bar\rho$ exactly; each factor of a cascade is at most 1. The mean is *not* lowered: with fixed weights it is preserved exactly. Compound growth of the whole *exceeds* the weighted mean of the parts’. | Holds everywhere it was measured. The size of each factor is a domain parameter, set by alignment and correlation; there is no universal factor such as one half. For example, the collective share of growth-rate energy is 0.116 from US counties to the nation, 0.402 from countries to world GDP and 0.727 from metros to the Case–Shiller composite. |
| P2 | The aggregate response is exactly the impact-weighted mixture of unit responses; it lies between two shifted copies of the lag distribution; coarse bins capture a share $\ge1-(\mathrm{spread})/\Delta$ of it. | COVID-19 waves, the 2006–11 housing crash and a beam in a magnet all fit the mixture law ($R^2$ 0.992, 0.993, 1.0000). The squeezed share rises from 0.01 (daily bins) to 0.93 (yearly bins) for the first wave. |
| P3 | Koenig and virial: a bound composite carries internal energy $(1+2/n)K$; it is lighter than its parts for attractive $1/r$-type binding and heavier for confinement. Free composites are always heavier (invariant mass). | All 2,938 nuclei and hydrogen are lighter than their parts; all 15 hadrons are heavier; all 832 ATLAS four-lepton events have whole $\ge$ parts. In a simulated gas, collective motion turns into heat with total energy conserved to $1.11\times10^{-16}$. |
| A | <span style="color: greypending">“the Dark energy” (template row; body an unfilled placeholder)</span> | <span style="color: greypending">no number; working hypothesis in Hypothesis 14.14</span> |
| B | The velocity field splits exactly into bulk, linear field and internal motion; expansion is the trace of the linear field. | Pantheon+: $H_0=73.25\pm1.40\,\mathrm{km\,s^{-1}\,Mpc^{-1}}$, one rate at all distances ($\chi^2=5.7$ for 6 degrees of freedom). The motion left after removing it carries a bulk flow of 290 km/s, mostly removed by a gravity model. |
| C | Index returns are weighted sums of stock returns; order flow adds exactly across levels and venues. | Earlier runs: every exact statement held to rounding error; a market-wide move takes about 5 s to reach all coins. New tests are listed in Section 14.9. |
| D | Zeros of $Z(t)$ are where the units of the Riemann–Siegel sum cancel. | All 1,747,146 zeros up to height 1,000,000 lie on the critical line, as counted independently (missing: 0). The statistics are those of random-matrix energy levels. This is a check, not a proof of the Riemann hypothesis. |

### 14.2 The setup *\[AT-III §2\]*

The setup is Part II’s (Definition 13.5 and Table 13.2), compressed.

**Definition 14.1** **(AT-III Def. 2.1: units, weights, aggregate).** **\[SETUP\]** A system has *units* $i=1,\dots,N$. At time $t$ each carries a weight $w_{ti}\ge0$ with $\sum_i w_{ti}=1$ and a “velocity” $x_{ti}\in\mathbb{R}^d$; the velocity can be a return, a growth rate, a velocity or a deflection. The *aggregate* is $X_t=\sum_i w_{ti}x_{ti}$. A *hierarchy* is a chain of partitions $\mathcal{P}_0\prec\mathcal{P}_1\prec\dots\prec\mathcal{P}_L$, where $\mathcal{P}_0$ is the units and every group of $\mathcal{P}_{\ell+1}$ is a union of groups of $\mathcal{P}_\ell$. A group $g$ has weight $W_g=\sum_{i\in g}w_i$ and velocity $X_g=W_g^{-1}\sum_{i\in g}w_ix_i$.

Table 14.2 gives the same symbols across the domains tested. Three kinds of quantity are distinguished (Part II, Definition 2.4): *additive* quantities add exactly (weight, momentum, four-momentum, market value, order flow, counts and the value function of the original document); *mergeable* quantities can be recovered from additive moments (centre, collective velocity, spread and internal energy); *emergent* quantities are neither (invariant mass as a function of the parts’ masses alone, volatility as a function of the parts’ volatilities alone, equilibria and policies). The original framework’s population measure is $\nu_t=\sum_i m_i\,\delta_{(x_i,v_i,\theta_i)}$, with kinetic equation (B.14), group state (B.29) and hierarchy (B.31, N.3); it is this setup with a particular dynamics attached (Section 14.11).

**Table 14.2.** The same symbols across the domains tested *\[AT-III Tab. 2\]*.

| Domain | unit | weight $w_i$ | velocity $x_i$ |
|---|---|---|---|
| Stock index | stock | market value (yesterday) | daily return |
| Crypto basket | coin | equal | return over a bar (1 s to 1 day) |
| Order book | queue at a price level | — | order flow (change in queue size) |
| Epidemic | county, country | last week’s cases | weekly growth of new cases |
| Economy | country | last year’s GDP | annual GDP growth |
| Housing | metro index | fixed index weight $\times$ level | monthly return |
| Gas | molecule | mass | velocity |
| Beam | particle | charge | deflection angle |
| Stars, galaxies | star, cluster, galaxy | mass (or 1) | velocity; peculiar velocity after removing expansion |
| Particles | lepton, muon | energy | four-momentum |
| Zeta function | term $n^{-1/2-it}$ | $n^{-1/2}$ | phase $\theta(t)-t\log n$ |

### 14.3 The exact layer *\[AT-III §3, App. A\]*

Everything in this section holds for any data and any dynamics. The package checks each statement numerically (`tests/test_core.py`, 12 checks). The proofs are the source’s Appendix A, placed under the statements.

#### 14.3.1 Speed, energy and turbulence (P1) *\[AT-III §3.1\]*

**Theorem 14.2** **(AT-III Thm. 3.1: speed and energy).** **\[PROVED\]** At each time, $$\tag{14.1}
|X|\le\sum_i w_i|x_i|,\qquad \sum_i w_i|x_i|^2=|X|^2+\sum_i w_i|x_i-X|^2 .$$ Define the *speed ratio* $\varphi=|X|/\sum_i w_i|x_i|$ and the *collective share* $\kappa=|X|^2/\sum_i w_i|x_i|^2$. Then $0\le\kappa\le\varphi^2\le1$. Summing numerators and denominators over time keeps both ratios in $[0,1]$. $\varphi=1$ exactly when all non-zero units point the same way.

*Proof.* The first relation is the triangle inequality for the norm. For the second, expand $\sum_i w_i|x_i-X|^2=\sum_i w_i|x_i|^2-2X\cdot\sum_i w_ix_i+|X|^2=\sum_i w_i|x_i|^2-|X|^2$. By Cauchy–Schwarz, $(\sum_i w_i|x_i|)^2\le\sum_i w_i|x_i|^2$, so $\kappa\le|X|^2/(\sum_i w_i|x_i|)^2=\varphi^2$. Sums over time of non-negative terms preserve the per-period inequalities. Equality in the triangle inequality requires all non-zero $x_i$ to be positive multiples of one vector. $\square$

**In words.** The aggregate never moves faster than its units do on average. Its kinetic energy is the collective part of theirs; the rest is internal motion, which the aggregate does not show. The second identity of (14.1) is König’s split (Theorem 13.9 in Part II).

**Theorem 14.3** **(AT-III Thm. 3.2: turbulence).** **\[PROVED\]** Let the weights $w_i$ be constant, the units have standard deviations $\sigma_i$ and correlations $\rho_{ij}$, and put $a_i=w_i\sigma_i$. The *turbulence ratio* $\Psi=\operatorname{sd}(X)/\sum_i w_i\sigma_i$ satisfies $\Psi\le1$, and exactly $$\tag{14.2}
\Psi^2=H+(1-H)\,\bar\rho,\qquad H=\frac{\sum_i a_i^2}{\bigl(\sum_i a_i\bigr)^2},\qquad \bar\rho=\frac{\sum_{i\ne j}a_ia_j\rho_{ij}}{\sum_{i\ne j}a_ia_j}.$$ $N_{\mathrm{eff}}=1/H$ is the effective number of units.

*Proof.* $\operatorname{Var}(X)=\sum_{ij}a_ia_j\rho_{ij}$ and $(\sum_i w_i\sigma_i)^2=(\sum_i a_i)^2=\sum_i a_i^2+\sum_{i\ne j}a_ia_j$. Divide both by $(\sum_i a_i)^2$ and separate the diagonal. $\Psi\le1$ because $\rho_{ij}\le1$ (Minkowski’s inequality). $\square$

**In words.** How much calmer the whole is than its parts depends on two numbers only: how concentrated the risk is ($H$), and how correlated the parts are on average ($\bar\rho$). With $\bar\rho=0$ the ratio is $N_{\mathrm{eff}}^{-1/2}$; with $\bar\rho=1$ there is no reduction.

**Theorem 14.4** **(AT-III Thm. 3.3: mean and compound growth).** **\[PROVED\]** (a) With constant weights the mean is preserved: $\overline{X}=\sum_i w_i\,\overline{x_i}$. (b) For buy-and-hold growth factors $R_i>0$ over a period, $\log\sum_i w_iR_i\ge\sum_i w_i\log R_i$, with a gap of about $\tfrac{1}{2}\operatorname{Var}_w(\log R)$ when the spread is small.

*Proof.* (a) Linearity of the time average. (b) Jensen’s inequality for the concave logarithm. Expanding $\log R$ around its weighted mean gives the gap $\tfrac{1}{2}\operatorname{Var}_w(\log R)+O(\text{third moment})$. $\square$

**In words.** Aggregation does not lower the mean. It lowers turbulence, and it raises compound growth above the weighted average of the parts’ compound growth. This is why most stocks can trail the index they make up.

**Theorem 14.5** **(AT-III Thm. 3.4: cascade).** **\[PROVED\]** Along a hierarchy, define the level-$\ell$ speed $S_\ell=\sum_t\sum_{g\in\mathcal{P}_\ell}W_{tg}|X_{tg}|$ and energy $E_\ell=\sum_t\sum_g W_{tg}|X_{tg}|^2$. Both are non-increasing in $\ell$. The total ratios factorise into level factors in $[0,1]$: $$\tag{14.3}
\varphi_{0\to L}=\prod_{\ell=1}^{L}\frac{S_\ell}{S_{\ell-1}},\qquad
\kappa_{0\to L}=\prod_{\ell=1}^{L}\frac{E_\ell}{E_{\ell-1}}.$$

*Proof.* A group at level $\ell+1$ is a union of groups $h$ at level $\ell$, with $W_gX_g=\sum_{h\subset g}W_hX_h$. Apply Theorem 14.2 inside each group with weights $W_h/W_g$ and sum over groups and times. The product formula telescopes. $\square$

**In words.** Going up a hierarchy, each step keeps only part of the motion. The share kept depends only on how aligned the groups merged at that step are. Nothing fixes it at one half: “quarks to atoms halves the speed” would need that particular alignment, and the factor has to be measured level by level.

#### 14.3.2 Events (P2) *\[AT-III §3.2\]*

**Theorem 14.6** **(AT-III Thm. 3.5: mixture law).** **\[PROVED\]** Let unit $i$ respond to an event with $r_i(t)=a_if_i(t-\tau_i)$, where $f_i$ rises from 0 to 1, $a_i$ is the impact and $\tau_i$ the lag (the unit’s half-response time). Write $A=\sum_i w_ia_i$, and suppose all impacts have the same sign. Then the aggregate response is exactly $$\tag{14.4}
\frac{R(t)}{A}=\sum_i c_i\,f_i(t-\tau_i),\qquad c_i=\frac{w_ia_i}{A}.$$ If every $f_i$ completes its rise within $[-\varepsilon,\varepsilon]$, then $F(t-\varepsilon)\le R(t)/A\le F(t+\varepsilon)$. Here $F(t)=\sum_i c_i\,\mathbf 1\{\tau_i\le t\}$ is the impact-weighted distribution of lags. The spread of the aggregate response is the spread of the lags plus the mean spread within a unit (law of total variance).

*Proof.* $R=\sum_i w_ia_if_i(t-\tau_i)$; divide by $A$. If $f_i(u)=0$ for $u\le-\varepsilon$ and $f_i(u)=1$ for $u\ge\varepsilon$, then $\mathbf 1\{\tau_i\le t-\varepsilon\}\le f_i(t-\tau_i)\le\mathbf 1\{\tau_i\le t+\varepsilon\}$. Multiply by $c_i\ge0$ and sum. The variance statement is the law of total variance for the mixture distribution. $\square$

**Theorem 14.7** **(AT-III Thm. 3.6: squeezing).** **\[PROVED\]** Sample the aggregate in bins of width $\Delta$, and let the event fall at a uniformly random position inside its bin. If the response is contained in $[t_0-a,\,t_0+b]$, the share of it that falls inside the bin holding $t_0$ is at least $1-(a+b)/\Delta$. It tends to 1 as $\Delta\to\infty$. For small $\Delta$ it is about $\Delta$ times the response density at $t_0$.

*Proof.* With $U$ uniform on $[0,1]$, the bin is $[t_0-U\Delta,\,t_0+(1-U)\Delta]$. It contains $[t_0-a,t_0+b]$ whenever $U\Delta\ge a$ and $(1-U)\Delta\ge b$, which has probability $1-(a+b)/\Delta$. For small $\Delta$ the bin holds the response mass in an interval of length $\Delta$ around $t_0$. $\square$

**In words.** Every unit reacts smoothly and at its own time, and the whole is their mixture. Sampled coarsely, the mixture looks like a jump at $t_0$: no reaction, then all of it. The logistic micro picture and the step macro picture are the same event at two resolutions.

#### 14.3.3 Velocity fields, mass and binding (B, P3) *\[AT-III §3.3\]*

**Theorem 14.8** **(AT-III Thm. 3.7: linear-field split).** **\[PROVED\]** Fit $v_i=V_0+M(x_i-\bar x)+r_i$ by weighted least squares, where $\bar x$ is the weighted mean position. Then, exactly, $$\tag{14.5}
\sum_i w_i|v_i|^2=|V_0|^2+\sum_i w_i\,|M(x_i-\bar x)|^2+\sum_i w_i|r_i|^2 .$$ The three parts are bulk (collective) motion, the linear field and internal motion. The tensor $M=tial v/tial x$ has three parts: its trace divided by the dimension, which is the *expansion rate* or speed per unit of space; its antisymmetric part, the rotation; and its traceless symmetric part, the shear. In Galactic coordinates the Oort constants are $A=\tfrac{1}{2}(M_{xy}+M_{yx})$, $B=\tfrac{1}{2}(M_{yx}-M_{xy})$, $C=\tfrac{1}{2}(M_{xx}-M_{yy})$ and $K=\tfrac{1}{2}(M_{xx}+M_{yy})$. A flat rotation curve gives $A=-B=\Theta_0/2R_0$.

*Proof.* With $y_i=x_i-\bar x$ and $\sum_i w_iy_i=0$, the normal equations give $V_0=\sum_i w_iv_i$ and $\sum_i w_ir_iy_i^{\top}=0$. Hence $\sum_i w_ir_i=0$, $\sum_i w_iV_0\cdot My_i=0$ and $\sum_i w_ir_i\cdot My_i=\operatorname{tr}(M\sum_i w_iy_ir_i^{\top})=0$. The cross terms vanish. For the Oort constants, write the radial and tangential components of $My$ at Galactic longitude $l$ in the plane: $v_r/d=K+A\sin2l+C\cos2l$ and $v_l/d=B+A\cos2l-C\sin2l$. For a flat rotation curve, $v=\Theta_0(y,R_0-x)/R$ about the Sun, so $tial v_x/tial y=\Theta_0/R_0$ and $tial v_y/tial x=0$. $\square$

**Theorem 14.9** **(AT-III Thm. 3.8: composite mass).** **\[PROVED\]** For future-directed timelike four-momenta $p_i$, the invariant mass is superadditive: $M(\sum_i p_i)\ge\sum_i M(p_i)$. The excess times $c^2$ is the parts’ kinetic energy in the centre-of-momentum frame, and it vanishes only if all parts move together.

*Proof.* For future-directed timelike $p,q$, $p\cdot q\ge M(p)M(q)$ (reverse Cauchy–Schwarz in Minkowski space). Hence $M(p+q)^2=M(p)^2+M(q)^2+2p\cdot q\ge(M(p)+M(q))^2$; induct on the number of parts. In the centre-of-momentum frame $M(\sum_i p_i)c^2=\sum_i E_i^*=\sum_i m_ic^2+\sum_i K_i^*$. $\square$

**Known result 14.10** **(AT-III Known result 3.9: virial theorem and its sign law; e.g. Goldstein et al., 2002).** **\[KNOWN RESULT\]** For a bound, stationary system with power-law potential energy $V\propto r^n$, the time averages satisfy $2\langle K\rangle=n\langle V\rangle$. The internal energy is therefore $E_{\mathrm{int}}=K+V=(1+2/n)K$, and the composite’s rest energy is $\sum_i m_ic^2+E_{\mathrm{int}}$. For $n=-1$ (gravity, Coulomb), $E_{\mathrm{int}}=-K<0$ and the composite is *lighter* than its parts. For $n=+1$ (linear confinement, as in potential models of heavy quarkonium), $E_{\mathrm{int}}=3K>0$ and it is *heavier*.

**Remark 14.11** **(Relation to Part II — editorial).** Theorem 14.2, Theorem 14.9 and Known result 14.10 restate Theorem 13.9, Theorem 13.12 and Known result 13.14 of Chapter 13 in the compressed setup; Theorem 14.3, Theorem 14.4, Theorem 14.5, Theorem 14.6, Theorem 14.7 and Theorem 14.8 are new to AT-III.

### 14.4 P1: aggregation lowers speed and turbulence *\[AT-III §4\]*

Theorem 14.2, Theorem 14.3 and Theorem 14.5 prove P1 in the only form in which it is true for all systems: ratios that cannot exceed one. Two parts of the original wording need correcting.

- **\[REFUTED AS STATED\]** *“The index may have a lower mean.”* It does not. With fixed weights its mean return equals the weighted mean of its stocks’ mean returns (Theorem 14.4a; the package checks this on the S&P 500, Table 14.13). What is lower is turbulence. What is *higher* is compound growth relative to the typical stock (Theorem 14.4b).

- **\[REFUTED AS STATED\]** *“Quarks to atoms may halve the directional speed.”* No universal factor exists (Theorem 14.5). In a fixed frame each level keeps the share of motion that its groups have in common. That share ranges from almost all to almost none in the data below.

What remains to measure are the parameters: the level factors and, for turbulence, the pair $(N_{\mathrm{eff}},\bar\rho)$ that fixes $\Psi$ through (14.2).

###### What Table 14.3 says

**\[MEASURED\]** Every ratio is below one, as it must be; the data decide only how far below. *US counties:* only 0.116 of the growth-rate energy of the counties is collective; on average 0.716 of the case weight moves with the nation in a given week, and the largest state (California) moved against it in 0.25 of weeks, the Tesla-and-S&P pattern in an epidemic. *World GDP* is calmer than its countries by $\Psi=0.606$; the value follows exactly from $N_{\mathrm{eff}}=22.6$ and $\bar\rho=0.338$. The United States grew against the world in 0.12 of years. *Twenty housing markets* are strongly correlated ($\bar\rho=0.692$); aggregating them keeps most of their motion ($\kappa=0.727$, $\Psi=0.850$). The most contrary metro, TX-Dallas, moved against the composite in 0.22 of months.

**Table 14.3.** P1 measured *\[AT-III Tab. 3\]*. $\varphi$: speed ratio; $\kappa$: collective share of energy; $\Psi$: turbulence ratio (constant weights), equal to $\sqrt{H+(1-H)\bar\rho}$ to rounding error in every row; agreement: share of weight moving in the aggregate’s direction. $^{u}$: run pending on the user’s machine (**\[PENDING RUN\]**). Filled rows: **\[MEASURED\]**.

| System | units $\to$ aggregate | data | $\varphi$ | $\kappa$ | $\Psi$ | $N_{\mathrm{eff}}$ | $\bar\rho$ | agreement |
|---|---|---|---|---|---|---|---|---|
| COVID-19 | counties $\to$ US | weekly, 2020–22 | 0.542 | 0.116 | 0.574 | 21.3 | 0.296 | 0.716 |
| COVID-19 | countries $\to$ world | weekly, 2020–22 | 0.554 | 0.162 |   |   |   | 0.656 |
| GDP | countries $\to$ world | annual, 1990-2023 | 0.690 | 0.402 | 0.606 | 22.6 | 0.338 | 0.780 |
| Housing | metros $\to$ Composite-20 | monthly, 2000–26 | 0.898 | 0.727 | 0.850 | 10.2 | 0.692 | 0.854 |
| Stocks$^{u}$ | stocks $\to$ S&P 500 | daily, 12 months | – | – | – | – | – | – |
| Stocks$^{u}$ | stocks $\to$ Dow | daily | – | – | – |   |   |   |
| Crypto$^{u}$ | coins $\to$ basket | 1-minute bars | – | – | – |   |   |   |
| Crypto$^{u}$ | coins $\to$ basket | daily bars | – | – | – |   |   |   |
| Stars$^{u}$ | stars $\to$ 100 pc sphere | Gaia DR3, LSR frame | – | – |   |   |   |   |
| Stars | stars $\to$ groups (3 levels) | Gaia DR3, 169,740 stars |   | 0.20 |   |   |   |   |
| Winds$^{u}$ | stations $\to$ region | hourly ASOS | – | – |   |   |   |   |
| Storms$^{u}$ | track points $\to$ storms | IBTrACS | – | – |   |   |   |   |

![Society, real data [AT-III Fig. 1]. (a) Collective share κ (log scale, 1 down to 0.1) kept at each level 0–3 of four hierarchies (P1, Theorem 14.5): COVID US, COVID world, GDP and house prices; every curve falls at every step, the county→state step losing most. (b) The first US wave of 2020 (share of first-wave cases, February–July 2020): the United States curve, the case-weighted mixture of the 2,366 county half-times (step mixture F) and the template mixture lie on top of one another (P2, Theorem 14.6). (c) Share of a wave that falls in the single bin holding its midpoint, against bin width in days (100 to about 3 × 102, log scale; Theorem 14.7): the synchronised Omicron wave squeezes into a step at shorter bins than the first wave.](figures/agg_society.png)

*Society, real data [AT-III Fig. 1]. (a) Collective share κ (log scale, 1 down to 0.1) kept at each level 0–3 of four hierarchies (P1, Theorem 14.5): COVID US, COVID world, GDP and house prices; every curve falls at every step, the county→state step losing most. (b) The first US wave of 2020 (share of first-wave cases, February–July 2020): the United States curve, the case-weighted mixture of the 2,366 county half-times (step mixture F) and the template mixture lie on top of one another (P2, Theorem 14.6). (c) Share of a wave that falls in the single bin holding its midpoint, against bin width in days (100 to about 3 × 102, log scale; Theorem 14.7): the synchronised Omicron wave squeezes into a step at shorter bins than the first wave.*

###### The cascade

**\[MEASURED\]** Figure 14.1a shows the collective share kept at each level of four hierarchies, all from real data: counties $\to$ states $\to$ census regions $\to$ nation; countries $\to$ UN sub-regions $\to$ regions $\to$ world, for COVID-19 and for GDP; metros $\to$ census regions $\to$ composite. Every curve falls at every step, as Theorem 14.5 requires, and the step sizes differ: the first step from counties to states loses most of the epidemic’s motion, while the step from metros to regions loses little of the housing markets’.

###### Growth, particles and gases

**\[MEASURED\]** Table 14.4 collects the remaining P1 numbers. The world’s GDP grew by a factor $e^{1.525}$ over 1990-2023; the GDP-weighted mean of the countries’ log growth is lower, 1.235: the Jensen gap of Theorem 14.4b. A share 0.84 of the starting GDP sat in countries that grew less than the world. For the S&P 500 the package measures the same split as the share of stocks that trail the index, and checks the preserved mean (Table 14.13). In the simulated gas of Section 14.6 a vortex sits on thermal motion; the collective share of kinetic energy kept by cells of decreasing size is monotone, as required, and the parameter that matters is the ratio of cell size to the size of the coherent motion. Part I found the same for particles grouped in a hierarchy.

**Table 14.4.** P1: the numbers quoted in the text of AT-III §4 *\[AT-III §4\]*. All **\[MEASURED\]**.

| Quantity | Value |
|---|---|
| Share of weeks California moved against the nation (COVID-19) | 0.25 |
| Share of years the United States grew against the world (GDP) | 0.12 |
| Share of months TX-Dallas moved against the composite (housing) | 0.22 |
| World GDP growth factor, 1990-2023 | $e^{1.525}$ |
| GDP-weighted mean of countries’ log growth | 1.235 (Jensen gap, Theorem 14.4b) |
| Share of starting GDP in countries that grew less than the world | 0.84 |
| Simulated gas: collective share of kinetic energy kept by cells | 0.000 whole box (the vortex has no net momentum); 0.128 for $4\times4$ cells; 0.191 for $16\times16$; 0.222 for $64\times64$ |
| Part I particles in a hierarchy: bulk shares for 1000, 200, 40, 8 and 1 groups | 1.000, 0.822, 0.753, 0.657, 0.471 (re-run here: 0.471 for one group) |

### 14.5 P2: events, lags and impacts *\[AT-III §5\]*

Theorem 14.6 and Theorem 14.7 turn P2 into two testable statements: an aggregate’s response is the impact-weighted mixture of its units’ responses, and its apparent abruptness depends on the bin width compared with the spread of the lags. The tests take events where units can be followed one by one (Table 14.5).

**Table 14.5.** P2 measured *\[AT-III Tab. 4\]*. $R^2$ of the aggregate response against the step mixture $F$ and against the template mixture $\sum_i c_if(t-\tau_i)$; spread of the impact-weighted lags; 10–90% rise times of a typical unit (impact-weighted median) and of the aggregate. $^{u}$: **\[PENDING RUN\]** other rows **\[MEASURED\]**.

| Event | units | $R^2$ step | $R^2$ template | lag IQR | unit rise | aggregate rise |
|---|---|---|---|---|---|---|
| COVID-19 first wave, US | 2,366 counties | 0.968 | 0.992 | 44 d | 61 d | 83 d |
| COVID-19 Omicron wave, US | 3,154 counties | 0.923 | 0.997 | 9 d | 47 d | 53 d |
| COVID-19 first wave, world | countries | 0.922 | 0.985 | 30 d | 58 d | 83 d |
| Housing crash 2005–11 | 19 metros | 0.964 | 0.993 | 5.5 mo | 14.9 mo | 16.6 mo |
| Beam through a magnet | 20,000 particles | 1.000 | 1.0000 | 0.398 $\mu$s | 0.160 $\mu$s | 0.782 $\mu$s |
| Crypto jumps$^{u}$ | coins, 1-s bars | – | – | – s |   |   |

###### The beam: the user’s example

**\[MEASURED\]** A bunch of charged particles with a 5% speed spread crosses a dipole magnet with soft edges. Each particle’s deflection is a smooth logistic-like ramp lasting 0.160 $\mu$s. The beam centroid’s deflection is the mixture, and it lasts 0.782 $\mu$s because the particles arrive at different times. The share of the deflection that falls in one time bin grows with the bin width (Table 14.6). This is P2’s “logistic at the micro level, a step at coarse scales”, reproduced from first principles (Figure 14.3c).

###### Epidemic waves

**\[MEASURED\]** The 2020 wave reached US counties over months: the impact-weighted interquartile range of their half-times is 44 days, so the national curve rose more slowly (83 days, 10–90%) than a typical county’s (61 days). The Omicron wave reached counties within 9 days of each other; it is the more synchronised event, and it squeezes faster (Table 14.6).

###### The housing crash

**\[MEASURED\]** The metros peaked between 2005-09 (MA-Boston) and 2007-08 (NC-Charlotte); the composite peaked in 2006-07. The composite’s fall from June 2005 is exactly the weighted sum of the metros’ falls, because the composite is a fixed combination of the metro indices to within 0.00173 (largest relative error over 317 months). It matches the mixture of their half-times with $R^2=0.993$.

**Table 14.6.** P2: squeezing shares and the housing identity *\[AT-III §5, Tab. 1\]*. All **\[MEASURED\]**.

| Quantity | Value |
|---|---|
| Beam: share of the deflection in one time bin | 0.01 for 10 ns bins; 0.26 for 0.2 $\mu$s; 0.76 for 1 $\mu$s; 0.94 for 4 $\mu$s |
| Beam: speed spread of the bunch; unit ramp; centroid ramp | 5%; 0.160 $\mu$s; 0.782 $\mu$s |
| COVID-19 first wave: share in one bin, daily $\to$ yearly bins | 0.01 $\to$ 0.93 |
| Share of the wave in monthly bins: Omicron against first wave | 0.54 against 0.28 |
| Housing: composite as a fixed combination of the metro indices | largest relative error 0.00173 over 317 months |
| Housing: metro peaks; composite peak | 2005-09 (MA-Boston) to 2007-08 (NC-Charlotte); 2006-07 |

###### Markets

**\[MEASURED\]** The author’s earlier runs established three things (Table 13.1): a market-wide move takes about five seconds to reach all coins, with BTC first; the correlation between coins rises from 0.745 at one minute to 0.82 at fifteen minutes (the Epps effect, Hypothesis 13.19); order-book information lasts about forty seconds. **\[PENDING RUN\]** The new tests follow single market-wide jumps in one-second bars: for each coin they measure the half-time and the impact, fit the mixture law to the basket and record the squeezing (Table 14.5 and Table 14.13). They also measure how concave the price response to signed taker flow is, a proxy for the square-root law, which strictly concerns the total impact of large orders executed in pieces (Bouchaud et al., 2018; Tóth et al., 2011): the exponent is 1 for linear impact and $\tfrac{1}{2}$ for a square root.

### 14.6 P3: matching of energy and of flows *\[AT-III §6\]*

P3 makes three claims: energies are matched; internal motion is hidden at aggregate levels; and flows dominate. Each has a precise counterpart.

#### 14.6.1 Kinetic with potential: bound composites *\[AT-III §6.1\]*

**\[MEASURED\]** Known result 14.10 predicts the *sign* of the difference between a bound whole and its parts from the shape of the binding. The data agree in every case tested (Table 14.7, Figure 14.2): atoms ($n=-1$) and nuclei (short-range attraction) are lighter than their parts; hadrons (confinement, $n\approx+1$ at large distance) are heavier than their current quark masses, the proton’s internal energy dominating and the ratio falling towards one as the quarks get heavier; free composites (Theorem 14.9) are heavier than the sum of their pair masses in every ATLAS four-lepton event of the author’s pilot.

**Table 14.7.** The whole against its parts *\[AT-III §6.1\]*. All **\[MEASURED\]**.

| Composite (binding) | Test | Result |
|---|---|---|
| Atoms ($n=-1$) | hydrogen against a proton plus an electron, from tabulated atomic masses | lighter by 13.6 eV (13.6 eV expected) |
| Nuclei (short-range attraction) | 2,938 tabulated isotopes against free nucleons and electrons | all lighter (share 1.0000); binding energy peaks at Ni-62, 8.795 MeV per nucleon, a mass defect of 0.0094 of the parts |
| Hadrons (confinement, $n\approx+1$) | 15 hadrons against their current quark masses | all heavier; proton 104 times its quarks; $J/\psi$ 1.22, $\Upsilon$ 1.13 |
| Free composites (Theorem 14.9) | 832 ATLAS four-lepton events, whole against the sum of the two pair masses | whole heavier in every event (832 of 832); median gap 0.172 of the whole |

![The whole against its parts [AT-III Fig. 2]. (a) Nuclei: binding energy per nucleon (MeV, 0–9) against mass number A (0–300) for 2,938 isotopes; every point is positive, so every nucleus is lighter than its free nucleons, with the peak near A ≈ 60. (b) Hadrons: the ratio hadron mass / sum of quark masses (log scale, 1 to 102) against the sum of the current quark masses (MeV, 101 to 104) for p, π+, K+, Ω−, D0, B+, J/ψ and Υ; every ratio exceeds one and approaches it as the quarks get heavier.](figures/agg_bound_composites.png)

*The whole against its parts [AT-III Fig. 2]. (a) Nuclei: binding energy per nucleon (MeV, 0–9) against mass number A (0–300) for 2,938 isotopes; every point is positive, so every nucleus is lighter than its free nucleons, with the peak near A ≈ 60. (b) Hadrons: the ratio hadron mass / sum of quark masses (log scale, 1 to 102) against the sum of the current quark masses (MeV, 101 to 104) for p, π+, K+, Ω−, D0, B+, J/ψ and Υ; every ratio exceeds one and approaches it as the quarks get heavier.*

#### 14.6.2 Internal with external: collective motion becomes heat *\[AT-III §6.2\]*

**\[MEASURED\]** A direct-simulation Monte Carlo gas (Bird, 1994) of 120,000 hard-sphere molecules starts as a Taylor–Green vortex on thermal motion, with velocities drawn from a uniform cube rather than a Maxwellian (Table 14.8, Figure 14.3). Collisions conserve momentum and energy exactly; the vortex is collective energy and decays; the internal (thermal) energy rises by exactly what the vortex lost; and the internal velocities relax to a Maxwell–Boltzmann distribution. This is the step from $y$ to $x$ in Deng, Hani and Ma’s derivation of fluid equations (Deng et al., 2025), used as the guiding example in Part I: internal motion forgets everything except its mean and variance, and so the aggregate closes.

**Table 14.8.** The simulated gas *\[AT-III §6.2\]*. All **\[MEASURED\]** (computed).

| Quantity | Value |
|---|---|
| Molecules (hard spheres, DSMC) | 120,000 |
| Change of total energy over the run (rounding) | at most $1.11\times10^{-16}$ |
| Decay rate of the vortex (collective energy) | 0.123 per time unit |
| Vortex amplitude kept after 127 collisions per molecule | 0.683 |
| Rise of internal (thermal) energy | 0.125, exactly what the vortex lost |
| Kurtosis of the internal velocities | 1.82 $\to$ 3.00 (3 for a Gaussian) |

![Computed physics [AT-III Fig. 3]. (a) Collective share κ of the gas against cell size (log scale, 10−1 to a few units) at the start (t = 0, from 0.22) and halfway (t = 1.4, from 0.145): smaller cells keep more, and the whole box keeps none. (b) Against time (0 to 2.7): the vortex (collective) amplitude decays from 1 to about 0.68, the heat gained (internal) rises to about 0.125, and the distance to the Maxwell distribution falls to zero. (c) A beam crossing a magnet: individual particles (grey) deflect as smooth ramps; the beam centroid (blue) is their mixture and coincides with the mixture of half-times (red dashed); time in microseconds from  − 1 to 2.5 (P2).](figures/agg_computed_physics.png)

*Computed physics [AT-III Fig. 3]. (a) Collective share κ of the gas against cell size (log scale, 10−1 to a few units) at the start (t = 0, from 0.22) and halfway (t = 1.4, from 0.145): smaller cells keep more, and the whole box keeps none. (b) Against time (0 to 2.7): the vortex (collective) amplitude decays from 1 to about 0.68, the heat gained (internal) rises to about 0.125, and the distance to the Maxwell distribution falls to zero. (c) A beam crossing a magnet: individual particles (grey) deflect as smooth ramps; the beam centroid (blue) is their mixture and coincides with the mixture of half-times (red dashed); time in microseconds from  − 1 to 2.5 (P2).*

#### 14.6.3 Internal motion is hidden, so flows dominate *\[AT-III §6.3\]*

Part I proved the precise version of “internal actions are hidden” (its Theorem 3.1, a Mori–Zwanzig split): an aggregate evolves by a Markov part, a memory part and a noise part, and the last two carry the hidden internal motion. At coarser levels the internal share of motion, $1-\kappa$, *grows* (Table 14.3). Two things follow: what remains visible is the collective flow; the hidden internal motion reaches the aggregate only as noise and memory. In markets the hypothesis becomes a measurable statement:

**Hypothesis 14.12** **(AT-III Hyp. 6.1: flows dominate at aggregate levels).** **\[HYPOTHESIS\]** The share of price change explained by net order flow (order-flow imbalance, OFI, Cont et al., 2014) is larger for aggregates (a basket, a book summed over levels) than for units, and peaks at a time scale set by how fast liquidity refills.

**\[PENDING RUN\]** The package measures this share in three places, listed in Table 14.13: the Binance order book at the best level and over five levels, from one second to five minutes; coins against the basket, using taker flow, from one minute to one day; and futures depth within 1% of the mid. **\[MEASURED\]** The earlier runs found that one-minute OHLC bars recover 35% of the order-flow information and one-hour bars 18%. The flows’ share of price action is therefore a scale-dependent parameter, not a constant.

###### “Something equal to a constant, or a growth matching the flow of resources”

**\[MEASURED\]** For additive quantities the precise form is a balance law: stock now equals stock before plus inflow minus outflow. It holds exactly here in three places: counts (the counties’ weekly cases sum to the national series to within 23,408 cases out of 103,802,702); energy in the gas (Table 14.8); value in an index (Table 14.13). For non-additive quantities (price, mass) the matching is through a response coefficient, impact per unit of flow or the virial factor; that coefficient is a domain parameter.

#### 14.6.4 Stationary action in galaxies *\[AT-III §6.4\]*

In bound gravitating systems the virial theorem is the time-averaged form of stationary action. Two tests in Section 14.7 apply it: the ratio of observed to virial velocity dispersion, for clusters and moving groups; and the radial acceleration relation, $g_{\mathrm{obs}}=g_{\mathrm{bar}}/\bigl(1-e^{-\sqrt{g_{\mathrm{bar}}/g_\dagger}}\bigr)$ (McGaugh et al., 2016; Lelli et al., 2017) **\[KNOWN RESULT\]**. Visible matter alone does not balance the observed motion, so the whole “pulls harder” than its visible parts.

### 14.7 B: gravity, collective motion and the expansion of space *\[AT-III §7\]*

#### 14.7.1 Two rules, one tool *\[AT-III §7.1\]*

Gravity binds; expansion separates. Theorem 14.8 measures both with the same fit, $v=V_0+Mx+r$: in a galaxy’s disc, $M$ is rotation and shear (the Oort constants); among galaxies far apart, $M$ is isotropic expansion, $M=H_0\mathbb{I}$, and $H_0$ is the speed per unit of space that P3 and B asked about; inside a bound system, the expansion part of $M$ vanishes. The procedure the author proposed is: measure the separate rule, remove it, and study what is left. What is left is peculiar motion, whose collective part is a bulk flow.

#### 14.7.2 The speed per unit of space, measured *\[AT-III §7.2\]*

**\[MEASURED\]** The Pantheon+ compilation (Scolnic et al., 2022; Brout et al., 2022) has 1,701 light curves of type Ia supernovae. The four steps and their results are in Table 14.9 and Figure 14.4. The rule is therefore one number per unit of distance. The well-known difference from the value inferred from the cosmic microwave background (67.4, Planck Collaboration, 2020) is outside what this test can settle.

**Table 14.9.** Pantheon+: the expansion measured and removed *\[AT-III §7.2–7.3, Fig. 4\]*. All **\[MEASURED\]** (real data).

| Step | Sample | Result |
|---|---|---|
| 1\. Calibration | 77 supernovae in galaxies with Cepheid distances | absolute magnitude $M_B=-19.252$ |
| 2\. Hubble flow | 277 supernovae in the Hubble flow | $H_0=73.25\pm1.40\,\mathrm{km\,s^{-1}\,Mpc^{-1}}$, as in Riess et al. (2022) |
| 3\. All distances | all 1,303 supernovae beyond $z=0.023$ | $H_0=73.08$ and $\Omega_m=0.347$ |
| 4\. Shells | redshift shells from $z=0.01$ to 2.3 | shell values agree with a single rate: $\chi^2=5.7$ for 6 degrees of freedom, a spread of $4.39\,\mathrm{km\,s^{-1}\,Mpc^{-1}}$ (Figure 14.4b) |
| Reference | cosmic microwave background (Planck Collaboration, 2020) | 67.4; the difference is outside what this test can settle |
| Peculiar velocities | 445 supernovae at $0.01<z<0.06$, redshifts in the CMB frame | dipole (bulk flow) $290\pm65$ km/s toward Galactic $(l,b)=(314^\circ,20^\circ)$; adding the dipole lowers $\chi^2$ by 22.8 for three parameters |
| With the local-gravity model | Pantheon+ redshifts corrected by a model of the local gravity field | dipole drops to $129\pm55$ km/s ($\Delta\chi^2=5.8$); scatter of the Hubble residuals falls from 0.147 to 0.141 mag; about 145 km/s of velocity scatter removed at $z\approx0.027$ |
| Figure 14.4a | 1,466 SNe Ia | distance moduli about one law |

![The expansion as a separate rule (Pantheon+, real data) [AT-III Fig. 4]. (a) 1,466 SNe Ia around one law: residual distance modulus μ − model (mag,  ± 1) against redshift z (10−2 to above 1, log scale), scattered about zero. (b) Speed per unit distance by redshift shell: H0 (km/s/Mpc, 67–74) per shell with error bars, the fitted single value 73.1 (dashed) and the Planck CMB value 67.4 (dotted); the highest shell carries the largest error bar. (c) Collective motion on top: after removing the rule, the peculiar velocities (km/s,  ± 2000) of supernovae at 0.01 &lt; z &lt; 0.06 in the CMB frame against the cosine of the angle to their best-fit dipole, with the dipole of 290 km/s as the sloped line: a bulk flow.](figures/agg_pantheon.png)

*The expansion as a separate rule (Pantheon+, real data) [AT-III Fig. 4]. (a) 1,466 SNe Ia around one law: residual distance modulus μ − model (mag,  ± 1) against redshift z (10−2 to above 1, log scale), scattered about zero. (b) Speed per unit distance by redshift shell: H0 (km/s/Mpc, 67–74) per shell with error bars, the fitted single value 73.1 (dashed) and the Planck CMB value 67.4 (dotted); the highest shell carries the largest error bar. (c) Collective motion on top: after removing the rule, the peculiar velocities (km/s,  ± 2000) of supernovae at 0.01 &lt; z &lt; 0.06 in the CMB frame against the cosine of the angle to their best-fit dipole, with the dipole of 290 km/s as the sloped line: a bulk flow.*

#### 14.7.3 What is left after removing it: collective motion *\[AT-III §7.3\]*

**\[MEASURED\]** For the 445 supernovae at $0.01<z<0.06$, the peculiar velocity is the observed redshift minus the redshift that the distance alone would give. With redshifts in the CMB frame these velocities carry a dipole, a bulk flow of $290\pm65$ km/s toward Galactic $(l,b)=(314^\circ,20^\circ)$; with Pantheon+’s redshifts corrected by a model of the local gravity field the dipole drops to $129\pm55$ km/s (Table 14.9). Three layers result: *layer one*, expansion, is a separate rule; it is measured and removed. *Layer two*, gravity’s collective motion, is a bulk flow that a model of the mass distribution largely accounts for. *Layer three* is internal: individual motions and measurement error.

#### 14.7.4 Where expansion stops, and the same field one level down *\[AT-III §7.4\]*

**\[PENDING RUN\]** The remaining gravity tests run on the user’s machine (Table 14.10). Each has a literature value or a clear expectation, and each was also checked on synthetic catalogues in the real formats with a planted answer.

- *The Local Group.* The Updated Nearby Galaxy Catalog (Karachentsev et al., 2013) gives distances and velocities for about 900 galaxies within 11 Mpc. A line fitted to the galaxies at 1–3.5 Mpc gives the local expansion rate and the radius $R_0$ where it vanishes; Karachentsev et al. (2009) found $R_0=0.96\pm0.03$ Mpc. Galaxies inside 0.7 Mpc should show no expansion. The timing argument (Kahn and Woltjer, 1959; Lynden-Bell, 1981) turns $R_0$ into a mass.

- *Cosmicflows-4* (Tully et al., 2023) extends the test to 250 Mpc: a self-calibrated expansion rate and the bulk flow in spheres of growing radius. The bulk flow should decline with radius: P1 at cosmic scale.

- *Stars within 100 pc* (Gaia DR3 with radial velocities). The exact split of Theorem 14.8 gives the energy shares in bulk motion, in the Galactic field and in internal motion. The field gives the Oort constants, which Bovy (2017) measured from Gaia DR1.

- *Cluster motions.* The mean motions of the clusters of Hunt and Reffert (2024) within 1.5 kpc measure the same field one level up.

- *Matching of energy in clusters (P3).* The ratio $q=\sigma_{\mathrm{obs}}/\sigma_{\mathrm{vir}}$ uses $\sigma_{\mathrm{vir}}^2=GM_J/(7.5\,r_h)$ (Spitzer, 1987). Bound open clusters should have $q$ of order one (inflated by binaries); moving groups, which are unbound, should have $q\gg1$. Four nearby clusters observed directly in Gaia cones give the dynamical-to-visible mass ratio ($\Upsilon$ of Part II; expected values in Table 14.14). Groups of 30 neighbouring field stars should come out unbound.

- *Galaxies.* In SDSS groups (Tempel et al., 2017) the line-of-sight velocity spread, expressed as a Hubble distance, is compared with the projected size: if velocities inside groups were expansion, the ratio would be about one (the “fingers of God”). The mass-to-light ratio of groups against their luminosity tests whether bigger aggregates hide more mass. Five SDSS galaxy clusters give virial against stellar mass (Zwicky, 1933). The SPARC rotation curves give the acceleration scale of the radial acceleration relation.

**Table 14.10.** Gravity and the local expansion: tests run on the user’s machine *\[AT-III Tab. 5\]*. All rows **\[PENDING RUN\]** the last column is the offline check on synthetic catalogues, planted value $\to$ recovered value.

| Test | expected or literature | this run | synthetic check |
|---|---|---|---|
| Local expansion rate, 1–3.5 Mpc ($\mathrm{km\,s^{-1}\,Mpc^{-1}}$) | — | – | $70\to66.6$ |
| Zero-velocity radius $R_0$ (Mpc) | $0.96\pm0.03$ | – | $0.96\to0.92$ |
| Mean velocity inside 0.7 Mpc (km/s) | $\approx0$ (bound) | – | $0\to-4$ |
| Timing mass ($M_\odot$) | a few $10^{12}$ | – | — |
| Cosmicflows-4 expansion rate, self-calibrated | $\approx75$ (CF4 zero point) | – | $75\to74.7$ |
| Cosmicflows-4 bulk flow within 250 Mpc (km/s) | declines with radius | – | $300\to316\pm31$ |
| Oort $A$, $B$ from stars within 100 pc ($\mathrm{km\,s^{-1}\,kpc^{-1}}$) | 15.3, $-11.9$ | –, – | $15,-12\to12.0,-9.3$ ($\pm1.4$) |
| Oort $A$, $B$ from cluster motions within 1.5 kpc | 15.3, $-11.9$ | –, – | $15,-12\to15.3,-11.8$ ($\pm0.2$) |
| Energy shares of stars: bulk, field, internal | — | –, –, – | — |
| $q$, bound clusters (median) | order 1 | – | $1.5\to1.51$ |
| $q$, moving groups (median) | $\gg1$ | – | $6\to5.6$ |
| Dynamical / visible mass, four nearby clusters | order 1 | – | $1\to0.97$ |
| Dynamical / visible mass, 30-star field groups | $\gg1$ (unbound) | – | — |
| Velocity spread / projected size, groups | $\gg1$ | – | $12.6\to12.6$ |
| Slope of $\log(M/L)$ against $\log L$, groups | $>0$ | – | $0.33\to0.31$ |
| Virial / stellar mass, five galaxy clusters | $\gg1$ | – | — |
| $g_\dagger$ ($\mathrm{m\,s^{-2}}$), SPARC | $1.20\times10^{-10}$ | – | $1.20\to1.20$ ($\times10^{-10}$) |
| Scatter about the one-parameter law (dex) | 0.13 | – | $0.11\to0.11$ |

###### Where expansion takes over

The ratio of the expansion velocity across a system, $H_0R$, to its internal speed is a single number per scale (Table 14.11). Expansion is negligible inside clusters (ratio $\sim10^{-3}$) and inside galaxies. It becomes comparable to internal motion at the zero-velocity radius of groups ($\sim1$ Mpc), and it dominates beyond, where the bulk flows of a few hundred km/s ride on recession velocities of thousands.

**Table 14.11.** Expansion against internal motion by scale: $H_0R$ over the internal speed ($H_0=70$) *\[AT-III Tab. 6\]*. Rows marked $^{u}$ are **\[PENDING RUN\]** the supernova row is **\[MEASURED\]**.

| System | size | internal speed (km/s) | $H_0R$/internal |
|---|---|---|---|
| Open cluster (bound)$^{u}$ | $\sim$– pc | – | $\sim10^{-3}$ |
| Galaxy group$^{u}$ | – Mpc | – | $\sim0.1$ |
| Local Group edge$^{u}$ | $R_0=$ – Mpc | — | $\approx1$ by definition |
| Supernova shell, $z\approx0.027$ | $\approx115$ Mpc | 290 (bulk) | $\approx28$ |

**Remark 14.13** **(AT-III Figure 5, not produced — editorial).** **\[PENDING RUN\]** The source’s Figure 5 (“Gravity (user run)”) is two placeholder boxes, `gravity_stars` and `gravity_galaxies`, which appear once `run_all.py` has run this part on the user’s machine. Its caption reserves the panels: top (a) exact energy split of stars within 100 pc; (b) Oort constants from stars and from cluster motions against the literature; (c) observed-to-virial dispersion for bound clusters and moving groups; bottom (a) radial acceleration relation; (b) mass-to-light ratio of groups; (c) expansion against internal motion by scale.

### 14.8 Application A: the dark energy (placeholder) *\[AT-III template, final.pdf\]*

The later template of AT-III (`final.pdf`: the same paper with every measured number blanked to “–”) makes one addition. The list of applications in its §1.1 gains an item *A* with no text, and its Table 1 gains the row “A the Dark energy” whose body is an unfilled placeholder; no section is written for it. The only sentence on the subject in either version is the end of P3:

> “Galaxies and stars follow stationary action; the ‘empty void’ expands per unit of empty space.” *\[AT-III §1.1, P3\]*

**Hypothesis 14.14** **(Dark energy as a property of empty space).** **\[HYPOTHESIS\]** Dark energy depends on local emptiness: empty space expands on its own. The effect compounds with volume; it is near-uniform in voids and in average regions; it fades to $\approx0$ in clusters and galaxies; it is capped at zero density and stops above a density limit. The law is to be found by testing against real data.

**Remark 14.15** **(Provenance and the test — editorial).** The hypothesis is stated by the author outside the documents; neither AT-III nor its template gives a number, a functional form or a result, so nothing here is measured. The test the documents already provide is the Pantheon+ / velocity-field machinery of Section 14.7: the expansion is the trace of the linear field (Theorem 14.8), measured per redshift shell (Figure 14.4b, one rate at all distances) and set against internal motion per scale (Table 14.11, where it vanishes inside bound systems “by definition” at $R_0$). A rate that depends on local emptiness would show as a trace of $M$ that differs between voids and dense regions at fixed distance, which the shell test of Table 14.9 does not resolve by itself.

### 14.9 C: markets, from order books to indices *\[AT-III §8\]*

#### 14.9.1 What earlier runs established *\[AT-III §8.1\]*

**\[MEASURED\]** The author’s notebooks 01–04 ran on Binance, Tardis, CMS, ATLAS and Gaia data (Table 13.1); Table 14.12 lists what AT-III carries forward from them.

**Table 14.12.** What the earlier runs established, as quoted in AT-III *\[AT-III §8.1, §5, §6.3\]*. All **\[MEASURED\]** (earlier runs on real data).

| Statement | Result |
|---|---|
| Every exact statement held to floating-point precision | bars merge exactly, order flow adds exactly, and binned book imbalance is exact when bin edges align |
| The “restoration” in exponential moving averages is mechanical | slopes within 0.022 of the random-walk value on 132,480 BTC minutes |
| A small reversal exists | confirmation run fixed in advance (January–June 2026, 10 coins): rank information coefficient $-0.035$ to $-0.087$, BTC $z=-10.8$, effect present in 10 of 10 coins; breaks even at 0.3–3.3 bp round trip, against a 10 bp cost |
| Noise is not independent | scaling exponents 0.46–0.50 for returns, 0.81–0.87 for volume and 0.87–0.92 for trade counts |
| Propagation (Section 14.5) | a market-wide move takes about five seconds to reach all coins, BTC first; correlation between coins 0.745 at one minute $\to$ 0.82 at fifteen minutes (Epps effect); order-book information lasts about forty seconds |
| Flows at bar level (Section 14.6) | one-minute OHLC bars recover 35% of the order-flow information, one-hour bars 18% |

#### 14.9.2 The new tests *\[AT-III §8.2\]*

**\[PENDING RUN\]** The package runs four groups of tests on the user’s machine (Table 14.13).

1.  *The S&P 500 and the Dow.* The S&P 500 is rebuilt from about 500 stocks, with weights from the iShares IVV holdings back-cast by price. The P1 ratios of Table 14.3 follow, with the cascade stocks $\to$ GICS sub-industries $\to$ sectors $\to$ index, the preserved mean, the share of stocks that trail the index, and Tesla against the index. The price-weighted Dow is rebuilt from its 30 members since their last change.

2.  *Crypto across time scales.* One-minute bars for 15 coins (30 in the full preset) give $\varphi$, $\kappa$ and $\Psi$ from one minute to one day, with the cascade coin $\to$ sector $\to$ basket, and the share of price change explained by taker flow for coins and for the basket (Hypothesis 14.12).

3.  *Market-wide jumps in one-second bars.* The P2 tests of Table 14.5: lags, impacts, mixture, squeezing and the concavity of impact.

4.  *Order books.* Tardis top-five snapshots give the imbalance forecast by horizon and the order-flow price law across time scales and depth. Quotes from several venues give the lead and lag between venues. Binance futures depth within $\pm1\%$ of the mid gives the depth imbalance against later returns.

The expectations fixed before the run in Part II (Table 14.14) are the planted answers these tests are judged against, together with the “expected or earlier” column of Table 14.13.

**Table 14.13.** Markets: tests run on the user’s machine *\[AT-III Tab. 7\]*. All rows **\[PENDING RUN\]** the last column is the offline check on synthetic files with planted answers.

| Test | expected or earlier | this run | synthetic check |
|---|---|---|---|
| S&P 500 rebuilt from stocks, RMS error (bp/day) | $\approx0$ (exact) | – | $0\to0.0006$ |
| Collective share: sub-industries, sectors, index | falls at each step | –, –, – | — |
| Mean daily return: fixed-weight portfolio, weighted stock means (bp) | equal | –, – | equal |
| Share of stocks trailing the index: 12 months, long run | most | –, – | — |
| Tesla: share of days against the index; volatility ratio | some days | –, – | — |
| Dow rebuilt, RMS error (bp/day) | $\approx0$ (exact) | – | $0\to2\times10^{-12}$ |
| Coins $\to$ basket: $\kappa$ at 1 min, 1 h, 1 day | — | –, –, – | — |
| Mean pairwise correlation at 1 min and 1 day | 0.745 at 1 min (earlier) | –, – | — |
| Flow $R^2$, coin and basket, 1 min | basket $>$ coin (Hypothesis 14.12) | –, – | — |
| Flow $R^2$, coin and basket, 1 day |   | –, – | — |
| Jumps: first coin; slowest coin | BTC first (earlier) | –; – | BTC; LTC ($9\to8.5$ s) |
| Jumps: lag IQR (s); share in one 15-s bar | about 5 s (earlier) | –; – | 4.1; 0.43 |
| Impact exponent, 1-s and 60-s bins | $\tfrac{1}{2}$ to 1 | –, – | $0.5\to0.51$; 0.91 |
| Book imbalance IC at 1 s and 60 s | 0.53, 0.08 (earlier) | –, – | — |
| OFI $R^2$, best level and five levels, 1 s | rises with depth | –, – | — |
| OFI $R^2$, best level and five levels, 60 s |   | –, – | — |
| Venues behind Binance, median lag (s) | — | – | $0.6, 1.5, 3\to1, 2, 3$ |
| Futures depth imbalance against the next 5 min (IC) | — | – | planted $\to0.54$ |

**Table 14.14.** Expected values stated before the run for the matching parameters of the particle, gravity and market tests *\[AT-II Tab. 3, Tab. 1\]*; they are the “expected” side of Table 14.7, of the mass-ratio rows of Table 14.10 (where $\Upsilon$ is written dynamical / visible mass) and of Table 14.13. All **\[PENDING RUN\]** except the ATLAS row (**\[MEASURED\]**).

| System | exact part | gap between whole and parts | expected |
|---|---|---|---|
| CMS dimuons | four-momentum | $M/(m_1+m_2)$; $\beta=\|P\|/E$ | $J/\psi$: 14.7; $\beta$ broad, $M$ sharp |
| ATLAS four leptons | four-momentum | $(M_{4\ell}-M_{12}-M_{34})/M_{4\ell}$ | $\ge0$ always; median 17% (measured; 0.172 in Table 14.7) |
| Open clusters | momentum | $\Upsilon=M_{\mathrm{dyn}}/M_{\mathrm{vis}}$ | 1–5 (bound, binaries, tides) |
| Field star groups | momentum | $\Upsilon$ | $\sim10^5$ (not bound) |
| Galaxy clusters | momentum | $\Upsilon=M_{\mathrm{VT}}/M_\star$ | 30–100 or more (dark matter, gas) |
| S&P 500 | index return | $\kappa$; $\sigma_I/\sum w\sigma$ | $\kappa\approx0.2$–$0.4$; ratio 0.6–0.75 |
| Crypto basket | basket return | $\kappa(\Delta)$; $\sigma_B/\sigma$ | $\kappa$ rising with $\Delta$, about $0.75\to0.8$; propagation $\tau\approx5$ s (Epps, Hypothesis 13.19) |
| Order book | order flow, depth | mid move relative to the microprice (microprice relaxation $k(H)$) | $k\gg1$ for BTC, flattening after seconds |

**Remark 14.16** **(AT-III Figure 6, not produced — editorial).** **\[PENDING RUN\]** The source’s Figure 6 (“Markets (user run)”) is a placeholder box, `markets_overview`, to be filled by the user’s run. Its caption reserves: (a) cascades for the S&P 500 and the crypto basket; (b) collective share, turbulence ratio and flow $R^2$ against bar length; (c) a market-wide jump in one-second bars, the basket’s response and the mixture of the coins’ half-times.

### 14.10 D: the Riemann zeta function as an aggregate *\[AT-III §9\]*

#### 14.10.1 The idea, made precise *\[AT-III §9.1\]*

For $\Re s>1$, $\zeta(s)=\sum_n n^{-s}$ is literally an aggregate of units $n^{-s}=n^{-\sigma}e^{-it\log n}$: each unit is a vector of length $n^{-\sigma}$ turning at its own rate $\log n$. On the critical line the Riemann–Siegel formula (Edwards, 1974) writes the real function $Z(t)=e^{i\theta(t)}\zeta(\tfrac{1}{2}+it)$ as $$\tag{14.6}
Z(t)=2\sum_{n\le\sqrt{t/2\pi}}\frac{\cos\bigl(\theta(t)-t\log n\bigr)}{\sqrt n}+R(t),$$ a finite aggregate of oscillating units plus a small remainder; the package uses the correction terms $C_0$–$C_2$ for the remainder. In the language of Theorem 14.2: a zero is a height where the units’ sum vanishes, so the speed ratio of the aggregate is zero; the author’s “real and imaginary parts as aggregating layers” are the two families of curves $\Re\zeta=0$ and $\Im\zeta=0$, and the zeros are where they cross (Figure 14.6). **\[MEASURED\]** Measured on the dyadic blocks of (14.6), the alignment $|\sum\text{blocks}|/\sum|\text{blocks}|$ is 0.00443 at zeros and 0.158 at random heights: the zeros are points of near-perfect cancellation among large units.

**Known result 14.17** **(AT-III Known result 9.1: what is and is not known).** **\[KNOWN RESULT\]** Bohr and Landau (1914) proved that almost all zeros lie arbitrarily close to $\Re s=\tfrac{1}{2}$. The Riemann hypothesis (all non-trivial zeros on the line) has been checked numerically to height $3\times10^{12}$ (Platt and Trudgian, 2021). It remains unproved. Nothing below is, or could be, a proof. It is a check of the package and a reading of the zeros in aggregation terms.

#### 14.10.2 Results to height $10^6$ *\[AT-III §9.2\]*

**\[MEASURED\]** Table 14.15 lists every number; Figure 14.5 shows them. Sign changes of $Z(t)$, located on a grid refined until the count agrees with the independent count $N(T)$ from Turing’s method (Turing, 1953) in `mpmath`, give every zero on the line. After unfolding, the spacings have mean 1 and the statistics of the energy levels of a random quantum system: the zeros repel each other and the pair correlation follows Montgomery’s $1-(\sin\pi u/\pi u)^2$ (Montgomery, 1973; Odlyzko, 1987). $N(T)$ splits into a smooth mean $\theta(T)/\pi+1$ and an error $S(T)$, P1’s “mean state and an error”, whose variance grows as Selberg’s leading term $\log\log T/2\pi^2$ (Selberg, 1946) predicts up to a lower-order offset. The primes are rebuilt from the zeros: Chebyshev’s $\psi(x)$ stays within Schoenfeld’s bound $|\psi(x)-x|<\sqrt x\log^2x/8\pi$ (Schoenfeld, 1976), which is equivalent to the Riemann hypothesis, and the explicit formula rebuilds $\psi$ from the first $K$ zeros, each zero a unit wave $x^\rho/\rho$, with an error that falls as units are added. Two proved analogues close the check: the Hasse bound and the Sato–Tate law (Barnet-Lamb et al., 2011) for the elliptic curve $y^2=x^3+x+1$, and the Dirichlet $L$-function for the character mod 4.

**Table 14.15.** The zeta function as an aggregate: results to height $10^6$ *\[AT-III §9.1–9.2\]*. All **\[MEASURED\]** (computed).

| Quantity | Value |
|---|---|
| Zeros on the line up to $T=1{,}000{,}000$ (sign changes of $Z(t)$) against the count $N(T)$ in the strip (Turing’s method, `mpmath`) | 1,747,146 of 1,747,146 (missing: 0) |
| Riemann–Siegel values against `mpmath`; spot-checked zeros | agree to $2.84\times10^{-8}$; $4.95\times10^{-10}$ |
| Alignment $\|\sum\text{blocks}\|/\sum\|\text{blocks}\|$ of the dyadic blocks | 0.00443 at zeros; 0.158 at random heights |
| Unfolded spacings: mean | 1 |
| Kolmogorov–Smirnov distance of the spacings from GUE; from independent levels | 0.0151; 0.293 |
| Share of spacings below a tenth of the mean; same for independent levels | $9.11\times10^{-4}$; 0.0952 (the zeros repel) |
| Pair correlation against Montgomery’s $1-(\sin\pi u/\pi u)^2$ | RMS error 0.0178 |
| Error $S(T)$ at random heights in $[T/2,T]$: mean, standard deviation, maximum | $5.81\times10^{-4}$, 0.442, 1.71 |
| Growth of $\operatorname{Var}S$ as $T$ rises a hundredfold; Selberg’s leading term $\log\log T/2\pi^2$; remaining offset (lower-order term) | 0.0252; 0.0205; 0.063 |
| $\psi(x)$ within Schoenfeld’s bound up to $x=100{,}000{,}000$: largest ratio to the bound; ratio beyond $10^5$ | 0.918 at $x=97$; at most 0.112 |
| Explicit formula, error with the first $K=10,10^2,10^3,10^4$ zeros | 0.545, 0.2, 0.0474, 0.0109 |
| Elliptic curve $y^2=x^3+x+1$: Hasse bound at all primes tested; largest ratio | 9,589 primes; 0.99969 |
| Sato–Tate law for its angles: KS distance, $p$-value | 0.00879, $p=0.447$ |
| Dirichlet $L$-function, character mod 4: zeros on the line up to height 60 | 25, against 25.2 expected |

![The zeta function as an aggregate (computed) [AT-III Fig. 7]. (a) Z(t) for t from 7000 to 7012 ( ± 8): zeros are its sign changes. (b) Density of the block alignment |∑blocks|/∑|blocks| (0 to 1) at random heights (grey, spread out) and at zeros (blue, piled near 0): the units cancel at zeros. (c) Density of the normalised spacing (0 to 3): the histogram of zeta zeros (the panel’s legend counts 1,746,496), the GUE random-matrix curve and the independent (Poisson) curve; the zeros follow GUE. (d) Montgomery’s law: pair correlation of the zeros (dots) against u in mean spacings (0 to 3) and the curve 1 − (sinπu/πu)2. (e) Primes: $(\psi(x)-x)/\sqrt x$ (blue, within  ± 1) against x from 102 to 108, between the two branches of the RH bound $\pm\sqrt x\log^2x/8\pi$ divided by $\sqrt x$ (dashed,  ± 10). (f) Proved analogue: density of $\theta_p=\arccos(a_p/2\sqrt p)$ for 9,589 primes against the Sato–Tate density $\tfrac{2}{\pi}\sin^2\theta$.](figures/agg_zeta.png)

*The zeta function as an aggregate (computed) [AT-III Fig. 7]. (a) Z(t) for t from 7000 to 7012 ( ± 8): zeros are its sign changes. (b) Density of the block alignment |∑blocks|/∑|blocks| (0 to 1) at random heights (grey, spread out) and at zeros (blue, piled near 0): the units cancel at zeros. (c) Density of the normalised spacing (0 to 3): the histogram of zeta zeros (the panel’s legend counts 1,746,496), the GUE random-matrix curve and the independent (Poisson) curve; the zeros follow GUE. (d) Montgomery’s law: pair correlation of the zeros (dots) against u in mean spacings (0 to 3) and the curve 1 − (sinπu/πu)2. (e) Primes: $(\psi(x)-x)/\sqrt x$ (blue, within  ± 1) against x from 102 to 108, between the two branches of the RH bound $\pm\sqrt x\log^2x/8\pi$ divided by $\sqrt x$ (dashed,  ± 10). (f) Proved analogue: density of $\theta_p=\arccos(a_p/2\sqrt p)$ for 9,589 primes against the Sato–Tate density $\tfrac{2}{\pi}\sin^2\theta$.*

![The two “layers” of ζ(σ+it) [AT-III Fig. 8]: the curves ℜζ = 0 (blue) and ℑζ = 0 (orange, dashed) in the window  − 0.5 ≤ σ ≤ 1.5, t up to 50, with the zeros as black dots. Every zero in the window is a crossing of the two families, and every crossing lies on $\sigma=\tfrac{1}{2}$ (the vertical dashed line); zeros need both layers to vanish.](figures/agg_zeta_layers.png)

*The two “layers” of ζ(σ+it) [AT-III Fig. 8]: the curves ℜζ = 0 (blue) and ℑζ = 0 (orange, dashed) in the window  − 0.5 ≤ σ ≤ 1.5, t up to 50, with the zeros as black dots. Every zero in the window is a crossing of the two families, and every crossing lies on $\sigma=\tfrac{1}{2}$ (the vertical dashed line); zeros need both layers to vanish.*

###### What this adds, and what it does not

The aggregation reading explains why zeros sit where units cancel. It also explains why their statistics look like those of a large system with internal motion: the mean counting function is smooth, and the error $S(T)$ grows like $\sqrt{\log\log T}$. It does not explain why the cancellation happens only on the line. That is the Riemann hypothesis, and the numerical checks here are consistent with it to height $10^6$ and no further.

### 14.11 The original framework and the Bitcoin study as special cases *\[AT-III §10\]*

The original document (Chapter 11) builds a full dynamic model: agents choose by a logit rule (its F.2); the population measure evolves by a kinetic equation (B.14); a mean-field-game equilibrium closes the loop (H.1), with propagation of chaos (G.2) and a law of large numbers (G.4); groups merge (N.1), value adds (N.3) and equilibria form a hierarchy (N.5). Everything in Section 14.3 holds for any such dynamics. The original framework is therefore one closure of the general aggregation picture: a particular law of motion for the population measure. Table 14.16 maps its main statements onto AT-III.

**Table 14.16.** The original framework inside the general one *\[AT-III Tab. 8\]*.

| Original statement | Counterpart here | Status |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|
| Population measure (B.2), kinetic equation (B.14) | Units and weights (Definition 14.1); additive moments evolve by balance laws | setup **\[SETUP\]** Group state (B.29), hierarchy (B.31, N.3) | Partitions and cascades (Theorem 14.5) | proved **\[PROVED\]** Tower property (Prop. 7.2) | Exact merging of additive and mergeable quantities | proved; held on data **\[MEASURED\]** Scale-invariant interaction principle (Conj. 6.2, Conjecture 11.3) | The identities are scale-invariant; dynamics are not (exponents differ by domain, Part I Sec. 5.6) | identities: yes; laws: no |
| Restoration (Hyp. 9.1, Hypothesis 11.6) | EMA restoration is mechanical (Part I Thm. 6.1) | refuted as stated **\[REFUTED AS STATED\]** Equilibrium migration (Hyp. 9.2, Hypothesis 11.7) | Needs a dynamic test | open **\[OPEN\]** Cross-scale coherence $C_t$ (Hyp. 9.3, Hypothesis 11.8) | Collective share $\kappa$ and agreement (Table 14.3) | measured **\[MEASURED\]** Value additivity (N.3), behavioural additivity (N.4) | Additive quantities (Section 14.2) | exact |
| Merger and hierarchical equilibrium (N.1, N.5) | Equilibria are emergent, not additive | open (dynamics) **\[OPEN\]** MFG equilibrium, exploitability (H.1, H.4) | A model class for two-sided matching (Part II Sec. 6, Section 13.6) | not yet tested **\[PENDING RUN\]** |   |   |   |   |

###### The Bitcoin restoration study

**\[REFUTED AS STATED\]** The original study regressed a “restoration” variable, $Y=E_{t+h}+D_{t+h}-D_t$, built from an exponential moving average $E$ and the deviation $D$ from it, on the deviation. The author’s own note on that section flagged the construction as wrong. Part I showed why (its Theorem 6.1): for any price path, the moving average makes $Y$ depend on $D_t$ mechanically. The slopes it produces are those of a random walk, and on 132,480 BTC minutes the measured slopes were within 0.022 of them (Table 14.12). The study is thus a special case of Theorem 14.6: a moving average is a fixed lag distribution applied to every unit, and it manufactures apparent restoration. What survived is a small, genuine short-horizon reversal (Table 14.12), below trading costs. The study’s own tables (displacement bins, information coefficients by scale and horizon, the 64-minute coefficient model, motion-and-flow states and the chronological out-of-sample comparison) are reproduced in Subappendix D.1.

### 14.12 Status and next steps *\[AT-III §11\]*

**Table 14.17.** Status after this round (hindsight only) *\[AT-III Tab. 9\]*.

| Item | Result | Data |
|---|---|---|
| Exact layer | 12/12 identity checks; Part I 23/23 checks; notebook 00 53/53 | computed |
| P1 | Ratios below one everywhere; parameters $(N_{\mathrm{eff}},\bar\rho)$ and level factors measured | real: COVID, GDP, housing, gas; user: stocks, crypto, stars, winds, storms, ocean |
| P2 | Mixture law and squeezing confirmed | real: COVID, housing, beam; user: crypto jumps, venues |
| P3 | Sign law confirmed (atoms, nuclei, hadrons, ATLAS); energy exchange exact (gas) | real; user: virial ratios, RAR, flows |
| B | $H_0$ measured and removed; one rate at all distances; bulk flow, mostly gravitational | real: Pantheon+; user: UNGC, CF4, Gaia, clusters, groups |
| C | Exact layer held; reversal below costs; new tests defined | earlier runs; user: new tests |
| D | All zeros to $10^6$ on the line; GUE statistics; primes within the RH-equivalent bound | computed |

Table 14.17 is the source’s status table. In this chapter’s tags: the exact layer is **\[PROVED\]** P1, P2, P3, B and D are **\[MEASURED\]** on the real and computed data named in the table and **\[PENDING RUN\]** on the user-run sources; C is **\[MEASURED\]** for the earlier runs and **\[PENDING RUN\]** for the new tests; A is **\[HYPOTHESIS\]** with nothing measured (editorial).

###### What comes next *\[AT-III §11\]*

**\[PLAN\]** (1) Run the package where the data hosts are reachable (one command); every dash in the tables then fills in, and the verdicts in `results/report.md` are against criteria fixed in the code. (2) Turn the hindsight matches into forecasts, as planned: each measured parameter becomes a prediction for a period not yet seen, the level factors, $(N_{\mathrm{eff}},\bar\rho)$, the lag spreads and the flow $R^2$. (3) Two-sided matching (Part II, Section 6; Section 13.6): simulate micro rules, for example the original framework’s mean-field game, and require them to reproduce the measured aggregate fingerprint.

### 14.13 Data, code and reproducibility *\[AT-III App. B\]*

###### One command

`python run_all.py` (presets `quick`, `standard`, `full`) runs seven parts: `earlier`, `zeta`, `expansion`, `gravity`, `society`, `markets` and `physics`. It writes `results/summary.json`, `numbers.tex` (one macro per number in the paper), tables, figures and `report.md`; recompiling the paper then shows the new run’s numbers. The notebook `notebooks/00_all_tests.ipynb` runs the same parts step by step. `AGG_OFFLINE=1` replaces every remote source with a synthetic file in the real format with planted answers; it tests the code, not the world. The exact layer is checked by `tests/test_core.py` (12 checks; Table 14.17).

###### Sources

- *Computed:* the zeta function and the zeros (Riemann–Siegel with `mpmath` checks); the gas (DSMC); the beam; nuclear masses (`periodictable`); hadron and quark masses (`particle`, Particle Data Group, 2024).

- *Bundled snapshot of public GitHub mirrors, taken 25 October 2026:* Pantheon+SH0ES distances; JHU CSSE COVID-19 time series (Dong et al., 2020); World Bank GDP and population; S&P CoreLogic Case–Shiller indices; UN regions; S&P 500 GICS classifications. Also bundled: the author’s ATLAS four-lepton pilot results.

- *Downloaded on the user’s run:* Gaia DR3 (Gaia Collaboration, 2023); VizieR catalogues (Updated Nearby Galaxy Catalog, Cosmicflows-4, Hunt & Reffert, Tempel et al.); SDSS DR17; SPARC; iShares holdings, Yahoo prices and the Dow members; Binance archives and Tardis.dev; CMS open data; Iowa Environmental Mesonet ASOS, IBTrACS (Knapp et al., 2010) and the Global Drifter Program (Elipot et al., 2016).

###### What ran where

The numbers in this copy come from a run in the build environment, which reached GitHub and the Python package index only. That covers the earlier checks, zeta, Pantheon+, society, the gas, the beam, bound states and ATLAS; everything marked $^{u}$ awaits the user’s run. Every loader and analysis for those sources was checked against synthetic files with planted answers, and the recovered values are quoted where they help (Table 14.10 and Table 14.13). The earlier runs are the author’s notebooks 01–04 (Table 14.12); notebook 03 v2 supplied the Gaia group cascade of Table 14.3.

# Part VI: Working notes: from theory to the desk

## Chapter 15: Market making and inventory control *\[NB-01\]*

> **What this chapter establishes**
>
> A market maker is paid the spread many times over and gives it back by being trapped in inventory; every rule in the note manages that balance (Rule 15.1). Quoting decisions are derived from a mid-price model (15.2); the reference model is the Avellaneda–Stoikov reservation price (15.3). The worked case — a range-bound asset near 10,000 over about 30,000 ticks, a fixed spread of about 20, a hard limit of $\pm 80$ — reduces the problem to one decision, the inventory skew (15.6), plus rare, inventory-aligned taking; a taking layer that fired too often cut the recorded PnL from about 2,300 to about 1,600. Parameter values are starting points for a grid search, not fitted results (the conventions of all the notes are in Chapter 23).

### 15.1 The objective and the design checklist *\[NB-01 §The objective, §Design checklist\]*

**Rule 15.1** **(The PnL decomposition).** **\[PRACTICE\]** Everything in the note manages the balance between being paid the spread and being trapped in inventory, $$\tag{15.1}
\text{PnL} \approx \text{spread capture} - \text{adverse selection} - \text{inventory risk} - \text{overtrading cost}.$$ Tight quotes fill more often, against better-informed flow; wide quotes fill less often, at better quality; quoting too aggressively blows up inventory, quoting too passively never fills. The aim is to earn the spread repeatedly without getting trapped; predicting direction is secondary.

**\[SETUP\]** Model the mid-price first, then derive each quoting decision from it: $$\tag{15.2}
\mathrm{d}S_t = \mu_t\,\mathrm{d}t + \sigma_t\,\mathrm{d}W_t + J_t\,\mathrm{d}N_t ,$$ drift $\mu_t$, volatility $\sigma_t$, and a jump term (jump probabilities and the risk premium for bearing them). The levers: *spread* — widen in high volatility, narrow in low; *bid and ask price* — predict the future optimal quote and shift both quotes in the direction of the drift; *bid and ask size* — smaller in high volatility, larger in low; *inventory* — avoid large inventory in high volatility, accept more in low, adjust for jumps; *flattening* — open question whether, and when, to cross the spread to flatten a position; *hard controls* — risk limits, maximum inventory bounds, order throttling.

### 15.2 Models *\[NB-01 §Models\]*

**Known result 15.2** **(Avellaneda–Stoikov reservation price).** **\[KNOWN RESULT\]** (Avellaneda and Stoikov, 2008.) The reference model for optimal quoting in a limit order book, combining inventory risk and quoting in a tractable form. A risk-aversion parameter $\gamma$ moves both quotes against inventory through the reservation price $$\tag{15.3}
r = s - q\,\gamma\,\sigma^2 ,$$ $s$ the mid-price, $q$ the signed inventory, $\sigma^2$ the price variance over a short rolling window. The full model multiplies the last term by the time left to the horizon; the notes use the stationary form. Quotes are updated continuously from volatility and inventory: in the original model the spread widens with volatility, and inventory moves the centre of the quotes, not their width. Market orders arrive at random (Poisson or exponential intensity), which gives the fill probability on each side.

**Table 15.1.** Extensions and alternatives to Avellaneda–Stoikov *\[NB-01 §Models\]*.

| Family | What it adds |
|---|---|
| Queue and depth extensions | Fill probability depends on quote size and on how many orders are ahead, so the model tracks queue position (Markov or fluid approximations). |
| Richer price dynamics | Stochastic volatility, jumps or correlated factors in place of a plain Brownian mid-price. |
| Discrete-time versions | Real systems requote at intervals (milliseconds to seconds), not continuously. |
| Cartea–Jaimungal | Explicit execution costs (fees, slippage, the cost of hedging or crossing the spread) and market impact: large or persistent quoting changes prices and arrival rates. Closed-form or semi-closed-form quoting controls. |
| Limit-order-book models | The book as discrete levels; quote at the touch, one tick away or deeper, trading fill probability against edge. Being first in the queue is worth more than being last. |
| Reinforcement learning | State: book, inventory, volatility regime, time of day. Actions: move the bid and ask, or do not quote. Reward: realised PnL with inventory penalties and fill rates. Adapts to non-stationary markets, at the cost of high dimensionality, large data needs, overfitting risk and low-latency inference. |

**\[PRACTICE\]** In practice $\gamma$, the volatility estimate and the fill probabilities are re-estimated in near real time; the edge comes from fitting them to real order flow (fill probabilities, hedging costs, short-term patterns).

### 15.3 Worked case: range-bound asset, fixed spread, hard limit *\[NB-01 §Worked case\]*

**\[SETUP\]** One asset whose bid, ask and mid oscillate around 10,000 over about 30,000 ticks, no sustained trend, no cross-asset signal. The spread is fixed at about 20 points (half-spread $h = 10$); the position limit is $\pm 80$; only one bid and one ask can be live at a time. The path is not perfectly calm: occasional outlier moves of about 30 points, and one sharp drop around steps 16,000–17,000, where symmetric quoting would have accumulated a losing long position.

**\[PRACTICE\]** **Conclusion of the analyses.** Inventory-skewed market making around a stable fair value, plus rare, high-threshold mean-reversion taking aligned with inventory; with the spread fixed, the main quoting decision left is the skew. Per step: fair value, inventory skew, inventory regime, then the check for a rare take.

**Fair value and width.** Use something more robust than the raw mid — a denoised or volume-weighted mid, the microprice (queue-weighted top of book), a short rolling regression or EWMA — optionally with a small tilt from imbalance and order flow; where the width is not fixed, set it from the spread and the local volatility $\sigma_t$ so that quotes widen in noise and tighten in calm: $$\tag{15.4}
f_t = \text{microprice}_t + \beta_1\,\text{imbalance}_t + \beta_2\,\text{orderflow}_t, \qquad
\text{width}_t = \max\bigl(\text{min width},\; c_1\,\text{spread} + c_2\,\sigma_t\bigr).$$

> “Keep it simple. Overfitting is a big danger here.” *\[NB-01 §1\]*

### 15.4 Inventory skew *\[NB-01 §Inventory skew\]*

The general quote model has a half-width $w$ that expands with volatility, an inventory skew that pushes quotes toward reducing risk, and an alpha skew that leans quotes when the short-term signal is strong: $$\tag{15.5}
\text{bid} = f - w - \text{inventory skew} + \text{alpha skew}, \qquad
\text{ask} = f + w - \text{inventory skew} + \text{alpha skew}.$$ With a fixed spread and no strong signal this reduces to one decision: shift the centre of the quotes by inventory and hang the fixed half-spread $h$ around it, $$\tag{15.6}
r_t = f_t - k\,q_t, \qquad \text{bid}_t = r_t - h, \qquad \text{ask}_t = r_t + h .$$ The notes give three ways to set the penalty $k$, and they agree (Table 15.2); Table 15.3 shows the quotes for the full-strength linear rule. When long, the ask gets cheaper and the bid moves away; when short, the bid rises and the ask moves away; the position is worked off without crossing the spread. The raw analyses call $m = 0.5$ “conservative” (skew $= q/q_{\max}\times 5$: closer to mid, more fills, slower inventory clearance) and $m = 1$ “aggressive” (skew $= q/q_{\max}\times 10$: flat inventory first, fewer fills), and expect a moderate skew to win because the data mean-revert strongly *\[QB\]*.

**Table 15.2.** Quotes under the full-strength linear rule ($m = 1$, $h = 10$, limit 80) *\[NB-01 §2\]*.

| Parameterisation | Rule | Value here |
|---|---|---|
| Linear in inventory | skew $= m\,(q/q_{\max})\,h$, multiplier $m$ between 0.3 and 1.0 | $k = 0.125\,m$ per unit |
| Avellaneda–Stoikov | $k = \gamma\sigma^2$ | set by the grid search on $\gamma$ |
| Rule of thumb | about 1 tick per 10–15 units | $k \approx 0.07$–$0.10$, $m \approx 0.5$–$0.8$ |

**Rule 15.3** **(At the limit, remove the order).** **\[PRACTICE\]** “At the limit, remove the order, do not just skew it.” At $+80$ cancel the bid and quote only the ask; at $-80$ cancel the ask and quote only the bid. The linear rule puts the remaining quote at mid; a more patient variant leaves it at mid $\pm 10$, or one tick inside that ($s + 9$ when long) to make the fill more likely *\[NB-01 §2; QB\]*.

**Inventory regimes and size** *\[NB-01 §3\]*. Two band schemes appear in the notes (Table 15.4); both shrink size as inventory grows and stop quoting the risky side near the limit. Size per side follows the same logic: full size (20–30) at zero inventory, reduced at 40, small at 60, zero on the risky side at 80.

**Table 15.4.** Inventory bands: the two schemes in the notes *\[NB-01 §3\]*.

| $\lvert q\rvert$ | Four-band scheme | Three-band scheme |
|---|---|---|
| 0–20 | Quote normally | Full market making |
| 20–40 | Skew harder | Full market making |
| 40–50 | Skew harder | Skew quotes and reduce size |
| 50–70 | Put flattening ahead of earning spread | Skew quotes and reduce size |
| 70–80 | Put flattening ahead of earning spread; stop quoting the risky side near 80 | Quote the flattening side only |

**Where to place the quotes** *\[NB-01 §4\]*. *Join*: quote at the reservation price $\pm 10$ and capture the full 20 per round trip. *Improve*: quote one tick inside the market (best bid $+1$, best ask $-1$), capture about 18, with priority over the resting book; the analyses disagree on whether priority matters when only one order pair is live. **\[PRACTICE\]** Reprice on every new mid-price tick and immediately after every fill.

**Taking liquidity** *\[NB-01 §5\]*. Aggressive taking is not the default for this kind of asset: it pays the spread, consumes liquidity at the wrong time, interferes with the maker’s inventory, and most apparent signals are noise. **\[MEASURED\]** In the recorded test, adding a taking layer cut PnL from about 2,300 to about 1,600, diagnosed as taking too often on too weak a signal. **\[PRACTICE\]** Take only when all of the following hold: price is far from fair value — the best ask below fair, or the best bid above fair, by 6–10 ticks (the stricter reading 8–10), equivalently fair value $\pm n$ local standard deviations; the gap exceeds fees, adverse-selection risk, expected short-term noise and the value of keeping inventory free for market making; the trade fits the inventory — never buy when already too long or sell when already too short, and in the stricter version only in the direction that reduces inventory (short: only buys; long: only sells); imbalance and order flow agree, and the position is not near the limit. A z-score alone fires too often in noisy tick data: use it as a secondary filter, or to lean the quote skew, not as a trigger for crossing the spread.

> “In practice: take rarely, make constantly.” — “Never fight your own book.” *\[QB\]*

**Table 15.5.** Left: the decision rule by state. Right: approaches rejected for this asset *\[NB-01 §6, §7\]*.

| State | Action | Approach | Why it fails here |
|---|---|---|---|
| Price near fair value | Make both sides. | Momentum or trend following | No sustained directional moves; it gets chopped up. |
| Price slightly stretched | Skew quotes toward reversion. | Breakout strategies | Spikes revert quickly with no follow-through. |
| Price very stretched | Take selectively, keeping the opposite quote posted to unwind. | Low-frequency positioning | The edge is in the microstructure, not in macro direction. |
| Inventory too large | Stop optimising edge and flatten. | Always-on z-score taking | Reacts to noise and overtrades. |
|   |   | Fixed symmetric thresholds without inventory context | Works in backtests, breaks once inventory and adverse selection matter. |
|   |   | Uncoordinated making and taking | The two fight over the same inventory. |

**Tuning** *\[NB-01 §8\]*. **\[PLAN\]** The grid, and what is recorded per cell:

``` python
for risk_aversion in [0.3, 0.5, 0.7, 1.0]:      # skew multiplier
    for inventory_limit in [40, 60, 80]:        # soft limit: one-sided quoting beyond it
        simulate()                              # record total_pnl, max_drawdown, fill_rate
```

If the skew is too weak, quotes stay symmetric and the book keeps hitting the $\pm 80$ limit, forcing a stop or a loss-making liquidation; if too strong, quotes skew so hard at an inventory of only $\pm 10$ that fills stop. **\[PRACTICE\]** Target the lowest `risk_aversion` that keeps inventory inside $\pm 79$ for 99% of the session; for strongly mean-reverting data a lower risk aversion will probably win, because inventory corrects itself. The quantity maximised is $$\tag{15.7}
\text{profit} = \text{fills} \times \text{average spread captured} - \text{inventory at close} \times \text{mark-to-market loss}.$$

**Limits of the analysis, and live venues** *\[NB-01 §Limits, §Live-market considerations\]*. No strategy is provably optimal from a chart alone: the linear skew is the practical form of the Avellaneda–Stoikov reservation price, derived for a driftless diffusion and a specific fill-intensity model — a well-motivated heuristic. Kept in reserve: micro mean reversion (sell spikes to about 10,020–10,030, buy dips to about 9,975–9,985, or bands from a rolling short-term standard deviation) and pairs trading if the plotted lines had been separate instruments. On real venues: widen or pull the exposed quote when the book turns heavily one-sided (adverse selection); spread capture in noisy assets needs low-latency infrastructure, since a slow maker is filled mainly when the market moves against it; at this scale fees can exceed the signal edge; outlier moves need hard inventory limits or hedging rules.

## Chapter 16: The Prosperity competitions *\[NB-02, NB-03\]*

> **What this chapter establishes**
>
> IMC Prosperity is run in rounds, each with an algorithmic challenge (a Python trader on a simulated exchange, bounded by position limits) and a manual challenge; profit is counted in seashells. Every approach studied combines taking against a fair value with making around it. The round-by-round record of Prosperity 2 (Table 16.2) shows that the structural trade — the cross-exchange conversion, the basket spread, the option priced by Black–Scholes, the disclosed counterparties — paid more than modelling price drivers, and nine lessons repeat (Rule 16.1). The 2025 team log records the quoting rules tested on Kelp and Resin (Table 16.4), an error-correction stat-arb design for Ink, and the crash-risk measures NCSKEW (16.3) and DUVOL (16.4).

### 16.1 The competition, the environment and the core pattern *\[NB-02 §The competition, §The environment, §The core pattern\]*

Market making is the main focus, and most rounds add a product type that needs a new idea: Prosperity 1 (2023) Pearls (stable) and Bananas (drifting); Prosperity 2 (2024) Amethysts, Starfruit, Orchids, Chocolate, Strawberries, Roses, Gift Basket, Coconut, Coconut Coupon; Prosperity 3 (2025) Rainforest Resin (stable), Kelp (volatile), Ink (prone to sudden shocks); Prosperity 4 (2026) Hydrogel Pack, Velvetfruit Extract and the VEV vouchers (Chapter 17). `TradingState` is everything the trader sees at each step — `timestamp`, `listings`, `traderData`, `position`, `own_trades`, `order_depths`, `market_trades`, `observations`; the book for one product is `state.order_depths``[’KELP’]`. The trader receives the state, loops over the products, reads the order depths and returns orders, subject to a position limit per product. The bots post the buy and sell orders visible in the order depth; what triggers their behaviour is not disclosed, posting absurd orders does not move them, and they are dynamic: they place their own trades and do not simply match incoming orders one for one. Practical constraints reported by participants: in the Prosperity 3 tutorial only 2,000 ticks were visible and 10,000 hidden ticks decided the result, so anything tuned on the visible sample can fail on the hidden data; the official engine uses hidden bot logic, so open-source backtesters give different numbers from a real upload; code must run inside the server’s time limit (heavier logic has timed out); manual trades are not real time but submitted before the round closes.

**\[PRACTICE\]** **The core pattern.** Every approach studied combines two decisions: *take* liquidity when the current book is favourable against an estimate of fair value, and *make* liquidity by posting a bid and an ask around it. The edge is prediction plus execution logic, bounded at all times by the position limit. Table 16.1 compares three teams’ code on Pearls and Bananas; what they share: they are stateful (none reacts to the current book alone); position limits are enforced everywhere; the parts are simple (a fixed fair value, a moving average or EMA, a short rolling regression, undercutting the best bid or ask, an inventory skew); logic is split into reusable methods such as `reset_from_state`, `buy_product`, `sell_product`, `continuous_buy` and `continuous_sell`. Own plan for a stable asset of this kind (its mid sits at a constant level and the bid or the ask occasionally moves to meet it): (1) make markets, (2) take against fair value when mispricings appear, (3) skew by inventory to de-risk.

**Table 16.1.** Three teams’ code compared on Pearls (stable at 10,000) and Bananas (drifting) *\[NB-02 §The core pattern\]*.

|   | Team 1 | Team 2 | Team 3 |
|---|---|---|---|
| Pearls | Fixed fair value of 10,000; buys below, sells above | Posts both sides around the default price: bid 9,999, ask 10,001 | Acceptable bid and ask bounds around 10,000; takes when quotes are favourable, undercuts the best price to make, adjusts quotes by inventory |
| Bananas | Caches recent books, computes weighted-average bid and ask, trades when the current book beats them by a threshold | EMA as a dynamic fair value; quotes symmetric when flat, shifted down when long, shifted up when short | Regression forecast on a rolling cache of mid-prices, converted into lower and upper acceptable prices, then trades and quotes around those bounds |
| State kept | Cached bids and asks | Positions, PnL, cash, EMA prices, past prices | Positions, traded volume, cash PnL per product, rolling caches, signals from market participants, product-specific parameters |

### 16.2 Prosperity 2 round by round *\[NB-02 §Prosperity 2\]*

Position limits are from the official round descriptions; the Orchids limit was not recorded. The basket spread of round 3 is $$\tag{16.1}
\text{spread} = P_{\text{basket}} - \bigl(4\,P_{\text{chocolate}} + 6\,P_{\text{strawberries}} + P_{\text{roses}}\bigr).$$

**Table 16.2.** Prosperity 2 (2024) round by round: products, the winning idea, and every number the notes record; figures quoted from write-ups are theirs *\[NB-02 §Prosperity 2; QB\]*.

| Round | New products (limit) | The trade | Numbers recorded |
|---|---|---|---|
| Round | New products (limit) | The trade | Numbers recorded |
| 1 | `AMETHYSTS` (20), `STARFRUIT` (20) | Market making and taking around fair value. Amethysts: fair value 10,000; sell when bids exceed it, buy when asks fall below it, quote both sides. Flattening matters: with a limit of $\pm 20$, teams added liquidation logic to get back toward zero so that capacity was free for the next trade. Starfruit random-walks over hundreds of seashells; a rolling mid works, but the better fair value is the midpoint of the quotes of a large market-maker bot that posts deep liquidity on both sides. Anchoring to those heavy-lot quotes and ignoring micro-noise beat short linear regressions. | Top solutions: 30k–40k seashells or more. |
| 2 | `ORCHIDS` (not recorded) | Cross-exchange arbitrage. Orchids trade locally and on the south archipelago, with shipping costs and import and export tariffs; conversions are allowed only when they move the position toward zero. Sunlight and humidity looked important and gave only weak or spurious correlations (a red herring). A large local buyer absorbed big volume when quoted slightly above the best bid, while the net cost of importing was often favourable: sell locally above cost, import to flatten, repeat — close to risk-free. Refinement: keep shorting to the limit at a price that converts back profitably on the next step, and convert to zero and go short again in the same iteration. The sell quote depends on tariffs and shipping; when tariffs are low the trade may not pay. | One write-up: 60k, then 109k after the same-iteration refinement. Those who found it: 60k–100k or more within hours, 500k–1M in extended simulations; low or negative PnL for those who did not. |
| 3 | `CHOCOLATE` (250), `STRAWBERRIES` (350), `ROSES` (60), `GIFT_BASKET` (60) | Basket against components. One basket holds 4 chocolate bars, 6 strawberries and 1 rose; the spread (16.1) mean-reverts around a stable level that need not be zero (examples 0, 300 and 370). Signal: a z-score or hard thresholds on the spread; buy the cheap side, sell the rich side. Lead–lag tests were mixed; plain mean reversion was enough. One write-up: the round was close to a copy of the previous edition’s basket round; the first version went fully long or fully short the basket at its thresholds; trading the components at grid-searched thresholds lost on Roses, so component trading was switched off. Pitfalls: small position caps make timing matter; live results were worse than tuned backtests. | Loss of over 36k on Roses. Other participants reported about 600k in backtests. |
| 4 | `COCONUT` (300), `COCONUT_COUPON` (600) | Option pricing and implied-volatility mean reversion. Coconut trades near 10,000; the coupon is a call on it with strike 10,000 and 250 trading days to expiry, one round being one trading day. Price the coupon with Black–Scholes (17.1): buy coupons when implied volatility is cheap, sell when rich, delta-hedge with coconuts. Limits bind: 600 coupons against 300 coconuts leaves the hedge incomplete; some teams accepted the residual delta. A directional strategy on Coconut itself was dropped. The Coconut data was a near-exact match for Prosperity 1 data: teams that mapped the old series onto the new one could see the future (one write-up credits Puerto Vallerta with finding this first, during round 4). | Implied volatility settled near 16%. Black–Scholes parameters tuned to 420k in backtests; live coupon profit came close. Directional Coconut: $-77$k against $+184$k on coupons. Data-mapping teams: more than a million seashells. |
| 5 | None; `counter_party` of `OwnTrade` populated | Following informed counterparties. Some named bots consistently bought lows and sold highs (the community digest names Rianna, Olivia and Remy): mirror them. Signals in one write-up: long Chocolate when Vladimir sells to Remy, short when Remy sells to Vladimir; long Roses when Rihanna (also spelled Rhianna) sells to Vinnie, short when Vinnie sells to Rihanna. Final-round behaviour: larger bets, partial or no hedging, dynamic programming on trade sequences, only the signals teams trusted. | A grid search of 3,600 backtests found nothing beyond what was visible by eye. |

**The Prosperity 1 equivalent (Stanford Cardinal, 2nd)** *\[NB-02 §Round 1\]*. Pearls sat at 10,000 while the best bid sometimes reached 10,002 and the best ask 9,998, with trades up to 5 either side, so taking and making around 10,000 was enough. For Bananas a linear regression on the last few timesteps predicted the next price; taking on it worked, taking plus making worked better; refitting on the fly did worse; the coefficients were similar on neighbouring days, seen as a possible further gain. One round can cost a lot: an algorithmic score below $-120$k in round 2 took the team from 9th to 926th place, and they still finished 2nd. **One team’s final strategy per product (Jasper van Merle, 9th), all profitable in round 5**: `AMETHYSTS` market making around 10,000; `STARFRUIT` market making around the popular mid-price; `ORCHIDS` arbitrage between the north and south archipelagos; `CHOCOLATE` and `ROSES` directional, on the Vladimir–Remy and Rihanna–Vinnie trades; `STRAWBERRIES` and `GIFT_BASKET` directional, parameters overfit on round 3 data; `COCONUT` none (no consistently profitable strategy found); `COCONUT_COUPON` trading around the Black–Scholes value.

**Manual rounds** *\[NB-02 §Manual rounds; QB\]*, solved with simulations, closed-form answers, estimates of what other participants would do, or plain guesswork. *Fish (round 1)*: covered in Edgar Maddocks’s Medium article “How to trade with secretive fish”. *Currency loop (round 2)*: compute the profit of every route; the best was seashells $\to$ pizza slices $\to$ wasabi roots $\to$ seashells $\to$ pizza slices $\to$ seashells, for 113,938.8. *Expeditions (round 3)*: more than 75k from one expedition looked unlikely and more than 25k achievable, which made two expeditions the best number; expeditions 83 and 87 returned 78,577 against a maximum of 106,291. *Bids (round 4)*: round 2’s optimal bids had been 952/978; bidding 952 and 980, slightly above the expected crowd (the average bid ended up at 980), returned 102,592, the apparent maximum. *News trading (round 5)*: trade only products with a confident direction and size by conviction — 10% of capital on the least certain product (icicle earrings, buy) and the rest split equally over electric blankets, sleds and moustache serum (sell) and ice sculptures and PS6 (buy), with refrigerators, lava lamps and hot chocolate left alone; 115k, against a best reported 149k and an optimum of 157k. *Price guess (Prosperity 1, Stanford Cardinal)*: 9,777, based on a simulation, was profitable; the median price of the bottom 50% was 9,685.

### 16.3 The Prosperity 3 tutorial, the write-ups and the lessons that repeat *\[NB-02 §Prosperity 3 tutorial, §Write-ups, §Lessons\]*

What the community tried in the tutorial round: replace the organisers’ sample algorithm, which trades around a hard-coded acceptable price of 10 and often loses money; fair-value trading (a fair price, often a moving average; buy below, sell above); split by product — market making on Rainforest Resin (stable, so tight low-risk quotes) and trend or mean-reversion trading on Kelp (larger directional gains or losses); relative value between the two (offsetting positions, mean reversion, or momentum in the volatile asset); tuning of volumes, risk limits, spread sizes, moving-average and learning-rate parameters on the short tutorial data, with open doubts about generalisation; low-risk grinding, since past top strategies looked like near-arbitrage or market making with minimal directional risk and large directional bets rarely pay over many repeated trades; no dominant advanced method beyond simple and moderate ones.

**Write-ups studied** (rank, edition, author): 2, Prosperity 2, Linear Utility; 2, Prosperity 1, Stanford Cardinal; 9, Prosperity 2, Jasper van Merle — market making, soft and hard liquidation at worse-than-usual prices to exit prolonged positions, buy and sell price taken from the maximum-volume level, linear regression on Starfruit tried and apparently not profitable, round 1 submitted with the tutorial code unchanged *\[QB\]*; 13, Prosperity 2, Kang, Kim, Lee; 30, Gabriel Romon; 57, Prosperity 1, Michael Okon; 91, Nicolas Sinott; outside the top 350, Prosperity 1, Academiq-AI; 381, David Teather. Repositories: `jmerle/imc-prosperity-2` (with its backtester and visualizer) and `ShubhamAnandJain/IMC-Prosperity-2023-Stanford-Cardinal`.

**Rule 16.1** **(Lessons that repeat).** **\[PRACTICE\]** (1) Find the game’s own fair value: often the midpoint of the largest resting quotes, not a rolling mid-price or average. (2) Flatten inventory to keep capacity; position limits bind in every round. (3) Look for the structural trade before building a model: the cross-exchange conversion and the basket spread paid more than modelling the price drivers. (4) Distrust decorative data; some indicators are there to mislead. (5) Grid-search with a local backtester, then discount the result: tuned thresholds overfit and the live engine differs. (6) Check whether data is reused from earlier rounds or editions. (7) Read the trade log: named counterparties can carry more signal than prices. (8) Avoid large directional bets unless the final-round ranking justifies the risk. (9) Expect platform problems: earlier editions had submission outages and Lambda errors, and one team dropped an on-the-fly regression partly because of them.

### 16.4 The 2025 team log: preparation *\[NB-03 §Preparation\]*

Team: Mark, Saeid, James, Minjae and Raymond; products Rainforest Resin (stable around 10,000), Kelp (volatile) and Ink (prone to sudden shocks). **\[PLAN\]** Goals: profitability first, speed second. Standing tasks: (1) index feasible strategies for prospective rounds — stock splits, dividend-based products, premiums; (2) generate and collect likely manual-trading questions, since manual trading might be significantly more profitable; (3) index niche optimisations for the core strategies from new research and old repositories; (4) everyone reads the list of previous and current competitors; (5) collect datasets to backtest against — in hand: Jasper van Merle’s backtester, a data repository, S&P 500 data and options data; (6) record anything relevant on the per-person ideas pages. Also: check return skewness as a momentum signal. Hypotheses per round type are in Table 16.3.

**Table 16.3.** Hypotheses per round type, before the rounds opened *\[NB-03 §Preparation\]*.

| Round type | Plan | Considerations |
|---|---|---|
| Market making | Assume round 1 matches the tutorial. Experiment with undercutting on Resin. Tweak the Kelp pricing model. | Regimes may change; inventory may drag in some periods, and shorting may beat going long in others. Try a hidden Markov model. |
| Options | Build the pricing model in NumPy. Build a volatility surface: sell what sits above the smile, buy what sits below. | Have responses ready for market moves. Adjust to the smile. |
| Arbitrage | Expect something like the Orchids round, with transport and fees. | Some indicators are red herrings. In an earlier edition the trade was importing from another island and selling at very high prices locally. Decide whether to hedge. |

### 16.5 5 April 2025: quoting rules for Kelp and Resin *\[NB-03 §5 April\]*

**\[LOG\]** **Fair values.** Market making: VWMP, the volume-weighted mid-price. Momentum: a “semi-OU” fair value, logged as $\text{mean} + \theta\,(\text{mean} - \text{mid-price})$. ATR as the signal for how far from fair value to quote, in three liquidity states: default, distance $\operatorname{ATR}/2$; liquid, $\operatorname{ATR}$; highly illiquid (no trades in the last $N$ steps; $N = 300$ in the rules), $\operatorname{ATR}$ if market depth exceeds a threshold. **Position penalty.** Order size is scaled symmetrically by distance from the position limit PL, with one set parameter, $$\tag{16.2}
\text{adjustment} = 1 - \text{Penalty}\!\left(\lvert \text{position}\rvert/\text{PL}\right).$$ **Regime switching** was planned through a volatility assessment. The two rule sets tested are in Table 16.4. The visible difference is the rounding: Strategy 1 rounds the fair value and then applies an integer-divided ATR, Strategy 2 applies the offset and then rounds; Resin’s liquid state also uses VWMP in Strategy 1 and the OU value in Strategy 2. The log does not say which change explains the gap in PnL, and Resin mixes the OU fair value and VWMP exactly as logged. **\[PLAN\]** Parameters queued for testing, each product alone and both together — Kelp: base trade size, ATR period, VWMP “pop” timeframe, aggressiveness denominator and penalty, and flooring ATR at 1 (`max(ATR, 1)`, marked as important); Resin: base trade size, ATR period, theta of the OU fair value, aggressiveness denominator and penalty, and the same ATR floor. Open item: tune the denominators to test the penalty logic.

    Strategy 1: total PnL about 3,500
      KELP   default    bid = round(VWMP) - atr // 2    ask = round(VWMP) + atr // 2
             liquid     bid = round(VWMP) - atr // 1    ask = round(VWMP) + atr // 1
             illiquid   bid = round(VWMP) - atr // 1    ask = round(VWMP) + atr // 1
      RESIN  default    bid = round(OU)   - atr // 2    ask = round(VWMP) + atr // 2
             liquid     bid = round(VWMP) - atr // 1    ask = round(VWMP) + atr // 1
             illiquid   bid = round(VWMP) - atr // 1    ask = round(VWMP) + atr // 1
    Strategy 2: total PnL about 2,800
      KELP   default    bid = round(VWMP - atr / 2)     ask = round(VWMP + atr / 2)
             liquid     bid = round(VWMP - atr / 1)     ask = round(VWMP + atr / 1)
             illiquid   bid = round(VWMP - atr / 1)     ask = round(VWMP + atr / 1)
      RESIN  default    bid = round(OU - atr / 2)       ask = round(VWMP + atr / 2)
             liquid     bid = round(OU - atr / 1)       ask = round(OU + atr / 1)
             illiquid   bid = round(VWMP - atr / 1)     ask = round(VWMP + atr / 1)

### 16.6 Daily entries, the Ink design and the crash-risk measures *\[NB-03 §7 April – §Crash-risk measures\]*

**\[LOG\]** **7 April 2025 (day 1).** Saeid: finished volatility targeting, which runs as a risk-manager module alongside the trader module; summarised all Prosperity 2 manual-trading rounds in a shared sheet. James: walked through another team’s commented code; a way to run `trader.py` together with `backtester.py` is needed. Minjae: ARMA — the public material is good, the plan is to combine snippets from it. Mark: reviewed previous winners and market-making firms; two assets, one stable and one volatile; a question about arbitrage; for options, market making for short-term alpha (Stoikov), watching volatility, with the open question whether to adjust inventory with gamma and beta. Raymond: grid-search the other team’s approach; get our own backtester working.

**\[LOG\]** **8 April 2025 (day 2).** James and Minjae: the returns move within the same bound; they are looking for a relationship on top of that; James will work on an error-correction model (ECM) with Saeid. Raymond: implemented a quoting model (logged as “Sakarov(?)”, most likely Avellaneda–Stoikov, Known result 15.2) and is tuning risk aversion and volatility; a pairs trade is implemented and not yet good; may test short against long moving averages. Saeid: implementing the ECM, a crash-detection module and an inventory-clearing module.

**\[HYPOTHESIS\]** **Round 1 design: error-correction stat arb (James and Saeid).** *Viability condition*: both series are I(1), non-stationary in levels and stationary in differences; testing on raw prices and on log returns supported this. *Trading logic*: (1) fit the ECM ($X$ on $Y$, or $Y$ on $X$) over the last $N$ timesteps; (2) run a Phillips–Ouliaris test on the residuals over the last $M$ timesteps — stationary: infer the theoretical value of the dependent variable from the independent one and trade the gap as stat arb; non-stationary: switch regime to stay out of the shock. *Signals*: dependent variable — take the ECM theoretical value as fair value and trade its z-score; independent variable — a conventional fair-value model, ATR on VWMP or another momentum strategy; the stable product (10,000) — reuse Stanford Cardinal’s approach, or semi-OU plus ATR. *To determine*: grid search for $N$ (a more accurate ECM) and for $M$ (the more sudden the shocks, the higher $M$); which product is dependent and which independent, to maximise profit and protect against Ink shocks (working guess: Ink as the independent variable, since its volatility makes the quotes more competitive); which regime to fall back on when the cointegration relationship is lost, that is, when an Ink shock is coming. *Extension*: a VECM combines a VAR with the ECM; if a lead–lag relationship exists it can feed the prediction of the independent variable, provided the independent variable is the lagging one. *Detecting an Ink crash*: a Kalman filter (hard to implement); the Johansen test (only useful if a lead–lag dynamic exists; a vector autoregression at every timestep is memory-intensive, and a VECM probably is too); the error-correction term (flag the point where the adjustment coefficient $\alpha$ becomes insignificant — marked in the log as inference); order-book patterns (evaluate the book before each crash; if the patterns are consistent they may also predict the size of the crash). The general blueprint of the same idea is Chapter 18.

**Known result 16.2** **(NCSKEW and DUVOL).** **\[KNOWN RESULT\]** (Chen, Hong and Stein, 2001: forecasting return skewness with cross-sectional regressions.) Negative conditional skewness is the negative of the third moment of demeaned returns $r_t$ over a window of $n$ observations, scaled by the variance to the power $3/2$; down-to-up volatility is the log ratio of volatility on down days to volatility on up days, from squared returns, with $n_u$ up days and $n_d$ down days: $$\tag{16.3}
\text{NCSKEW} = -\,\frac{n\,(n-1)^{3/2} \sum r_t^3}{(n-1)(n-2)\bigl(\sum r_t^2\bigr)^{3/2}} ,$$ $$\tag{16.4}
\text{DUVOL} = \ln\!\left(\frac{(n_u - 1)\sum_{\text{down}} r_t^2}{(n_d - 1)\sum_{\text{up}} r_t^2}\right).$$ DUVOL does not use the third moment, so it is less affected by a few extreme moves; it is the preferred measure.

**\[KNOWN RESULT\]** **PTPI early-warning signal** (the acronym appears to be the potential tipping points indicator of Xing and Yang, 2019). Findings noted: the indicator built from trading value outperforms the versions built from trading volume and from closing price — it becomes volatile only before and during each crash and is quiet otherwise; the more volatile the indicator, the fewer days remain until the crash; reading: trading value is the best proxy for liquidity and gives the earliest warning. **\[PLAN\]** Ideas carried forward: use skewness alongside momentum to forecast price moves; use linear regressions between products to find pairs for statistical arbitrage.

## Chapter 17: Options and voucher strategies *\[NB-04\]*

> **What this chapter establishes**
>
> The option-pricing lesson of Prosperity 2 — a call priced by Black–Scholes (17.1), mean reversion in implied volatility around 16% with a delta hedge limited by position caps — and the strategy designs for Prosperity 4 (2026), where an underlying (`VELVETFRUIT_EXTRACT`) carries a ladder of call vouchers. Seven strategies were ranked; the best candidate is voucher-surface relative value with a delta hedge (Section 17.3), the best continuous-flow choice is spot and voucher market making, and one rule stands above all: trade only two-sided books. These are designs, not backtested strategies: the data file had no exercise style, maturity, settlement timing, fees or trade event stream.

### 17.1 Black–Scholes as used *\[NB-02 §Round 4; NB-04 §Earlier option rounds\]*

**Known result 17.1** **(Black–Scholes, as used for the coupons and vouchers).** **\[KNOWN RESULT\]** (Black and Scholes, 1973.) For a call with strike $K$ on spot $S$, time $\tau$ to expiry, volatility $\sigma$ and rate $r$, $$\tag{17.1}
C = S\,N(d_1) - K e^{-r\tau} N(d_2), \qquad
d_{1,2} = \frac{\ln(S/K) + (r \pm \tfrac{1}{2} \sigma^2)\,\tau}{\sigma\sqrt{\tau}}, \qquad
\Delta = N(d_1).$$ The notes name the model and its inputs but do not write the formula out, and record no rate (editorial). As used in Prosperity 2: $K = 10{,}000$, $\tau = 250$ trading days with one round as one day; the implied volatility backed out of coupon prices settled near 16%; the trade was mean reversion in implied volatility — buy cheap, sell rich — with a delta hedge limited by the caps of 600 coupons against 300 coconuts; one write-up’s tuned parameters gave 420k in backtests (Table 16.2). For the 2026 vouchers the same decomposition supplies intrinsic value $\max(S-K,0)$, time value $C - \max(S-K,0)$ and the deep-in-the-money basis (17.2).

### 17.2 The instruments, the ranking and the one rule above all *\[NB-04 §The instruments, §Ranking, §One rule\]*

**Table 17.1.** The 2026 instruments in the one order-book snapshot file analysed, and the ranking of the seven strategies by return, Sharpe ratio, complexity and requirements, condensed *\[NB-04 §The instruments, §Ranking\]*.

| Instrument | Behaviour in the data |
|---|---|
| `VELVETFRUIT_EXTRACT` (spot) | Spread stable at about 5 ticks. |
| `VEV_4000`, `VEV_4500` (deep in the money) | Almost synthetic spot: average time value about 0.01, basis nearly flat. |
| `VEV_5000`, `VEV_5100`, `VEV_5200`, `VEV_5300` (near the money) | Largest time value and the strongest useful sensitivity to spot: where the opportunity is. |
| `VEV_6000`, `VEV_6500` (far out of the money) | Prone to missing one side of the book. Excluded. |
| Hydrogel Pack | Stable centre near 10,000, mean spread about 15.7, no strong link to Velvetfruit. |
| Strategy | Return and quality / complexity |
| Voucher-surface relative value with delta hedge (Section 17.3) | High / high |
| Spot and voucher market making | Medium-high / medium |
| Deep in-the-money basis | Medium / high |
| Hydrogel standalone market making | Medium / low-medium |
| Stale-quote taking, blip fades, Hydrogel against Velvetfruit stat arb | Low to medium-low / not recorded |

The voucher strip is orderly, monotone and tied closely to spot; vouchers move with spot at lag 0 at snapshot granularity, so there is little lead–lag to exploit (Table 17.1).

**Rule 17.2** **(Trade only two-sided books).** **\[PRACTICE\]** When any leg loses its best bid or best ask, an apparent mispricing can be fake, because the parity it relies on is no longer executable. Every strategy below trades only when the voucher and the hedge both have live two-sided books.

### 17.3 The voucher surface *\[NB-04 §1\]*

**\[HYPOTHESIS\]** **Voucher-surface relative value with delta hedge**, the best candidate. Universe `VEV_5000`–`VEV_5300`, hedged with `VELVETFRUIT_EXTRACT`. Signal, at each snapshot: (1) compute intrinsic value and time value for each voucher; (2) fit a smooth rolling curve of time value against strike over the last 50–200 snapshots; (3) take residuals from the curve: buy a voucher whose residual is below $-1.5\sigma$ to $-2.5\sigma$, sell one above $+1.5\sigma$ to $+2.5\sigma$; (4) hedge the spot exposure with Velvetfruit using a rolling beta or a local delta proxy. Working hedge ratios from the file: `VEV_5000` about 0.65, `VEV_5100` about 0.58, `VEV_5200` about 0.44, `VEV_5300` about 0.27. Entry on the residual z-score breach with voucher and hedge both two-sided; exit when the residual reverts inside $\lvert z\rvert < 0.5$; time stop 5–30 snapshots; hard stop when the hedge ratio changes materially or a best side disappears. Risk controls: net spot delta close to zero after hedging; a gross exposure cap per strike; a kill switch if the top of book disappears; reject signals when the spread exceeds its median plus $2\sigma$. Sensitivity to missing sides: high.

### 17.4 Market making, basis and the secondary ideas *\[NB-04 §2–6\]*

**\[HYPOTHESIS\]** **Spot and voucher market making**, the best choice when continuous flow is required: the spot spread is stable, the near-the-money vouchers are informationally linked to spot, and the surface is well behaved, so inventory can be hedged. Instruments: `VELVETFRUIT_EXTRACT`, `VEV_5000`, `VEV_5100`, `VEV_5200`, and `VEV_5300` selectively. Quoting rules: base half-width $0.5\times$ to $1.2\times$ the median spread for spot and $0.8\times$ to $1.5\times$ for vouchers; inventory skew — widen the adverse side as inventory grows and lean quotes toward the hedge that is needed; reprice every snapshot in which the underlying or the surface moves, cancel immediately if a side goes missing in any hedge leg; size proportional to visible depth and inversely proportional to churn. Operating rules: quote only when both sides are present; pull quotes during bursts of high churn, or when the underlying moves sharply without confirmation from the vouchers; hedge voucher fills into spot immediately once inventory passes a threshold. Risk controls: a spot inventory cap; vega and gamma approximated by limits per moneyness bucket; stop quoting out-of-the-money tails while sides are missing; a volatility throttle when a one-snapshot spot move exceeds 2–3 median moves. Sensitivity to missing sides: moderate to high — passive bids in out-of-the-money vouchers become unworkable and can poison model fair values, so keep the curve trader active in the 5000–5300 strikes only. The quoting logic itself is Chapter 15.

**\[HYPOTHESIS\]** **Deep in-the-money basis**, a structural hedge and basis control more than an alpha strategy. For a call with price $C_t$ and strike $K$ on spot $S_t$, track $$\tag{17.2}
B_t = C_t + K - S_t ,$$ which for deep in-the-money calls should stay very close to a small constant. Uses: hedge spot inventory with `VEV_4000` or `VEV_4500` when the spot book is temporarily less attractive; trade temporary basis deviations, if vouchers can be converted or exercised at low friction. Rules: buy the call and sell spot when $B_t$ is too low, sell the call and buy spot when it is too high; trade only when both books are two-sided and the conversion rules are known; exit when the basis returns toward its rolling median, and exit hard on a spread blowout or a missing side.

**\[HYPOTHESIS\]** **Stale-quote taking** is secondary because the measured lead–lag is weak. A spot move of 2–4 ticks, or in the top decile of spot moves, triggers a check; a voucher counts as stale when its move is below 30–40% of the beta-adjusted expected move; hold 1–3 snapshots; cancel when the voucher reprices before the order would realistically arrive. Take liquidity only with a real latency advantage confirmed on raw event timestamps. Sensitivity to missing sides: very high — a quote can look stale when it is simply not executable.

**\[HYPOTHESIS\]** **Blip fades.** An order-flow version could not be validated without the event stream; a book-based version can be designed on `VELVETFRUIT_EXTRACT`, `VEV_5000`, `VEV_5100`, `VEV_5200`. Signal: a one-snapshot outlier move with no depth continuation behind it, followed by a partial reversal within one or two snapshots. Entry: fade a move of at least 4–5$\times$ the median one-snapshot move, in small size, only while the spread stays normal or narrow. Exit: hold 1–5 snapshots; stop out if price extends another 1–2 ticks against the position. Sensitivity: moderate; build the signal from the reconstructed book state, not from duplicated trade-print columns.

**\[HYPOTHESIS\]** **Hydrogel standalone market making.** No vouchers and no strong cross-asset signal from Velvetfruit, so plain inventory-managed market making, not pairs trading: quote around the midpoint at $0.5\times$ to $1.0\times$ the median spread; symmetric size at low inventory, strong skew once inventory passes a threshold; reduce quoting during visible churn bursts; mark to the midpoint, not to the last price. Risk controls: a strict inventory cap, a time stop for stale inventory, and a switch-off if visible depth collapses or update churn passes a threshold.

**\[PLAN\]** **Planning notes from 2025** *\[NB-04 §Earlier option rounds; NB-03\]*: build the pricing model and a volatility surface, sell what sits above the smile and buy what sits below it (Table 16.3); market making on options for short-term alpha (Stoikov), watching volatility, with the gamma-and-beta inventory adjustment left open (Chapter 16, 7 April).

## Chapter 18: Statistical arbitrage blueprint *\[NB-05\]*

> **What this chapter establishes**
>
> A design template for an equity-style statistical arbitrage book, in seven stages: a liquid, survivorship-free universe; a factor risk model that neutralises market, sector and style; residual mean-reversion alphas with “cheap for a reason” filters; clusters and baskets, with a Kalman-filter spread (18.1) whose hedge ratio evolves; a constrained mean-variance optimiser with transaction costs (18.2); execution; the controls that separate a live book from a backtest. A blueprint, not a tested system.

### 18.1 The pipeline, stage by stage *\[NB-05 §The pipeline, §A–G\]*

**\[HYPOTHESIS\]** **Goal.** Harvest relative mispricings while staying neutral to known risks (market, sector, style), controlling turnover and being honest about costs. The tools per stage: A, liquidity screens and survivorship-free histories; B, a factor model and shrinkage covariance; C, residual z-scores, context filters, ensembles; D, clustering, PCA, cointegration, a Kalman filter; E, constrained mean-variance with costs; F, scheduling, passive orders, cancel and replace; G, correlation and crowding monitors, kill switches.

**A. Universe and data hygiene** — trade only what can be traded, on clean data; stat arb lives or dies here: a liquid universe only (screen on average daily volume, spread, and borrow constraints for shorts); survivorship-bias-free data with corporate actions and delisting returns; intraday data helps, but a robust daily strategy is possible. **B. Risk model and neutralisation**, the spine: a factor model, daily or intraday, with exposures $B$ (market beta, sector and industry, size, value, momentum, quality, low volatility, plus custom microstructure factors where available), the factor covariance $\Sigma_f$ estimated with shrinkage and the specific risk $\Sigma_\epsilon$ diagonal or clustered; it neutralises factor exposure (target $B^{\top}x \approx 0$), sizes positions by predicted risk and avoids hidden factor bets. **C. Alpha: residual mean reversion with context.** Fit returns (or prices) to the factors, compute the residual return $\widehat\epsilon_i(t)$ for each name, and build a mispricing score from two EMA horizons $h_1$ and $h_2$: $$\tag{18.1}
r = B f + \epsilon, \qquad
z_i(t) = \bigl[\mathrm{EMA}(\widehat\epsilon_i, h_1) - \mathrm{EMA}(\widehat\epsilon_i, h_2)\bigr] / \text{robust scale}(\widehat\epsilon_i), \qquad
y_t = \beta_t\, x_t + \epsilon_t ,$$ where the last member is the Kalman-filter spread of stage D, used for pairs and baskets instead of the z-score. Context signals avoid buying what is cheap for a reason: liquidity and volume shock filters; volatility-regime filters (mean reversion dies when correlations spike in a crisis); earnings and news blackout windows for equities; short-term reversal and the intraday microprice where microstructure data exists. Run an ensemble of alphas: cross-sectional residual reversion (broad); industry and sector relative value (within clusters); pairs and baskets (cointegration-based); event mean reversion — post-earnings drift is not mean reversion and should not be mixed in. **D. Clusters and baskets** — group names into tradable spreads, beyond naive pairs: build clusters from industry membership and the correlation of residual returns; inside each cluster define baskets by PCA on residual returns, by graph methods (minimum spanning tree, community detection), or by cointegration tests that find stationary spreads. Kalman-filter pairs and baskets model the spread $y_t = \beta_t x_t + \epsilon_t$ of (18.1) with a slowly evolving hedge ratio and trade when the spread deviates from its filtered mean by a robust z-score; the filter adapts the hedge ratio through time, which matters in real markets. **E. Portfolio construction** turns alpha into positions by constrained mean-variance optimisation with transaction costs, $$\tag{18.2}
\max_x \; \alpha^{\top}x - \frac{\gamma}{2}\, x^{\top}\Sigma\, x - \kappa \cdot \mathrm{TC}(\Delta x),$$ subject to dollar neutrality $\sum_i x_i = 0$, beta neutrality $b^{\top}x = 0$ with sector and style neutrality, position bounds set by liquidity and borrow, turnover constraints and a gross exposure cap. “This optimiser is the engine of the strategy. The alpha can be simple; the constraints and costs are what make it real.” **F. Execution** keeps the edge after trading; stat arb is turnover-heavy, so execution is part of the strategy: schedule trades to minimise impact (TWAP or VWAP with participation caps); spread-aware limit orders for passive fills when the signal half-life allows; cancel-and-replace logic to avoid adverse selection. **G. Risk controls** survive the regimes that break stat arb: a correlation spike detector (when cross-asset correlation jumps, reduce risk; correlation blow-ups are a real failure mode); a crowding proxy (when many names in the book move together, cut exposure); a high-volatility regime rule (stop trading or widen entry bands); a kill switch for borrow-cost spikes and short squeezes. (Related: s-scores in Chapter 20; the error-correction version in Chapter 16; the trend optimiser (19.3).)

## Chapter 19: Trend-following blueprint *\[NB-06\]*

> **What this chapter establishes**
>
> A design template for a multi-asset trend-following system: an ensemble of risk-scaled trend estimators (19.1) squashed by $\tanh$ and combined across horizons of 5–10 to 250 days; horizon weights learned online or conditioned on a chop/trend regime; sizing from a risk budget and a volatility forecast (19.2) under a volatility target, a drawdown governor and a crisis overlay; cost-aware portfolio optimisation (19.3); execution; monitoring and kill switches. A blueprint, not a tested system.

**\[HYPOTHESIS\]** **Goal.** Capture persistent directional drift across assets while surviving regime shifts (crashes, choppy ranges) through ensembles, dynamic risk control and cost-aware portfolio optimisation.

### 19.1 The blueprint, stage by stage *\[NB-06 §A–G\]*

**A. Data and universe.** A multi-asset futures universe is ideal — rates, equity indices, FX, commodities; equities and crypto also work. Use continuous returns with robust rolls, and corporate actions for equities; compute tradable volatility and liquidity proxies (spread estimates, average daily volume, ADV, realised intraday range). **B. Trend signal: an ensemble of estimators.** Use several partly redundant estimators and average them with dynamic weights. For asset $i$ and horizon $h$ take a risk-scaled trend strength in one of two forms — a moving-average crossover (EWMAC style), whose slow anchor is $k$ times the fast horizon with $k$ between 2 and 8, or time-series momentum: $$\tag{19.1}
m_{i,h}(t) = \frac{\mathrm{EMA}_{h}(p_i)(t) - \mathrm{EMA}_{kh}(p_i)(t)}{\sigma_{i,h}(t)}
\qquad\text{or}\qquad
m_{i,h}(t) = \frac{r_i(t-h,\,t)}{\sigma_{i,h}(t)} .$$ Squash the result so that extreme values do not create extreme leverage, $s_{i,h}(t) = \tanh\bigl(m_{i,h}(t)/c\bigr)$ with $c$ around 2 to 4, and combine across horizons (typically 5–10, 20, 60, 120 and 250 trading days), $s_i(t) = \sum_h w_h(t)\, s_{i,h}(t)$. **C. Dynamic horizon weights.** Learning the weights $w_h$ online, instead of fixing them, is what makes the system adaptive. Option 1, Bayesian model averaging (fast and stable): each horizon is an expert with recent performance $P_h$ measured after costs, $w_h(t) \propto \exp\bigl(\eta\, P_h(t)\bigr)$, with shrinkage toward equal weights. Option 2, regime-conditioned weights: classify the market as choppy or trending from features such as a Hurst proxy, the variance ratio, ADX-style measures, return autocorrelation, drawdown slope and realised-volatility slope; in choppy regimes down-weight the short horizons, which whipsaw; in trending regimes allow them. **D. Position sizing.** The raw target per asset comes from a risk budget and a volatility forecast, $$\tag{19.2}
\mathrm{pos}_i(t) = \frac{R_{\mathrm{budget}}}{\widehat\sigma_i(t)} \cdot s_i(t),$$ with portfolio-level governors on top: a volatility target (scale all positions to hit a portfolio volatility, for example 10% annualised); drawdown control, reducing risk smoothly when the drawdown $\mathrm{DD}(t)$ breaches thresholds, $\lambda(t) = \mathrm{clip}\bigl(1 - \alpha \cdot \mathrm{DD}(t),\;
\lambda_{\min},\; 1\bigr)$; and an optional crisis overlay — when equity volatility spikes or correlations jump, move the risk budget toward diversifiers (rates, gold, FX) instead of going to cash only. The note gives no Sharpe formula; the sizing rule (19.2) is the risk-adjusted rule it uses (editorial). **E. Portfolio construction**, where serious systems differ from a toy trend model: choose weights $x$ to maximise expected utility net of the cost of trading from the previous weights, $$\tag{19.3}
\max_x \; \mu^{\top}x - \frac{\gamma}{2}\, x^{\top}\Sigma\, x - \kappa \cdot \mathrm{TC}\bigl(x - x_{\mathrm{prev}}\bigr),$$ subject to a risk budget per asset class, leverage caps, concentration limits, turnover limits and, optionally, correlation-aware constraints so the same macro bet is not loaded twice; estimate $\Sigma$ robustly (shrinkage, a factor model, or an EWMA that handles jumps). **F. Execution model**, the minimum needed for realism: scheduling (spread trades across the day and cap the participation rate); impact (cost rises with trade size relative to ADV and with volatility); slippage (penalise turnover and avoid trading at illiquid times). **G. Monitoring and kill switches.** Live drift: compare realised against predicted risk and turnover. Signal health: if one expert’s performance collapses across many assets, reduce its weight. Structural breaks: test for breaks in the cost and liquidity regime (the horizon map is Table 20.1; the volatility questions are in Chapter 23).

## Chapter 20: The multi-layer trading architecture *\[NB-07, QB\]*

> **What this chapter establishes**
>
> One firm, one pool of capital, several horizons. Each layer has its own position goal, signals, risk horizon and execution style; a shared risk view, capital allocator and data platform tie them together (Table 20.2). The fastest layer runs on execution quality and profit-taking, not prediction; the slower layers carry the prediction, risk and AI work. The layers feed each other through order flow, indicators and the anomalies that large positions create; competing agents at every horizon are modelled as a mean-field game. A design, not a built system.

### 20.1 Strategies by horizon and the four layers *\[NB-07 §Strategies by horizon, §The four layers; QB\]*

**\[PLAN\]** Two schemes appear in the drafts and are kept separate: a five-tier horizon map (Table 20.1) and the four-layer model (Table 20.2 and Table 20.3); they place some strategies at different horizons. The drafts differ slightly on the boundaries (Layer 1 runs from milliseconds up to minutes in some), and two drafts use $\pm x$ for every non-zero position goal.

**Table 20.1.** Strategies by horizon: the five-tier map *\[NB-07 §Strategies by horizon; QB\]*.

| Tier | Horizon | Strategies |
|---|---|---|
| Ultra-low latency | Microseconds to milliseconds | Market making (spread capture, order-book imbalance), latency arbitrage, basket arbitrage, cross-exchange arbitrage |
| Low latency | Milliseconds to seconds | Event-driven and news trading, micro-momentum and burst breakouts, gamma scalping and delta hedging |
| Medium | Minutes to hours | Mean reversion, pairs and statistical arbitrage, event-driven and news trading, VWAP and TWAP execution algorithms |
| Long | Days to years | Trend-following CTAs (long and short), FX carry, volatility risk premium |
| Ultra-long | Months and beyond | Factor investing, risk parity and all-weather portfolios, macro and private deals, holding |

**Table 20.2.** The four horizon layers of one book *\[NB-07 §The four layers\]*.

|   | Layer 1: HFT | Layer 2: short term | Layer 3: medium term | Layer 4: long term |
|---|---|---|---|---|
| Horizon | Milliseconds to seconds | Minutes to 3 days | 3 days to 3 weeks | 3 weeks to years |
| Position goal | 0 (neutral) | $\pm x$ | $\pm y$ | $\pm z$ |
| Objective | Small, frequent profits with minimal risk | Mean reversion and volatility | Trends and macro patterns | Macro and value investing |
| Core strategies | Market making, statistical arbitrage, liquidity detection | Mean reversion, volatility arbitrage, sentiment fades | Momentum, volatility regimes, cross-asset arbitrage | Fundamental valuation, macro regimes, tail-risk hedging |
| Prediction | Microstructure only | LSTM and Transformer intraday forecasts | Graph neural networks for cross-asset dependencies | Macro-factor models and causal inference |
| Execution | Latency-optimised, co-located | Limit and market orders mixed | VWAP and TWAP over sessions | Low turnover, cost-optimised rebalancing |

**Table 20.3.** The four layers in detail *\[NB-07 §Layer 1–4\]*.

|   | Layer 1: HFT | Layer 2: short term | Layer 3: medium term | Layer 4: long term |
|---|---|---|---|---|
| Strategies | Market making captures the bid–ask spread, models competing market makers as a mean-field game to set spreads and queue positions, and uses latency-optimised placement (predictive cancellations, sniping). Statistical arbitrage trades microstructural mispricings with a near-zero net position: ETF against constituents, cross-exchange spreads, index futures against underlying stocks, pairs and triples. Liquidity detection finds hidden liquidity and iceberg orders from order-book imbalance. | Mean reversion: cointegrated pairs, RSI overbought and oversold signals, reversion from intraday extremes or daily pivot points. Volatility arbitrage: implied against realised volatility (gamma scalping), earnings and macro announcements, straddles and strangles. Sentiment fades: NLP on news and social media to fade FOMO and panic. | Momentum: breakout detection (Bollinger Bands, Ichimoku), institutional order flow such as CTA positioning modelled as a mean-field game. Volatility regimes: switch between long-gamma and short-gamma strategies according to volatility clustering. Cross-asset arbitrage (AUD/USD against iron ore). Longer-cycle mean reversion (cyclical trends, seasonal patterns). Macro-event volatility (central bank announcements). Sector rotation and multi-day news flow. Hybrids switching between mean reversion and trend following by risk regime. | Fundamental valuation: discounted cash flow, EV/EBITDA screens, P/E ratios. Macro regimes: factor investing (value, quality) by yield-curve and PMI phases; reference styles Bridgewater’s risk parity and global macro, Buffett’s value investing. Tail-risk hedging: long volatility, gold, crypto. Stance: typically directional, net long or net short, building strategic positions for fundamental value or macro growth; ESG or other large-scale portfolio constraints may apply. |
| Prediction | Deliberately minimal (**\[HYPOTHESIS\]**): at these speeds latency removes most of the value of forecasting, so the layer relies on order-flow imbalance and execution efficiency; good execution can be profitable even with basic ideas. | LSTM or Transformer intraday forecasts, with conditional logic for events such as volatility spikes. | Graph neural networks for cross-asset dependencies, alternative data, and logic for regime changes from trending to mean-reverting. | Macro-factor models and causal inference to isolate macroeconomic drivers, adapting to the economic cycle. |
| Risk | Execution risk and slippage. No overnight exposure: residual positions are liquidated automatically and each day ends flat or near flat. Hard circuit breakers as a kill switch on latency spikes or abnormal volatility. Dynamic inventory control by reinforcement learning to limit adverse selection. Flash crashes are the scenario the controls must survive. | Time-decaying stop-losses (wider at first, tighter near expiry), inverse-volatility sizing, automatic take-profit and stop-loss triggers, VaR and stress tests. Positions non-zero but small; leverage below the HFT layer, directional bets above it. | Dynamic hedging of tail risk with options and futures; macro hedges with index futures or options; cross-asset correlation checks (bonds, currencies, commodities); position scaling on drawdown, with maximum drawdown and Sharpe ratio as the scaling metrics. Positions larger than in the short-term layer. | Long-horizon drawdowns, the Sortino ratio, sizing by risk tolerance and valuation, options against macro risks. |
| Execution and infrastructure | Level II order-book data at sub-millisecond latency, an in-memory order book, co-location and direct market access, smart order routing, queue-position tactics. | A mix of limit and market orders balancing speed against cost, using Layer 1’s microstructure analysis to refine entries and exits. | Larger blocks worked over several sessions with VWAP or TWAP to limit impact. | Quarterly rebalancing with transaction-cost optimisation; low turnover, consistent fundamental review, hedges or adjustments when fundamentals or the macro environment shift abruptly; passive vehicles for broad exposure with active trades for specific opportunities. |
| Human behaviour | Largely irrelevant at tick level, apart from brief microstructure anomalies during FOMO spikes. | Panic selling in volatility spikes and herding in momentum spikes, both modelled and traded. | Herding during trends, which amplifies moves. | Herding, panic selling and mania phases (the dot-com bubble) strongly affect long-horizon valuations and favour a contrarian stance. Open design choices: concentrated or diversified; long-biased, or balanced with derivatives for downside protection. |

### 20.2 What every layer needs, how the layers interact, and governance *\[NB-07 §What every layer needs – §Development path\]*

**\[PLAN\]** Five things every layer needs. (1) *Predictive models and conditional logic*: microstructure forecasting in Layer 1, increasingly macro and fundamental signals above it; conditional logic changes behaviour on scenarios such as breakouts, volatility spikes and overbought or oversold signals. (2) *Risk measurement on its own horizon*: tight intraday drawdown control in Layer 1; stops and scaling rules over days in Layer 2; wider drawdown thresholds with monthly or quarterly stress tests in Layers 3 and 4. (3) *A stance on pushing or following*: each layer may push the market under certain conditions — Layer 1 may take liquidity aggressively when the model finds it profitable, Layers 2 and 3 may lean into perceived momentum, Layer 4 acts through reallocation and accumulation; all of it stays inside market-abuse rules, and manipulative tactics such as quote stuffing are out of scope. (4) *Human behaviour*: behavioural signals grow with the horizon — negligible at tick level, important around earnings and macro announcements, a significant influence on long-horizon valuation. (5) *Execution as a source of alpha*: smart order routing, queue position and iceberg orders in Layer 1; TWAP and VWAP to build or exit positions quietly in Layers 2 and 3; minimising impact over days or weeks in Layer 4.

**\[HYPOTHESIS\]** **Mean-field games and cross-layer interaction.** Each agent is small relative to the market, but the aggregate of many agents shifts the dynamics. Layer 1: the algorithm is one of many HFT market makers, and profit depends on anticipating how the others react. Layers 2 and 3: the probable behaviour of many medium-frequency traders, alongside short-term signals. Layer 4: large institutions — mutual funds, pension funds, central banks — where the collective state of the market forecasts inflows, outflows and herd moves. How the layers feed each other: Layer 1 $\to$ Layers 2 and 3, order-flow data (liquidity changes, volume spikes); Layers 2 and 3 $\to$ Layer 4, medium-horizon indicators combined with fundamentals; Layer 4 $\to$ Layers 1–3, large positions create short-term anomalies and liquidity constraints, which open arbitrage and rebalancing trades for all three lower layers, plus macro signals for Layer 3 volatility positioning.

**\[PLAN\]** **Unified components.** Prediction engine: HFT, order-book dynamics plus mean-field modelling of competitors; short and medium term, hybrid models (LSTM with GARCH) and market-regime detection; long term, macro-factor models, causal AI and portfolio optimisation. Risk management: hierarchical VaR that aggregates risk across layers, a risk engine for hedging and limits, liquidity buffers (reserve capital for Layer 1 shocks). Behavioural overlays: sentiment gauges for crowd panic and euphoria (Layers 2 and 3), institutional flow such as ETF creations and redemptions (Layer 4). Execution synergy: Layer 1 scouts liquidity for Layer 2 and 3 trades and executes them; sizes, risk exposure and strategy allocations are monitored and adjusted continuously across all layers. **Governance.** A common risk dashboard consolidates exposure across layers with daily VaR, portfolio drawdown and liquidity usage. Capital moves between layers with performance and market conditions: if short-term strategies are consistently profitable while HFT struggles in a low-volatility market, margin and risk budget move to the short-term layer. Technology: shared machine-learning infrastructure, with reinforcement learning or other models extracting signals common to several horizons; cloud HPC for training, on-premises or co-located servers for inference; a data lake with unified ingestion (market data, fundamentals, news sentiment) and reusable cleaning and feature pipelines. Regulation: HFT and short-term strategies attract scrutiny, including market-manipulation concerns; keep audit logs of trades and reasoning, and a kill switch for when performance or risk deviates sharply. **Development path.** (1) Prototype each layer in a sandbox (simulation or paper trading; measure latency, fill rates and slippage for the HFT layer; walk-forward backtests for the others). (2) Integrate under a single portfolio manager and test the synergies: do HFT signals improve entry timing for the slower layers, and does the long-term fundamental stance act as a hedge or an anchor? (3) Deploy incrementally, one layer at a time with small capital, expanding as alpha and risk metrics confirm the strategies. Next steps as recorded: a design document per layer; implement and backtest the strategies; integrate and test in simulation; refine on performance, risk and market feedback.

### 20.3 Early system sketch: crypto and equities *\[NB-07 §Early system sketch; QB\]*

**\[PLAN\]** Assets: cryptocurrencies and equities. Horizons: ultra-low latency (sub-millisecond) and medium frequency (hours to days). Venues: Binance, OKX, Coinbase, Robinhood. Technology: Python, with C++ for speed. Leverage: flexible. Features: moving averages, volatility, order-flow imbalance, on-chain indicators, momentum, reversal, carry, post-earnings drift, low-volatility effects, PCA factor rotation, breakout detectors, ML predictors, RSI and other oscillators, transaction volume, whale movements, staking rates. Strategies (under ultra-low-latency and mid-frequency headings): market making (quote and rebalance to capture spreads and liquidity rebates, position near zero); cross-exchange and triangular arbitrage; order-book microstructure models that read order-flow imbalance and momentum ignition to enter before large moves, which needs sub-millisecond tick-by-tick processing; statistical arbitrage with Avellaneda–Lee s-scores; pairs trading (marked as an open question); momentum and trend; mean reversion; LSTM and Transformer predictors; long-term pairs trading; fundamental and on-chain signals; DeFi and DEX arbitrage. Risk: position limits per strategy; preset stop-loss and take-profit thresholds; portfolio-level drawdown monitoring with a system-wide safe mode in severe volatility; real-time alerts on any rule violation. **Pipeline**: market data $\to$ feature engine $\to$ strategy modules $\to$ order manager (C++) $\to$ risk manager $\to$ monitoring and logging. **Components**: an execution engine — a fast, event-driven order manager that receives send-order commands from strategies, handles API details (rate limits, retries, smart routing) and tracks outstanding orders and confirmations, with latency-critical code (order serialisation, nonce management) in C++ with Python bindings such as PyBind11; a machine-learning module — models trained off the trading path in Python (TensorFlow or PyTorch) and updated online or at intervals, for example LSTM networks for short-term price movement; reinforcement learning such as deep Q-networks is an option, though robust financial RL is still at the research frontier. **Build plan**, two versions recorded: prototype $\to$ paper-trade $\to$ C++ optimisation $\to$ staged release $\to$ live risk dashboards; and prototyping and backtesting $\to$ simulation and paper trading $\to$ C++ optimisation $\to$ data pipeline $\to$ integration testing $\to$ monitoring set-up $\to$ iterate and tune. **Research directions listed**: deep-representation models (Transformers, temporal graph attention networks, FinGPT); mean-field and broker games for order-flow toxicity; RL execution agents, dynamic Kelly sizing, rough-volatility surfaces, Chebyshev interpolation; graph-signal-processing extensions of HAR (realised-volatility vectors embedded on a stock-correlation graph and transformed in the graph-spectral domain for next-day risk signals); on-chain analytics for crypto (funding rates, NVT-style utilisation ratios, liquidation clusters).

**\[OPEN\]** **Claims recorded, not verified**: Level-2 order-book imbalance, expected fill price and implied spread are the primary predictors for signals from 5 minutes to 1 hour; spoofing is filtered by conditioning on filled orders only, or with depth-surface views; Transformer variants (Informer, Autoformer, TimeXer) are favoured for forecasting from 15 minutes to 1 day; temporal graph attention networks beat GARCH at volatility forecasting. **References named in the drafts**: “The Two Faces of a High Frequency Trade” (XTB); “Advanced Statistical Arbitrage with Reinforcement Learning” (arXiv); “Mean Field Game of High-Frequency Anticipatory Trading” (arXiv: HFTs supply liquidity according to their inventory aversion, which lowers costs for large traders when temporary market impact is significant); “High-frequency Statistical Arbitrage Strategy Based on Stationarized Order Flow Imbalance” (ScienceDirect); “Buy Low, Sell High: A High Frequency Trading Perspective” (SIAM J. Financial Mathematics); “An innovative high-frequency statistical arbitrage in Chinese futures market” (ScienceDirect); “The Evolution of Statistical Arbitrage: Rise of Alternative Data and Shorter Holding Periods” (QuantLink); “Statistical Arbitrage” (Investopedia); PrimeXBT tutorials (on-chain metrics).

**Remark 20.1** **(Editorial).** The four layers are the practice-side counterpart of the business, portfolio, strategy and execution layers of Chapter 24; Conjecture 5 (Chapter 10) asks for the principle that makes them optimal at once; Chapter 22 says why horizons cannot share one correction logic.

## Chapter 21: Reinforcement learning and control *\[NB-09\]*

> **What this chapter establishes**
>
> Pointers from a research call on reinforcement learning (RL) and stochastic control for trading, grouped by theme: which formulations to use (Markov states, continuous-time “little q” learning, classical control), what to do when the state cannot be made Markov (rough paths, neural RDEs, signatures, decision transformers), model-based against model-free methods, exploration, the learning signal, event dynamics and hierarchy, with a reading list. It is the toolkit for the constructive version of Conjecture 4 (Chapter 9).

**\[PLAN\]** **Framing.** In hindsight the optimal policy can be found; the hard part is finding it online. A Markov state answers “where are we now?”: if the process can be approximated as Markov, for example by stacking the last 7 frames into the state, the problem becomes solvable with q-learning. Do not act by pure argmax — a greedy policy stops exploring, and online learning lives on the exploration–exploitation trade-off. Feed-forward: test where you have an edge.

**Continuous time and space.** RL formulated directly in continuous time and space. “Little q”, the continuous-time counterpart of the Q-function, with regret bounds (with $N^{3/4}$ noted beside them) and continuous calibration and optimisation. Classical stochastic control: maximum principles and Bellman equations, with the Fudan group named as the reference school. **Non-Markovian problems.** When the state cannot be made Markov, work with the path itself: rough paths and rough differential equations (a calculus for irregular driving signals); neural RDEs (rough differential equations whose vector field is a neural network, for continuous-time non-Markovian stochastic control); path signatures (the signature transform turns a path into iterated-integral features, and signature regression learns on them); decision transformers (RL as sequence modelling). **Model-based and model-free.** Model-based: predict the underlying dynamics with a neural network, then plan against the model. Model-free: PPO, “soft” methods (presumably soft actor-critic) and critic methods, trained in simulation. **Exploration**: entropy regularisation rewards the policy for staying random enough to keep exploring; generalised entropies (Rényi, Tsallis) are options. **The learning signal**: reward shaping (auxiliary rewards that guide learning toward the real objective); counterfactual learning (update on what happened and on what was expected under the other actions); credit assignment (which action actually earned the reward); explainable AI (keep the policy’s reasons inspectable). **Event dynamics**: self-exciting processes (events that raise the probability of further events) and neural Hawkes processes (a neural parametrisation of the event intensity). **Structure**: hierarchical RL (policies at several levels of abstraction) and H-MARL (hierarchical multi-agent RL).

**Reading list.** “A Neural RDE approach for continuous-time non-Markovian stochastic control problems” (arXiv:2306.14258); “Solving and Learning non-Markovian Stochastic Control problems in continuous-time with Neural RDEs” (OpenReview); “q-Learning in Continuous Time” (arXiv:2207.00713). **Where RL appears elsewhere**: learned quoting policies and RL inventory control (Table 15.1, Table 20.3); RL execution agents in the early system sketch of Chapter 20; the constructive version of Conjecture 4 asks for value iteration, policy iteration or actor-critic schemes that provably converge to the optimal policy on a hybrid state space (Chapter 9); risk-aware Bellman control is one of the three building blocks of Conjecture 5 (Chapter 10).

## Chapter 22: Multiscale thinking *\[NB-10\]*

> **What this chapter establishes**
>
> An own hypothesis, sharpened in discussion and conceptual rather than empirical: across systems from the quantum to the macroscopic, corrections become rarer but larger as scale increases. Its correction: what changes with scale is whether the system is dominated by noise or by structure — aggregation is a signal-to-noise filter (Hypothesis 22.1). For trading it explains why market making and directional holding keep conflicting: they operate in different correction regimes, which is why the architecture of Chapter 20 gives each horizon its own layer.

**\[HYPOTHESIS\]** **The starting idea.** Small-scale systems show fast, frequent fluctuations and constant micro-corrections; large-scale systems show slower dynamics with larger, rarer adjustments; aggregation averages out noise and leaves smoother but more persistent deviations. The pattern shows up in quantum systems (constant fluctuations and decoherence corrections), molecular systems (thermal noise averaging into temperature), markets (tick noise against structural moves) and climate (weather against long-term shifts). **Where it needs correcting.** The mistake is to assume corrections are actively happening at every scale in the same way. At the micro level everything is fluctuation: no clear imbalance and no clear correction, only continuous stochastic motion. At the mesoscopic level restoring forces appear — diffusion, mean reversion, entropy maximisation — and imbalances exist and are corrected continuously through many small interactions; this is the closest match to “constant corrections”. At the macroscopic level small fluctuations cancel, only large coherent imbalances survive aggregation, and the system develops inertia, thresholds and nonlinear responses. Corrections at large scale are not rarer because the system waits; they are rarer because only large deviations are visible at that scale.

**Hypothesis 22.1** **(Aggregation is a signal-to-noise filter — refined statement).** **\[HYPOTHESIS\]** Micro level: high variance, low persistence. Macro level: low relative variance, high persistence. Small imbalances disappear in aggregation; large imbalances propagate and need large corrections. At small scales, systems are dominated by continuous stochastic fluctuations that look like constant micro-adjustments; at larger scales, aggregation filters out the small fluctuations, so only larger and more persistent imbalances remain, and these appear as rarer but larger corrections.

**What it means for trading.** At the order-book scale constant noise and microstructure dominate: spread capture. For short-term signals, small mean reversion: frequent, small trades. On longer horizons, trend and drift: fewer, larger moves. The trap is applying micro-level correction logic at the macro scale, or the reverse; that is why combining market making with directional holding keeps producing conflicts. Related concepts: renormalisation and coarse-graining, the central limit theorem, mean-field approximations, scale separation in stochastic systems; in markets, microstructure noise against alpha, liquidity against information, HFT against positional trading.

**Remark 22.2** **(The same filter in aggregation theory — editorial).** The refined statement is the informal form of the aggregation hierarchy of Chapter 13: parts are matched to a whole by the matching rule of Section 13.3, and the whole keeps the persistent component of the parts while their independent fluctuations cancel, the mechanism behind the reduction of speed and turbulence under aggregation in Chapter 14. NB-10 reaches the same reading from the trading side; its practical consequence — one layer per correction regime — is Table 20.2, and the principle that would make all layers optimal at once is Conjecture 5 (Chapter 10).

## Chapter 23: The research toolkit: reference scraps and getting started *\[NB-11, NB-12, QB\]*

> **What this chapter establishes**
>
> The reference material that does not belong to a larger note: forward-rate facts and money-market formulas, the questions prepared for speakers on volatility and trend following, and the still-unwritten questions on illiquid bonds; a condensed starting path in quantitative trading on about £50 — vocabulary, foundations, platforms and demo accounts, a five-step plan, what to study next — with the guide’s verdict on the research repositories; the map of the twelve notes (Table 23.3); and a half-page pointer to what NB-08 contains (Section 23.4).

### 23.1 Forward rates, the money-market account and the speaker questions *\[NB-11; QB §Volatility questions, §illiquid bonds questions\]*

**\[KNOWN RESULT\]** $P(t,T)$ is the price at time $t$ of a zero-coupon bond maturing at $T$; the continuously compounded yield $y(t,T)$, the simple spot rate $L(t,T)$, the simple forward rate for $[T_1,T_2]$ seen at $t$, and the forward yield over the same period are $$\begin{gathered}
P(t,T) = e^{-(T-t)\,y(t,T)}, \qquad P(t,T) = \frac{1}{1 + (T-t)\,L(t,T)}, \tag{23.1}\\
F(t;T_1,T_2) = \frac{1}{T_2 - T_1}\left(\frac{P(t,T_1)}{P(t,T_2)} - 1\right), \qquad
y(t;T_1,T_2) = \frac{(T_2 - t)\,y(t,T_2) - (T_1 - t)\,y(t,T_1)}{T_2 - T_1}. \tag{23.2}
\end{gathered}$$ For the one-year simple rate one year forward, $F(0;1,2) = P(0,1)/P(0,2) - 1 = e^{-y(0,1) + 2\,y(0,2)} - 1$. Why the instantaneous forward sits above an increasing yield curve: $f(t,T) = -tial_T \ln P(t,T) = y(t,T) + (T-t)\,tial_T y(t,T)$. The forward statements (Table 23.1) assume the forward period starts after today ($T_1$ later than $t$). A money-market account with continuous compounding at the short rate $r$ over $t$ years from $A_0$ is worth $A = A_0\,e^{rt}$; with a simple rate over one period, $A = A_0\,(1 + \text{simple rate})$.

**Table 23.1.** Forward-rate facts; where the note left a statement unfinished it was completed from the definitions *\[NB-11 §Forward rates\]*.

| If | Then | Status |
|---|---|---|
| The discount curve $P(t,T)$ is increasing in maturity | The simple forward rate is negative | As recorded |
| The yield curve is increasing | The instantaneous forward curve lies above the yield curve | As recorded |
| The yield curve is increasing | The forward yield lies above both spot yields | Completed from the definitions |
| The yield curve is increasing | The simple forward rate also lies above both continuously compounded spot yields | Completed from the definitions |
| The simple spot rates are decreasing, and $L(t,T_1)$, $L(t,T_2)$ have the same sign | The simple forward rate is not between the two spot rates; it lies below both | Completed from the definitions |

**\[OPEN\]** **Questions prepared for speakers.** For Artur Sepp, with the background reading listed with them (a paper on CTA trend following, SSRN 3167787) and a remark noted alongside — FX is more mean-reverting, so autocorrelation is useful there: (1) *spikes against regime changes* — in a modelling or trend-following framework, how do you tell temporary volatility spikes (noise, events) from structural changes in volatility dynamics, and which statistical signals or filters do you rely on? (2) *macro and cross-asset inputs* — do you bring macroeconomic or cross-asset signals into longer-horizon volatility forecasts, and how do you balance that against the responsiveness short-term risk models need? (3) *forecasting across time scales* — volatility behaves increasingly differently across time scales; which methods are most robust for short-term against long-term forecasting, and are machine-learning techniques overtaking HAR and GARCH? (4) *positioning for extremes* — how should asset exposure or inventory be adjusted ahead of, or in response to, extreme volatility events: forward-looking measures such as implied skew, or backward-looking stress tests? For Laura Ballotta: ask for access to the paper “Multivariate additive subordination with applications in finance”. Still to write: questions on illiquid bonds (the bucket holds only the heading).

### 23.2 Getting started in quantitative trading on a small budget *\[NB-12\]*

**\[PLAN\]** **The premise.** Real high-frequency trading needs specialised hardware, ultra-fast software, direct exchange data feeds, co-location and skilled staff; the cost runs into millions of pounds and is out of reach for a retail trader. So £50 is a learning budget, not trading capital: it buys a course or a book, or later funds a tiny live account whose only purpose is to feel what real money does to decision-making. The goal changes from doing HFT to learning about quantitative trading — concepts, mathematics, programming, market mechanics and simulated strategies — with no expectation of profit. Platform features, fees and rules are as the guide recorded them and were not re-checked.

**Table 23.2.** Vocabulary, and demo accounts on the platforms considered *\[NB-12 §Vocabulary, §Platforms\]*.

| Term | Meaning |
|---|---|
| Quantitative finance; quantitative trading | Using mathematical and statistical models, data and computation to make financial decisions; building and executing strategies from quantitative analysis, tested on historical data (backtesting) before going live. |
| High-frequency trading (HFT) | Algorithmic trading executed in microseconds to milliseconds, at very high order volume, with positions held from fractions of a second to a few minutes and rarely overnight. |
| Latency; co-location | The delay for market data to reach the trader, or for an order to reach the exchange and be processed; placing trading servers in the exchange’s own data centre to cut latency. |
| Mid-frequency trading (MFT) | Automated trading with holding periods from minutes to hours, or across a day; leans on order flow and short-term signals more than raw speed, and needs lighter infrastructure. |
| Market order; limit order; limit order book | Buy or sell immediately at the best available price (fast, no price guarantee); buy or sell only at a stated price or better (price control, no guarantee of execution); the exchange’s list of resting limit orders, quantities bid and offered at each price level. |
| Long and short; diversification | Buying in the expectation of a rise, selling (often borrowed) in the expectation of a fall; spreading exposure across assets or strategies to reduce overall risk. |
| Platform | Demo account — access; assets in demo; limits |
| Binance | Yes — Spot Test Network at testnet.binance.vision, with a GitHub login; crypto spot; separate API keys, no real order-book simulation. |
| OKX | Yes — “Demo Trading” mode inside the main platform; crypto spot, probably futures and options; virtual funds, can be topped up. |
| Coinbase | Not directly — through third-party simulators such as QuantConnect; crypto, by external simulation. |
| Robinhood | No. |
| Saxo Bank | Yes — demo sign-up on the website; stocks, FX, CFDs, probably futures; 20 days, with 100,000 USD of virtual cash. |

**Foundations** (prerequisites; advanced material is unproductive without them). (1) Markets and instruments: stock exchanges (NYSE, LSE) and crypto exchanges (Binance, Coinbase, OKX); stocks and the major cryptocurrencies (BTC, ETH) are accessible starting points. (2) Probability and statistics — probability quantifies how likely a move or a successful trade is, statistics tells whether a strategy’s performance is significant or luck: probability rules, independent and dependent events, sample spaces, mean and variance, the normal distribution, hypothesis testing; free, Khan Academy; structured and possibly paid, Coursera (for example Wharton’s quantitative modelling course). (3) Python, the dominant language because of its libraries, readability and community: fundamentals (variables, data types, operators, control flow); lists and dictionaries; NumPy (arrays, indexing, slicing, numerical functions); Pandas (DataFrames for importing, cleaning and analysing time series); Matplotlib (line charts, histograms, scatter plots); resources DataCamp (“Introduction to Python for Finance”), Coursera, Udemy, Codecademy, freeCodeCamp, python.org. **Platforms and paper trading.** Binance, OKX and Coinbase: large crypto exchanges with spot trading, often derivatives, high liquidity and full APIs; Coinbase Advanced adds charting and lower fees. Robinhood: commission-free, mobile-first US broker for stocks, ETFs, options and some crypto; the guide notes the US pattern day trader rule for margin accounts under 25,000 USD. Saxo Bank: traditional Danish online broker with global stocks, FX, CFDs, futures, options and bonds; platforms SaxoInvestor, SaxoTraderGO, SaxoTraderPRO; integrates with TradingView. Demo accounts are in Table 23.2; for crypto practice the guide recommends OKX demo trading or the Binance Spot Test Network. Paper trading gives risk-free mistakes, familiarity with the platform (order types, charts, positions, portfolio view), a first test of a strategy under realistic though imperfect conditions, and limited emotional preparation; it does not give realistic execution (demo fills often ignore available liquidity and slippage), realistic latency (which rules out testing anything truly high-frequency), real emotions (fear and greed are absent, so demo success does not guarantee success with real capital) or priority (demo systems may be slowed down when live markets are busy).

**The five-step plan.** (1) Choose a learning path: free material first (Khan Academy for probability and statistics, free Python tutorials), a structured course only if the budget allows. (2) Set up a demo account: on OKX switch to Demo Trading from the assets menu; on the Binance testnet log in with GitHub and generate an `HMAC_SHA256` API key, storing the key and secret securely. (3) Make the first paper trades, for mechanics not virtual profit: buy a small amount of BTC or ETH with a market order and note the fill price and speed; place a limit buy below the market and a limit sell above it and watch whether and when they fill; find the open orders, trade history, balances and charts. (4) Practise Python alongside: load a free price-history CSV into a Pandas DataFrame, compute simple returns, plot the price. (5) Optional and cautious, a tiny live trade only after substantial demo practice: £10–£20 on a platform with a low minimum deposit and low fees, one or two very small limit orders in BTC or ETH, observing the execution, the fees and your own reaction; any outcome is tuition, not investment.

**What to study next, and afterwards.** Concepts: latency and co-location; order-book dynamics (order flow, depth, bid and ask imbalance, the spread); market microstructure (how prices form, how trades execute, the role of market makers, the effect of exchange design); strategy archetypes — arbitrage (including latency arbitrage), market making, statistical arbitrage, event-driven trading, and mid-frequency strategies built on order-flow analysis of tick data or on reacting to HFT behaviour such as front-running countermeasures. Reading: Investopedia for terminology; QuantStart for strategy identification, backtesting and execution systems; Quantra by QuantInsti for specialised paid courses (“Trading in Milliseconds”: microstructure, latency types, order-flow calculation with the Lee–Ready algorithm, mid-frequency strategies). Reality check: the barriers to HFT are structural (technology and data costs, limits on data access, co-location, regulatory hurdles, a continuous arms race in which any advantage is short-lived); HFT is criticised for adding to volatility, contributing to flash crashes and creating an uneven playing field; the practical direction for a retail trader is algorithmic strategies on horizons of minutes to days, or mid-frequency ideas that depend on analysis more than speed. The path in one list: (1) build the foundation — probability, statistics, Python; (2) learn a platform through a demo account; (3) practise order types and watch how the market responds; (4) apply Python to basic financial data; (5) optionally, one very small live trade for the psychology; (6) study quantitative finance, microstructure and strategy theory; (7) move on to advanced material and research papers — progress takes time and consistent effort, and profitability is never guaranteed. Afterwards: advanced courses (Coursera, edX, Quantra, university programmes — financial engineering, machine learning for trading, derivatives); communities (QuantConnect forums, specialist subreddits, Elite Trader — read critically and ignore get-rich-quick signals); research (practitioner blogs, SSRN, arXiv q-fin); backtesting platforms (QuantConnect, Zipline, Backtrader — rigorous historical testing before any live deployment). **The research repositories.** The guide also looked at the WTech, Knowledgebase, KB and TMRW repositories, and could assess only what was visible, mainly WTech; KB and TMRW had no description to go on. Its verdict: working research notes at an advanced level, not teaching material. WTech covers strategy design (defining an ideal state, detecting market states, matching tactics to states, considering opponent positions), optimal execution, leverage and derivatives, HFT market making, and a research list from Markov models, mean-reversion analysis and convergence theorems to machine-learning models (autoencoders, gradient boosting), time-series cross-validation, mean-field games and event-based HFT; Knowledgebase is a collection of material on quantitative finance, insurance, mathematics and AI. Come back to them after step 6, as a view of what practitioners work on.

### 23.3 How the notes fit together *\[NB README\]*

The twelve notes were written at different times for different purposes — competition logs, design drafts, research statements, reading notes — and consolidated by topic in November 2026. Conventions: each opens with its scope and sources (own notes, credited public write-ups, or AI-assisted analysis not independently tested); blueprints and designs are starting points, not tested systems; parameter values are ranges to search, not fitted results; nothing is investment advice. Table 23.3 says where each note is written up and which research problem of Part IV it instantiates. Reading paths: a first orientation, NB-12 then NB-02; a market maker, NB-01 then NB-02 and NB-04; a systematic strategy, NB-05 or NB-06 then NB-07; the research programme, NB-08 then NB-10 and NB-09.

| Note | Group | Written up in | Research problem it instantiates |
|---|---|---|---|
| NB-01 Market making and inventory control | Practice | Chapter 15 | Estimating a fair value to quote around: central pricing (C2, Chapter 7); inventory skew and execution scheduling: stealth-optimal execution (C3, Chapter 8); switching between making, taking and hedging regimes: path switching (C1, Chapter 6) |
| NB-02 IMC Prosperity playbook; NB-03 Prosperity 2025 team log | Practice | Chapter 16 | Fair value (C2); several products and strategies under shared limits: the Final Problem (C5, Chapter 10) |
| NB-04 Options and voucher strategies | Practice | Chapter 17 | Making, taking and hedging regimes (C1) |
| NB-05 Statistical arbitrage; NB-06 Trend following | Blueprints | Chapter 18 and Chapter 19 | Execution scheduling (C3); single strategies of the kind the architecture of NB-07 combines |
| NB-07 Multi-layer trading architecture | Blueprints | Chapter 20 | C5: one principle for every layer and the whole firm |
| NB-08 Tomorrow’s Conjectures | Research | Section 23.4; statements in Chapter 6, Chapter 7, Chapter 8, Chapter 9 and Chapter 10 | — |
| NB-09 Reinforcement learning and control | Research | Chapter 21 | The toolkit for the existence of optimal strategies (C4, Chapter 9) |
| NB-10 Multiscale thinking | Research | Chapter 22 | Why layers on different horizons need different logic (C5) |
| NB-11 Reference scraps; NB-12 Getting started | Reference | Chapter 23 | — |

### 23.4 Conjecture 5 in the notes *\[NB-08\]*

NB-08 restates the five open problems published by Tomorrow Capital Research in one place with consistent notation (full statements at the firm’s site) and adds the working notes behind them. The statements themselves are written up once, in Chapter 6, Chapter 7, Chapter 8, Chapter 9 and Chapter 10; Table 23.4 only lists what the note contains and where each item is treated.

| Item in NB-08 | What it holds | Written up in |
|---|---|---|
| Overview table of the five conjectures | Title, area and the one-line question of each; Conjecture 4 carries the working title “Conjecture X” in its draft | Part IV |
| Conjecture 1: dynamic reallocation under path switching | Models $\mathcal{M}_k$, strategies $\pi^k$, the blend $\theta_t = (1-w_t)\theta^{(1)}_t + w_t\theta^{(2)}_t$ on $[T_2,T_3]$, the challenge; status: updated on the website to the whole transition path under frictions, PDF released | Chapter 6 |
| Conjecture 2: the central pricing problem | $N > 3$ interacting assets with derivatives, immediate against historical dependence, the toy impact rule, the two-part statement (estimator, multi-step confidence regions with $H \ge 5$), the research note on a unified framework | Chapter 7 |
| Conjecture 3: stealth-optimal execution distributions | Notional $Q$ over $[0,\tau]$, square-root footprint, at most 100 accounts, cost and memory ingredients, existence and algorithm challenge; status: a solution to the initial statement by Lorenzo M. Zorzi Chiarioni | Chapter 8 |
| Conjecture 4: existence of optimal strategies | Hybrid state on $M \times S$, the performance $J(\pi)$, the existence conjecture, the multi-agent and mean-field extension, what counts as a solution; no problem PDF released | Chapter 9 |
| Conjecture 5: the Final Problem | The firm hierarchy, local and global objectives, the multiscale principle, the three building blocks (asset and agent graphs, hybrid control, risk-aware Bellman control) | Chapter 10 |
| Working notes toward a variational principle | Action with the highest expected utility; utility takes cost and groupings into account; minimise free energy (risk), maximise conserved energy (return); properties needed to drive the dynamics not yet specified; open question whether this is a variational principle. Product ideas: ToE, a min–max strategy (find the trend, find where $\mathrm{d}X = 0$, check the sign of $\mathrm{d}^2 X$); TMRW — expand, establish, excel | Chapter 10 |
| How the conjectures show up in the other notes | The mapping of Table 23.3 | this Part |

### Status of the working notes

**Table 23.5.** Status of the rules and claims of Part VI. Where tested: the test bench `tmrw_lab` (Appendix E) — `micro/`, `strategies/`, `experiments/market_making`, `prosperity` (the competition replays), `blueprints`.

| Rule or claim | Tag | Where tested |
|---|---|---|
| Rule or claim | Tag | Where tested |
| PnL $\approx$ spread capture $-$ adverse selection $-$ inventory risk $-$ overtrading (Rule 15.1) | **\[PRACTICE\]** | `micro/`, `experiments/market_making` |
| Avellaneda–Stoikov reservation price (15.3); Cartea–Jaimungal, queue and LOB extensions | **\[KNOWN RESULT\]** | `experiments/market_making` (grid on $\gamma$) |
| Linear skew $k = 0.125\,m$, $m \in [0.3, 1.0]$; rule of thumb 1 tick per 10–15 units (Table 15.2) | **\[PRACTICE\]** | `experiments/market_making` |
| Remove the order at the limit (Rule 15.3); bands and sizes of Table 15.4 | **\[PRACTICE\]** | `experiments/market_making` |
| Take only 6–10 ticks from fair and inventory-reducing; the taking layer cut PnL 2,300 $\to$ 1,600 | **\[PRACTICE\]** **\[MEASURED\]** | `experiments/market_making` |
| Grid `risk_aversion` $\times$ `inventory_limit`; lowest risk aversion keeping $\lvert q\rvert \le 79$ for 99% of the session | **\[PLAN\]** | `experiments/market_making` |
| Micro mean reversion at 10,020–10,030 / 9,975–9,985 as a secondary strategy | **\[HYPOTHESIS\]** | `experiments/market_making` |
| Take against fair value, make around it, skew by inventory; the game’s fair value is the midpoint of the largest resting quotes | **\[PRACTICE\]** | `prosperity` |
| The structural trade before the model: cross-exchange conversion, basket spread (16.1), option by Black–Scholes, disclosed counterparties | **\[PRACTICE\]** | `prosperity` |
| Lessons that repeat (Rule 16.1) | **\[PRACTICE\]** | `prosperity` |
| 5 April 2025 quoting rules: Strategy 1 $\approx$ 3,500 against Strategy 2 $\approx$ 2,800 (Table 16.4) | **\[LOG\]** | `prosperity` (Kelp, Resin) |
| Position penalty (16.2); ATR-based quote distance by liquidity state | **\[PRACTICE\]** | `prosperity` |
| Error-correction stat arb with a Phillips–Ouliaris gate; VECM extension; Ink crash detection | **\[HYPOTHESIS\]** | `prosperity` (Ink) |
| NCSKEW (16.3), DUVOL (16.4); PTPI from trading value | **\[KNOWN RESULT\]** | `prosperity` (Ink) |
| Black–Scholes pricing with implied-volatility mean reversion near 16% and a capped delta hedge | **\[PRACTICE\]** | `prosperity` (Coconut coupon) |
| Trade only two-sided books (Rule 17.2) | **\[PRACTICE\]** | `prosperity` (2026) |
| Voucher-surface relative value, hedge ratios 0.65 / 0.58 / 0.44 / 0.27; spot and voucher market making; deep-ITM basis (17.2); stale quotes, blip fades, Hydrogel | **\[HYPOTHESIS\]** | `prosperity` (2026) |
| Stat-arb blueprint: factor neutralisation, residual z-score and Kalman spread (18.1), optimiser (18.2) | **\[HYPOTHESIS\]** | `blueprints` |
| Trend blueprint: ensemble signal (19.1), online horizon weights, sizing (19.2), drawdown governor, optimiser (19.3) | **\[HYPOTHESIS\]** | `blueprints` |
| Four horizon layers with one risk view, capital allocator and data platform (Table 20.2); governance; development path | **\[PLAN\]** | `strategies/` |
| Layer 1 prediction deliberately minimal; mean-field modelling of competitors at every horizon | **\[HYPOTHESIS\]** | `strategies/` |
| Claims recorded, not verified (Level-2 imbalance as primary 5-minute to 1-hour predictor; Transformer variants for 15 minutes to 1 day; temporal graph attention beats GARCH) | **\[OPEN\]** | — |
| RL and control toolkit: continuous-time q-learning, neural RDEs, signatures, entropy regularisation | **\[PLAN\]** | — (toolkit for Chapter 9) |
| Aggregation is a signal-to-noise filter (Hypothesis 22.1) | **\[HYPOTHESIS\]** | Chapter 13 and Chapter 14 |
| Forward-rate facts (Table 23.1); money-market account | **\[KNOWN RESULT\]** | — |
| Getting-started path on £50 | **\[PLAN\]** | — |

# Part VII: The operating plan

## Chapter 24: The four layers of the firm *\[BP\]*

> **What this chapter establishes**
>
> The business plan describes Tomorrow Capital as four coupled decision layers—business strategy (which ventures), portfolio and internal management (how much capital to each strategy, judged on a KPI backbone), trading strategies (the alphas) and execution (fills and market impact)—with objectives flowing down and telemetry flowing up. This chapter keeps every objective, primary risk, decision module, KPI, strategy family, rule, numerical threshold and worked example of the plan, written once. Everything is an operating intention (**\[PLAN\]**) unless tagged otherwise; the plan’s one explicit formula, $\mathbb{E}[\text{Return}]-\lambda\cdot\text{Risk}$, and its stated Bellman structure are kept as equations. Nothing here has been tested on data.

### 24.1 The company and its four layers *\[BP §Company\]*

**\[PLAN\]** Tomorrow Capital (TMRW) is a multi-layer financial-technology and investment firm built on the geometric–informational, multi-agent view of markets (Part II), aiming to maximise returns under tight risk control. *Business Strategy* allocates capital to ventures with outsized, long-horizon value and manages the downside of failed initiatives, using AI forecasting, risk assessment and control to choose high-dimensional, risk-adjusted actions (Section 24.2). *Portfolio and Internal Management* re-weights strategies, assets and products as regimes, competitors and internal KPIs change, on a KPI backbone of returns, volatility and drawdowns, tail risks, outcome probabilities and execution utilities (liquidation speed, costs), with closed-loop re-optimisation keeping capital near an efficient frontier (Section 24.3). *Trading Strategies* runs diversified, largely uncorrelated alphas across frequencies and markets (market making, commodities and energy, alternative assets) exploiting statistical inefficiencies and patterned behaviour (momentum, mean reversion, cross-asset relationships) (Section 24.4). *Execution* regulates turbulence by dynamic sizing, minimises footprint by stealth (TWAP/VWAP, slicing, dark venues) and can tactically shape short-term price (Section 24.5). A central *Intrinsic Value Engine* (stationary-action analogies, Bayesian/EM updates) estimates fair value, projects action corridors and flags mispricings for all strategies. Hybrid mechanics—continuous diffusion with discrete event jumps (Chapter 3)—are modelled for announcements, rebalances and regime breaks. Strategic options (new markets or products, infrastructure, M&A) pass data-driven filters for return, risk, competition and long-term fit before capital is deployed. Two customer-facing pillars: democratised access through the *TMRW Exchange* (zero-commission retail, deep liquidity) and a shared-success culture with transparent ethics (Chapter 28); the architecture must give security, redundancy, auditability and compliant governance (Chapter 25).

**Remark 24.1** **(The two company names — editorial).** The plan’s heading names a *Tomorrow Capital Company* and a *Tomorrow Group Company*. Its operating text uses Tomorrow Capital (TMRW) for the trading and investment firm; the branding section (Chapter 28) uses Tomorrow Group for the umbrella that also offers banking, insurance and pensions, whose venture units are listed in Section 27.2. The plan states no progression of names and does not mention Tomorrow Capital Research (the name under which Parts II–VI were written), Tomorrow Trading or Tomorrow Markets; the wordmark in Figure 28.1 reads “Tomorrow Capital”.

### 24.2 Business strategy layer *\[BP §Layer 1\]*

#### 24.2.1 Objective, primary risk, decision space

**\[PLAN\]** *Objective*: establish and grow profitable ventures whose expected returns significantly exceed their costs—new markets, new financial products, scaling of successful operations—so that capital compounds at superior rates; the layer sets the direction the three below follow. *Primary risk*: failed ventures with net losses (an unsuccessful entry into a competitive market, a technology project that never yields ROI, an acquisition that fails to integrate), quantified and forecast so that no move can jeopardise the capital base or strategic position (the plan’s analogy: cosmic-scale optimisation of the firm’s scope, scale and structure). A venture is a point in a state space with five dimensions: *competitor positioning* (number of established players, market share, capabilities); *market state* (growth, volatility, regulatory climate, demand trends); *internal readiness* (capital, infrastructure, talent, brand, risk capacity); *synergies and interdependencies* (complementarities, cannibalisation); *time horizon and optionality* (short-lived or long-term window; start small and scale, or one-shot). The problem, $$\tag{24.1}
\begin{gathered}
\max_{\text{venture}}\ \mathbb{E}[\text{profit contribution}]-\text{penalty}(\text{added volatility},\ \text{implementation cost})\\
\text{s.t. regulatory compliance and technological feasibility,}
\end{gathered}$$ is multi-objective (maximise expected return and strategic value, minimise risk and resource drawdown) and solved by stochastic optimisation, game-theoretic analysis or heuristic search in scenario space.

#### 24.2.2 Competitive intelligence as signal detection

**\[PLAN\]** Competitors are elements of a complex adaptive system, not adversaries. The layer scans for *signals*—competitor actions (a rival entering a new asset class or region), market-state changes (liquidity shifts, emerging demand), macro and geopolitical trends—infers what they imply and reallocates resources: observe $\to$ orient $\to$ decide $\to$ act. Example: a competitor’s 24/7 crypto exchange is read as demand for round-the-clock trading; if the inferred opportunity is high the firm accelerates its own 24/7 exchange, if the move is judged unprofitable it conserves resources. The intended edge is “signal advantage”. Rules and cadence of gathering: Section 27.3.

#### 24.2.3 The three-module decision system

**\[PLAN\]** A sense–think–act construct (Table 24.1). **\[SETUP\]** The control module’s logic in the plan’s words—a state’s value is the immediate reward plus the expected continuation value, the state being the firm’s business portfolio and competitive position, the utility a risk-adjusted return—reads $$\begin{aligned}
V(s)&=\max_{a}\Big\{r(s,a)+\mathbb{E}\big[V(s')\,\big|\,s,a\big]\Big\},\qquad s=(\text{business portfolio},\ \text{competitive position}),\tag{24.2}\\
U(a)&=\mathbb{E}[\text{Return}(a)]-\lambda\cdot\text{Risk}(a),\qquad \lambda=\text{risk-aversion coefficient},\tag{24.3}
\end{aligned}$$ or a utility penalising downside volatility and catastrophic loss disproportionately (editorial: only (24.3) is written as a formula in the plan).

**Table 24.1.** The business-layer AI: modules, inputs, outputs, with the plan’s illustrative numbers. All rows **\[PLAN\]**. *\[BP §Layer 1\]*

| Module | Inputs and methods | Output |
|---|---|---|
| 1\. Forecasting | Historical analogues (past economic cycles, industry expansions, M&A, large strategic moves; e.g. how entering the Asian market affected fintechs in the last decade, revenue trajectories of firms that adopted a new technology); game-theoretic what-if simulations in which the firm and competitors allocate resources (RTS-inspired surrogate contests); macro and market models (growth, adoption curves, technology trends; for a data centre: computational demand, cloud costs, client growth) | A distribution of returns per venture with expected yearly profit, time to breakeven, market-share growth; e.g. a new crypto exchange: 70% chance of a \$50M profit in 3 years, a small chance of failure with losses |
| 2\. Risk assessment | Failure-probability models (Bayesian networks, survival analysis; prior: 40% of fund launches during bear markets fail); volatility and downside (VaR, CVaR on strategic forecasts); surrogate adversarial scenarios (two new competitors enter; a regulatory change mid-project) over thousands of simulated worlds | A risk profile: chance of failure, loss magnitude, key factors; e.g. “volatility of annual returns $\sim$<!-- -->30%, 95% VaR $=-\$10$M over 2 years”; “20% probability of a $>50\%$ cost overrun; main factors regulatory delay and technology shortfall” |
| 3\. Decision and control | Bellman-style expected-utility optimisation over actions (expand into X, hold, consolidate Y), (24.2)–(24.3); policy search over combinations and sequences (phased: ETFs first, then a crypto platform funded from the gains) by branch-and-bound or RL agents | An action recommendation; outcomes fed back each cycle—forecast and risk models updated, $\lambda$ revised if the firm proved too aggressive or too conservative |

#### 24.2.4 Strategic options and coupling to the layers below

**\[PLAN\]** The ventures enumerated are in Table 24.2; each is an option exercised only when the modules show a clear benefit. An unconventional option such as energy trading or carbon credits may emerge as optimal where profit signals are strong and competition weak; over-expansion in a saturated asset class is flagged as suboptimal. *Top-down*: for the 24/7 crypto exchange the portfolio layer frees and allocates capital, the strategy layer builds crypto algorithms and market making, the execution layer deploys round-the-clock infrastructure and liquidity management. *Bottom-up*: the portfolio layer reports asset classes with consistently high risk-adjusted returns and spare capacity (scale), execution and operations report “systems near capacity” or “maximal penetration in market X” (consolidate), and risk metrics near limits raise the business-level risk assessment, tilting decisions toward consolidation until the system stabilises. The whole is a multi-layer control system: the business layer sets the setpoint, lower layers are subordinate controllers, the setpoint is recalibrated on their outcomes.

**Table 24.2.** Strategic options enumerated by the business layer. All rows **\[PLAN\]**. *\[BP §Layer 1\]*

| Option class | Candidates named | Constraint noted |
|---|---|---|
| New asset classes and markets | Cryptocurrencies and digital assets; sports betting, eSports assets, collectibles | Expertise and edge in the domain |
| Innovative financial products | A 24/7 trading exchange; perpetual futures; exotic options | Technological and regulatory challenges |
| Geographic and market expansion | Asia-Pacific, Middle East; from institutional to retail and high-net-worth clients | Local knowledge, new regulation, local partners or acquisitions |
| Vertical integration and infrastructure | Larger data centres or proprietary cloud; in-house risk-management system; AI research lab | Low-latency and data advantages |
| Business-line diversification | Banking (digital banking, credit products); insurance or fintech; wealth management and advisory | Regulatory capital for banking; long-tail liabilities for insurance |
| Mergers and acquisitions | Competitors or start-ups with a superior algorithm or niche; a data-analytics company; a regional brokerage | Cultural integration, high upfront cost; vetted with most rigour |

### 24.3 Portfolio and internal business management layer *\[BP §Layer 2\]*

#### 24.3.1 Dimensions, goals, features, collective portfolio *\[BP §2.1–2.2\]*

**\[PLAN\]** The layer runs across the organisation and inside each unit, optimising over a *strategic spectrum* (strategies, asset classes, products), *market coverage* (customer segments, trading environments) and *performance metrics* (expected returns, risks, correlations, liquidity profiles), re-weighted continuously as regimes, competitors and internal performance change, for long-term profit with controlled risk. Goals: *value creation* (deploy the strategy or combination suited to the current state) and *risk control* (detect misaligned strategies early; hedge or rotate capital away from a strategy wrong for the conditions). Features optimised in unison: return (expected, realised, risk-adjusted such as Sharpe); risk (standard deviation, concentration ratios, VaR, likelihood of drawdowns, observed drawdowns); liquidity and execution (liquidation speed, momentum effects, position sizing, stealth); diversification (correlations among assets and strategies, sub-portfolio interactions). **\[SETUP\]** “Idea 2”: risk is potential energy, return momentum kinetic energy; strategies are particles, sub-portfolios atoms, the portfolio a molecule; a regime change is an external force after which the system settles into a new minimum; small perturbations are damped, so moves follow only signals that pass robust statistical filters. **\[PLAN\]** A master *collective portfolio* holds all strategies, each tagged by ideal market state (bull/bear, high/low volatility), asset class, venue, hours, trade size and liquidity conditions (Table 24.3); many uncorrelated strategies give a stable aggregate (the plan cites a competitor’s “swingset” idea of grouping low-correlation, complementary return streams). Rebalancing is a closed loop with three triggers: market-regime shifts (volatility, trend, interest-rate environment); competitor actions and market structure (crowded inefficiencies, microstructure or liquidity changes); internal KPIs (a sub-portfolio underperforming or breaching a threshold). Each sub-portfolio’s capital follows its expected risk-adjusted efficiency, re-optimised in real time or daily.

**Table 24.3.** Illustrative strategy tags in the collective portfolio. All rows **\[PLAN\]**. *\[BP §2.1\]*

| Strategy | Venue, hours, size | Sensitivity |
|---|---|---|
| Small-scale crypto | Binance, European trading hours; trade sizes below ,000 | — |
| Large-cap U.S. equity | NYSE/Nasdaq large caps; deployment sizes above \$100,000 | — |
| Arbitrage | Several assets and exchanges at once; indifferent to position size | Extremely sensitive to execution stealth and timing |

#### 24.3.2 The KPI framework *\[BP §2.3\]*

**\[PLAN\]** Every strategy and sub-portfolio is measured on Table 24.4; KPIs aggregate strategy $\to$ sub-portfolio $\to$ portfolio and define the state the allocator optimises. A high-return, high-volatility strategy gets a large allocation only if counterbalancing factors (negative correlation with others) stabilise the whole.

**Table 24.4.** The KPI backbone. All rows **\[PLAN\]**. *\[BP §2.3\]*

| Group | KPIs |
|---|---|
| Return | Annualised (long-term expected) return; realised return to date; risk-adjusted return (Sharpe, Sortino) |
| Risk | Volatility; downside volatility; concentration or diversification score; maximum drawdown observed; VaR |
| Probabilities | Probability of an adverse event or loss beyond a threshold; probability of achieving the expected return; *regime pathing scores* (likelihood that the market or strategy shifts regime) |
| Utilities | Expected liquidation speed; leverage usage; transaction costs; other execution factors |

#### 24.3.3 Worked example: Portfolio A (equities) *\[BP §Layer 2, Example\]*

**\[PLAN\]** Portfolio A is a top-level equities portfolio whose deep-RL agent allocates across regional and thematic sub-portfolios and down to strategies (Table 24.5), on five principles: (i) the policy is learned from performance feedback; (ii) return is traded against risk—a sub-portfolio’s share is capped for concentration even when it performs well, and a position that cannot be exited quickly or without impact is sized down; (iii) liquidation speed and momentum are weighed, the certainty of a positive return is preferred to an uncertain higher one, but some allocation to high-risk, high-reward strategies is kept; (iv) *stealth*: beyond approximately million a sub-portfolio’s trades can be noticed or move prices, so its growth is throttled, new capital diverted or orders chunked; (v) *turbulence adaptation*: in a crash or shock part of the book moves to cash or low-volatility securities, sizes shrink and limits tighten until stability returns. *Long-term vision*: new “variational” principles are added as metrics or signals prove important, to maximise the certainty of returns, minimise systemic and idiosyncratic risk, and adapt to markets and competition as routine.

**Table 24.5.** The hierarchy of Portfolio A. All rows **\[PLAN\]**. *\[BP §Layer 2, Example\]*

| Unit | Contents |
|---|---|
| Sub-portfolio AA, U.S. tech (MSFT, META, AMZN) | Strategy AAA *Intrinsic Value Swings* (fundamental mispricing and mean reversion; mechanics in Definition 24.2); AAB *Momentum Capture* (trend following in strong trends); AAC *Event-Driven Benefits* (earnings, product launches, macro news); AAD–AAN as needed; the sub-agent reallocates among them |
| Sub-portfolio AB, European/Nordic (MAERSK, DANSKE Bank, NOVO Nordisk) | Local momentum and mean reversion, regional arbitrage; tuned to local hours, economic factors, liquidity |
| Sub-portfolios AC–AN | Emerging markets, commodities-related equities, small caps, other themes; each AI-optimised with own strategies and risk controls |
| Portfolio A manager | Funds sub-portfolios up or down on performance and conditions; hierarchy strategies $\to$ sub-portfolios $\to$ portfolio |

### 24.4 Trading strategies layer *\[BP §Layer 3\]*

**\[PLAN\]** The alphas, each as uncorrelated with the others as possible (independent degrees of freedom). *Goal*: maximum risk-adjusted return (a high Sharpe per strategy). *Risk*: trading losses, contained by position sizing and stop-loss protocols. Families and frequencies: Table 24.6. Design separates *market inevitabilities* (slow, near-certain tendencies, Table 24.7) from *market inefficiencies* (short-lived deviations, Table 24.8) and profits from both.

**Table 24.6.** Strategy families and frequency scales. All rows **\[PLAN\]**. *\[BP §Layer 3\]*

| Family | Scope and mechanism |
|---|---|
| Algorithmic, by frequency | Systematic across cryptocurrencies, equities, options, forex, bonds, commodities. *Ultra-high*: minutes or seconds up to a few hours, micro-inefficiencies, co-located servers. *High*: intraday, closed within the day, flat overnight. *Medium*: days to months, swing and trend following. *Low*: months to years, factor investing and tactical allocation (a drift strategy). Fast oscillations vs long-wavelength trends; decomposing by frequency leaves no timescale uncovered |
| Market making | Continuous two-sided quotes earning the spread at high velocity and volume; manages inventory risk and adverse selection; needs ultra-fast reaction and reliable pricing; a spring or shock absorber restoring price to fair value (rules: Chapter 15) |
| Commodities and energy | *Energy*: oil, natural gas, coal, electricity, renewables (solar, wind, hydro), uranium; drivers physical supply–demand, geopolitics, weather; spread trading (Brent vs WTI), trend following in supply shocks, seasonal mean reversion (natural gas). *Metals and resources*: industrial (copper, aluminium), precious (gold, silver), raw materials; mining output and inventories plus quantitative signals; mean reversion when price overshoots production cost; futures-curve vs spot arbitrage. No-arbitrage plays energy conservation; temporary imbalances are taken before they close |
| Alternative assets | Sports betting, digital collectibles (Steam marketplace), NFTs and digital assets, art, collectibles; inefficient pricing from low liquidity and few sophisticated participants (fan-sentiment odds, cross-marketplace gaps); unique data (scraped marketplaces, esports statistics); returns largely uncorrelated with financial markets |

**Table 24.7.** Market inevitabilities and the strategies built on them. All rows **\[PLAN\]** the 7–10% figure is **\[KNOWN RESULT\]** as cited by the plan without reference. *\[BP §Layer 3\]*

| Inevitability | Strategy response |
|---|---|
| Long-term growth drift | Broad equities rise over long horizons; managers assume 7–10% average annual return, $\sim$<!-- -->8% a standard planning figure; buy diversified indices in dips, aware of punctuating crashes |
| Cycles and crashes | Downturns are expected events: long-dated puts and tail-risk hedges that gain in a crash; systematic exposure reduction when stress indicators rise; forecasting from market dynamics, credit cycles, political risk |
| Mean reversion of extremes | Overbought/oversold by z-scores, deviation from long-term trend, valuation multiples vs history; contrarian trades on reversal (larger displacement, stronger restoring force) |
| Recurring mispricings | Fear, greed and institutional constraints guarantee gaps between price and value: buy panics, short bubbles; continuous scanning for new anomalies |
| Change and regime shifts | Bull to bear, low to high volatility, rate cycles: balance regime-dependent strategies; fund new strategies because edges decay |

**Table 24.8.** Market inefficiencies hunted, with the plan’s examples and horizons. All rows **\[PLAN\]** post-earnings drift is **\[KNOWN RESULT\]** as cited by the plan. *\[BP §Layer 3\]*

| Inefficiency | Mechanism, example, horizon |
|---|---|
| Inter-exchange arbitrage | Same asset, different venues (crypto): Bitcoin at \$30,100 on one exchange, \$30,000 on another; buy cheap, sell dear; windows of seconds or less, so ultra-high-frequency infrastructure; the firm enforces the law of one price (a mean-field principle) |
| ETF vs underlying | ETF price vs NAV (discounts in stress, slow authorised participants): buy the cheap side, short the dear side (ETF against a constituent basket), wait for convergence |
| Triangular arbitrage | Inconsistent implied rates in cycles: EUR/USD, USD/JPY, EUR/JPY; Bitcoin $\to$ Ether $\to$ altcoin $\to$ Bitcoin; the plan’s “ETF/BTC and BTC/TRX” loop; all legs at once; success in milliseconds (Maxwell’s demon) |
| Event-driven | Earnings, mergers, regulatory and macro news over- or under-reacted: post-earnings-announcement drift continues for weeks or months, so a positive surprise is held several weeks; overreactions faded; fundamental reading plus quantitative timing |
| Statistical arbitrage and patterns | Option price vs Black–Scholes; price vs a machine-learned prediction; pairs such as MasterCard/Visa (short the outperformer, buy the laggard); momentum on 6–12 month trends, mean reversion on 1-week or 1-day over-sharp moves; seasonal effects, cross-asset lead–lag; an evolving “quantitative encyclopedia” recalibrated as patterns weaken (Chapter 18) |

#### 24.4.1 The intrinsic value and forecasting engine (central alpha engine)

**Definition 24.2** **(Intrinsic value engine).** **\[SETUP\]** A central estimator of each asset’s “true” value and likely path, feeding price expectations to all strategies. (1) *Stationary action*: prices evolve along paths of least resistance (quasi-equilibrium punctuated by shocks), modelled as a harmonic oscillator around an equilibrium price with restoring forces and natural extreme values; the engine identifies the equilibrium (fundamental value from cash flows and yields, combined with sentiment) and the strength of reversion. (2) *EM and Bayesian updating*: an E-step forms the expectation of where price should be given current information and the stationary-action prior, an M-step re-fits parameters to maximise the likelihood of observed prices, iterated to intrinsic value and volatility—a Kalman or particle filter with true value as hidden state and market price as noisy observation. (3) *Action corridor*: with $[\ell_t,u_t]$ the most probable range projected, $$\tag{24.4}
a_t=\begin{cases}\text{buy}&p_t<\ell_t\\ \text{sell or short}&p_t>u_t\\ \text{no signal}&\ell_t\le p_t\le u_t\end{cases},\qquad
\text{close when } p_t \text{ returns to the projected path or overshoots it,}$$ an error-correction mechanism yielding buy-low/sell-high trades while the estimates are sound. The engine learns continuously (re-centring the equilibrium or re-shaping the potential when fundamentals or the rate regime change), may ingest alternative data (social-media sentiment, satellite activity), and a strategy may go with the baseline (mean reversion) or against it (momentum on continued divergence). (Editorial: (24.4) transcribes the plan’s rule; its formal version is the central pricing problem, Chapter 7.)

#### 24.4.2 Turbulence management and stealth execution

**\[PLAN\]** *Dynamic sizing*: in volatile, uncertain or illiquid markets strategies scale down (more cash, wider stops, less leverage) because model accuracy degrades and errors cost more; in calm, liquid, trending markets they size up (“adaptive friction”). *Stealth*: large orders move the market and reveal intent, so strategies slice, use TWAP/VWAP, dark pools and off-exchange venues and never telegraph full size; a large buy in a mid-cap stock is trickled over hours or days, possibly by providing liquidity on the bid; the firm behaves like a small trader even while accumulating, minimising the feedback other agents receive (the mean-field reasoning of Chapter 8: several agents executing large orders raise each other’s costs, so the firm stays part of the noise). Implementation: Section 24.5.

### 24.5 Execution and market impact layer *\[BP §Layer 4\]*

**\[PLAN\]** *Goal*: execute efficiently and subtly while shaping short-term price movement to advantage—best fills, hidden intent, tactical influence on short-term trends when beneficial. *Loss*: adverse market impact (signalling intent, pushing price while trading), which erodes the upper layers’ alpha through slippage and drift. The layer adapts to liquidity, volatility and microstructure and feeds slippage, fill rates and order-book shifts back up. **\[KNOWN RESULT\]** (cited by the plan without reference) As impact used offensively the plan cites Jane Street’s trading in Indian index derivatives, allegedly accumulating stocks to push an index up, shorting the index and unloading the stocks to drive it down. **\[PLAN\]** Any such use stays within ethical and legal boundaries; blatant manipulation is forbidden (Section 27.3). The seven tactics (Table 24.9) combine, e.g. an *adaptive VWAP* (1 and 7) whose aggression follows the signal (2) and taps dark pools when available (5). **\[SETUP\]** Tactic 6 minimises the plan’s implementation shortfall, per share for a buy: $$\tag{24.5}
\mathrm{IS}=\bar p_{\text{exec}}-p_{\text{decision}}=\text{market impact}+\text{timing cost}.$$

**Table 24.9.** The execution toolbox: seven tactics with the plan’s parameters. All rows **\[PLAN\]**. *\[BP §Layer 4\]*

| Tactic | Mechanism and parameters |
|---|---|
| 1\. Order slicing and scheduling | Parent order released as child orders. *TWAP*: equal parts at fixed intervals (e.g. 10% of the order every 30 minutes), predictable. *VWAP*: parts proportional to market volume, organic-looking. *Stochastic execution*: randomise each child’s time within a window and size around the target rate, keeping the schedule in expectation, to defeat pattern detection |
| 2\. Signal-driven execution | Pace follows alpha strength: strong signal $\to$ larger slices, faster schedule; weakening or flipping $\to$ slow, hold or pause |
| 3\. Multi-account fragmentation | Disperse over independent accounts or brokers: ten accounts buying 10,000 shares each instead of one buying 100,000, so the pieces cannot be aggregated |
| 4\. Game-theoretic and deceptive tactics | *Iceberg orders* showing 5–10% of true size; *decoy orders* on the opposite side (show sells to nudge price down before buying); legal and subtle; minor costs accepted for the larger goal |
| 5\. Liquidity seeking | Route to dark pools and alternative venues, ping for contra-side interest, fill large size off-book; small probes in the lit market otherwise |
| 6\. Implementation shortfall (arrival price) | Minimise (24.5): accelerate (sweep liquidity, pay the spread) when the market moves against the order, work passively on limits when it moves in favour or is steady; short-term price models recompute the trajectory; benchmark arrival price or VWAP |
| 7\. Adaptive, intelligent slicing | Feedback control: raise participation in deep, calm liquidity; pull back or pause when volatility spikes or the book thins; switch passive (post limits, earn spread) and aggressive (lift offers, hit bids) by urgency; re-optimise the remainder continuously |

**Remark 24.3** **(Two four-layer schemes — editorial).** The working notes’ “four layers” (Chapter 20) are by horizon—HFT, short, medium, long term—inside one book, and the notes call them a design, not a built system. The plan’s four layers are by function (venture, allocation, alpha, fill); the two are orthogonal: each horizon layer of the notes is a strategy family inside Section 24.4, allocated by Section 24.3 and executed by Section 24.5. Chapter 29 reconciles both with the conjectures.

## Chapter 25: Infrastructure and model layout *\[BP, DG\]*

> **What this chapter establishes**
>
> The plan’s architecture proposal assigns each layer a horizon, engines, technologies and hardware: cloud compute, solvers and strategic RL for the business layer; clusters with forecasting, risk and statistical double-testing engines and deep RL for portfolios; C++/Rust strategy agents with ONNX inference, a feature store and pre-trade checks; FPGA and kernel-bypass execution with tick-to-trade targets below 10 $\mu$s on FPGA and below 100 $\mu$s in software. A data lake and Kafka bus, microservices on Kubernetes, ModelOps with shadow trading, kill-switches and least-privilege security cut across layers; three phases take the firm from human-supervised classical methods to a self-optimising multi-agent system. All of it is intention; nothing in the sources is deployed.

### 25.1 Architecture overview and cross-layer flows *\[BP §Infra\]*

**\[PLAN\]** Priorities: modularity, scalability, performance (microsecond latency where needed), security (encrypted, authenticated pipelines, access control), fault tolerance (redundancy, graceful failure), extensibility. The plan’s Figure 1 shows decisions and constraints flowing down the four layers (solid arrows) and data and feedback up (dashed); its Figure 2 is Figure 26.3. Horizons and interfaces: Table 25.1. A unified pipeline ingests market data, news and signals in real time into a central data lake or stream hub feeding the portfolio and trading layers with market state (prices, volatility indicators, news sentiment) and logging execution and performance; components (risk engine, forecasting service, strategy models) are microservices publishing and subscribing to streams, so strategies run in parallel and backtests scale out to clusters. Transmissions between layers are encrypted and authenticated; the central optimisation engine and execution gateway have tightly controlled access; mirrored trading servers and backup gateways give hot standby; monitoring triggers failover and circuit-breakers (halts on extreme anomalies); audit logs and governance rules trace every AI decision. The per-layer engines, rules and tools are in Table 25.2, Table 25.3, Table 25.4 and Table 25.5; the plan’s own Table 1 is Table 25.6; the cross-cutting decisions are in Table 25.7 and the deployment phases in Table 25.8.

**Table 25.1.** Horizons and interfaces of the four layers. All rows **\[PLAN\]**. *\[BP §Infra\]*

| Layer | Horizon | Sends down | Reports up |
|---|---|---|---|
| Business | Multi-quarter to multi-year | Capital allocation, risk limits, profit targets, risk appetite across lines | — |
| Portfolio | Days to months; intra-day reaction to major moves | Target allocations and trading instructions per strategy or asset class | Firm-wide profit and risk outcomes |
| Trading strategies | Intraday to seconds; sub-second for HFT | Orders | Performance and risk metrics per strategy |
| Execution | Microseconds to nanoseconds; thousands of order messages per second at peak | — | Fills, market-impact data |

### 25.2 Engines, rules and tools per layer *\[BP §Infra\]*

**\[PLAN\]** *Business strategy layer* (Table 25.2): the AI “executive brain” decides which markets or asset classes to enter, how to split capital among trading strategies, longer-term investments and other ventures (banking, insurance arms) and which firm-wide risk limits to enforce; its central optimisation engine solves $$\tag{25.1}
\max\ \mathbb{E}[\text{long-term profit growth}]\quad\text{s.t.}\quad\mathbb{P}(\text{major drawdown})\le p_{\max}.$$ *Portfolio layer* (Table 25.3): turns “X risk-adjusted return at Y risk limit for the equities venture” into allocations, position changes, hedges and diversification; the market-state and forecasting engines say what might happen, the risk engine what could go wrong and where the book stands, the optimisation engine what to do, the statistical engine whether to trust it. *Trading layer* (Table 25.4): dozens of concurrent strategies (statistical arbitrage of mispriced equities, trend-following futures held for days, intraday crypto mean reversion, market making, news-sentiment trading), each with its own logic and models. *Execution layer* (Table 25.5): decisions become fills on microsecond-to-nanosecond timescales with extreme reliability (no missed or duplicated orders).

**Table 25.2.** Business strategy layer: engine, methods, outputs, tools. All rows **\[PLAN\]** except the tagged claim. *\[BP §Infra: Business\]*

| Item | Content |
|---|---|
| Central optimisation engine | Inputs: performance data from all portfolios, macro indicators, projections, budget and HR capacity; multi-criteria (25.1); recommends reallocation between strategies, leverage changes, a new asset class for correlation |
| Methods | Scenario simulation and predictive analytics (recessions, bull markets, regulatory changes); machine-learned strategic forecasts (market growth, rates); solvers (Gurobi, Google OR-Tools) for budget splits under a risk limit; deep RL with each quarter’s decisions as actions and long-term firm value as reward, as *hierarchical RL*: the business agent sets goals and constraints for portfolio and trading agents |
| Example outputs, KPIs | “Allocate 20% more capital to Portfolio A (equities) and reduce exposure of Portfolio B (crypto) due to higher risk forecasts; increase reserves for venture X; limit overall 1-day 99% VaR to \$Y across the firm; launch exploration of an AI-insurance venture with \$Z budget”; firm KPIs: target return, Sharpe ratio, maximum drawdown |
| Tools | Python, R (pandas, NumPy, SciPy); Julia or MATLAB for quants; C++ for production optimisation; PyTorch or TensorFlow, foundation models (LLMs, time-series transformers) for scenarios and unstructured data; OR-Tools, Gurobi or CPLEX; dashboards in Tableau, PowerBI or custom web (firm P/L, exposures, scenario outcomes); cloud or on-premises servers, AWS/GCP/Azure clusters for batch simulation, virtual private clouds, encryption at rest and in transit, strict IAM |
| Performance | Latency not critical; throughput and scalability are: scenario runs distributed over CPUs/GPUs; new data sources and ventures added as inputs and variables. **\[KNOWN RESULT\]** (cited without reference): companies report 20–30% operational-efficiency gains from AI in high-level decisions |

**Table 25.3.** Portfolio management layer: engines with the plan’s limits and examples, outputs, monitoring, tools. All rows **\[PLAN\]**. *\[BP §Infra: Portfolio\]*

| Item | Content |
|---|---|
| Central portfolio optimisation | Mean-variance, risk parity, CVaR minimisation, or deep RL and evolutionary search; obeys constraints from above such as max 10% in any single asset or max \$100M drawdown |
| Macro-scale market state | Regime classification (bull, bear, high-volatility stress, low-volatility growth) from rates, indicators, volatility indices by hidden Markov or regime-switching models, clustering or supervised classifiers; outputs a state indicator for strategies and risk models |
| Forecasting | Multi-horizon returns, volatilities, correlations: ARIMA, GARCH, factor models; LSTM and Transformer networks on price and alternative data; ensembles with Monte Carlo; “one-step delta” engines propagated through Monte Carlo (geometric Brownian motion or richer) to portfolio-value distributions |
| Risk management | VaR, CVaR, drawdown, beta, factor exposures, real-time and under scenarios (market $-5\%$ overnight; volatility doubles). Sub-modules: *risk conditional logic* (trim when volatility exceeds a threshold, automatically if pre-authorised); *concentration risk* (no single position $>N\%$); *extreme-event module* (extreme value theory; reserves and hedges when tail risk rises); *what-if engine* (“reduce tech exposure by 20%: how much does 1-month VaR drop?”) |
| Statistical double-testing | Backtest validation, out-of-sample and cross-validation, p-values, bootstrapping, White’s Reality Check against data-mining bias, rolling validation, factor analysis (alpha vs factor exposure), performance attribution; only sound strategies and allocations go forward |
| Outputs, DRL | “Portfolio 1 (Equities): target 50% net exposure, reduce tech-sector exposure by 10%, hedge with S&P put options worth 2% of portfolio. Portfolio 2 (Rates): shift from long-term to short-term bonds.” Deep RL first as decision support, later automated control, with CVaR in the reward and time-awareness (month-ends, seasonality) |
| Monitoring | High throughput, seconds to minutes; in a crisis a new optimal portfolio in near-real time; dashboards refresh VaR and Greeks continuously; anomaly detection flags P/L outside predicted bands |
| Tools | Spark, Ray or Dask for parallel simulation and backtests (10,000 Monte Carlo scenarios; 20 years of tick data); TensorFlow/PyTorch; FinRL or TradeMaster (PPO, DDPG, SAC); StatsModels, Prophet, scikit-learn, `arch` (GARCH), `pmdarima`, NumPy/pandas; cvxpy/OSQP for quadratic programs, IBM CPLEX for large mean-variance problems; Numerix or an in-house QuantLib risk service behind microservice APIs; SQL for positions and trades, KDB+, InfluxDB or TimescaleDB for tick and P/L series; Kubernetes microservices on a Kafka or RabbitMQ bus; on-premises servers for intraday risk alerts, cloud HPC for overnight risk and monthly re-optimisation |

**Table 25.4.** Trading strategies layer: components, engineering rules, tools. All rows **\[PLAN\]**. *\[BP §Infra: Trading\]*

| Item | Content |
|---|---|
| Strategy logic engines | Agents observing prices, book state and indicators, emitting buy/hold/sell; deep RL (DQN, DDPG, PPO, actor-critic; ensembles; hierarchical RL splitting regime detection from sizing); rule-based (sell if price deviates $X\%$ above mean); supervised (trade if predicted probability $>0.7$); CNN or LSTM on tick data (buy if predicted return $>0$) |
| Local market state | Order-flow imbalance detector over the last milliseconds; turbulence index over short windows; LSTM-autoencoder anomaly detection; trend/range classifiers and mean-reversion tests gating each strategy |
| Alpha signal generation | Per-strategy forecasts (e.g. next 5-minute return), linear or deep, ensembles of fundamental and technical models; a shared *feature store* (indicators, correlations, sentiment) updated by a streaming engine |
| Strategy-level risk | Risk budget from the portfolio layer (max drawdown \$1M, max position $N$ lots); risk monitor tracks exposure and P/L, stops the strategy on a daily loss, blocks or resizes orders beyond position or notional limits |
| Scenario overrides | Conditional rules for known events: reduce or stop trading through a central-bank announcement; ignore ML signals for minutes after a large opening gap |
| Coordination, recognition | A strategy-selection AI (multi-armed bandits, hierarchical RL) shifts capital and leverage to strategies suited to the regime; future recognition of other participants’ algorithms (icebergs, TWAPs) from market data |
| Latency, engineering | Tens of milliseconds for most, single-digit for some, sub-millisecond for market making (entirely C++); HFT strategies may live in the execution layer or on FPGAs; tight C++ loops without garbage collection or allocation on critical paths; threads pinned to cores with real-time priorities; processes co-located with the execution gateway; one thread or core per latency-critical strategy, asynchronous groups otherwise |
| Fault tolerance, security | Process isolation with a watchdog that logs, restarts and tells the portfolio layer to reallocate meanwhile; kill-switches on lost connectivity or abnormal order rates; code and processes access-restricted, internal secure channels, every order through the gateway’s global checks |
| Tools | Python for research and lower-frequency live trading, C++ or Rust (Numba extensions) for speed; ONNX Runtime and TensorRT for inference (train in Python, deploy in C++); Kafka backbone, Flink or Kafka Streams for streaming features, custom lock-free in-memory buses for microsecond paths; Redis or in-process memory for latest features; Pyfolio and Jupyter for backtests; pre-trade checks in C++; InfluxDB/Grafana for per-strategy P/L and risk; nanomsg/ZeroMQ messaging; a non-blocking order router with fills by callback; online learning recalibrating a short-term model every hour in background threads |

**Table 25.5.** Execution layer: components, hardware, safeguards, tools, targets. All rows **\[PLAN\]** except the tagged quotes. *\[BP §Infra: Execution\]*

| Item | Content |
|---|---|
| Ultra-low-latency engine | Kernel bypass (DPDK, Solarflare OpenOnload); CPU pinning and real-time settings; straight-line C/C++ critical paths handling an event end-to-end in a few microseconds; FPGA modules for feed decoding, simple trading logic and risk checks. **\[KNOWN RESULT\]** (quotes cited by the plan): “in HFT, milliseconds are too slow, microseconds are competitive, and nanoseconds win”; “FPGAs deliver deterministic, nanosecond-level performance” |
| Smart order router | Venue by liquidity, fees and fill probability, possibly model-driven |
| Pre-learned execution distributions | An execution optimisation model knowing from historical order-book data the impact of $X$ shares over $Y$ minutes and the intraday volume profile, trained offline or by RL in a market simulator; passive (post and wait) or aggressive (take liquidity, sweep levels) by urgency |
| Microstructure-aware logic | Book depth and iceberg detection; slow when price moves favourably, accelerate when adverse; queue-position tracking with price step-ups when stuck; pause on halts or liquidity vacuums, resume after block prints; learned impact models that “go dark” for minutes when the firm has been 10% of volume and impact rises |
| Hardware | One FPGA card per exchange connection with vendor or open IP cores; ASICs only as a future option for logic that never changes; quantum annealing (an overnight D-Wave run for the next day’s large-trade schedule) and analog or photonic processors as experimental plug-ins; immediate reliance on FPGAs and low-latency CPU code |
| Co-location | Next to matching engines (Mahwah for NYSE, Carteret for NASDAQ, European co-location centres); fibre or microwave links for inter-city arbitrage |
| Risk safeguards | In the gateway: fat-finger and trading-halt checks; firm-wide limits (never net short more than \$100M in a stock); price collars (not 10% above last price without approval); on FPGA or in a few CPU instructions |
| Booking | Acknowledgements and fills update orders and positions for the strategies; logged asynchronously (milliseconds acceptable) |
| Tools | C++ and some assembly; stripped-down Linux with real-time patches or Onload, frequency scaling disabled, hugepages; VHDL/Verilog or high-level synthesis (Xilinx Vivado HLS, Intel OpenCL), 10G Ethernet MAC and TCP/IP offload cores, Orthogone-style low-latency Ethernet and PCIe IP; native binary protocols (ITCH/OUCH; FIX too slow) on redundant links with sequence-number monitoring; a market simulator before go-live; hardware timestamping, latency percentiles on a telemetry dashboard, co-location network taps for audit |
| Targets, reliability, security | Tick-to-trade a few microseconds: below 10 $\mu$s for simple strategies on FPGA, below 100 $\mu$s for complex ones in software; at least two servers per exchange with failover, redundant connections, a kill-switch cancelling all open orders and halting trading, regular failover tests; traffic only from known exchange IPs, firewalls, encryption where supported, restricted physical and network access, migration to post-quantum cryptography for order and client data |

### 25.3 The technology stack *\[BP §Infra: Table 1\]*

**Table 25.6.** Technologies and tools by layer (the plan’s Table 1, every entry kept). All rows **\[PLAN\]**. *\[BP §Infra: Table 1\]*

| Layer | AI / models employed | Key frameworks and languages | Infrastructure / hardware |
|---|---|---|---|
| Business strategy (enterprise) | Multi-objective optimisation (profit vs risk); scenario simulation models (economic, business); reinforcement learning for strategic allocation; predictive analytics for macro trends | Python, R for analysis and prototyping; PyTorch/TensorFlow for deep RL or predictive models; OR-Tools, Gurobi for solvers; Dash/Plotly or Tableau for dashboards | Cloud VMs or on-prem servers (not latency sensitive); secure data warehouse for enterprise data; standard CPUs, possibly GPU for big ML training |
| Portfolio management (portfolio level) | Deep RL for dynamic portfolio optimisation; time-series DL (LSTM, Transformer) for return and risk forecasting; Monte Carlo engines for risk (VaR, stress tests); statistical tests (White’s Reality Check etc.) for strategy validation | Python (pandas, NumPy); TensorFlow/PyTorch for training and inference; FinRL/TradeMaster for trading RL; C++ for performance-critical risk calculations or QuantLib; Apache Spark/Dask for parallel backtesting | Scalable cluster or cloud (e.g. Spark on Kubernetes); GPU support for training forecasting and RL models; high-memory machines for large simulations; on-prem servers for real-time risk |
| Trading strategies (strategy level) | Multiple DRL agents for different strategies; supervised models for signal generation (price-direction classifiers); pattern recognition (CNN on order flow); anomaly detection for regime shifts | C++ for core strategy execution (esp. HFT); Python for research and medium-frequency deployment; ONNX Runtime/TensorRT for fast inference; ZeroMQ or Kafka for messaging | Low-latency Linux servers, CPU-tuned; optional GPU per server if the added latency is acceptable; co-located near exchanges (ms latency tier); redundant strategy servers for failover |
| Execution (trade execution) | Pre-trained optimal execution policies (simple rules or small neural nets); real-time decision rules on order-book state; possibly heuristic AI for venue selection | C/C++ with hardware intrinsics; FPGA programming (VHDL/Verilog) for critical paths; custom networking stacks (DPDK etc.); no high-level frameworks, raw optimised code | Co-located ultra-low-latency servers (ns–$\mu$s); FPGA cards for feed handling and fast decisions; direct exchange connections (binary protocols); high-speed networks (microwave links between markets) |

### 25.4 Cross-cutting infrastructure and deployment phases *\[BP §Infra: Cross-layer, Evolution\]*

**\[PLAN\]** The cross-layer decisions are in Table 25.7, the three phases and what follows them in Table 25.8. The stated end goal is “growing wealth steadily and safely for decades”.

**Table 25.7.** Cross-cutting infrastructure decisions. All rows **\[PLAN\]**. *\[BP §Infra: Cross-layer\]*

| Aspect | Decision |
|---|---|
| Hybrid cloud | On-premises co-located data centres for trading and execution; cloud or central data centres (Kubernetes) for business and portfolio layers, historical analysis and training; a Kafka-type broker bridges both with buffering and security; if the cloud fails, on-premises trading continues in a degraded mode on the last instructions; if on-premises fails, the cloud stops sending orders |
| Data pipeline and lake | All history (market data, trades, portfolios) in S3, Azure Blob or HDFS with a metadata catalogue and a distributed query engine (Presto, Spark SQL) for research and backtesting; a real-time Kafka pipeline for live data; everything encrypted and access-controlled (client data, PII in wealth management) |
| Concurrency and scaling | Microservices with defined APIs or event interfaces, replicated and load-balanced per component; Docker and Kubernetes in the cloud; orchestration with manual CPU pinning in co-location |
| Monitoring, logging, alerting | One system for P/L and risk, system and latency metrics; Grafana dashboards; PagerDuty alerts (strategy drawdown above X to risk, execution latency spikes to engineers, cloud connectivity to IT); centralised logs (ELK or cloud logging) to reconstruct what the algorithms did and why |
| Security and permissions | Least privilege per service (a strategy process cannot reach HR data); OAuth or mutual TLS between services; AI governance: statistical and risk engines catch erratic AI behaviour and require human review (the plan cites the Bank of England on uncontrolled AI trading) |
| Development workflow | CI/CD with ModelOps: versioned models, paper trading in simulation, a sandbox of shadow trades, statistical validation and risk-team approval before go-live |
| Extensibility | A new asset-class portfolio is a new portfolio instance with its own strategies and feeds; a new AI technique a new or updated microservice |

**Table 25.8.** The three deployment phases and the loops beyond them. All rows **\[PLAN\]**. *\[BP §Infra: Evolution\]*

| Phase | Content |
|---|---|
| 1\. Initial deployment | Business: scenario analysis and a basic optimisation spreadsheet model run by analysts, AI advising. Portfolio: classical mean-variance on daily data, ML built in the background. Trading: a handful of strategies (manual rules plus one or two ML-based). Execution: TWAP, VWAP and similar in optimised software, no FPGA. Humans supervise every AI decision: a portfolio manager approves allocations, a risk officer watches trades |
| 2\. Expansion and automation | New strategy agents (asset classes, frequency bands) plugged into feeds; the DRL agent takes over rebalancing with human override; the business layer’s RL agent or simulations suggest quarterly shifts as decision support; FPGA acceleration for the highest-frequency parts (a market maker’s quote updates); cloud bursting for overnight simulations; a fully parallel redundant trading set-up in a second data centre |
| 3\. Mature state | A self-optimising organisation: the business AI shifts capital in real time on regime detection and proposes new strategies with explanations; the portfolio layer integrates new data (satellite imagery), learns online, runs a multi-agent system of specialist “fund-manager AIs” under a “chief investment AI”; a *strategy factory* researches and deploys strategies continuously (AutoML, AI-generated agents, genetic breeding of successful strategies, fast pruning by the statistical engine); execution adopts AI hardware (DPUs, smart NICs) and quantum services for end-of-day batch optimisation or option pricing (the plan cites State Street); compliance: logged AI rationale, archived sandbox results, formal verification of execution risk checks |
| Scaling up | Horizontal: feed handlers partitioned by asset class, more strategy servers, more risk nodes; the lake may become a real-time lakehouse; tick history compressed or summarised |
| Model improvement | Every model retrained on a schedule (the LSTM forecaster weekly, daily where patterns change fast), offline in the cloud; A/B shadow runs of the new model beside the old before switching |
| Human oversight | Executives and portfolio managers become editors and supervisors: set objectives (translated into reward functions and constraints), investigate flagged situations, veto strategies exploiting loopholes a regulator could read as manipulation; quants use AI analytics to find patterns |
| Competitive edge | Adopt any new technology quickly; extend the same engines to wealth management, banking and insurance (insurance underwriting AI, credit portfolio AI) |

## Chapter 26: The diagrams *\[DG\]*

The five drawings of the firm are reproduced with a reading of each (editorial) tied to the layer it belongs to. They are the only place where the plan names concrete venues, coins, data sources, features and decision rules.

![The company algorithm [DG]. Left: the Expansion Algorithm (Expand → Data → Features → Analyse → Decisions → Execution; “establish an initial draft for these steps”) and the Establishment algorithm (overview strategic decisions, strategy states, strategy AI; time strategic leaps, acquire important resources, sandbagging, kill the leader, acquire information, achieve strategic advantages), with the “Excel” stage of the venture cycle. Top: the venture sequence from cryptocurrencies (with the reasons for starting there) through first attempt, multiple coins and exchanges to new assets, long-term investments, M&amp;A, banking, insurance/pensions. Centre, top to bottom: the crypto data infrastructure (indirect sentiment and competitor data; direct exchange data with price, derivatives and live availability per exchange), the feature catalogue (Table 26.1), four analysis engines with sub-engines all feeding the strategy engine (red), four decision templates, four execution components.](figures/diagram_company_algorithm.png)

*The company algorithm [DG]. Left: the Expansion Algorithm (Expand → Data → Features → Analyse → Decisions → Execution; “establish an initial draft for these steps”) and the Establishment algorithm (overview strategic decisions, strategy states, strategy AI; time strategic leaps, acquire important resources, sandbagging, kill the leader, acquire information, achieve strategic advantages), with the “Excel” stage of the venture cycle. Top: the venture sequence from cryptocurrencies (with the reasons for starting there) through first attempt, multiple coins and exchanges to new assets, long-term investments, M&amp;A, banking, insurance/pensions. Centre, top to bottom: the crypto data infrastructure (indirect sentiment and competitor data; direct exchange data with price, derivatives and live availability per exchange), the feature catalogue (Table 26.1), four analysis engines with sub-engines all feeding the strategy engine (red), four decision templates, four execution components.*

### 26.1 The company algorithm *\[DG\]*

Figure 26.1 is Chapter 24 drawn for the first venture. The left column is the business layer in two algorithms: the *Expansion Algorithm*, whose five steps (data, features, analyse, decisions, execution) are the trading and execution layers inside one venture, and the *Establishment algorithm*, whose boxes are the playbook of Section 24.2 and the state machine of Figure 26.5. The top row fixes the venture order and its rationale: cryptocurrencies first because (cloud note, quoted) “they generally have low transaction costs, they aren’t directly available for taxation laws, so we can use the compounding of returns without having to pay tax until we extract our profits”, and because most crypto exchanges offer granular historical and close-to-live or live order-book data; the first attempt is TRX/USDT on Kraken; then 29 named coins (BTC, ETH, XRP, BNB, SOL, DOGE, ADA, WBTC, XLM, SUI, LINK, HBAR, AVAX, TON, SHIB, LTC, DOT, UNI, PEPE, ONDO, AAVE, WLD, NEAR, ICP, FIL, ARB, OP, POL, VET, …); then Kraken, Coinbase, Gemini and on-chain; then new assets (equities, FX, derivatives, fixed income, commodities, energy products, ETFs), long-term investments, mergers/acquisitions, banking (loans, financing, regular banking), insurance/pensions—the option list of Table 24.2 in the same order. The data infrastructure splits *indirect* data—sentiment from Coindesk, Cointelegraph, Crypto.news, TradingView, MarketWatch, Reuters, Bloomberg, Twitter and Reddit; competitor data (trading of other traders) from Dextools, Dexscanner, Solscan and GeckoTerminal—from *direct* exchange data, whose availability table (price/derivatives/live) reads: Binance and on-chain yes/yes/yes; Jup.ag and Pump.fun yes/no/yes; Kraken and Gemini yes/no/no; KuCoin, Coinbase, OKX, ByBit, Crypto.com, Bitstamp, Revolut X no/no/no; Bitfinex, Deribit, Huobi not assessed. The features (Table 26.1) enter four *analysis engines*: the prediction engine (price intervals at $t{+}\dots$, likelihood of hitting $x$ within $t{+}\dots$, price paths to align with) with a market-states model, a momentum engine and a pathing engine (Markov engine, hidden Markov model, Markov-chain Monte Carlo; $t$-step delta vector; Monte Carlo engine) linked both ways to the what-if engine; the risk engine (risks and standard deviations at $t{+}\dots$, likelihoods of adverse effects, hedging) with the what-if engine, risk-conditional logic, concentration risk, extreme event and a risk-mitigation model outputting a derivatives strategy; the dynamics engine (hard-logic predictions, market dynamics and consequence analysis) with variational principles and a reactions engine; the statistics engine (double check for significance: statistical tests, hypothesis testing, strict conditional analysis, regression battery, time-series analysis, factor analysis, extreme value theory) with a likelihood engine and regression battery. All four feed the *strategy engine* (consider results and choose the future plan, emphasise strategy, allocate funds and inventory, choose hedging)—Section 24.3 in miniature. Decisions are four rule templates, the first strategies of Section 24.4: mean reversion (buy below the moving average, sell above), trend following (long on a positive trend, short on a negative), event-driven (buy on a positive event then sell; short on a negative then cover), “std-rev” (buy below $2.5\sigma$, sell above $2.5\sigma$). Execution lists order-book dynamics, execution timings, execution order distributions, transaction fees—Section 24.5 and Chapter 8.

**Table 26.1.** The feature catalogue of the company algorithm, names as drawn. *\[DG\]*

| Group | Features |
|---|---|
| Simple | returns, log returns, intraday range, high-low to close, open-close, close-open, high-low deviation, volume delta, amplitude, price levels, rolling returns |
| Technical: Average | time-weighted MA, volume-weighted MA, exponential MA, average true range, average return, average acceleration, average volume |
| Technical: Momentum | RSI, MACD, ROC, ADX, trend slope |
| Technical: Risk | standard deviation; historical, realized, implied, Parkinson and Garman–Klass volatility; Bollinger bands; VIX-like implied vol; volatility ratio/skew; kurtosis |
| Other | stochastic oscillator, Williams %R, CCI, parabolic SAR, Aroon indicator, Ichimoku cloud components, on-balance volume, Chaikin money flow, accumulation/distribution line, detrended price oscillator, money flow index, volume/price divergence, fractal dimension |
| Sentiment | news sentiment polarity, news volume/count, social media sentiment, social media volume, crypto fear/greed index, keyword indicators, sentiment embeddings/emotion, event flags |
| Statistical | kurtosis, skewness, Hurst exponent, autocorrelation, normalization (minmax, standard scaler), kernel distribution, expectation maximisation, ARIMA, GARCH, time-series momentum, hypothesis tests, hidden Markov model, filterings, outliers |
| Physics | COG, kinetic energy, potential energy, velocity, acceleration, quantum oscillations, MFG (the quantities of Part V) |
| Arbitrary | PN_counter, UUD_indicator |

### 26.2 The data structure *\[DG\]*

![The data-source map [DG]: news outlets and policy-rate sources (left, centre), market-data venues and APIs (right) and ESG providers (far right) converge on three markets—Crypto, Forex, Equity—routed by colour (purple, blue, green); the news node splits into macro, earnings and sentiment, the market-data node into asset and derivatives.](figures/diagram_data_sources.jpg)

*The data-source map [DG]: news outlets and policy-rate sources (left, centre), market-data venues and APIs (right) and ESG providers (far right) converge on three markets—Crypto, Forex, Equity—routed by colour (purple, blue, green); the news node splits into macro, earnings and sentiment, the market-data node into asset and derivatives.*

Figure 26.2 is the “unified data pipeline” of Chapter 25 as a source map and the *Data* step of the company algorithm widened from crypto to forex and equities. *News*: ten general outlets (Reuters, Guardian, Investing.com, Børsen, Financial Times, Wall Street Journal, Yahoo Finance, Bloomberg, MarketWatch, Barron’s), seven crypto outlets (Reddit, Coindesk, Cointelegraph, TradingView, Coingecko, Crypto.news, X), four policy-rate sources (Trading Economics world rates, Danmarks Nationalbank, Bank of England, ECB), split into macro (interest rates, inflation, currencies, employment, GDP, housing), earnings/dividends, general and asset-specific sentiment. *Market data*: KuCoin, Coinbase, OKX, ByBit, Binance, Jup.ag, Pump.fun, Alchemy, Quandl API, Twelve Data, Thomson Reuters, Nasdaq, Bloomberg, AlphaVantage API, Yahoo Finance (yfinance), Robinhood, the DEX scanners Dexscreener, Dextools, Solscan.io, GeckoTerminal, split into asset and derivatives. *ESG*: Refinitiv Datastream, Bloomberg, Morningstar, Preqin (the one vendor block, drawn in a different colour); LSEG, S&P Global, MSCI, Sustainalytics. Every outlet carries its URL (`reuters.com/business/finance`, `borsen.dk`, `nationalbanken.dk`, `bankofengland.co.uk`, `ecb.europa.eu`, …), fixing the intended ingestion as web and API collection rather than vendor feeds. The news branch feeds the macro and sentiment features of Table 26.1, the market-data branch price, derivatives and depth; Jup.ag and Pump.fun (highlighted) are the on-chain venues that the exchange table of Figure 26.1 marks as having live data. Nothing is weighted or prioritised: it is an inventory for the forecasting engines of the portfolio and trading layers.

### 26.3 The AI engines *\[DG\]*

![The AI engines [DG] (the plan’s Figure 2): data → clean-up → five data types → features → Risk AI, Statistics AI, Strategy AI and Forecast AI with their sub-models; Statistics AI feeds Strategy AI; Risk, Strategy and Forecast converge on OAI, which emits the execution strategy.](figures/diagram_ai_engines.jpg)

*The AI engines [DG] (the plan’s Figure 2): data → clean-up → five data types → features → Risk AI, Statistics AI, Strategy AI and Forecast AI with their sub-models; Statistics AI feeds Strategy AI; Risk, Strategy and Forecast converge on OAI, which emits the execution strategy.*

Figure 26.3 is the engine inventory of Table 25.3 and Table 25.4 in one picture. Data is cleaned into macro, price, options, news and market-depth data (etc.) and featurised. *Risk AI*: risk conditional logic model, concentration risk model, extreme event considerations, the what-if engine, option mitigation framework, extreme value theory—the risk engine with its four sub-modules plus an option-mitigation framework. *Statistics AI*: statistical tests, strict conditions analysis on deterministic parts, regression battery, time-series analysis, factor analysis, extreme value theory—the double-testing engine. *Strategy AI*: strategic conditional logic model, the “every action” optimisation example, reinforcement-learning models 1 *Speedy*, 2 *Risky*, 3 *Trendy*, binomial/multinomial projection—the strategy-logic engines, three RL agents named by temperament being the plan’s “multiple DRL agents for different strategies”. *Forecast AI*: market states model, Markov-chain Monte Carlo, one-step delta vector engine, various neural networks, hidden Markov model, Monte Carlo engine, regression battery—the forecasting engine. Against the analysis block of Figure 26.1, the dynamics engine is absorbed and the strategy engine has become the OAI node (not expanded in the drawing), which takes the three outputs and issues the execution strategy—the role the plan gives the portfolio optimisation engine and that Conjecture 5 (Chapter 10) asks to make principled. The wiring—statistics before strategy, risk and forecast in parallel—is the plan’s “the statistical engine validates, the risk engine constrains, the forecast engine informs”.

### 26.4 The corporate structure *\[DG\]*

![The organisation chart [DG]: board, CEO with an Internal Review function (Model Validation, Internal Audit, Infrastructure review), five chiefs with their departments, an overarching research department, and three pods served by hardware teams; coloured lines are review relationships.](figures/diagram_org_chart.jpg)

*The organisation chart [DG]: board, CEO with an Internal Review function (Model Validation, Internal Audit, Infrastructure review), five chiefs with their departments, an overarching research department, and three pods served by hardware teams; coloured lines are review relationships.*

Figure 26.4 draws the lean hierarchy of Section 27.2. Board of directors $\to$ Chief Executive Officer; beside the CEO an *Internal Review* function holding Model Validation, Internal Audit and Infrastructure review. Five chiefs: Investment (centralised investment team), Risk (centralised risk team), Research (strategies research), Technology (IT: software and hardware management), Operations (internal services, human resources, finance and accounting). An overarching research department with execution research spans investment, risk and strategy. Three pods, each with an operations team, a PM/analyst team, a risk pod, a strategy team and a software team; hardware teams serve all pods. Review lines: risk $\to$ Internal Review (orange), strategies research $\to$ Model Validation (green), HR and finance $\to$ Internal Audit (yellow), hardware management $\to$ Infrastructure review (grey). The Steering Group of the plan is the CEO with five chiefs; its independent committees (Risk, Audit/Internal Review, People & Ethics) appear as one Internal Review box with three review functions, each wired to the department it reviews; the enabler departments are the CTO and COO branches; the semi-autonomous units are three generic pods, each a miniature of the four layers—PM/analyst (portfolio), strategy team (strategies), risk pod (limits), operations and software (execution and infrastructure). Two differences from the text: the chart has no People & Ethics committee, and the pods are not the business-line venture units (exchanges, market making, banking, …); the pod is the unit of replication, the venture unit the unit of accountability.

### 26.5 The venture cycle *\[DG\]*

![The venture cycle [DG]: under Maximum Conservation, Expand → Establish → States → Excel, then “repeat with new object”; Expand opens four opportunity questions; after establishment a venture is in one of four mutually reachable states (Defensive, Aggressive, Counter, Neutral) defined in the text panel.](figures/diagram_venture_cycle.jpg)

*The venture cycle [DG]: under Maximum Conservation, Expand → Establish → States → Excel, then “repeat with new object”; Expand opens four opportunity questions; after establishment a venture is in one of four mutually reachable states (Defensive, Aggressive, Counter, Neutral) defined in the text panel.*

Figure 26.5 is the business layer’s loop as a state machine and the “strategy states” box of the Establishment algorithm. Expand opens *Opportunities*: New strategies? (mean reversion, trend following, extreme reversions, event reaction, …), New markets? (European, American, Asian, emerging), New assets? (crypto, equity, real estate, fixed income), New ventures? (insurance, banking, market making). The panel (quoted) says that once a venture is established “the market, market participants or you may change”, moving it between *Defensive*—defending the establishment by reduction of funds to be lost, increased sensitivity, change of triggers, decreased trading or change of trading scope; *Aggressive*—expanding, attacking or overtaking goals by increased funds to be lost, decreased sensitivity, change of triggers, following opponent strategies; *Counter*—countering attacks or other participants’ defensive measures by change of strategy, asset or market; *Neutral*—no significant activity, or proceeding with the pre-planned establishment. “Funds to be lost” and “sensitivity” are the two dials of Section 24.3 (capital at risk, trigger thresholds); the four states are the discrete form of the expand-or-fortify rule of Definition 27.1, with Counter and Neutral for the cases the rule does not cover; *Maximum Conservation* heads the whole cycle, consistent with the business layer’s primary risk but not defined further.

### 26.6 Status

**\[PLAN\]** Table 26.2 sets the plan’s main items against what the sources of this compendium show to exist (editorial; nothing outside the sources is claimed).

**Table 26.2.** Status of the operating plan: intention against evidence in the sources. *\[BP, DG, NB\]*

| Item | Tag | What exists in the sources |
|---|---|---|
| Four-layer decision framework | **\[PLAN\]** | A design; the notes’ own four-layer architecture states “a design, not a built system” (Chapter 20) |
| Business-layer forecasting, risk and control modules | **\[PLAN\]** | The venture cycle and establishment algorithm as drawings (Figure 26.5 and Figure 26.1); no model |
| Portfolio layer, KPI backbone, Portfolio A | **\[PLAN\]** | Illustrative only; the reallocation problem is Conjecture 1 (Chapter 6), untested |
| Collective portfolio of strategies | **\[PLAN\]** | Blueprints for market making, statistical arbitrage, trend following and options (Chapter 15, Chapter 18, Chapter 19 and Chapter 17); practice in the Prosperity competitions (Chapter 16) |
| Intrinsic value engine | **\[SETUP\]** | Stated as the central pricing problem, Conjecture 2 (Chapter 7); the hindsight tests of Chapter 14 concern the aggregation layer, not this engine |
| Stealth execution, the seven tactics | **\[PLAN\]** | Conjecture 3 (Chapter 8) formalises the distribution problem; no execution system |
| Technology stack, FPGA, co-location | **\[PLAN\]** | Nothing deployed; the notes’ early sketch is Python with C++ for speed (Chapter 20) |
| Data pipeline | **\[PLAN\]** | The source map (Figure 26.2); the first attempt TRX/USDT on Kraken in Figure 26.1; the test-bench loaders of Section 14.13 |
| Phases 1–3 | **\[PLAN\]** | Before Phase 1 |
| The five diagrams | — | Exist as drawings (DG), reproduced here |

## Chapter 27: People and governance *\[BP\]*

> **What this chapter establishes**
>
> The plan’s people charter has five employment tracks with stated pay floors (Builder $\approx$£45,000 with equity; Expert $\ge$£100,000 cash on 12-month rolling contracts; Operations $\approx$£35,000 living wage; Early-career at or above market plus stipend; Leadership paid on team outcomes), a lean structure (Steering Group, three committees, venture units, enabler departments), listening rituals on a fixed cadence, four non-negotiable guardrails, an ethical competitive-intelligence playbook with one decision rule (ahead: expand; level or behind: fortify), and a continuous-improvement programme with a seven-stage idea pipeline and a £1 million grand challenge. All of it is intention (**\[PLAN\]**); no hire, committee or programme exists in the sources.

### 27.1 Mission, employment pathways, partnerships *\[BP §People\]*

**\[PLAN\]** Mission: “the best place to do meaningful work”, rewarding both long-term ownership and immediate impact. The five tracks are in Table 27.1. **\[PLAN\]** *Partnerships* only where values and incentives align: partners are investment firms, banks, fintechs, universities and technology providers with strong governance and a “better tomorrow” ethos; value exchange by revenue-, cost- or profit-sharing (e.g. a share of profits for a partner’s technology or distribution, or co-developed products); every alliance under written terms with defined on-ramps and exit ramps so that the firm can withdraw cleanly if a partner’s objectives diverge.

**Table 27.1.** The five employment tracks, every number as stated. All rows **\[PLAN\]**. *\[BP §People: Pathways\]*

| Track | For whom | Compensation, benefits, terms | Focus and principle |
|---|---|---|---|
| 1\. Builder (long-term, ownership) | Loyal, mission-driven contributors wanting stability, rich benefits, equity | $\approx$£45,000 base; enhanced health and dental, pension, transport stipend, extra leave, equity from day one; annual profit-sharing pools, periodic retention equity grants; open-ended employment with multi-year vesting, no punitive lock-ins | The “middle-leg work”: process improvement, reliability, research support, client care |
| 2\. Expert (high cash, project-centric) | Specialists with scarce, world-class skills preferring cash to equity | Cash-heavy, at or above £100,000; minimal standard benefits, opt-in extras; project bonuses on measurable outcomes or attributable profit; equity limited by default; 12-month rolling or fixed-term contracts; confidentiality, IP and reasonable non-compete clauses | Narrow, high-leverage objectives: a new algorithmic model, latency optimisation, a security audit |
| 3\. Operations (facilities and support) | Cleaners, cooks, technicians, receptionists, cashiers; reliable, resilient, service-oriented | Living-wage floor $\approx$£35,000 (adjusted for local cost of living), deliberately above industry standard; full healthcare and pension from the start; skill ladders and paid training; profit-sharing after the first year | “Respect and stability first”: consistent hours, safe environment, growth |
| 4\. Early-career (students, interns, apprentices) | Students and juniors | At or above market pay plus a stipend or scholarship; one-week work-experience rotations, summer internships, longer apprenticeships with mentoring; high performers fast-tracked to full-time with equity signing bonuses and a personal development budget | “Inspire and cultivate the next generation”; the 100-year vision starts with young talent |
| 5\. Leadership (managers, department heads) | Operators who are also coaches | Competitive base plus components tied to team outcomes: team performance targets, employee engagement scores, responsible risk management, personal development goals; full benefits | Service mindset; “accountability with support”; zero tolerance for toxic management; judged on what and how |

### 27.2 Organisational structure, listening, guardrails *\[BP §People\]*

**\[PLAN\]** A lean hierarchy with clear accountability (drawn in Figure 26.4): a *Steering Group* (small C-suite: CEO, CTO, COO, …) setting strategy, complemented by independent committees for Risk, Audit (Internal Review) and People & Ethics open to every employee, and a Board of Advisors and/or investors engaged as the firm scales; *venture units*—Exchanges, Market-Making, Algorithmic Trading, Investing, Credit, Banking, Insurance, Pensions, Real Estate, Traditional Finance—each semi-autonomous under a venture head reporting to the Steering Group; *enabler departments*—Engineering/IT, Operations, Research, HR (People Operations), Finance, Legal/Compliance—working horizontally with their own senior, mid, junior and intern structure; *career ladders* of Senior, Mid-level and Junior roles plus interns or apprentices in every team.

**\[PLAN\]** *Listening*: quarterly skip-level conversations (a manager’s manager with junior staff), monthly informal coffee chats, bi-annual growth and feedback check-ins, open Q&A forums (town halls, ask-me-anything sessions) with the Steering Group, anonymous pulse surveys; “You Said, We Did” updates publish what changed (new coffee machines, flex-days for personal events, office upgrades) and acknowledge ideas not yet implemented; an *Idea Engine* of micro-grants or seed funding lets any employee pilot a project, with successful ideas scaled and originators recognised. Goal: maximise retention, authentic word-of-mouth, and compounding small improvements. **\[PLAN\]** *Guardrails (non-negotiable)*: fairness and inclusion (merit-based hiring and promotion, no disparaging labels or discrimination); compliance and ethics (all laws in every jurisdiction; confidentiality and IP ownership clauses in every contract; non-competes reasonable and lawful; regular ethics, security and compliance training); employee well-being (safe conditions, reasonable hours, support for health, family and learning; rest is not penalised); transparency (clear pay bands, plain-language HR policies).

### 27.3 Competitive intelligence and market strategy *\[BP §People: CI\]*

**\[PLAN\]** Goal: always know the firm’s position relative to market and competitors, so that every insight supports a decision to *expand* into a new arena (“blue ocean”) or to *stabilise and improve* an existing one (“red ocean”). Principles: legality and ethics (no deceit, theft or espionage); integrity of information (verifiable facts over rumour); respect for privacy and rights (public-domain or consented information; never inducing anyone to break obligations); actionable insights only.

**Definition 27.1** **(Decision rule of competitive position).** **\[PLAN\]** If the firm is *clearly ahead* (edge significant and established): *expand*—channel resources to innovation and new markets or products competitors have not reached. If *neck-and-neck or behind*: *stabilise and fortify*—shore up core offerings, improve efficiency, close gaps, cut costs, reinforce customer relationships, optimise risk controls, before new forays.

**Table 27.2.** Competitive intelligence: approved methods, prohibited tactics, operating model, governance. All rows **\[PLAN\]**. *\[BP §People: CI\]*

| Element | Content |
|---|---|
| Approved methods | \(1\) Public market and alternative data: prices, volumes, order-book dynamics, on-chain data within providers’ terms; web traffic, app-store rankings, technology-adoption indicators. (2) Public disclosures and digital footprint: announcements, regulatory filings, earnings calls, investor presentations, press releases, patents, open-source repositories (commit history, issue trackers), job postings. (3) Customer and user feedback: win/loss interviews, client surveys, UX research, lawful questions to clients who switched, “mystery shopper” exercises without misrepresentation. (4) Industry events and networks: conferences, seminars, hackathons, panels. (5) Open collaboration: sponsored competitions and bounties with clear terms. (6) Ethical talent attraction: genuine interviews, never pressing candidates for proprietary information |
| Prohibited | No false pretences (no fake job openings or sham interviews); no harassment or poaching by malice; no disinformation; no trade-secret misuse (respect joiners’ continuing obligations); no unlawful surveillance or hacking; no market manipulation, insider trading or market abuse |
| Operating model | Monthly one-page intelligence brief per major competitor (products, pricing, hires and exits, market share, rumours labelled unverified); an early-warning dashboard (unusual volume or pricing changes, spikes in a competitor’s web traffic or app usage, hiring surges such as blockchain developers, public downtime); quarterly red-team/blue-team wargame sessions with playbooks (a competitor cutting fees, entering a market with an aggressive product); a quarterly blue-ocean scan with a short-list and rapid feasibility tests or prototypes; KPIs: (a) forecast success rate, (b) impact of intelligence-informed decisions (losses prevented, wins secured), (c) time and cost efficiency |
| Governance | A written CI policy reviewed annually by Legal and HR, with training and certification; every datum logged with source and usage context, scraping within platform limits, legal review when fair use is in doubt; no bribery or inducements, all gifts and hospitality pre-approved and logged, declared conflicts where friends or family work for competitors; safe, anonymous whistleblower channels, prompt investigation, no retaliation |

### 27.4 Continuous improvement and open innovation *\[BP §People: Innovation\]*

**\[PLAN\]** Purpose: constant evolution by tapping collective intelligence inside and outside the firm. Principles: always-on iteration (weekly or monthly improvements rather than annual reviews); openness with high standards (every idea heard, a high bar for evidence); data-driven decisions (simulations, pilots, A/B tests; results, not seniority, decide); shared success (credit, and where warranted profit or equity, for contributors). The programmes are in Table 27.3; ideas move through the seven-stage loop of Table 27.4, each stage with owners and criteria. **\[PLAN\]** *Governance and ethics*: IP rights fixed upfront (contributor licence agreements for open source; clear prize terms, often paying for ownership or licence); no sensitive data in open programmes (synthetic or historical, anonymised or permissioned); ethical participation (no cheating, no harassment; staff trained as ambassadors); legal compliance (gaming and gambling law for contests, export controls, legal review of rules, MOUs and data agreements); records of why ideas were green-lit or not, for audit of bias. *Success metrics*: idea-pipeline throughput (submitted vs evaluated vs piloted vs implemented); impact on performance (revenue, cost savings, risk reduction attributable to ideas); participation and engagement (employees contributing, hackathon and contest entries, open-source contributions); retention and attraction (retention of participants, hires citing the programmes); reputation and network growth (media mentions, partnership offers, speaking invitations).

**Table 27.3.** The innovation programmes, numbered as in the plan. All rows **\[PLAN\]**. *\[BP §People: Innovation\]*

| Programme | Content |
|---|---|
| 1\. Simulation platforms | High-fidelity simulators per business (stock, bond, cryptocurrency markets, …), internal engines and reputable external platforms as benchmarks; test strategies, algorithms and business ideas, train algorithms and new hires |
| 2\. Competitions | 2.1 External challenges (algorithmic trading contest, risk-forecasting challenge) with monetary prizes, for solutions and recruiting. 2.2 Internal efficiency sprints (reduce server processing time, cut cloud costs by X%), rewarded and rolled out company-wide. 2.3 Strategy-game tournaments (trading games, chess, Go, custom online market games with fictional money; semi-professional tournaments with prizes) to study decision-making, resource allocation, risk-taking, adaptability |
| 3\. External advisors | 3.1 Elite strategists and gamers (esports champions, chess grandmasters, Go champions, poker professionals; a StarCraft champion’s reasoning on expansion or allocation problems). 3.2 Industry and research collaboration (Google DeepMind, OpenAI, Jane Street, university labs; workshops, staff exchanges, two-way sharing of non-sensitive knowledge). 3.3 Academic pipeline (scholarships, Ph.D. funding, lab sponsorship, internships and competitions for undergraduates and exceptional high-school students) |
| 4\. Open knowledge sharing | Public lectures and seminars; interactive workshops (two-day “Next-Gen Options Pricing”, “AI in Credit Risk Management”); panels and roundtables with contrarian voices; open-source releases of utilities or stripped-down frameworks after review; *Grand Innovation Challenges*, e.g. a model optimising three conflicting objectives at once with a £1 million prize, solutions open-sourced or proprietary by case; educational sponsorships (a new encryption protocol, a micro-loan algorithm for emerging markets) with no strings beyond first right of refusal to commercialise jointly; strategic partnerships (fintech start-ups, non-profits, an economics-education YouTuber); open-house days with demos, games and coding puzzles |
| 5\. Venture Wing | An internal accelerator for employee and outside ideas: a small team, seed funding and mentorship; successes become divisions or spin off with the firm holding a stake |

**Table 27.4.** The idea-to-impact loop. All rows **\[PLAN\]**. *\[BP §People: Innovation\]*

| Stage | Rule |
|---|---|
| Intake | Ideas from suggestion box, competition entries, partner workshops, public submissions, logged in one repository open to strategy and R&D |
| Triaging | A rotating expert committee categorises (process improvement, new product idea, research hypothesis) and marks green (explore now), yellow (hold), red (decline with explanation) |
| Sandbox simulation | Green ideas tested cheaply: simulators, a proof of concept in one department, sample data |
| Live shadowing | Pilot at small scale or in parallel (a new algorithm with a small amount of capital beside the main ones; a policy in one team), monitored closely |
| Controlled rollout | Gradual, with fallbacks and explicit success metrics |
| Post-mortem | Retrospective for successes and failures, documented without blame |
| Reward and recognition | Bonuses, promotion, public recognition, further funding; the origin of the idea told internally and, where fitting, externally |

### 27.5 Status

**Table 27.5.** Status of the people chapter. *\[BP, DG\]*

| Item | Tag | What exists in the sources |
|---|---|---|
| Five tracks, pay floors, partnerships | **\[PLAN\]** | Stated only; no hires or contracts in the sources |
| Steering Group, committees, venture units, pods | **\[PLAN\]** | The organisation chart (Figure 26.4); pods differ from venture units (Chapter 26) |
| CI playbook and decision rule | **\[PLAN\]** | The venture-cycle states (Figure 26.5) are its discrete form |
| Innovation programmes, idea loop, grand challenge | **\[PLAN\]** | The Prosperity competitions were entered (Chapter 16); nothing else in the sources |

## Chapter 28: Brand *\[BP\]*

> **What this chapter establishes**
>
> The branding strategy is written for *Tomorrow Group*: a vision of “a brighter financial future” under the motto “For a better Tomorrow”, attributes of quiet confidence, a visual identity fixed to the hex (deep blue \#0B1F3B, charcoal \#111418, off-white \#F4F1EA, beige \#E9E2D3, gold \#C8A96A, silver \#B6BDC8) with a serif wordmark and a sans-serif body, a five-principle voice, four message pillars adapted to retail, institutional and regulatory audiences, and a touchpoint-by-touchpoint rollout. The logo and wordmark that exist are reproduced. Everything is intention (**\[PLAN\]**) except the quoted wording; the plan names Tomorrow Capital, Tomorrow Group, the TMRW Exchange, the Tomorrow Academy, Project Empowerment and the TMRW Compact, and states no sequence of renamings.

### 28.1 Vision, motto, attributes *\[BP §Brand\]*

**\[PLAN\]** Vision: help customers, clients and stakeholders build a brighter financial future; the brand is a forward-looking partner for all financial needs, modern in innovation, timeless and classic in presentation, in a tone of quiet confidence without hype. The plan’s own wording is the content here:

> Motto: **“For a better Tomorrow”**. Attributes: “trustworthy, modern, and luxurious”; “approachable and inclusive … yet also prestigious and high-quality”; voice “calm, clear, and sincere, avoiding jargon or gimmicks”; “authenticity” and “integrity” so that “trust—the cornerstone for any financial institution—is continuously reinforced”. *\[BP §Brand\]*

### 28.2 Visual identity *\[BP §Brand\]*

**\[PLAN\]** *Logo*: a simple, scalable, abstract mark evoking time and forward motion without clichés (no generic arrows, clocks, dollar signs or vaults); three candidates—a minimal horizon line with a rising arc (a sunrise of tomorrow), a “T” monogram shaped like an hourglass, a path of dots converging into a solid line (clarity from uncertainty); it must stay recognisable at any size down to a 16px favicon, work in one colour (monochrome, embossing, dark and light backgrounds), and leave room to build the brand story around a non-representational symbol. *Palette and type* are in Table 28.1; the existing mark and wordmark are Figure 28.1. *Accessibility*: contrast at or above WCAG AA (minimum 4.5:1 for text), aiming higher (“AA+”) on web and print, tested per combination (white on deep blue, charcoal on off-white pass easily); blue chosen also because around 1 in 10 people have some red-green colour blindness; sufficient font sizes, clear spacing, dark text on light backgrounds; at most two font families.

**Table 28.1.** Colour palette and typography, values as stated. All rows **\[PLAN\]** the 2025 serif trend and the 1-in-10 figure are **\[KNOWN RESULT\]** as cited by the plan. *\[BP §Brand\]*

| Element | Value | Role and rationale |
|---|---|---|
| Deep Blue (primary) | \#0B1F3B | Dominant colour, logo, backgrounds, headers and footers; trust, security, stability; serious institutional navy, not bright |
| Charcoal Gray (primary) | \#111418 | Text and secondary backgrounds; seriousness and permanence, warmer than pure black, high contrast, pairs with the metallic accent |
| Off-White, Warm Beige | \#F4F1EA, \#E9E2D3 | Background fills and paper colours balancing blue and charcoal; warmth, approachability (“luxurious but not aloof”); light ground for dark text |
| Metallic Gold or Silver accent | \#C8A96A, \#B6BDC8 | Sparingly: logo mark, icons, rule lines; prestige and quality; navy-and-gold as the classic luxury pairing; silver where a cooler, innovative tone is needed |
| Serif typeface | Garamond, Baskerville or a modernised serif | Wordmark and major headlines, pull quotes, the word “Tomorrow” in slogan lock-ups; tradition, authority, heritage; the plan cites a 2025 trend of financial brands reintroducing serifs; clean, not ornamental |
| Sans-serif typeface | Helvetica, Open Sans or a humanist sans | Body, interface and label text; legibility on screens and at small sizes; contemporary and approachable; no whimsical or “techy” fonts |
| Pairing | Two families maximum | Tested combinations: classic serif plus geometric sans vs modern slab serif plus humanist sans, for “timeless yet modern”; fixed in the brand guidelines for every document and screen |

<figure>
<p>![](figures/tmrw_logo.png) ![](figures/tomorrow_wordmark.png)</p>
<figcaption>The existing mark and wordmark <em>[DG]</em>. Left: a white rising arc on a blue field—the “horizon line with a rising arc” candidate of the plan. Right: the wordmark “Tomorrow Capital” in a sans-serif beside the arc on a blue-to-white gradient; it reads Tomorrow <em>Capital</em>, not Tomorrow Group, and uses a sans-serif where the plan proposes a serif (editorial).</figcaption>
</figure>

**Remark 28.1** **(The palette in this document — editorial).** The colour tokens of this compendium are the plan’s values: `tmrwblue` \#0B1F3B, `tmrwcharcoal` \#111418, `tmrwbeige` \#F4F1EA, `tmrwgold` \#C8A96A (the headings, boxes and status tags of every chapter).

### 28.3 Voice and core messages *\[BP §Brand\]*

**\[PLAN\]** The voice is calm, optimistic and transparent, reassuring and respectful toward a first-time retail investor and a regulator alike, on five principles. *Clarity and simplicity*: plain language, no buzzwords (not “leveraging proprietary HFT algorithms for liquidity optimization” but “using smart technology to make trading fairer and smoother for you”). *Positive and empowering*: benefits and possibilities, never fear or urgency; words such as enable, empower, secure, build, future, together, trust; the customer is the hero, the firm the guide. *Quiet confidence*: facts and actions, never boasts (not “we are the best bank out there” but “we’re committed to doing what’s right, and we’re not afraid to do things differently for your benefit”); understated luxury in tone. *Transparency and honesty*: openly explain how the firm makes money, its fees and where it is still improving; acknowledge and fix mistakes; the TMRW Exchange material states “Zero commissions for retail trades—no catch. (We sustain the platform through optional premium services for professionals; see page X for details.)”; Project Empowerment’s free knowledge library (“no sign-up required”) is a front-and-centre proof point presented humbly. *Personal and inclusive*: “you” and “your”, no legalistic public copy, diverse ages, ethnicities and literacy levels in imagery, the internal TMRW Compact of shared success visible outside, no canned scripts in customer service. The style guide carries dos and don’ts (do: “We’re here to help you build your tomorrow.”; don’t: “We guarantee to make you rich.”). The four pillars and their audience weighting are in Table 28.2 and Table 28.3.

**Table 28.2.** The four message pillars with the plan’s taglines, proof points and claims. All rows **\[PLAN\]**. *\[BP §Brand: Core messages\]*

| Pillar and tagline | Public message, proof points, framing to institutions and regulators |
|---|---|
| 1\. Democratising market access: “Anyone can invest and succeed.” | *Open Access to Finance*: institutional-grade platforms for everyone; the TMRW Exchange, the flagship, lets retail investors trade with zero commissions—“the same quality of trade execution and data access that a big Wall Street firm gets—now in your hands”; the model is sustained transparently by premium services for professionals and institutional partners, and a wide user base gives deep liquidity and better prices for all; “bringing Wall Street to Main Street”; commitments to publish execution-quality reports, no hidden fees, no payment-for-order-flow conflicts |
| 2\. Shared success culture: “We invest in people, not just profits.” | *A New Standard in Banking Ethics and Culture*: every employee met is also an owner; the living-wage policy and universal stock-ownership plan are advertised (“entry-level salaries start at £35k in London”; “our employee turnover is among the lowest in the industry”); community, charity and education work told quietly through stories (a financial-literacy workshop at a school, a mentored small business); to regulators and investors, aligned interests as governance and risk strength and as the S and G of ESG |
| 3\. Unified financial ecosystem: “All your financial needs under one roof, at a fair price.” | *One-Stop Convenience and Value*: banking, investments, insurance, pensions in one platform and app with one login and dashboard; radically low fees from economies of scale (“a bank account, investment account, and basic insurance for less than half of what you’d pay separately elsewhere”); a lifetime relationship earning a little from each service (“we only succeed if you do”); no tying, opt-in cross-selling; the ecosystem drawn as a circle or network; slogan extension “Bank, Invest, Insure—plan for all of it with Tomorrow, for a better tomorrow”; to institutions, diversified revenue and retention |
| 4\. Financial education and community trust: “Knowledge is power, and we’re giving it away.” | *Empowerment through Education*: under *Project Empowerment*, the free *Tomorrow Academy*—articles, videos, mini-courses, Q&A, webinars, budgeting guides, an interactive learning centre—open to customer or not; a “No Stupid Questions” series (“What is inflation?”, “How do pensions work?”); “reverse marketing” with the logo kept small (“brought to you by Tomorrow”); impact metrics in annual reports (“£X in fees saved by consumers”, “Y people improved their credit scores”) as good corporate citizenship toward regulators |

**Table 28.3.** Audience weighting of the pillars. All rows **\[PLAN\]**. *\[BP §Brand: Core messages\]*

| Audience | Emphasis and sample framing |
|---|---|
| Retail clients | Pillars 1 and 3 loudest (“do what only the big players could, with every finance made easy and affordable”); pillar 4 as a free benefit; pillar 2 as the reason to feel good about the relationship |
| Institutional clients and investors | Pillar 1’s volume and technology, pillar 3’s lifetime-value economics; pillar 2 as execution strength, pillar 4 as low reputational risk; formal, data-driven tone, e.g. “we’ve attracted 1 million users in our first year by doing what’s right” |
| Regulators and policymakers | Pillars 1, 4 and 2: wider access done transparently, financial literacy, higher conduct standards; backed by a best-execution policy, no predatory fees, internal controls against market abuse, conflict-of-interest safeguards; the motto as evidence of intent |

### 28.4 Touchpoints and rollout *\[BP §Brand: Experience\]*

**\[PLAN\]** Execution across channels is fixed in Table 28.4, all under one Brand Style Guide (logo usage, colour codes, typography, voice; the plan cites K Capital’s brand guide as the model of consistency).

**Table 28.4.** Brand execution by touchpoint. All rows **\[PLAN\]**. *\[BP §Brand: Experience\]*

| Touchpoint | Decisions |
|---|---|
| Website and app | Deep blue and off-white scheme, the mark in the corner, approved fonts; clean, uncluttered layout with neutral space and accessible controls; contextual education snippets (“Did you know…”); visible security signals; an About Us with short team videos; a simplified mark for the app icon; micro-copy in the voice (“Hang tight, we’re fetching your data…”) |
| Marketing collateral | Brochures, decks, one-pagers, social graphics from the style guide: blue cover with logo, serif headline, sans body, imagery of diverse people using technology or subtle hopeful abstracts (a sunrise), charts in charcoal, blue and gold; the slogan as tagline on covers and closings |
| Presentations and events | Templated decks with logo and fonts; a city skyline at dawn for institutional pitches, workshop or family photos (with permission) for community events; booths in deep blue with white logo and a gold strip and the slogan on the wall; polished and inviting |
| Advertising and social | A *“Meet Tomorrow”* campaign, one pillar per ad (“Wall Street access with Main Street heart. Meet Tomorrow.”; “Banking on a better future—for everyone. Meet Tomorrow.”), call to action “Learn how we’re different at tomorrow.com”; authentic imagery or a consistent illustration style; social posts alternating Academy tips, community highlights and announcements with recognisable colour borders |
| Onboarding | A welcome kit: branded welcome email thanking the client for joining the mission; debit cards in logo and colours; optionally a physical packet—deep-blue folder, a CEO-signed letter, a visual Getting Started Guide, a gold bookmark or logo pin |
| Environmental | Offices and flagship spaces in the palette with gold accents in fixtures or trim, the logo at reception; a “Kulturnat”-style open house in London named *Tomorrow Open Day* with demos, a mini investing class and the team; navy staff shirts, off-white tote bags with a gold “T” and the slogan; staff friendly, not salesy |
| Regulatory communications | Annual reports and filings in brand fonts and colours with a mission and community-impact section; quarterly execution-quality and ESG reports formatted readably with infographics |
| Mockups and launch | Sample web pages, app screens, business cards, letterheads and ads reviewed internally and with focus groups (logo scaling, print colour, mobile legibility); then internal training and an external launch announcement of the vision “for a better Tomorrow” |

### 28.5 Names and status

**Table 28.5.** Status of the brand chapter, with the inventory of names the plan uses (editorial). *\[BP, DG\]*

| Item | Tag | What exists in the sources |
|---|---|---|
| Vision, motto, attributes, voice | **\[PLAN\]** | Wording only |
| Logo concepts, palette, typography | **\[PLAN\]** | A mark and a wordmark exist (Figure 28.1); the palette is used by this document |
| Four pillars, audiences, touchpoints | **\[PLAN\]** | No product, campaign or report in the sources; the TMRW Exchange is a venture option of Section 24.2 |
| Names | — | The plan uses *Tomorrow Capital* (TMRW) for the firm, *Tomorrow Group* for the branded umbrella, the product and programme names *TMRW Exchange*, *Tomorrow Academy*, *Project Empowerment*, *TMRW Compact*, *Tomorrow Open Day*, the campaign *Meet Tomorrow* and the domain `tomorrow.com`; it states no progression from Tomorrow Capital Research to Tomorrow Capital and never names Tomorrow Trading or Tomorrow Markets; the existing wordmark reads Tomorrow Capital |

# Part VIII: Synthesis

## Chapter 29: How the documents fit together (editorial)

> **What this chapter establishes**
>
> The documents of Table 1 were written over nineteen months for different purposes — a modelling frame, a market model, four conjectures, a theory of aggregation, a desk’s working notes, a business plan — and use different words for the same objects. This chapter is the crosswalk: one architecture read four ways (Table 29.1); the conjectures placed next to the theorems that bound them and the engines that would run them; and the reconciliation of the places where two documents disagree (Section 29.3). Everything here is editorial: it adds no result, it only says which result is which.

### 29.1 One architecture read four ways

**Table 29.1.** Crosswalk of the programme’s vocabularies (editorial). Each row is one object; each column the name a family of documents gives it.

| Object | Field framework (GI, GI-H, GI-X) | Market model (MD, WP, FS, BP) | Conjectures (C1–C5) | Aggregation theory (AT-0, AT-II, AT-III); notes (NB) |
|---|---|---|---|---|
| The unit | agent $i$ on the manifold $(M,g)$, state $x_i$ (2.5) | agent / asset node of the two graphs (4.1) | trader, venue, child order (C3), asset (C2) | unit $i$ with weight $w_i$ and velocity $x_i$ (Definition 13.5); a quote, a fill, a coin (NB) |
| The whole | the field $\phi$ and the coupling $W(t)$ (2.4) | the market surface $V^{(\mathrm{market})}$ (4.4) | the central price $P_{T+1}$ (7.1) | the aggregate $X=\sum_i w_i x_i$; the index, the composite, the nation (Section 13.3) |
| What adds up | information flow on the graph (2.7) | order flow, positions, cash | flow $I$ in (7.1); the parent order $Q$ (C3) | additive quantities: order flow, momentum, money (Proposition 13.6); inventory (NB-01) |
| What splits | energy of the field: kinetic and potential terms of (3.4) | value layers fundamental $\to$ financial $\to$ information $\to$ market | impact cost $g(x)\approx c\sqrt{x}$ (C3); risk vs return (C5) | squared quantities: König’s split (Theorem 13.9); $\kappa$, $\varphi$, $\Psi$; variance and impact (NB-05/06) |
| The dynamics | diffusion, Ricci flow, jumps (2.1), (2.12) | 7-step loop, Bellman on $R-L$ (4.7) | switching $\theta_t$ (C1); hybrid MFG (C4) | Langevin template (13.12); mean-field limit (equation (12.11)); Fokker–Planck book (13.15) |
| Equilibrium | least action / HJB (Chapter 3) | market clearing (4.6) | existence of optimal strategies (C4) | MFG/MFC and exploitability (Chapter 12); hierarchically consistent equilibrium (Chapter 12); NESS (Section 12.11.2) |
| Events | resets $\Phi_{s\to s'}$ (GI-H) | shocks in the loop (WP) | news and path switches (C1) | mixture law and squeezing (Theorem 14.6 and Theorem 14.7); taking rules (NB-01) |
| What is measured | – (no numbers in GI) | – (no numbers in MD/WP) | the parameters of each conjecture (toys, Appendix E) | $\kappa,\varphi,\Psi,N_{\mathrm{eff}},\tau,\Upsilon$ domain by domain (Chapter 14); PnL, inventory, fills (NB) |

###### Reading the table.

The field framework supplies the state space and the equations of motion; the market model fixes which objects live in it and in what order value propagates; the conjectures are statements about prices that can be tested inside that frame; aggregation theory supplies the exact part — what any such model must satisfy whatever its details — and the measured parameters; the notes are the same objects seen from a desk, one book at a time. The hierarchy of Definition 13.5 is the spine: units in groups in groups of groups, with additive quantities carried across levels exactly and squared quantities split into a collective part and an internal part.

### 29.2 Conjectures, theorems and engines

- **C1 (path switching, Chapter 6)** is the temporal-aggregation question of AT-0 §M (Chapter 12): a strategy that rolls one-step dynamics into blocks and switches between two parameter paths; the exact statement behind it is the turnpike window $\tau_{\mathrm{relax}}\ll\Delta\tau\ll
  \tau_{\mathrm{drive}}$, and the toy (Appendix E) finds a breakeven switching lag of about half the regime duration. The firm’s engine is the strategy layer of Section 24.4.

- **C2 (central pricing, Chapter 7)** writes the next price as $\alpha I+(1-\alpha)H+\varepsilon$; its additive term $I$ is the order flow of Proposition 13.6 and (13.14), its history term $H$ is a collective average, and its error $\varepsilon$ is the internal motion of Theorem 13.9. The toy recovers a planted $\alpha$ with $N>3$ assets and $H\ge5$ (Appendix E); the real test needs level-1 data (Section 14.9).

- **C3 (stealth execution, Chapter 8)** is the square-root impact law of Section 13.5.5 turned into a schedule: a concave footprint $g(x)\approx c\sqrt{x}$ makes lumping cheap and detection dear, so the optimal number of children is interior; the toy finds $N^\ast\approx55$ of $N_{\max}=100$ for $Q=1{,}000{,}000$ USD. The engine is the execution layer of Section 24.5.

- **C4 (the full market model, Chapter 9)** is the existence question of AT-0 §H–N (Chapter 12) posed on the hybrid state space of Chapter 2; the toy’s damped best-response iteration converges to zero exploitability on a two-mode grid. What is not known is existence on the continuous hybrid space with jumps (Chapter 31).

- **C5 (the final problem, Chapter 10)** is the matching rule read as a portfolio: return is additive across products and strategies, risk is a square that splits, and the shared limits are the constraint; the toy’s expected-utility allocation beats the naive one under every limit. The engine is the portfolio layer of Section 24.3 and the cost-aware optimiser of Chapter 20.

### 29.3 Where the documents disagree, and how this edition reads them (editorial)

1.  **The mean.** AT-0 Hypothesis 9.1 (Hypothesis 11.6) and P1 as first stated expected aggregation to lower the mean and perhaps halve directional speed. AT-III proves the mean is preserved with fixed weights (Theorem 14.4) and that no universal factor exists (Section 14.4); the test bench confirms both (H1, H2 in Table 30.2). This edition reads every earlier “lower mean” sentence as “lower speed and turbulence”.

2.  **Risk in the market model.** The drafts (MD-1, MD-2) optimise reward minus loss, $R-L$ (4.7); the framework summary (FS) makes VaR/CVaR the core risk metric; the business plan adds Greek budgets. Read together: $R-L$ is the objective, VaR/CVaR and the Greek budget are the constraints of Section 24.3 — the form C5 later adopts.

3.  **The Bitcoin study.** AT-0 §13 reports the minute-bar reversal as a strategy candidate; AT-III §10 places it inside P1 as internal motion below trading costs (Section 14.11, Subappendix D.1); the bench’s restoration agrees (reversal of a few bp against a 10 bp round trip).

4.  **Two counts of zeros.** AT-III’s text gives 1,747,146 zeros to height $10^6$; its figure legend 1,746,496. The text is the count the paper argues from; the discrepancy is recorded in Section 14.10 and not resolved here. The bench counts to height 2,000 on the quick preset (none missing).

5.  **The dark energy.** The November 2026 template reserves application A with an unfilled body; the author’s stated working hypothesis is recorded as Hypothesis 14.14 with no number, and the velocity-field machinery of Section 14.7 is the test. Nothing in the bench tests it yet.

6.  **What “Part I” means.** AT-II refers to “Part I” and “the original document”; these are AT-0 (Chapter 11 and Chapter 12) and the earlier runs now in Table 13.1.

7.  **Prosperity numbers.** The notes report competition PnL (e.g. 3,500 vs 2,800 on 5 April 2025) on the competition’s own feed; the bench’s feed is synthetic, so only the ranking is comparable.

## Chapter 30: The ledger

> **What this chapter establishes**
>
> One list of what is proved, one list of every headline number with its source and its place in this document, and the status of every hypothesis after the test-bench run of this edition.

### 30.1 What is proved

- Additive quantities match exactly across levels (Proposition 13.6); the index return is the weighted sum of stock returns (Corollary 13.7).

- König’s split (Theorem 13.9); internal motion grows under aggregation (Theorem 13.11); the speed ratio $\varphi\le1$ and collective share $\kappa\le\varphi^2$ (Theorem 14.2); the turbulence identity $\Psi^2=H+(1-H)\bar\rho$ (Theorem 14.3).

- The mean is preserved; compound growth of the whole exceeds the weighted mean of the parts’ (Theorem 14.4); the cascade factorises with every factor $\le1$ (Theorem 14.5).

- The mixture law and its bounds (Theorem 14.6); the squeezing bound (Theorem 14.7).

- The linear-field split with Oort’s constants and expansion as the trace (Theorem 14.8).

- Invariant-mass superadditivity (Theorem 13.12); volatility subadditivity with the gap identity (Theorem 13.13); the virial sign law (Known result 14.10, Known result 13.14).

- The exact linear lumping criterion $CA=BC\iff A(\ker C)\subseteq\ker C$ (Theorem 12.39).

- Proposition 7.2 of AT-0 and Proposition J.2 (Proposition 12.18); the imaginary-time Schrödinger correspondence (Section 13.5.4).

All of these are re-checked to rounding error by `experiments.exact_layer` (74 identities, Appendix E).

### 30.2 Every headline number

**Table 30.1.** Headline numbers of the programme, with source and place. Detailed tables are referenced in the last column; bench values are in Appendix E.

| Quantity | Value | Source | Where |
|---|---|---|---|
| Quantity | Value | Source | Where |
|   |   |   |   |
| Collective share $\kappa$, US counties $\to$ nation | 0.116 | AT-III Table 3 | Table 14.3; bench: real NYT 2020 run in Appendix E |
| $\kappa$, countries $\to$ world GDP | 0.402 | AT-III Table 3 | Table 14.3; bench (real GDP table): 0.414 |
| $\kappa$, metros $\to$ Case–Shiller composite | 0.727 | AT-III Table 3 | Table 14.3 |
|   |   |   |   |
| Mixture-law fit $R^2$: COVID wave / housing crash / beam | 0.992 / 0.993 / 1.0000 | AT-III §5 | Table 14.5 |
| Squeezed share, first wave, daily $\to$ yearly bins | 0.01 $\to$ 0.93 | AT-III Table 4 | Table 14.5 |
|   |   |   |   |
| Nuclei lighter than their parts | 2,938 of 2,938 (and hydrogen, 13.6 eV) | AT-III §6.1 | Section 14.6; bench: 2,939 isotopes (periodictable) all lighter |
| Hadrons heavier than their quarks | 15 of 15 | AT-III §6.1 | Section 14.6; bench: 15/15 (PDG) |
| ATLAS four-lepton events, whole $\ge$ parts | 832 of 832, median gap 0.172 | AT-III §6.1 | Section 14.6 |
| Simulated gas, energy conserved to | $1.11\times10^{-16}$ | AT-III §6.2 | Section 14.6; bench: $<10^{-10}$ |
|   |   |   |   |
| $H_0$ from Pantheon+ | $73.25\pm1.40$ km s$^{-1}$ Mpc$^{-1}$ | AT-III §7.2 | Table 14.10; bench (real Pantheon+): 72.9 |
| One rate at all distances | $\chi^2=5.7$, 6 d.o.f. | AT-III §7.2 | Table 14.10 |
| Bulk flow left after the split | 290 km/s | AT-III §7.3 | Table 14.10 |
| Gaia internal-share ladder | $0\to0.63\to0.77\to0.80$ | AT-II §1.1 | Table 13.1 |
| $\Upsilon$ expected: open clusters / field groups / galaxy clusters | 1–5 / $\sim10^5$ / 30–100+ | AT-III §7, Table 6 | Table 14.11, Table 1.1 |
|   |   |   |   |
| Epps as aggregation | $\rho_\infty=0.813$, $\tau\approx5$ s | AT-II §4 | Hypothesis 13.19, Table 13.1 |
| $J/\psi$ in CMS dimuons | 3.1 GeV, $\sigma=0.21$ GeV, 93% | AT-II §1.1 | Table 13.1 |
| Expected: $M/(m_1+m_2)$ at the $J/\psi$; S&P $\kappa$; $\sigma$ ratio; crypto $\kappa$ | 14.7; 0.2–0.4; 0.6–0.75; 0.75 $\to$ 0.8 | AT-III §8.2 | Table 1.1, Table 14.13 |
| Bitcoin study: reversal per trade vs cost | 0.3–3.3 bp vs 10 bp; rank IC $-0.035$ to $-0.087$ | AT-III §10 | Subappendix D.1, Table 11.6 |
|   |   |   |   |
| Zeros on the critical line to height $10^6$ | 1,747,146 (figure legend: 1,746,496); missing 0 | AT-III §9.2 | Section 14.10; bench to 2,000: 1,507, missing 0 |
|   |   |   |   |
| Market making: inventory inside $\pm79$ | 99% of the session | NB-01 | Section 15.4; bench: 100% |
| Taking layer | PnL 2,300 $\to$ 1,600 | NB-01 | Chapter 15; bench: $-3\%$ to $-16\%$ on its own market |
| Prosperity 2 best round | 113,938.8 | NB-02 | Table 16.2 |
| 5 April 2025 quoting rules | $\approx3{,}500$ vs $\approx2{,}800$ | NB-03 | Table 16.4 |

### 30.3 Hypotheses by status

**Table 30.2.** The twelve registered hypothesis tests of `tmrw_lab` and their verdicts in the run of this edition (Appendix E). “Refuted” for H1 and H2 refers to the original wording that AT-III corrected; “real” means a public data host was reached.

|   | Hypothesis | Data | Verdict | Matches |
|---|---|---|---|---|
| H1 | Aggregation lowers the mean (AT-0 Hyp. 9.1 as stated) | simulation | **refuted** | 3/3 |
| H2 | A universal speed factor such as one half (P1 as first stated) | simulation | **refuted** | 6/7 |
| H3 | The Epps effect is aggregation: kappa(Delta) = kappa_inf Delta/(Delta+tau) | simulation | **supported** | 4/4 |
| H4 | Impact is concave in size, I(Q) = Y sigma_d sqrt(Q/V_d) | simulation | **supported** | 4/4 |
| H5 | Price changes are linear in order-flow imbalance | simulation | **supported** | 9/9 |
| H6 | Mixture law and squeezing of event responses (P2) | simulation | **supported** | 5/5 |
| H7 | Bound 1/r composites are lighter than their parts; free and confined ones heavier | real | **supported** | 5/5 |
| H8 | Expansion is one rate at all distances after the linear-field split | real | **supported** | 4/4 |
| H9 | Zeros of Z(t) as cancellation of units; GUE spacings | analytic | **supported** | 6/6 |
| H10 | Central pricing: P\_{T+1} = alpha I + (1-alpha) H + eps | simulation | **supported** | 5/5 |
| H11 | Stealth-optimal schedule under concave cost | simulation | **supported** | 6/6 |
| H12 | Linear inventory skew and the taking layer (NB-01) | simulation | **supported** | 2/2 |

Beyond the bench: the statements tagged **\[PENDING RUN\]** in Table 14.17 and Table 14.13 (CMS dimuons, the S&P and crypto baskets at full size, the BTC order book, Gaia and the galaxy clusters) keep that status — their hosts were not reachable, and the bench’s synthetic stand-ins test the code path only. The **\[OPEN\]** hypotheses of AT-0 (Hypothesis 11.7) and the conjectures of Part IV remain open as statements about the world; what the toys establish is that each has a consistent model in which it can be true.

## Chapter 31: Open problems

1.  **Existence on the hybrid space (C4).** Prove or refute the existence of a mean-field equilibrium for the hybrid-geometric model of Chapter 9 with jumps and reset maps; the discrete toy converges, the continuous case is open (AT-0 §N “target theorem”).

2.  **The matching parameters as functions.** AT-II states and AT-III measures $\kappa,\varphi,
    \Psi,\tau,\Upsilon$ as numbers; the programme needs them as functions of concentration, correlation and lag structure (the turbulence identity is the first such function). Which other parameters have exact expressions?

3.  **Emergent quantities.** Definition 13.5 names a third kind of quantity, neither additive nor a split square. The two-sided matching of Section 13.6 is a procedure, not a theory: when does it identify the parts’ dynamics from the whole?

4.  **The order book at full size.** The OFI law, the microprice ratio and the square-root impact of Section 13.5 were measured in earlier runs and expected in Table 1.1; the bench could not reach the hosts. The real level-1 run is the first thing to do with data access.

5.  **The dark energy.** Turn Hypothesis 14.14 into a law with one free parameter and test it with the velocity-field split on Pantheon+ and a void catalogue.

6.  **The zeta count.** Reconcile the two counts (1,747,146 vs 1,746,496) and extend the unit-cancellation picture of Section 14.10 from a check to a statement about $S(T)$.

7.  **C5 in production.** The final problem (Chapter 10) needs the firm’s own products and limits; the toy shows the form. The four horizon layers of Chapter 20 are the place it lives.

8.  **The “corrected equilibrium” of AT-0 §12.** The author’s own annotation rejects the EMA-based equilibrium of the practical implementation (Chapter 11); what replaces it is the NESS of Section 12.11.2, which has no estimator yet.

## Appendix A: Notation

**Table ?.** Symbols used across the document (the sources’ own symbols; where two sources use one symbol differently the chapter says so).

| Symbol | Meaning | Where |
|---|---|---|
| Symbol | Meaning | Where |
| $(M, g(t))$ | the manifold and its time-dependent metric; Ricci-flow-type evolution | Chapter 2 |
| $\phi$, $W(t)$ | the field(s) on $M$ and the coupling between fields, agents and geometry | Chapter 2 |
| $x_i(t)$, $a_i$ | state and action of agent $i$ | Chapter 2 and Chapter 11 |
| $\Phi_{s\to s'}$ | reset map (jump) between discrete modes $s, s'$ of the hybrid system | Chapter 2 |
| $\mathcal{S}$, $\Theta_e$ | the layered market state and an object’s parameter/state vector | Chapter 4 |
| $V^{(\cdot)}$ | value surfaces: fundamental, financial, information, market | Chapter 4 |
| $R$, $L$ | reward and loss in the market model’s Bellman equation | Chapter 4 |
| $\theta_t$, $w_t$ | the mixed parameter path and its switching weight (C1) | Chapter 6 |
| $\alpha$, $I$, $H$, $\varepsilon$ | impact share, impact term, history term, noise of central pricing (C2) | Chapter 7 |
| $Q$, $N_{\max}$, $g(x)$, $J_\lambda$ | parent order, maximum children, child footprint, objective (C3) | Chapter 8 |
| $m_t$, $\mu$, $\operatorname{BR}$ | mean field (empirical measure), its law, best response | Chapter 11 and Chapter 12 |
| $\varphi(t)$ | exploitability (distance from equilibrium) | Chapter 12 |
| $A_\ell$ | the aggregation map from level $\ell$ to $\ell+1$; $A_\ell\circ\operatorname{BR}_\ell=\operatorname{BR}_{\ell+1}\circ A_\ell$ | Chapter 12 |
| $A$, $C$, $B$ | microscopic generator, aggregation matrix, lumped generator ($CA=BC$) | Section 12.13 |
| $w_i$, $x_i$, $X$ | weight and velocity of unit $i$; the aggregate $X=\sum_i w_i x_i$ | Chapter 13 and Chapter 14 |
| $\varphi$ | speed ratio $\lvert X\rvert/\sum_i w_i\lvert x_i\rvert\le1$ (also used for exploitability in AT-0 and the field in GI) | Theorem 14.2 |
| $\kappa$ | collective share $\lvert X\rvert^2/\sum_i w_i\lvert x_i\rvert^2$ | Theorem 14.2 |
| $\Psi$, $H$, $N_{\mathrm{eff}}$, $\bar\rho$ | turbulence ratio; Herfindahl $H=\sum a_i^2/(\sum a_i)^2$ with $a_i=w_i\sigma_i$; $N_{\mathrm{eff}}=1/H$; mean correlation | Theorem 14.3 |
| $\Upsilon$ | dynamical-to-visible mass ratio $M_{\mathrm{dyn}}/M_{\mathrm{vis}}$ | Known result 13.14 |
| $\tau$, $\tau_i$ | the lag parameter of the Epps law; unit lags in the mixture law | Hypothesis 13.19 and Theorem 14.6 |
| $c_i$, $f_i$, $A$ | impacts, unit responses and total impact in $R(t)/A=\sum_i c_i f_i(t-\tau_i)$ | Theorem 14.6 |
| $V_0$, $M$, $r$; $A,B,C,K$ | bulk flow, linear field, internal motion; Oort’s constants | Theorem 14.8 |
| $\operatorname{OFI}$, $\beta$ | order-flow imbalance and its price coefficient | equation (13.14) |
| $Y$, $\sigma_d$, $V_d$ | square-root impact constant, daily volatility and volume | Section 13.5.5 |
| $Z(t)$, $\theta(t)$ | the Riemann–Siegel $Z$ function and theta function | Section 14.10 |
| $r$, $q$, $\gamma$, $\sigma^2$, $k$ | reservation price, inventory, risk aversion, variance, skew per unit (Avellaneda–Stoikov) | Chapter 15 |
| $h$ | half-spread (10 ticks in the worked case) | Chapter 15 |

## Appendix B: Where the proofs are

Every proof in the sources sits under the statement it proves: AT-II’s appendix A proofs under Theorem 13.9, Theorem 13.11, Theorem 13.12, Theorem 13.13 and Known result 13.14 and in Section 13.5.4; AT-III’s appendix A proofs under Theorem 14.2, Theorem 14.3, Theorem 14.4, Theorem 14.5, Theorem 14.6, Theorem 14.7 and Theorem 14.8; the lumping theorem’s proof under Theorem 12.39; Proposition 7.2 of AT-0 in Section 11.7. The test bench re-derives each identity numerically (Appendix E); the unit tests in `tmrw_lab/tests/test_core.py` are the shortest statement of each.

## Appendix C: Data, code and reproducibility

The data sources, notebooks and reproducibility notes of AT-III are in Section 14.13. This edition adds the test bench of Appendix E, whose loaders reach the same public sources (NYT and JHU COVID-19 series, the GDP table, Pantheon+, the isotope and hadron tables shipped with `periodictable` and `particle`) and fall back to synthetic generators with planted answers for the hosts that are not reachable (Binance, Tardis, CERN open data, the IAEA mass table, Gaia, FRED, Yahoo). The LaTeX source of this document, the markdown edition and the package are assembled by `assemble.sh` into one folder; `latexmk -pdf main.tex` rebuilds the PDF, `bash md/build_md.sh` the markdown.

## Appendix D: The Bitcoin study

### D.1 The Bitcoin study: tables *\[AT-III §10\]*

AT-III §10 places the original Bitcoin restoration study (AT-0 Experiment 11.1, Experiment 11.9; its own Tables 2–7 are reproduced in Chapter 11 as Table 11.2, Table 11.3, Table 11.4, Table 11.5, Table 11.7 and Table 11.6) inside the general aggregation picture. The study regressed a “restoration” variable $Y=E_{t+h}+D_{t+h}-D_t$, built from an exponential moving average $E$ of log price and the deviation $D$ from it, on the deviation; the author’s own note on that section flagged the construction as wrong. Part I (its Theorem 6.1, Chapter 12) showed why: for any price path the moving average makes $Y$ depend on $D_t$ mechanically, so the slopes it produces are those of a random walk. The study is thus a special case of Theorem 14.6: a moving average is a fixed lag distribution applied to every unit, and it manufactures apparent restoration. The five tables below give this reading, one per table of the original study, with the numbers AT-III puts in their place; those numbers are the ones of Table 14.12 (Section 14.9). AT-III reports no bin-level, coefficient-level, state-level or walk-forward numbers of its own for the study: its four numbers are the slope gap, the confirmation-run information coefficients, the coin count and the break-even cost. The original study’s own values stay in Chapter 11.

| Object | In the original study | AT-III reading |
|---|---|---|
| Displacement bins | outcomes by standardised displacement $z_t$ from the EMA equilibrium, eight bins (Table 11.3) | **\[REFUTED AS STATED\]** the restoration share per bin is what a random walk gives through the EMA (Part I Thm. 6.1); Hyp. 9.1 “restoration” is refuted as stated (Table 14.16) |
| Scales and horizons | equilibrium scale $h$ and forward horizon $H$ in minutes (Table 11.4) | **\[PROVED\]** the scale $h$ fixes a lag distribution applied to every unit (Theorem 14.6), not a restoring force |
| Restored number | — | **\[MEASURED\]** slopes within 0.022 of the random-walk value on 132,480 BTC minutes |

| Object | In the original study | AT-III reading |
|---|---|---|
| $\mathrm{IC}(d,r)$, $\mathrm{IC}(f,r)$, $\mathrm{IC}(v,r)$ | future return against displacement, flow pressure and equilibrium velocity, per $(h,H)$ pair, all negative (Table 11.4) | not re-run in AT-III; by Part I Thm. 6.1 the construction gives a random walk these signs, so they are not evidence of a restoring equilibrium (editorial inference) |
| What survived | — | **\[MEASURED\]** a small, genuine short-horizon reversal: confirmation run fixed in advance, January–June 2026, 10 coins, rank IC $-0.035$ to $-0.087$ (at 5–60 min), BTC $z=-10.8$, present in 10 of 10 coins |

| Object | In the original study | AT-III reading |
|---|---|---|
| Slope of $Y$ on the deviation $D_t$ | the estimated restoration coefficient at each scale | **\[PROVED\]** equal to the random-walk value for any price path (Part I Thm. 6.1); **\[MEASURED\]** measured within 0.022 of it |
| Standardised feature coefficients | the 64-minute model with its ranked features (Table 11.5) | not re-estimated in AT-III, whose only coefficient-level statement is the slope above |

| Object | In the original study | AT-III reading |
|---|---|---|
| Motion $\times$ flow states | outcomes by equilibrium-motion state (contracting, expanding) and flow-pressure state (opposes, supports the displacement) (Table 11.7) | **\[OPEN\]** equilibrium migration (Hyp. 9.2, Hypothesis 11.7) needs a dynamic test |
| Cross-scale coherence $C_t$ | direction agreement and velocity dispersion across scales as features | **\[MEASURED\]** measured as the collective share $\kappa$ and the agreement share (Hyp. 9.3, Hypothesis 11.8; Table 14.3) |
| Merger, hierarchical equilibrium | the original framework’s merger (N.1) and hierarchical equilibrium (N.5) | **\[OPEN\]** equilibria are emergent, not additive (open in the dynamics) |

| Object | In the original study | AT-III reading |
|---|---|---|
| Chronological out-of-sample comparison | nested feature models, trend only to full multiscale (Table 11.6) | not re-run in AT-III; the restoration it tested is refuted as stated (Table 14.16) |
| The reversal after costs | — | **\[MEASURED\]** breaks even at 0.3–3.3 bp round trip, against a 10 bp cost: a genuine effect, below trading costs |

## Appendix E: The test-bench run *\[LAB\]*

> **What this appendix is**
>
> The Python package `tmrw_lab` (shipped with this edition) re-runs every statement of the programme that can be run: the exact layer as identities checked to rounding error, the hindsight tests of Chapter 14 domain by domain, the refuted Bitcoin special case restored inside the general picture, toy models for the five conjectures of Part IV, the simulations behind the working notes of Part VI, and twelve registered hypothesis tests, each with a verdict. The body below is generated by `make_appendix.py` from `results/summary.json` of the run named in the first paragraph; the tables carry the measured value next to the value the compendium expects, with the source of the expectation.

### E.1 How to run it

```
cd tmrw_lab
pip install -e .            # numpy, scipy, pandas, matplotlib, mpmath, requests
pip install -e ".[full]"    # + statsmodels, scikit-learn, periodictable, particle
python run_all.py --preset quick       # smoke run, about a minute
python run_all.py                      # standard preset
python run_all.py --preset full        # the sizes quoted in AT-III (hours; needs the data hosts)
AGG_OFFLINE=1 python run_all.py        # no network: synthetic data with planted answers
python run_all.py --only society zeta  # a subset
python make_appendix.py                # regenerate this appendix from results/summary.json
python -m pytest -q                    # the unit tests of the exact layer
```

###### Reading the verdicts.

A quantity is *match* when it lies inside the quoted range or within the tolerance of the quoted value, *differs* when it does not, *measured* when the compendium quotes no expectation. The *data* column of each module says whether the run used real data (a public host was reached), a synthetic file with a planted answer (the host was not reachable: the verdict then says that the code recovers what was planted, not that the world agrees), a simulation (a model run with no data) or analysis (an identity). Hypothesis verdicts are *supported*, *refuted* or *inconclusive*; the verdict refers to the hypothesis as the registry states it, which for H1 and H2 is the original wording that Chapter 14 refuted.

###### What the bench does not do (editorial).

It does not replace the hindsight runs of AT-III: the hosts that AT-III used for the full-size runs (Tardis, Binance, CERN open data, the IAEA mass table, Gaia, FRED) are not reachable from the build machine, so those modules fall back to synthetic data at the sizes of the preset. The real data it does reach — the NYT and JHU COVID-19 series, the GDP table, Pantheon+, the isotope masses in `periodictable` and the hadron masses in `particle` — are the same sources AT-III quotes.

###### The run.

Preset `quick`, offline=False, seed 20261106: 25 modules ran, 0 failed, 0 were skipped. Each module below reports the quantities it measured next to the value the compendium expects for them; “match” means inside the quoted range (or tolerance), “differs” outside it, “measured” when no expectation is quoted. Modules on synthetic data test the pipeline, not the world: their verdicts say the code recovers the planted answer.

### E.2 The exact layer

#### E.2.1 The exact layer, checked to rounding error

`experiments.exact_layer`; data: analytic; 1.23 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| exact.konig.residual | 1.63e-16 | 0 |   | match | AT-III Thm 3.1 / AT-II Thm 3.4 |
| exact.phi.excess_over_one | 0 | 0 |   | match | AT-III Thm 3.1 |
| exact.kappa.excess_over_phi2 | 0 | 0 |   | match | AT-III Thm 3.1 |
| exact.kappa.below_zero | 0 | 0 |   | match | AT-III Thm 3.1 |
| exact.hierarchy.additive_mismatch | 2.41e-16 | 0 |   | match | AT-II Prop 3.1 |
| exact.hierarchy.psi2_identity_residual | 1.11e-16 | 0 |   | match | AT-III Thm 3.2 |
| exact.hierarchy.psi2_excess_over_one | 0 | 0 |   | match | AT-III Thm 3.2 |
| exact.hierarchy.internal_share_decrease | 0 | 0 |   | match | AT-II Thm 3.6 |
| exact.hierarchy.factor_excess | 0 | 0 |   | match | AT-III Thm 3.4 |
| exact.cascade.speed_product_residual | 0 | 0 |   | match | AT-III Thm 3.4 |
| exact.cascade.energy_product_residual | 0 | 0 |   | match | AT-III Thm 3.4 |
| exact.hierarchy.kappa_excess_over_phi2 | 0 | 0 |   | match | AT-III Thm 3.1 |
| exact.cascade.snapshot_residual | 0 | 0 |   | match | AT-III Thm 3.4 |
| exact.cascade.snapshot_factor_excess | 0 | 0 |   | match | AT-III Thm 3.4 |
| exact.turbulence.identity_residual | 2.78e-17 | 0 |   | match | AT-III Thm 3.2 |
| exact.turbulence.series_vs_formula | 2.78e-17 | 0 |   | match | AT-III Thm 3.2 |
| exact.turbulence.psi_excess_over_one | 0 | 0 |   | match | AT-III Thm 3.2 |
| exact.mean.residual | 3.47e-18 | 0 |   | match | AT-III Thm 3.3a |
| exact.jensen.violation | 0 | 0 |   | match | AT-III Thm 3.3b |
| exact.jensen.gap_over_half_variance | 0.9997 | 1 |   | match | AT-III Thm 3.3b (gap ≈ ½ Var_w log R) |
| exact.index.residual | 6.08e-16 | 0 |   | match | AT-II Cor 3.2 |
| exact.leftover.range_violation | 0 | 0 |   | match | AT-II Def 4.2 |
| exact.leftover.identity_residual | 1.11e-16 | 0 |   | match | AT-II Def 4.2 / Thm 3.6 |
| exact.mixture.residual | 2.22e-16 | 0 |   | match | AT-III Thm 3.5 |
| exact.mixture.bound_violation | 0 | 0 |   | match | AT-III Thm 3.5 |
| exact.squeezing.violation | 0 | 0 |   | match | AT-III Thm 3.6 |
| exact.squeezing.mc_share | 0.9252 | 0.6–1 |   | match | AT-III Thm 3.6 (share ≥ 1 − (a+b)/Δ) |
| exact.squeezing.limit_one | 7.81e-13 | 0 |   | match | AT-III Thm 3.6 |
| exact.linear_field.split_residual_3d | 3.88e-16 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.M_recovery_3d | 5.08e-16 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.V0_recovery_3d | 3.42e-16 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.expansion_residual_3d | 4.44e-16 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.share_sum_3d | 4.44e-16 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.split_residual_2d | 0 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.M_recovery_2d | 1.75e-16 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.V0_recovery_2d | 4.42e-17 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.expansion_residual_2d | 5.55e-17 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.share_sum_2d | 1.11e-16 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.oort_reconstruction | 1.04e-17 | 0 |   | match | AT-III Thm 3.7 |
| exact.linear_field.oort_K_is_expansion | 0 | 0 |   | match | AT-III Thm 3.7 |
| exact.mass.superadditivity_violation | 0 | 0 |   | match | AT-II Thm 3.7 |
| exact.mass.frame_invariance | 2.15e-16 | 0 |   | match | AT-II Thm 3.7 |
| exact.mass.equality_when_together | 0 | 0 |   | match | AT-II Thm 3.7 |
| exact.vol.subadditivity_violation | 0 | 0 |   | match | AT-II Thm 3.8 |
| exact.vol.gap_identity_residual | 4.44e-16 | 0 |   | match | AT-II Thm 3.8 |
| exact.vol.series_vs_formula | 0 | 0 |   | match | AT-II Thm 3.8 |
| exact.virial.kepler_residual | 0 | 0 |   | match | AT-III Known 3.9 |
| exact.virial.kepler_2K_plus_U | 0 | 0 |   | match | AT-II Known 3.9 |
| exact.virial.kepler_sign | -1 | -1 |   | match | AT-III Known 3.9 (bound: lighter) |
| exact.virial.harmonic_residual | 2.27e-16 | 0 |   | match | AT-III Known 3.9 |
| exact.virial.harmonic_sign | 1 | 1 |   | match | AT-III Known 3.9 (confined: heavier) |
| exact.lumping.supply_demand_residual | 1.26e-15 | 0 |   | match | AT-0 Sec. U (CA = BC) |
| exact.lumping.supply_demand_B | -3 | -3 |   | match | AT-0 Sec. U (B = −3) |
| exact.lumping.supply_demand_same_future | 2.39e-15 | 0 |   | match | AT-0 Sec. U.1 |
| exact.lumping.supply_demand_closed_form | 5.4e-15 | 0 |   | match | AT-0 Sec. U (y = 2e^−3t) |
| exact.lumping.counterexample_false_closure | 0 | 0 |   | match | AT-0 Sec. V |
| exact.lumping.counterexample_residual | 0.7071 | 0.7071 |   | match | AT-0 Sec. V (CA = \[−1 2\] vs \[b −b\]) |
| exact.lumping.counterexample_ydot_state1 | 1 | 1 |   | match | AT-0 Sec. V |
| exact.lumping.counterexample_ydot_state2 | 46 | 46 |   | match | AT-0 Sec. V |
| exact.lumping.sine_residual | 1 | 1 |   | match | AT-0 Sec. S.2 (CA = \[0 1\] vs \[b 0\]) |
| exact.lumping.sine_second_order | 0 | 0 |   | match | AT-0 Sec. S.2 (ÿ = −y) |
| exact.lumping.rotation_dynamics | 0 | 0 |   | match | AT-0 Sec. S (ż = A_rot z) |
| exact.lumping.rotation_no_real_line | 0 | 0 |   | match | AT-0 Sec. S.1 |
| exact.lumping.random_lumpable_residual | 2.15e-16 | 0 |   | match | AT-0 Thm W.1 |
| exact.lumping.random_lumpable_flag | 0 | 0 |   | match | AT-0 Thm W.1 |
| exact.lumping.random_lumpable_drift | 5.88e-15 | 0 |   | match | AT-0 Sec. W.2 (Ce^At = e^BtC) |
| exact.lumping.random_nonlumpable_false_closure | 0 | 0 |   | match | AT-0 Thm W.1 |
| exact.lumping.markov_residual | 5.55e-17 | 0 |   | match | Kemeny–Snell strong lumpability (AT-0 Thm W.1 with A = Pᵀ) |
| exact.lumping.markov_recovery | 7.85e-17 | 0 |   | match | Kemeny–Snell strong lumpability |
| exact.contest.conservation | 8.88e-16 | 0 |   | match | AT-0 Prop I.2 |
| exact.epps.kappa_inf | 0.8 | 0.8 |   | match | AT-II Hyp 4.3 (planted 0.8) |
| exact.epps.tau | 5 | 5 | s | match | AT-II Hyp 4.3 (planted 5 s; Fig. 1b τ ≈ 5 s) |
| exact.epps.kappa_inf_noisy | 0.8012 | 0.8 |   | match | AT-II Hyp 4.3 (1% noise) |
| exact.epps.tau_noisy | 5.006 | 5 | s | match | AT-II Hyp 4.3 (1% noise) |

- hierarchy capped at N=200 units x T=1000 steps (the Ψ² identity needs an N×N correlation matrix)

- 74/74 numbers match; hierarchy N=200, T=1000, levels=3 with group counts \[200, 34, 6, 1\]; Ψ² at the unit level 0.166 (N_eff=78.5, ρ̄=0.155)

- virial averages use the exact Kepler orbit sampled uniformly in time (eccentric anomaly) and an anisotropic harmonic orbit; the planted linear field has its internal motion projected to satisfy the normal equations so M and V0 are recovered exactly

![The exact layer, checked to rounding error (test bench, this run).](figures/exact_layer.png)

*The exact layer, checked to rounding error (test bench, this run).*

### E.3 The hindsight tests

#### E.3.1 P1 on societies: counties, countries, metros

`experiments.society`; data: real; 1.28 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| society.covid_us.kappa | 0.3209 | 0.116 |   | differs | AT-III Table 3 |
| society.covid_us.phi | 0.7033 | 0–1 |   | match | AT-III Thm 3.1 |
| society.covid_us.Psi2 | 0.3888 | 0–1 |   | match | AT-III Thm 3.2 |
| society.covid_us.turbulence_identity_residual | 5.55e-17 | 0 |   | match | AT-III Thm 3.2: Psi^2 = H + (1-H) rho_bar |
| society.covid_us.N_eff | 66.58 | – |   | measured |   |
| society.covid_us.mean_residual | 0 | 0 |   | match | AT-III Thm 3.3 |
| society.covid_us.jensen_gap | 0.1566 | 0–10 |   | match | AT-III Thm 3.3 |
| society.covid_us.kappa_groups_to_top | 0.5481 | – |   | measured |   |
| society.world_gdp.kappa | 0.4139 | 0.402 |   | match | AT-III Table 3 |
| society.world_gdp.phi | 0.7074 | 0–1 |   | match | AT-III Thm 3.1 |
| society.world_gdp.Psi2 | 0.3267 | 0–1 |   | match | AT-III Thm 3.2 |
| society.world_gdp.turbulence_identity_residual | 5.55e-17 | 0 |   | match | AT-III Thm 3.2: Psi^2 = H + (1-H) rho_bar |
| society.world_gdp.N_eff | 16.55 | – |   | measured |   |
| society.world_gdp.mean_residual | 0 | 0 |   | match | AT-III Thm 3.3 |
| society.world_gdp.jensen_gap | 0.003706 | 0–10 |   | match | AT-III Thm 3.3 |
| society.world_gdp.kappa_groups_to_top | 0.6007 | – |   | measured |   |
| society.case_shiller.kappa | 0.727 | 0.727 |   | match | AT-III Table 3 |
| society.case_shiller.phi | 0.8674 | 0–1 |   | match | AT-III Thm 3.1 |
| society.case_shiller.Psi2 | 0.7237 | 0–1 |   | match | AT-III Thm 3.2 |
| society.case_shiller.turbulence_identity_residual | 5.55e-16 | 0 |   | match | AT-III Thm 3.2: Psi^2 = H + (1-H) rho_bar |
| society.case_shiller.N_eff | 7.442 | – |   | measured |   |
| society.case_shiller.mean_residual | 0 | 0 |   | match | AT-III Thm 3.3 |
| society.case_shiller.jensen_gap | 2.69e-05 | 0–10 |   | match | AT-III Thm 3.3 |
| society.case_shiller.kappa_groups_to_top | 0.8807 | – |   | measured |   |

- covid_us: real data

- world_gdp: real data

- case_shiller: synthetic data (planted answer: the units’ dispersion is scaled to the AT-III kappa)

- velocity = growth of the level, weight = last period’s level; kappa, phi summed over time (AT-III Table 2)

- counties: NYT 2020 file, weekly new cases, growth of the weekly level; AT-III’s county run (kappa = 0.116) used its own period and binning, so the real-data value here is a fresh measurement, not a replication

![P1 on societies: counties, countries, metros (test bench, this run).](figures/society.png)

*P1 on societies: counties, countries, metros (test bench, this run).*

#### E.3.2 P2/P3 on a gas, a beam and an epidemic wave

`experiments.gas_beam`; data: real; 1.34 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| gas.energy_conservation_rel | 2.36e-16 | 0 |   | match | AT-III Sec. 6.2: 1.11e-16 |
| gas.kappa_initial | 0.9195 | 0.5–1 |   | match | started with a collective drift |
| gas.kappa_final | 0.000516 | 0–0.05 |   | match | AT-III Sec. 6.2: collective motion becomes heat |
| beam.mixture_r2 | 0.9998 | 1 |   | match | AT-III Sec. 5: 1.0000 |
| beam.squeezed_share_fine | 0.01291 | 0–0.2 |   | match | AT-III Thm 3.6 |
| beam.squeezed_share_coarse | 0.9838 | 0.9–1 |   | match | AT-III Thm 3.6 |
| beam.bound_holds | 1 | 1 |   | match |   |
| waves.mixture_r2 | 0.9975 | 0.992 |   | match | AT-III Sec. 5 (first US wave) |
| waves.squeezed_share_daily | 0.02468 | 0.01 |   | match | AT-III Table 4: 0.01 (daily bins) |
| waves.squeezed_share_yearly | 1 | 0.93 |   | match | AT-III Table 4: 0.93 (yearly bins) |

- gas: 400 hard discs; beam: 200 particles with gamma lags; wave: real county data

![P2/P3 on a gas, a beam and an epidemic wave (test bench, this run).](figures/gas_beam.png)

*P2/P3 on a gas, a beam and an epidemic wave (test bench, this run).*

#### E.3.3 P3: nuclei, hadrons and four-lepton events

`experiments.nuclei_hadrons`; data: real; 1.72 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| nuclei.n_total | 2939 | – |   | measured | real isotope masses |
| nuclei.share_lighter | 1 | 1 |   | match | AT-III Sec. 6.1: all 2,938 nuclei |
| nuclei.n_lighter | 2939 | – |   | measured |   |
| nuclei.binding_per_nucleon_max_MeV | 8.795 | 8.8 |   | match | AT-III: peak near 56Fe / 62Ni (8.79 MeV) |
| nuclei.hydrogen_binding_eV | 13.6 | 13.6 | eV | match | AT-III Sec. 6.1 |
| hadrons.n | 15 | 15 |   | match | AT-III: 15 hadrons |
| hadrons.share_heavier | 1 | 1 |   | match | AT-III Sec. 6.1 |
| hadrons.mass_over_quarks_min | 5.074 | 1–1e+09 |   | match |   |
| atlas.n_events | 832 | 832 |   | match | AT-III Sec. 6.1 (synthetic stand-in) |
| atlas.share_whole_ge_parts | 1 | 1 |   | match | AT-III: 832/832 |
| atlas.median_gap | 0.172 | 0.172 |   | match | AT-III: median 0.172 (planted) |
| free.min_mass_gap_rel | 0.00361 | 0–1 |   | match | AT-II Thm 3.7 |

- nuclei from real, hadrons from real; four-lepton events synthetic (CERN open data not reachable)

![P3: nuclei, hadrons and four-lepton events (test bench, this run).](figures/nuclei_hadrons.png)

*P3: nuclei, hadrons and four-lepton events (test bench, this run).*

#### E.3.4 B: expansion, bulk flow and the stellar hierarchy

`experiments.expansion`; data: real; 0.25 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| expansion.H0 | 72.86 | 73.25 | km/s/Mpc | match | AT-III Sec. 7.2: 73.25 +/- 1.40 |
| expansion.chi2_const_rate | 13.13 | 0–16.8 |   | match | AT-III: 5.7 for 6 dof (16.8 = 99% point; peculiar-velocity floor 250 km/s here instead of the gravity-model correction) |
| expansion.dof | 6 | 6 |   | match | AT-III: 6 distance bins |
| expansion.n_sne | 496 | – |   | measured | Pantheon+ (real) |
| expansion.bulk_flow_kms | 291.5 | 290 | km/s | match | AT-III Sec. 7.3 (planted) |
| expansion.rate_from_split_rel_err | 0.00879 | 0 |   | match | AT-III Thm 3.7 |
| expansion.split_shares_sum | 1 | 1 |   | match | exact split (cross terms vanish in the least-squares split) |
| gaia.internal_share_level1 | 0.6513 | 0.63 |   | match | AT-III Sec. 7.3: 0 -$>$ 0.63 -$>$ 0.77 -$>$ 0.80 (planted) |
| gaia.internal_share_level2 | 0.752 | 0.77 |   | match | AT-III Sec. 7.3: 0 -$>$ 0.63 -$>$ 0.77 -$>$ 0.80 (planted) |
| gaia.internal_share_level3 | 0.8562 | 0.8 |   | match | AT-III Sec. 7.3: 0 -$>$ 0.63 -$>$ 0.77 -$>$ 0.80 (planted) |
| gaia.upsilon_open_clusters_median | 2.456 | 1–5 |   | match | AT-III Table 6: 1-5 |
| gaia.upsilon_field_groups_median | 7.011e+04 | 1e+04–1e+06 |   | match | AT-III Table 6: ~1e5 |

- Pantheon+: real; local-volume split and stellar hierarchy synthetic with planted answers

![B: expansion, bulk flow and the stellar hierarchy (test bench, this run).](figures/expansion.png)

*B: expansion, bulk flow and the stellar hierarchy (test bench, this run).*

#### E.3.5 D: zeros of the zeta function as cancellation of units

`experiments.zeta`; data: analytic; 2.04 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| zeta.height_T | 2000 | – |   | measured | AT-III ran to 10^6 (full preset) |
| zeta.n_zeros_found | 1507 | 1507 |   | match | exact count (mpmath.nzeros) |
| zeta.n_zeros_smooth | 1508 | – |   | measured | Riemann-von Mangoldt |
| zeta.missing | 0 | 0 |   | match | AT-III Sec. 9.2: missing 0 |
| zeta.share_on_line | 1 | 1 |   | match | AT-III: all zeros on the critical line (counted) |
| zeta.units_at_mid_zero | 13 | – |   | measured |   |
| zeta.partial_sum_at_zero_over_amplitude | 2.17e-11 | 0 |   | match | units cancel at a zero |
| zeta.gue_ks | 0.04454 | 0–0.1 |   | match | AT-III Sec. 9.2: GUE statistics |
| zeta.spacing_var | 0.1468 | 0.18 |   | match | GUE Wigner surmise: variance 3pi/8 - 1 = 0.178 |

- 1507 zeros on \[50, 2000\] against the exact count 1507 (smooth 1507.6); grid step 0.182; a check, not a proof

![D: zeros of the zeta function as cancellation of units (test bench, this run).](figures/zeta.png)

*D: zeros of the zeta function as cancellation of units (test bench, this run).*

#### E.3.6 C: index and basket aggregation (stocks, coins)

`experiments.markets`; data: synthetic; 1.13 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| markets.sp500.additive_mismatch | 0 | 0 |   | match | AT-II Cor 3.2 |
| markets.sp500.kappa | 0.3 | 0.2–0.4 |   | match | AT-III Sec. 8.2 / AT-II Tab. 3: 0.2-0.4 |
| markets.sp500.phi | 0.6033 | 0–1 |   | match | AT-III Thm 3.1 |
| markets.sp500.sigma_ratio | 0.6237 | 0.6–0.75 |   | match | AT-III Sec. 8.2: 0.6-0.75 |
| markets.sp500.Psi2 | 0.3801 | 0–1 |   | match | AT-III Thm 3.2 |
| markets.sp500.turbulence_identity_residual | 0 | 0 |   | match |   |
| markets.sp500.N_eff | 13.06 | – |   | measured |   |
| markets.sp500.rho_bar | 0.3286 | – |   | measured |   |
| markets.sp500.jensen_gap | 9.2e-05 | 0–1 |   | match | AT-III Thm 3.3 |
| markets.sp500.leftover_share | 0.7 | – |   | measured | AT-II Def 4.1: internal share of squared returns |
| markets.crypto.kappa_shortest_bar | 0.1484 | – |   | measured | bar 1 s (synthetic) |
| markets.crypto.kappa_5min | 0.775 | 0.75–0.85 |   | match | AT-III: rising to ~0.8 |
| markets.crypto.kappa_rises | 1 | 1 |   | match | AT-II Hyp 4.4 |
| markets.crypto.epps_tau_s | 4.213 | 1–10 | s | match | AT-II: tau ~ 5 s (fitted) |
| markets.crypto.kappa_inf | 0.7347 | 0.7–0.9 |   | match | AT-II: 0.813 |

- stocks: synthetic (30 names, 2520 days); coins: synthetic (10 coins at 1 s)

![C: index and basket aggregation (stocks, coins) (test bench, this run).](figures/markets.png)

*C: index and basket aggregation (stocks, coins) (test bench, this run).*

#### E.3.7 C at the order book: OFI, microprice, memory, impact

`experiments.order_book`; data: synthetic; 0.82 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| order_book.ofi_beta_1s | 0.04619 | 0–1e+09 |   | match | AT-II eq. OFI: beta $>$ 0 |
| order_book.ofi_r2_1s | 0.268 | 0.5–1 |   | differs | AT-II Known 5.2 / Cont-Kukanov-Stoikov: R^2 ~ 0.6 at 1 s |
| order_book.ofi_beta_10s | 0.02736 | 0–1e+09 |   | match | AT-II eq. OFI: beta $>$ 0 |
| order_book.ofi_r2_10s | 0.164 | 0.2–1 |   | differs | AT-II Known 5.2 / Cont-Kukanov-Stoikov: R^2 ~ 0.6 at 1 s |
| order_book.ofi_beta_60s | 0.005728 | 0–1e+09 |   | match | AT-II eq. OFI: beta $>$ 0 |
| order_book.ofi_r2_60s | 0.02551 | 0.2–1 |   | differs | AT-II Known 5.2 / Cont-Kukanov-Stoikov: R^2 ~ 0.6 at 1 s |
| order_book.mid_over_microprice_100ms | 1.346 | 2–1e+06 |   | differs | AT-II Tab. 3 / AT-III Sec. 8.2: far above 1 for BTC |
| order_book.mid_over_microprice_1s | 2.641 | – |   | measured |   |
| order_book.mid_over_microprice_10s | 3.37 | – |   | measured |   |
| order_book.mid_over_microprice_60s | 2.981 | 1 |   | differs | AT-III: flat (~1) after seconds |
| order_book.sign_hurst | 0.775 | 0.85 |   | match | AT-II Table 1: H ~ 0.85-0.9 (planted 0.85) |
| order_book.sign_acf_gamma | 0.4269 | 0.5 |   | match | AT-II Known 5.7: gamma ~ 0.5 |
| order_book.impact_exponent | 0.5669 | 0.5 |   | match | AT-II Known 5.6: 1/2 (planted per-trade sqrt(size)) |
| order_book.impact_Y | 1.866 | – |   | measured |   |
| order_book.potential_depth | 26.2 | – |   | measured | AT-II Sec. 5.3: U = -D log rho |
| order_book.propagator_G1 | 1.616 | 0–1e+09 |   | match | AT-II Known 5.7 |

- the level-1 events are a synthetic stand-in (no level-1 history is reachable): the OFI R^2 and the mid/microprice ratios test the measurement path, not BTC; the AT-III expectations are kept for the real run

- events: synthetic (60000 events over 19124 s); Binance level-1 history is not available, trade sizes synthetic

![C at the order book: OFI, microprice, memory, impact (test bench, this run).](figures/order_book.png)

*C at the order book: OFI, microprice, memory, impact (test bench, this run).*

### E.4 The refuted special case

#### E.4.1 The Bitcoin study as a special case (refuted hypothesis restored)

`experiments.bitcoin_restoration`; data: synthetic; 0.54 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| bitcoin.hurst_returns | 0.4155 | 0–0.5 |   | match | AT-0 / earlier run: 0.159 (mean reverting: H $<$ 0.5) |
| bitcoin.halflife_steps | 8.415 | 5 | min | match | AT-0: ~5 steps |
| bitcoin.rank_ic_1 | -0.03927 | -0.15–0 |   | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_5 | -0.06443 | -0.15–0 |   | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_10 | -0.07456 | -0.15–0 |   | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_30 | -0.09227 | -0.15–0 |   | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_60 | -0.08763 | -0.15–0 |   | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_100 | -0.1179 | -0.15–0 |   | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.decile_reversal_1 | 0.000298 | 0–1 |   | match | bottom minus top decile future return $>$ 0 |
| bitcoin.reversal_bp_per_trade | 4.016 | 0–10 |   | match | AT-III Sec. 10: 0.3-3.3 bp vs 10 bp cost |
| bitcoin.oos_sharpe_after_costs | -62.98 | -1e+06–0 |   | match | below costs |
| bitcoin.n_bars | 2999 | – |   | measured | synthetic |

- AT-0 Hypothesis 9.1 as stated is refuted: the aggregate mean is preserved; what aggregation lowers is turbulence. The restoration places the study inside P1: a short-lived internal motion (mean reversion) below the cost of trading it.

- bars: synthetic; horizons (1, 5, 10, 30, 60, 100); walk-forward split at the midpoint; 10 bp round-trip

![The Bitcoin study as a special case (refuted hypothesis restored) (test bench, this run).](figures/bitcoin_restoration.png)

*The Bitcoin study as a special case (refuted hypothesis restored) (test bench, this run).*

### E.5 Toy models for the five conjectures

#### E.5.1 Toy models for Conjectures 1-5

`experiments.conjecture_toys`; data: simulation; 0.89 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| c1.gain_timely | 0.00875 | 0–1e+09 |   | match | C1: switching in time beats either fixed path |
| c1.gain_lagged | -0.004609 | -1e+09–0 |   | match | C1: switching late loses |
| c1.breakeven_lag | 49.51 | 0–100 | steps | match | C1: the lag beyond which switching stops paying (regime duration) |
| c2.alpha_hat | 0.5938 | 0.6 |   | match | C2: P\_T+1 = alpha I + (1-alpha) H + eps (planted alpha) |
| c2.alpha_tstat | 161.9 | 3–1e+09 |   | match | C2: alpha significant |
| c2.r2 | 0.3631 | – |   | measured |   |
| c2.coverage_band | 0.9051 | 0.85–1 |   | match | C2: 1 - delta coverage of the conformal band (delta = 0.1) |
| c2.rmse_ratio_vs_random_walk | 0.8862 | 0–1 |   | match | C2: beats the random walk |
| c2.n_assets | 30 | 4–1e+09 |   | match | C2: N $>$ 3 |
| c3.cost_equal | 1492 | – |   | measured |   |
| c3.cost_front | 1921 | – |   | measured |   |
| c3.cost_equal_over_front | 0.7767 | 0–1 |   | match | C3: equal split cheapest under the symmetric cost |
| c3.optimal_n | 55 | 1–100 |   | match | C3: N $<$= N_max = 100 |
| c3.sqrt_exponent_check | 0.5002 | 0.5 |   | match | C3: g(x) ~ c sqrt(x) |
| c3.q_usd | 1e+06 | 1e+06 |   | match | C3: Q = 1,000,000 USD |
| c4.exploitability_final | 1.78e-11 | 0 |   | match | C4: equilibrium exists (exploitability -$>$ 0) |
| c4.iterations_to_converge | 33 | 1–500 |   | match |   |
| c4.fixed_point_residual | 5.37e-11 | 0 |   | match |   |
| c4.jump_flux | 0.000479 | – |   | measured | mass crossing the guard per step (hybrid reset map) |
| c5.utility_optimal | 0.01746 | – |   | measured |   |
| c5.utility_naive | 0.007453 | – |   | measured |   |
| c5.improvement | 0.01001 | 0–1e+09 |   | match | C5: highest expected utility under shared limits beats naive |
| c5.limits_respected | 1 | 1 |   | match | C5: shared limits |
| c5.free_energy_optimal | 0.006532 | 0–0.008267 |   | match | C5: minimise free energy (risk) – at or below the naive allocation’s |

- c1: C1 path switching: two alternating regimes with regime-optimal parameter vectors θ¹, θ²; the mixed path θ_t = (1 − w_t)θ¹ + w_tθ² follows a hysteresis switch on a noisy regime signal lagged by L steps with a linear ramp; realised utility (P&L − risk charge − transaction costs) of the switched path against the better fixed path as a function of L. Expected: gain $>$ 0 for a timely switch, $<$ 0 onc

- c2: C2 central pricing: a panel of N $>$ 3 assets with P\_t+1 = α I_t + (1 − α) H_t + ε, I_t = P_t + β q_t linear in the signed flow, H_t the mean of the last H ≥ 5 prices; α recovered by pooled OLS (α̂, t-statistic, R²), split-conformal 5-step regions with coverage checked against 1 − δ, and the random-walk baseline.

- c3: C3 stealth execution: Q = 1e6 USD into N ≤ 100 children over V venues; child cost x·g(x) = c x^3/2 from the square-root footprint g(x) = c√x, base cost k·Q and a timing penalty λ per slot; equal vs front-loaded vs random splits, the optimal N under the penalty, and the fitted exponent δ of the per-unit cost (expected 0.5).

- c4: C4 hybrid MFG: 2 modes × M grid states with logit policies on soft Q-values, a crowding mean-field reward and a guard-triggered reset map between modes; damped best-response iteration to the mean-field equilibrium; entropy-regularised exploitability, iterations to converge and the fixed-point residual (expected 0).

- c5: C5: maximise expected utility = return - cost - lambda\*risk - gamma\*grouping under shared limits (gross, per-product, risk budget); compare with naive proportional allocation.

![Toy models for Conjectures 1-5 (test bench, this run).](figures/conjecture_toys.png)

*Toy models for Conjectures 1-5 (test bench, this run).*

### E.6 The working-notes simulations

#### E.6.1 Market making: skew, bands, taking, tuning (NB-01)

`experiments.market_making`; data: simulation; 3.7 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| mm.pnl_no_skew | 1389 | – | ticks | measured | NB-01 worked case |
| mm.share_inside_79_no_skew | 1 | – |   | measured | NB-01 |
| mm.pnl_linear_skew | 1368 | – | ticks | measured | NB-01 worked case |
| mm.share_inside_79_linear_skew | 1 | – |   | measured | NB-01 |
| mm.pnl_band_skew | 1366 | – | ticks | measured | NB-01 worked case |
| mm.share_inside_79_band_skew | 1 | – |   | measured | NB-01 |
| mm.pnl_linear_skew_taking | 1329 | – | ticks | measured | NB-01 worked case |
| mm.share_inside_79_linear_skew_taking | 1 | – |   | measured | NB-01 |
| mm.share_inside_79 | 1 | 0.99–1 |   | match | NB-01: inside +/-79 for 99% of the session (linear skew) |
| mm.taking_layer_pnl_rel_change | -0.02851 | -0.3 |   | match | NB-01: taking cut PnL 2,300 -$>$ 1,600 (-30%) |
| mm.skew_vs_no_skew_pnl_rel_change | -0.01552 | – |   | measured |   |
| mm.decomposition_identity_residual | 1.27e-11 | 0 |   | match | NB-01 rule: PnL = spread capture - adverse selection - inventory cost - overtrading (exact) |
| mm.decomp_spread_capture | 1197 | – | ticks | measured |   |
| mm.decomp_adverse_selection | 157.9 | – | ticks | measured |   |
| mm.decomp_inventory_cost | -329 | – | ticks | measured |   |
| mm.decomp_overtrading | 0 | – | ticks | measured |   |
| mm.decomp_inventory_risk | -416.5 | – | ticks | measured |   |
| mm.decomp_liquidation | 87.5 | – | ticks | measured |   |
| mm.grid_best_risk_aversion | 0.3 | 0.3–1 |   | match | NB-01 grid \[0.3, 0.5, 0.7, 1.0\] |
| mm.grid_best_inventory_limit | 40 | 40–80 |   | match | NB-01 grid \[40, 60, 80\] |

- 4 sessions of 3000 ticks; variants share the same market path (common random numbers)

- the NB-01 absolute numbers (PnL 2,300 / 1,600) are from the note’s own session; the bench compares the variants on its own synthetic market

![Market making: skew, bands, taking, tuning (NB-01) (test bench, this run).](figures/market_making.png)

*Market making: skew, bands, taking, tuning (NB-01) (test bench, this run).*

#### E.6.2 Prosperity quoting rules on a synthetic feed (NB-02/03)

`experiments.prosperity`; data: simulation; 0.19 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| prosperity.pnl_stable | 4.382e+04 | – |   | measured | NB-03 (5 Apr 2025) reported ~3,500 on the competition feed; synthetic feed here, level not comparable |
| prosperity.pnl_drifting | 3.921e+04 | – |   | measured | NB-03 reported ~2,800; synthetic feed here |
| prosperity.note_pnl_stable_2025 | 3500 | – |   | measured | NB-03, 5 April 2025 (the competition’s own feed) |
| prosperity.note_pnl_drifting_2025 | 2800 | – |   | measured | NB-03, 5 April 2025 |
| prosperity.stable_beats_drifting | 1 | 1 |   | match | NB-03: the fixed-fair product earns more |
| prosperity.limits_respected | 1 | 1 |   | match | position limit 50 |
| prosperity.takes | 1355 | – |   | measured |   |
| prosperity.makes | 3200 | – |   | measured |   |
| prosperity.ncskew_drift | -0.01827 | – |   | measured | Chen-Hong-Stein 2001 (NB-03) |
| prosperity.duvol_drift | -0.04463 | – |   | measured | Chen-Hong-Stein 2001 (NB-03) |

- 3000 ticks, two products (fixed-value and drifting), takes strictly inside fair, makes one tick inside the touch with the position penalty

![Prosperity quoting rules on a synthetic feed (NB-02/03) (test bench, this run).](figures/prosperity.png)

*Prosperity quoting rules on a synthetic feed (NB-02/03) (test bench, this run).*

#### E.6.3 Blueprints: stat-arb, trend ensemble, cost-aware allocation (NB-05/06/07)

`experiments.blueprints`; data: simulation; 0.52 s.

| Quantity | Measured | Expected | Unit | Verdict | Source |
|---|---|---|---|---|---|
| Quantity | Measured | Expected | Unit | Verdict | Source |
| statarb.hedge_ratio | 1.498 | 1.5 |   | match | planted beta = 1.5 |
| statarb.adf_t | -7.318 | -1e+09—3.34 |   | match | NB-05: Engle-Granger cointegration (5% critical value -3.34) |
| statarb.halflife_hat | 20.03 | 20 | bars | match | NB-05 (planted 20) |
| statarb.sharpe_oos | 1.538 | – |   | measured | z-score bands 2.0/0.5, 5 bp cost |
| statarb.trades | 129 | – |   | measured |   |
| trend.sharpe_oos | 3.142 | 0–1e+09 |   | match | NB-06: positive on trending regimes (synthetic) |
| trend.max_drawdown | 0.1456 | – | log-return | measured |   |
| trend.turnover | 0.1152 | – |   | measured |   |
| optimiser.improvement | 0.02859 | 0–1e+09 |   | match | NB-07 / C5: beats naive proportional allocation |
| optimiser.limits_respected | 1 | 1 |   | match |   |
| optimiser.utility | 0.043 | – |   | measured |   |
| optimiser.utility_naive | 0.01441 | – |   | measured |   |

- four horizon layers (NB-07): L1 micro (ms-s): order book, microprice, OFI, queue position; L2 intraday (min-h): mean reversion, pairs, market making inventory; L3 swing (days-weeks): trend ensemble, stat-arb baskets, vol regimes; L4 allocation (weeks-months): cost-aware allocation under shared limits (C5)

- 3000 bars; stat-arb pair with planted half-life 20; trend series with 6 alternating drift regimes; 30-asset allocation

![Blueprints: stat-arb, trend ensemble, cost-aware allocation (NB-05/06/07) (test bench, this run).](figures/blueprints.png)

*Blueprints: stat-arb, trend ensemble, cost-aware allocation (NB-05/06/07) (test bench, this run).*

### E.7 Registered hypothesis tests

**Table ?.** Hypothesis tests: verdict and the statistic behind it.

| Hypothesis | Data | Verdict | Statistic |
|---|---|---|---|
| Hypothesis | Data | Verdict | Statistic |
| H1 Aggregation lowers the mean (AT-0 Hyp. 9.1 as stated) | simulation | refuted | h1.mean_residual_max = 1.95e-18 (exp. 0) |
| H2 A universal speed factor such as one half (P1 as first stated) | simulation | refuted | h2.phi_min = 0.1363 (exp. 0–1) |
| H3 The Epps effect is aggregation: kappa(Delta) = kappa_inf Delta/(Delta+tau) | simulation | supported | h3.tau_hat_s = 1.655 (exp. 1–10) |
| H4 Impact is concave in size, I(Q) = Y sigma_d sqrt(Q/V_d) | simulation | supported | h4.exponent_linear_depth = 0.5048 (exp. 0.5) |
| H5 Price changes are linear in order-flow imbalance | simulation | supported | h5.beta_1s = 0.006276 (exp. 0–1e+09) |
| H6 Mixture law and squeezing of event responses (P2) | simulation | supported | h6.mixture_fit_r2_min = 0.9996 (exp. 0.99–1) |
| H7 Bound 1/r composites are lighter than their parts; free and confined ones heavier | real | supported | h7.nuclei_n = 300 |
| H8 Expansion is one rate at all distances after the linear-field split | real | supported | h8.H0 = 72.86 (exp. 73.25) |
| H9 Zeros of Z(t) as cancellation of units; GUE spacings | analytic | supported | h9.height_T = 2000 |
| H10 Central pricing: P\_T+1 = alpha I + (1-alpha) H + eps | simulation | supported | h10.alpha_hat = 0.6007 (exp. 0.6) |
| H11 Stealth-optimal schedule under concave cost | simulation | supported | h11.n_star_grid = 32 (exp. 2–99) |
| H12 Linear inventory skew and the taking layer (NB-01) | simulation | supported | h12.share_inside_79 = 1 (exp. 0.99–1) |

## Appendix F: Index of sources

**Table ?.** Which part of this document compacts which source (labels as in Table 1).

| Source | Its sections | Compacted in |
|---|---|---|
| Source | Its sections | Compacted in |
| GI | manifold, fields, coupling, agents, information graph, coupled geometry, analysis tools | Chapter 2 |
| GI-H | hybrid frames, reset maps, complex states | Chapter 2 (hybrid section) |
| GI-X | cost functional, field PDE, action principle, computational loop, extensions | Chapter 3 |
| MD-1, MD-2 | environment, time-evolving equations, optimal policy, strategy–prediction–risk, graph memory, loop | Chapter 4 |
| WP, WP-M | architecture, graphs, rules, value surface, temporal evolution, applications; the model sketch | Chapter 5, Section 5.8 |
| FS | component summary | Chapter 5 |
| BP §1 | the initial theoretic proposal (five layers) | Chapter 5 |
| BP §2–8 | company, four layers, infrastructure, people, brand | Chapter 24, Chapter 25, Chapter 27 and Chapter 28 |
| DG | five diagrams | Chapter 26 |
| C1–C4 | the four conjecture notes | Chapter 6, Chapter 7, Chapter 8 and Chapter 9 |
| C5 (NB-08, QB) | the final problem | Chapter 10, Section 23.4 |
| AT-0 §1–15, A–D | setup, agents, mergers, multiscale, hypotheses, tests, experiments, implementations, results, appendices A–D | Chapter 11 |
| AT-0 §E–W | finite-agent model to the lumping theorem | Chapter 12 |
| AT-II | the matching rule, the dynamics of the parts, two-sided matching | Chapter 13 |
| AT-III | the exact layer and the hindsight tests; data and code; the template’s application A | Chapter 14, Section 14.13, Section 14.8 |
| AT-III §10, AT-0 §13 | the Bitcoin study | Subappendix D.1, Section 14.11 |
| NB-01 | market making and inventory control | Chapter 15 |
| NB-02, NB-03 | Prosperity playbook and 2025 team log | Chapter 16 |
| NB-04 | options and voucher strategies | Chapter 17 |
| NB-05, NB-06 | stat-arb and trend blueprints | Chapter 18 and Chapter 19 |
| NB-07, QB | multi-layer trading architecture | Chapter 20 |
| NB-09, NB-10 | reinforcement learning and control; multiscale thinking | Chapter 21 and Chapter 22 |
| NB-11, NB-12, QB | reference scraps; getting started; the bucket’s open questions | Chapter 23 |
| LAB | the test bench | Appendix E, Table 30.2 |

=0mu plus 1mu

## Appendix G: References

Every work cited by the source documents, in one flat alphabetical list by first author. The grey tag names the citing documents (keys as in Table 1); entries are kept as the sources give them, partial where the source is partial.

99

*\[NB-02\]* Academiq-AI (2023). IMC Prosperity 1 write-up (outside the top 350; no link given). *\[GI-X\]* Activeloop. What is Potential Fields (glossary entry). <https://www.activeloop.ai/resources/glossary/potential-fields/> *\[GI-X\]* Adaptive connectivity control in networked multi-agent systems. PLOS ONE, <https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0314642> (no authors given in the source). *\[NB-07\]* Advanced Statistical Arbitrage with Reinforcement Learning. arXiv (no authors, identifier or date given in the source). *\[C3\]* Almgren and Chriss. Optimal execution schedules (‘Almgren–Chriss-type schedules’, the benchmark named in Conjecture 3; cited by name only, no year or full reference given). *\[GI-X\]* Analysis and Numerical Approximation of Mean Field Game Partial … (title truncated in the source). Mathematical Institute, University of Oxford, <https://www.maths.ox.ac.uk/node/65382> *\[NB-05, NB-07\]* Avellaneda and Lee. Statistical-arbitrage s-scores (cited by name only; no year or full reference given). *\[NB-01, NB-03, NB-04\]* Avellaneda and Stoikov (2008). The Avellaneda–Stoikov model of optimal quoting in a limit order book: reservation price and inventory skew (cited by name only; the notes give no title or venue). *\[NB-11\]* Ballotta, L. Multivariate additive subordination with applications in finance (paper to be requested from the author; no year or venue given). *\[AT-III\]* Barnet-Lamb, T., Geraghty, D., Harris, M. and Taylor, R. (2011). A family of Calabi–Yau varieties and potential automorphy II. Publications of the RIMS 47(1), 29–98. *\[AT-0\]* Benamou, J.-D. and Brenier, Y. (2000). A computational fluid mechanics solution to the Monge–Kantorovich mass transfer problem. Numerische Mathematik 84(3), 375–393. *\[AT-0\]* Bertucci, C. (2018). Optimal stopping in mean field games, an obstacle problem approach. Journal de Mathématiques Pures et Appliquées 120, 165–194. *\[AT-III\]* Bird, G. A. (1994). Molecular Gas Dynamics and the Direct Simulation of Gas Flows. Oxford University Press. *\[AT-III\]* Bohr, H. and Landau, E. (1914). Ein Satz über Dirichletsche Reihen mit Anwendung auf die $\zeta$-Funktion und die $L$-Funktionen. Rendiconti del Circolo Matematico di Palermo 37, 269–272. *\[AT-II, AT-III\]* Bouchaud, J.-P., Bonart, J., Donier, J. and Gould, M. (2018). Trades, Quotes and Prices: Financial Markets Under the Microscope. Cambridge University Press. *\[AT-II\]* Bouchaud, J.-P., Gefen, Y., Potters, M. and Wyart, M. (2004). Fluctuations and response in financial markets: the subtle nature of ‘random’ price changes. Quantitative Finance 4(2), 176–190. *\[AT-III\]* Bovy, J. (2017). Galactic rotation in Gaia DR1. Monthly Notices of the Royal Astronomical Society 468(1), L63–L67. *\[AT-III\]* Brout, D. et al. (2022). The Pantheon+ analysis: cosmological constraints. The Astrophysical Journal 938, 110. *\[NB-07\]* Buy Low, Sell High: A High Frequency Trading Perspective. SIAM Journal on Financial Mathematics (no authors, volume or date given in the source). *\[AT-0\]* Caines, P. E. and Huang, M. (2021). Graphon mean field games and their equations. SIAM Journal on Control and Optimization 59(6), 4373–4399. *\[AT-0\]* Cardaliaguet, P., Delarue, F., Lasry, J.-M. and Lions, P.-L. (2019). The Master Equation and the Convergence Problem in Mean Field Games. Annals of Mathematics Studies 201, Princeton University Press. *\[AT-0\]* Cardaliaguet, P., Lasry, J.-M., Lions, P.-L. and Porretta, A. (2012). Long time average of mean field games. Networks and Heterogeneous Media 7(2), 279–301. *\[AT-0\]* Cardaliaguet, P. and Lehalle, C.-A. (2018). Mean field game of controls and an application to trade crowding. Mathematics and Financial Economics 12(3), 335–363. *\[AT-0\]* Carmona, R. and Delarue, F. (2018). Probabilistic Theory of Mean Field Games with Applications, Vols. I–II. Springer. *\[AT-0\]* Carmona, R., Delarue, F. and Lacker, D. (2017). Mean field games of timing and models for bank runs. Applied Mathematics & Optimization 76(1), 217–260. *\[NB-01\]* Cartea and Jaimungal. Quoting controls with explicit execution costs and market impact (cited by name only; no year or full reference given). *\[AT-0\]* Chan, P. and Sircar, R. (2015). Bertrand and Cournot mean field games. Applied Mathematics & Optimization 71(3), 533–569. *\[NB-03\]* Chen, Hong and Stein (2001). Forecasting return skewness with cross-sectional regressions; the source of the NCSKEW and DUVOL crash-risk measures (cited by name and year only). *\[GI\]* Computational Mean-field Games on Manifolds. arXiv:2206.01622, <https://arxiv.org/pdf/2206.01622> (no authors given in the source). *\[AT-II, AT-III\]* Cont, R., Kukanov, A. and Stoikov, S. (2014). The price impact of order book events. Journal of Financial Econometrics 12(1), 47–88. *\[GI-X\]* Coordination of multi-agent systems on interacting physical and … (title truncated in the source). ScienceDirect, <https://www.sciencedirect.com/science/article/abs/pii/S0167691117300038> *\[NB-12\]* DataCamp. Introduction to Python for Finance (course). *\[AT-0\]* Dawson, D. A. and Gärtner, J. (1987). Large deviations from the McKean–Vlasov limit for weakly interacting diffusions. Stochastics 20(4), 247–308. *\[GI-X\]* DayTrading.com. Geometric Mechanics in Finance, Markets & Trading. <https://www.daytrading.com/geometric-mechanics> *\[AT-II, AT-III\]* Deng, Y., Hani, Z. and Ma, X. (2025). Hilbert’s sixth problem: derivation of fluid equations via Boltzmann’s kinetic theory. arXiv:2503.01800. *\[AT-III\]* Dong, E., Du, H. and Gardner, L. (2020). An interactive web-based dashboard to track COVID-19 in real time. The Lancet Infectious Diseases 20(5), 533–534. *\[AT-0\]* Drăgulescu, A. and Yakovenko, V. M. (2000). Statistical mechanics of money. The European Physical Journal B 17(4), 723–729. *\[AT-II\]* Duffie, D. and Singleton, K. J. (1993). Simulated moments estimation of Markov models of asset prices. Econometrica 61(4), 929–952. *\[AT-III\]* Edwards, H. M. (1974). Riemann’s Zeta Function. Academic Press. *\[AT-III\]* Elipot, S., Lumpkin, R., Perez, R. C., Lilly, J. M., Early, J. J. and Sykulski, A. M. (2016). A global surface drifter data set at hourly resolution. Journal of Geophysical Research: Oceans 121, 2937–2966. *\[AT-II\]* Epps, T. W. (1979). Comovements in stock prices in the very short run. Journal of the American Statistical Association 74(366), 291–298. *\[AT-0\]* Freidlin, M. I. and Wentzell, A. D. (2012). Random Perturbations of Dynamical Systems, 3rd ed. Springer. *\[AT-III\]* Gaia Collaboration, Vallenari, A. et al. (2023). Gaia Data Release 3: summary of the content and survey properties. Astronomy & Astrophysics 674, A1. *\[AT-III\]* Goldstein, H., Poole, C. and Safko, J. (2002). Classical Mechanics, 3rd ed. Addison-Wesley. *\[AT-0\]* Gomes, D. A. and Saúde, J. (2014). Mean field games models—a brief survey. Dynamic Games and Applications 4(2), 110–154. *\[AT-II\]* Gouriéroux, C., Monfort, A. and Renault, E. (1993). Indirect inference. Journal of Applied Econometrics 8(S1), S85–S118. *\[AT-II\]* Heisler, J., Tremaine, S. and Bahcall, J. N. (1985). Estimating the masses of galaxy groups: alternatives to the virial theorem. The Astrophysical Journal 298, 8–17. *\[NB-07\]* High-frequency Statistical Arbitrage Strategy Based on Stationarized Order Flow Imbalance. ScienceDirect (no authors or date given in the source). *\[AT-0\]* Hopenhayn, H. A. (1992). Entry, exit, and firm dynamics in long run equilibrium. Econometrica 60(5), 1127–1150. *\[AT-0\]* Huang, M., Malhamé, R. P. and Caines, P. E. (2006). Large population stochastic dynamic games: closed-loop McKean–Vlasov systems and the Nash certainty equivalence principle. Communications in Information and Systems 6(3), 221–252. *\[AT-III\]* Hunt, E. L. and Reffert, S. (2024). Improving the open cluster census. III. Using cluster masses, radii, and dynamics to create a cleaned open cluster catalogue. Astronomy & Astrophysics 686, A42. *\[NB-07\]* An innovative high-frequency statistical arbitrage in Chinese futures market. ScienceDirect (no authors or date given in the source). *\[NB-07, NB-12\]* Investopedia. Statistical Arbitrage (article) \[NB-07\]; also the general reference for terminology \[NB-12\]. (No links given.) *\[AT-III\]* Kahn, F. D. and Woltjer, L. (1959). Intergalactic matter and the Galaxy. The Astrophysical Journal 130, 705–717. *\[NB-02\]* Kang, Kim and Lee (2024). IMC Prosperity 2 write-up (13th place). (No link given in the source.) *\[AT-III\]* Karachentsev, I. D. et al. (2009). The very local Hubble flow. Monthly Notices of the Royal Astronomical Society 393, 1265–1274. *\[AT-III\]* Karachentsev, I. D., Makarov, D. I. and Kaisina, E. I. (2013). Updated nearby galaxy catalog. The Astronomical Journal 145, 101. *\[GI\]* Kearns et al. Graphical games: ‘a graphical game represents such networked payoffs’ (cited by name only; no year, title or venue given). *\[NB-12\]* Khan Academy. Free material for probability and statistics. *\[AT-III\]* Knapp, K. R., Kruk, M. C., Levinson, D. H., Diamond, H. J. and Neumann, C. J. (2010). The International Best Track Archive for Climate Stewardship (IBTrACS). Bulletin of the American Meteorological Society 91, 363–376. *\[GI-X, NB-12\]* Knowledgebase (the author’s own working files and repositories). Deep Thoughts on Trading Strategy and Knowledgebase (`Deep thoughts.docx`, `Knowledgebase.docx`): conceptual remarks on multi-horizon trading strategies and variational principles in decision making \[GI-X\]; the WTech, Knowledgebase, KB and TMRW repositories \[NB-12\]. *\[GI-X\]* Kobayashi et al. (2024). Information geometry of dynamics on graphs and hypergraphs. Information Geometry, <https://link.springer.com/article/10.1007/s41884-023-00125-w> *\[AT-0\]* Kolmogorov, A. N. (1941). The local structure of turbulence in incompressible viscous fluid for very large Reynolds numbers. Doklady Akademii Nauk SSSR 30, 301–305. *\[AT-0, GI-X\]* Lasry, J.-M. and Lions, P.-L. (2007). Mean field games. Japanese Journal of Mathematics 2(1), 229–260. (GI-X cites ‘Lasry and Lions’ mean-field game theory’ by name.) *\[AT-III\]* Lelli, F., McGaugh, S. S., Schombert, J. M. and Pawlowski, M. S. (2017). One law to rule them all: the radial acceleration relation of galaxies. The Astrophysical Journal 836, 152. *\[AT-II\]* Lillo, F. and Farmer, J. D. (2004). The long memory of the efficient market. Studies in Nonlinear Dynamics & Econometrics 8(3). *\[NB-02\]* Linear Utility (2024). IMC Prosperity 2 write-up (2nd place). (No link given in the source.) *\[AT-II\]* Lo, A. W. and MacKinlay, A. C. (1990). When are contrarian profits due to stock market overreaction? Review of Financial Studies 3(2), 175–205. *\[AT-III\]* Lynden-Bell, D. (1981). The Observatory 101, 111. (No title given in the source.) *\[NB-02\]* Maddocks, E. How to trade with secretive fish. Medium (article on the Prosperity 2 round-1 manual challenge; no link or date given). *\[AT-0\]* Matějka, F. and McKay, A. (2015). Rational inattention to discrete choices: a new foundation for the multinomial logit model. American Economic Review 105(1), 272–298. *\[AT-III\]* McGaugh, S. S., Lelli, F. and Schombert, J. M. (2016). Radial acceleration relation in rotationally supported galaxies. Physical Review Letters 117, 201101. *\[NB-07\]* Mean Field Game of High-Frequency Anticipatory Trading. arXiv (no authors, identifier or date given in the source). *\[AT-III\]* Montgomery, H. L. (1973). The pair correlation of zeros of the zeta function. Proceedings of Symposia in Pure Mathematics 24, 181–193. *\[NB-09\]* A Neural RDE approach for continuous-time non-Markovian stochastic control problems. arXiv:2306.14258, <https://arxiv.org/abs/2306.14258> (no authors given in the source). *\[AT-III\]* Odlyzko, A. M. (1987). On the distribution of spacings between zeros of the zeta function. Mathematics of Computation 48, 273–308. *\[NB-02\]* Okon, M. (2023). IMC Prosperity 1 write-up (57th place; no link given). *\[AT-0\]* Parise, F. and Ozdaglar, A. (2023). Graphon games: a statistical framework for network games and interventions. Econometrica 91(1), 191–225. *\[AT-III\]* Particle Data Group, Navas, S. et al. (2024). Review of particle physics. Physical Review D 110, 030001. *\[AT-0\]* Pavliotis, G. A. and Stuart, A. M. (2008). Multiscale Methods: Averaging and Homogenization. Springer. *\[AT-0\]* Perrin, S., Pérolat, J., Laurière, M., Geist, M., Élie, R. and Pietquin, O. (2020). Fictitious play for mean field games: continuous time analysis and applications. In Advances in Neural Information Processing Systems 33 (NeurIPS). *\[AT-III\]* Planck Collaboration, Aghanim, N. et al. (2020). Planck 2018 results. VI. Cosmological parameters. Astronomy & Astrophysics 641, A6. *\[AT-III\]* Platt, D. and Trudgian, T. (2021). The Riemann hypothesis is true up to $3\cdot10^{12}$. Bulletin of the London Mathematical Society 53(3), 792–797. *\[NB-07\]* PrimeXBT. Tutorials, for the standard set of on-chain metrics. (No link or date given.) *\[GI-X\]* PyQuant News. How to use the information coefficient to measure your alpha. <https://www.pyquantnews.com/the-pyquant-newsletter/information-coefficient-measure-your-alpha> *\[NB-09\]* q-Learning in Continuous Time. arXiv:2207.00713, <https://arxiv.org/abs/2207.00713> (no authors given in the source). *\[NB-07\]* QuantLink. The Evolution of Statistical Arbitrage: Rise of Alternative Data and Shorter Holding Periods. (No link or date given.) *\[NB-12\]* Quantra by QuantInsti. Trading in Milliseconds (course): microstructure, latency types, order-flow calculation with the Lee–Ready algorithm, and mid-frequency strategies. *\[NB-12\]* QuantStart. Strategy identification, backtesting and execution systems (web resource; no link given). *\[AT-III\]* Riess, A. G. et al. (2022). A comprehensive measurement of the local value of the Hubble constant with 1 km s$^{-1}$ Mpc$^{-1}$ uncertainty from the Hubble Space Telescope and the SH0ES team. The Astrophysical Journal Letters 934, L7. *\[AT-II\]* Risken, H. (1989). The Fokker–Planck Equation: Methods of Solution and Applications, 2nd ed. Springer. *\[NB-02\]* Romon, G. IMC Prosperity write-up (30th place; edition not recorded, no link given). *\[AT-0\]* Rózsa, Z. and Tóth, J. (2004). Exact linear lumping in abstract spaces. Proceedings of the 7th Colloquium on the Qualitative Theory of Differential Equations, No. 21, pp. 1–20. (Theorems 1 and 4 discuss the intertwining and kernel-invariance conditions.) *\[GI-X\]* Ryzhik (2018). Mean-Field Game Notes (lecture notes, Stanford). <https://math.stanford.edu/~ryzhik/STANFORD/MEAN-FIELD-GAMES/notes-mean-field.pdf> *\[AT-III\]* Schoenfeld, L. (1976). Sharper bounds for the Chebyshev functions $\theta(x)$ and $\psi(x)$. II. Mathematics of Computation 30, 337–360. *\[AT-III\]* Scolnic, D. et al. (2022). The Pantheon+ analysis: the full data set and light-curve release. The Astrophysical Journal 938, 113. *\[AT-III\]* Selberg, A. (1946). Contributions to the theory of the Riemann zeta-function. Archiv for Mathematik og Naturvidenskab 48(5), 89–155. *\[GI\]* A Simple Differential Geometry for Networks and its Generalizations. arXiv:1910.06258, <https://ar5iv.org/pdf/1910.06258> (no authors given in the source). *\[AT-0\]* Sims, C. A. (2003). Implications of rational inattention. Journal of Monetary Economics 50(3), 665–690. *\[NB-02\]* Sinott, N. IMC Prosperity write-up (91st place; edition not recorded, no link given). *\[GI-X\]* SmythOS. Agent-based Modeling in Finance: Revolutionizing Market Simulations and Risk Management. <https://smythos.com/ai-industry-solutions/finance/agent-based-modeling-in-finance/> *\[NB-09\]* Solving and Learning non-Markovian Stochastic Control problems in continuous-time with Neural RDEs. OpenReview (no authors or link given in the source). *\[GI-X\]* Some analytically solvable problems of the mean-field games theory. arXiv:1911.09441, <https://arxiv.org/abs/1911.09441> (no authors given in the source). *\[AT-II, AT-III\]* Spitzer, L. (1987). Dynamical Evolution of Globular Clusters. Princeton University Press. *\[NB-11\]* A paper on CTA trend following (background reading for the questions prepared for Artur Sepp; no authors or title given). SSRN 3167787, <https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3167787> *\[NB-02, NB-03\]* Stanford Cardinal (2023). IMC Prosperity 1 write-up and code (2nd place). GitHub: <https://github.com/ShubhamAnandJain/IMC-Prosperity-2023-Stanford-Cardinal>. *\[AT-II\]* Stoikov, S. (2018). The micro-price: a high-frequency estimator of future prices. Quantitative Finance 18(12), 1959–1966. *\[GI\]* The structure and dynamics of multilayer networks. PMC, <https://pmc.ncbi.nlm.nih.gov/articles/PMC7332224/> (no authors given in the source). *\[AT-0\]* Sutton, R. S., Precup, D. and Singh, S. (1999). Between MDPs and semi-MDPs: a framework for temporal abstraction in reinforcement learning. Artificial Intelligence 112(1–2), 181–211. *\[AT-0\]* Sznitman, A.-S. (1991). Topics in propagation of chaos. In École d’Été de Probabilités de Saint-Flour XIX—1989, Lecture Notes in Mathematics 1464, pp. 165–251. Springer. *\[NB-02\]* Teather, D. IMC Prosperity write-up (381st place; edition not recorded, no link given). *\[AT-III\]* Tempel, E. et al. (2017). Merging groups and clusters of galaxies from the SDSS data. The catalogue of groups and potentially merging systems. Astronomy & Astrophysics 602, A100. *\[NB-08\]* Tomorrow Capital Research. Tomorrow’s Conjectures: the five open problems (public posts; full statements at <https://lnkd.in/dPKxZcKc>). *\[AT-II, AT-III\]* Tóth, B., Lempérière, Y., Deremble, C., de Lataillade, J., Kockelkoren, J. and Bouchaud, J.-P. (2011). Anomalous price impact and the critical nature of liquidity in financial markets. Physical Review X 1, 021006. *\[AT-0\]* Tullock, G. (1980). Efficient rent seeking. In J. M. Buchanan, R. D. Tollison and G. Tullock (eds.), Toward a Theory of the Rent-Seeking Society, pp. 97–112. Texas A&M University Press. *\[AT-III\]* Tully, R. B. et al. (2023). Cosmicflows-4. The Astrophysical Journal 944, 94. *\[AT-III\]* Turing, A. M. (1953). Some calculations of the Riemann zeta-function. Proceedings of the London Mathematical Society s3-3(1), 99–117. *\[NB-02, NB-03\]* van Merle, J. (2024). IMC Prosperity 2 write-up and code (9th place). GitHub repositories: <https://github.com/jmerle/imc-prosperity-2> (write-up and trader), <https://github.com/jmerle/imc-prosperity-2-backtester> (backtester) and <https://github.com/jmerle/imc-prosperity-2-visualizer> (visualizer). *\[GI-X\]* Variational Mean Field Games. cvgmt preprint (PDF), <https://cvgmt.sns.it/media/doc/paper/2979/BenCarSan-v4.pdf> (no authors given in the source). *\[NB-12\]* Wharton (Coursera). Quantitative modelling course (named as a structured, possibly paid option for probability and statistics). *\[GI-X\]* Wikipedia. Hybrid system. <https://en.wikipedia.org/wiki/Hybrid_system> *\[GI\]* Wikipedia. Laplacian matrix. <https://en.wikipedia.org/wiki/Laplacian_matrix> *\[GI\]* Wikipedia. Multi-agent system. <https://en.wikipedia.org/wiki/Multi-agent_system> *\[GI-X\]* Wikipedia. Quantum finance. <https://en.wikipedia.org/wiki/Quantum_finance> *\[GI-X\]* Wikipedia. Quantum game theory. <https://en.wikipedia.org/wiki/Quantum_game_theory> *\[GI\]* Wikipedia. Ricci flow. <https://en.wikipedia.org/wiki/Ricci_flow> *\[NB-03\]* Xing and Yang (2019). The potential tipping points indicator (PTPI) for crash detection (cited by name and year only). *\[NB-07\]* XTB. The Two Faces of a High Frequency Trade. (No link or date given.) *\[AT-II, AT-III\]* Zwicky, F. (1933). Die Rotverschiebung von extragalaktischen Nebeln. Helvetica Physica Acta 6, 110–127.

