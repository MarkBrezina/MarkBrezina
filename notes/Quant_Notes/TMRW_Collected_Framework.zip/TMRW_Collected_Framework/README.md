# Tomorrow Capital Research — The Collected Framework

Single-source compendium of the research programme (April 2025 – November 2026) and the test bench
that re-runs every statement of it that can be run.

```
TMRW_Collected_Framework/
├── TMRW_Collected_Framework.pdf   the compendium (198 pages, 8 parts, 31 chapters, 7 appendices)
├── compendium.md                  the same document as GitHub-flavoured markdown (tables, equations, figures)
├── README.md                      this file
├── figures/                       every figure as PNG/JPG (for the markdown edition and reuse)
├── latex/                         the LaTeX source: main.tex, src/*.tex, figures/, md/ (markdown tools)
│                                  build:  latexmk -pdf main.tex        markdown:  bash md/build_md.sh
└── tmrw_lab/                      the test bench (Python package) with the results of the last run
                                   run:    python run_all.py --preset quick && python make_appendix.py
```

## What is in the compendium

| Part | Content | Sources |
|---|---|---|
| I  The programme at a glance | chronology, the three propositions as finally stated, the matching rule, the table of expectations with the bench values, the short answer | all |
| II The geometric–informational framework | manifold, fields, coupling, agents, information graph, hybrid frames and reset maps; the extended overview (cost functional, field PDE, action principle, computational loop) | GI, GI-H, GI-X |
| III The market model | market dynamics drafts (graphs, value surface, Bellman on R−L, RL), the whitepaper, the model sketch (forces, Lagrangian, action), the framework summary, the first five-layer proposal | MD-1, MD-2, WP, WP-M, FS, BP §1 |
| IV The five conjectures | C1 path switching, C2 central pricing, C3 stealth-optimal distribution, C4 the full market model, C5 the final problem | C1–C4, NB-08, QB |
| V  Aggregation theory | the original setup (agents, mergers, mean field, hypotheses, experiments, Bitcoin study), the rigorous layer (E–W incl. the lumping theorem), the matching rule (AT-II), the collected account with the hindsight tests on societies, gases, nuclei, hadrons, collider events, galaxies, markets and the zeta function (AT-III), the dark-energy placeholder | AT-0, AT-II, AT-III |
| VI Working notes | market making and inventory control, the Prosperity competitions, options and vouchers, stat-arb and trend blueprints, the multi-layer architecture, RL and control, multiscale thinking, the research toolkit | NB-01 … NB-12, QB |
| VII The operating plan | the four layers of the firm, infrastructure and model layout, the five diagrams, people and governance, brand | BP, DG |
| VIII Synthesis | crosswalk of the vocabularies, conjectures ↔ theorems ↔ engines, reconciliation of the disagreements, the ledger of every headline number, hypotheses by status, open problems | editorial |
| Appendices | notation; where the proofs are; data and code; the Bitcoin study tables; **the test-bench run** (every module's numbers against the compendium's expectations); index of sources; 129 references | |

Every statement carries a status tag — `[PROVED] [KNOWN RESULT] [HYPOTHESIS] [CONJECTURE] [MEASURED]
[PENDING RUN] [REFUTED AS STATED] [SETUP] [PLAN] [PRACTICE] [LOG]` — and a source label such as
`[AT-III §6.2]`. Everything not in a source is marked *editorial*.

## The test bench (`tmrw_lab`)

```
pip install -e tmrw_lab            # numpy, scipy, pandas, matplotlib, mpmath, requests
pip install -e "tmrw_lab[full]"    # + statsmodels, scikit-learn, periodictable, particle
cd tmrw_lab
python run_all.py --preset quick   # ~1 min: 13 experiments + 12 hypothesis tests -> results/
python run_all.py                  # standard preset;  --preset full = the sizes of AT-III (hours)
AGG_OFFLINE=1 python run_all.py    # no network: synthetic data with planted answers
python run_all.py --only society zeta --skip-hypotheses
python make_appendix.py            # regenerates latex/src/labrun_body.tex (Appendix E) from results/summary.json
python -m pytest -q                # unit tests of the exact layer
```

* `core/identities.py` — the exact layer as functions (König split, speed ratio, collective share,
  turbulence identity, mean/Jensen, cascade, mixture law, squeezing, linear-field split with Oort's
  constants, invariant mass, volatility subadditivity with the gap identity, virial mass and sign law,
  Epps law); `core/lumping.py` (exact linear lumping CA = BC), `core/mfg.py` (logit policies, mean-field
  fixed points, exploitability, hierarchical consistency, quenches, turnpike window), `core/impact.py`
  (OFI, microprice, square-root impact, propagator, Hurst, the book as a potential), `core/matching.py`
  (the matching rule as a checker, two-sided matching), `core/riemann_siegel.py` (Z(t) as an aggregate).
* `data/` — loaders that reach public hosts (NYT and JHU COVID-19, the GDP table, Pantheon+; isotope and
  hadron masses from `periodictable` / `particle`) and synthetic generators with planted answers for the
  hosts that are not reachable (Binance, Tardis, CERN open data, IAEA, Gaia, FRED, Yahoo/Stooq).
* `experiments/` — exact_layer, society, gas_beam, nuclei_hadrons, expansion, zeta, markets, order_book,
  bitcoin_restoration, conjecture_toys, market_making, prosperity, blueprints.
* `hypotheses/` — H1–H12, each with a verdict (supported / refuted / inconclusive); `conjectures/` —
  toys for C1–C5; `micro/` — Avellaneda–Stoikov, the range-bound market-making simulator, Prosperity
  quoting, Hawkes book, voucher surface; `strategies/` — stat-arb pipeline, trend ensemble, cost-aware optimiser.

Every result records its data origin (real / synthetic / simulation / analytic). A value from a
synthetic stand-in tests the code path, not the world; the appendix and the tables say which is which.

## Reading paths

* Results only: Part I, then Part VIII and Appendix E.
* The mathematics: Parts II–V (the exact layer is Chapter 14 §3; the proofs sit under the statements).
* The desk: Part VI, then `tmrw_lab/micro` and `tmrw_lab/strategies`.
* The firm: Part VII.
