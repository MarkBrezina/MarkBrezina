"""H3 -- The Epps effect is aggregation (AT-II Hyp. 4.3 / 4.4).

If the units respond to a common move with lags τ_i of order τ, the collective share measured on bars
of length Δ follows κ(Δ) ≈ κ_∞ Δ/(Δ + τ) with τ of a few seconds (AT-II measured ρ_∞ = 0.813, τ ≈ 5 s on
ten coins).  The test simulates coin returns at 1 s resolution whose factor loadings arrive with
exponential lags (mean τ = 5 s), measures κ(Δ) for Δ from 1 s to 10 min, fits κ_∞ and τ, and checks
monotonicity and the recovered τ.  If the markets loader reaches real minute data it adds the
real-data fit as a second number.
"""
from __future__ import annotations
import numpy as np

from ..core import identities as I
from ..result import Result
from ._common import verdict_from

DELTAS = np.array([1, 2, 5, 10, 20, 30, 60, 120, 300, 600], dtype=float)


def simulate_lagged_coins(rng, n_coins, n_seconds, tau=5.0, kappa_inf=0.8):
    """Coin returns at 1 s: x_i = beta * (f filtered by a first-order lag with time constant tau_i) + noise,
    tau_i ~ Exp(tau).  A coin's response to the common move is spread over a few seconds."""
    f = rng.normal(size=n_seconds)
    beta = np.sqrt(kappa_inf / (1 - kappa_inf))          # loading so that kappa_inf is the long-run share
    x = np.zeros((n_seconds, n_coins))
    for i in range(n_coins):
        ti = max(rng.exponential(tau), 0.2)
        k = np.arange(0, int(8 * ti) + 1)
        kern = np.exp(-k / ti); kern /= kern.sum()
        resp = np.convolve(f, kern)[:n_seconds]
        x[:, i] = beta * resp + rng.normal(size=n_seconds)
    return x


def kappa_by_bar(x, deltas):
    """Variance-based collective share on bars of length Delta: sum_bars |X|^2 / sum_bars sum_i w_i |x_i|^2."""
    out = []
    w = np.full(x.shape[1], 1.0 / x.shape[1])
    for d in deltas:
        d = int(d)
        n = (len(x) // d) * d
        bars = x[:n].reshape(-1, d, x.shape[1]).sum(axis=1)
        X = bars @ w
        out.append(float(np.sum(X ** 2) / np.sum(w * np.sum(bars ** 2, axis=0))))
    return np.array(out)


def run(cfg) -> Result:
    res = Result(name="hypotheses.h03_epps_aggregation",
                 title="H3 The Epps effect is aggregation: kappa(Delta) = kappa_inf Delta/(Delta+tau)")
    rng = np.random.default_rng(cfg.seed)
    n_coins = cfg.sizes["n_coins"]
    n_seconds = min(cfg.sizes["n_bars"] * 60, 400_000)
    tau_true = 5.0
    x = simulate_lagged_coins(rng, n_coins, n_seconds, tau=tau_true)
    kap = kappa_by_bar(x, DELTAS)
    kinf, tau_hat = I.epps_tau_fit(DELTAS, kap)
    fit = I.epps_law(DELTAS, kinf, tau_hat)
    r2 = 1 - np.sum((kap - fit) ** 2) / max(np.sum((kap - kap.mean()) ** 2), 1e-300)
    mono = float(np.mean(np.diff(kap) >= -0.01))
    res.add("h3.tau_hat_s", tau_hat, expected=1.0, expected_hi=10.0, unit="s",
            source="AT-II Hyp 4.4: tau of a few seconds (fitted; the planted adjustment time is 5 s)")
    res.add("h3.planted_adjustment_time_s", tau_true, unit="s")
    res.add("h3.kappa_inf_hat", kinf, expected=0.8, tol=0.2, source="AT-II: rho_inf = 0.813 on ten coins (planted 0.8)")
    res.add("h3.fit_r2", r2, expected=0.9, expected_hi=1.0, source="functional form kappa_inf Delta/(Delta+tau) (approximate for an exponential response)")
    res.add("h3.monotone_share", mono, expected=1.0, abs_tol=0.15, source="kappa rises with Delta")
    res.add("h3.kappa_1s", kap[0]); res.add("h3.kappa_600s", kap[-1])
    res.data_origin = "simulation"
    # real data, if the markets loader is available and reaches a host
    try:
        from ..data import loaders_markets as LM
        data, origin = LM.load_crypto_minutes(cfg)
        if data is not None and origin == "real":
            arr = np.log(np.asarray(data, float)); r = np.diff(arr, axis=0)
            d_min = np.array([1, 2, 5, 10, 15, 30, 60], float)
            k_real = kappa_by_bar(r, d_min)
            ki, th = I.epps_tau_fit(d_min * 60, k_real)
            res.add("h3.real_tau_hat_s", th, expected=5.0, tol=3.0, unit="s", source="AT-II: tau ~ 5 s (real minute data; coarse)")
            res.add("h3.real_kappa_1min", k_real[0], expected=0.745, tol=0.3, source="AT-II Fig 1b: 0.745 at 1 min")
            res.data_origin = "real"
            res.note("real minute data reached; the minute grid cannot resolve a 5 s lag, so the real tau is only indicative")
    except Exception as e:  # noqa: BLE001
        res.note(f"markets loader not used ({type(e).__name__})")
    res.note(f"{n_coins} simulated coins at 1 s, {n_seconds} s, first-order response with time constants ~ Exp(5 s); "
             "variance-based kappa on bars 1 s .. 600 s fitted by the Epps form (the fitted tau is a few times smaller "
             "than the adjustment time constant, as for an exponential response)")
    verdict_from(res, supported=(r2 > 0.9 and mono > 0.8 and 0.5 <= tau_hat <= 20.0 and abs(kinf - 0.8) < 0.2))
    return res
