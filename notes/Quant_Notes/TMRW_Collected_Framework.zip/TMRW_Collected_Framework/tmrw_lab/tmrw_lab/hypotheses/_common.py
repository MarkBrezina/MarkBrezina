"""Shared helpers for the hypothesis tests."""
from __future__ import annotations
import numpy as np


def verdict_from(res, supported: bool, inconclusive: bool = False) -> None:
    res.verdict = "inconclusive" if inconclusive else ("supported" if supported else "refuted")


def ols(y, X):
    """OLS with intercept: returns beta (without intercept), t-stats, R²."""
    y = np.asarray(y, float)
    X = np.asarray(X, float)
    if X.ndim == 1:
        X = X[:, None]
    A = np.column_stack([np.ones(len(y)), X])
    beta, *_ = np.linalg.lstsq(A, y, rcond=None)
    resid = y - A @ beta
    n, k = A.shape
    s2 = resid @ resid / max(n - k, 1)
    cov = s2 * np.linalg.pinv(A.T @ A)
    t = beta / np.sqrt(np.maximum(np.diag(cov), 1e-300))
    r2 = 1 - resid @ resid / max(((y - y.mean()) ** 2).sum(), 1e-300)
    return beta[1:], t[1:], float(r2)


def correlated_factor_panel(rng, n_units, n_steps, rho=0.3, sigma_spread=0.5):
    """Unit 'velocities' x_{t,i} = beta_i f_t + e_{t,i} with heterogeneous sigmas; weights random."""
    f = rng.normal(size=n_steps)
    sig = np.exp(rng.normal(0, sigma_spread, n_units))
    beta = np.sqrt(rho) * sig
    e = rng.normal(size=(n_steps, n_units)) * np.sqrt(1 - rho) * sig
    x = f[:, None] * beta + e
    w = rng.pareto(1.5, n_units) + 1
    return x, w / w.sum()
