"""H1 -- "Aggregation lowers the mean" (AT-0 Hypothesis 9.1 / P1 as first stated).

AT-III Thm 3.3: with fixed weights the time-mean of the aggregate equals the weighted mean of the
units' time-means exactly; compound growth of the whole is *higher* than the weighted mean of the
parts' compound growth (Jensen).  So the hypothesis as stated is refuted; what aggregation lowers is
speed and turbulence (H2).  The test simulates panels with heterogeneous units, weights and
correlation and measures the mean residual and the Jensen gap.
"""
from __future__ import annotations
import numpy as np

from ..core import identities as I
from ..result import Result
from ._common import correlated_factor_panel, verdict_from


def run(cfg) -> Result:
    res = Result(name="hypotheses.h01_mean_not_lowered",
                 title="H1 Aggregation lowers the mean (AT-0 Hyp. 9.1 as stated)")
    rng = np.random.default_rng(cfg.seed)
    n_units = cfg.sizes["n_units"]; n_steps = cfg.sizes["n_steps"]; n_trials = cfg.sizes["n_trials"]
    resid, gaps, lowered = [], [], 0
    for k in range(n_trials):
        rho = rng.uniform(0.0, 0.9)
        x, w = correlated_factor_panel(rng, n_units, n_steps, rho=rho)
        x = 0.01 * x + rng.normal(0.0005, 0.0005)       # returns with a small drift
        m_agg, agg_m = I.mean_preserved(x, w)
        resid.append(abs(m_agg - agg_m))
        if m_agg < agg_m - 1e-12:
            lowered += 1
        r = np.clip(x, -0.9, None)
        g_whole, g_parts, gap = I.jensen_growth_gap(r, w)
        gaps.append(gap)
    res.add("h1.mean_residual_max", max(resid), expected=0.0, abs_tol=1e-12, unit="",
            source="AT-III Thm 3.3 (mean preserved exactly)")
    res.add("h1.share_trials_mean_lowered", lowered / n_trials, expected=0.0, abs_tol=0.0,
            source="AT-0 Hyp. 9.1 predicts 1.0")
    res.add("h1.jensen_gap_min", min(gaps), expected=0.0, expected_hi=1.0,
            source="AT-III Thm 3.3 (Jensen: whole's compound growth >= parts' mean)")
    res.add("h1.jensen_gap_mean", float(np.mean(gaps)))
    res.data_origin = "simulation"
    res.note(f"{n_trials} panels of {n_units} units x {n_steps} steps, correlation drawn in [0, 0.9]")
    res.note("The mean of the aggregate equals the weighted mean of the unit means to machine precision in every "
             "trial; compound growth of the whole is never below the weighted mean of the parts'. "
             "The hypothesis as stated (aggregation lowers the mean) is refuted; the corrected statement "
             "(aggregation lowers speed and turbulence, not the mean) is H2.")
    verdict_from(res, supported=(lowered / n_trials > 0.5))
    return res
