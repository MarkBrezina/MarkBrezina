"""H5 -- Price changes are linear in order-flow imbalance at short horizons (AT-II Known 5.2, eq. OFI).

Queue-reactive book (Cont, Kukanov & Stoikov 2014): the best bid and ask are queues fed by limit
orders, drained by cancellations and market orders; the mid moves one tick when a queue empties.
The order-flow imbalance OFI = Σ (e_n) with e_n = ±Δq at the best quotes predicts the mid change
linearly, ΔP ≈ β·OFI, with β ≈ 1/(2·average depth).  The test simulates the book, computes OFI and ΔP
on windows of 1 s, 10 s and 60 s (at 100 events per second), and regresses.
"""
from __future__ import annotations
import numpy as np

from ..result import Result
from ._common import ols, verdict_from


def simulate_queue_book(rng, n_events, depth0=50.0, p_market=0.25, p_cancel=0.3, p_limit=0.45):
    bid_q = depth0; ask_q = depth0; mid = 0.0
    ofi = np.zeros(n_events); dmid = np.zeros(n_events)
    for n in range(n_events):
        u = rng.random(); side = rng.random() < 0.5     # True: bid side
        size = rng.exponential(5.0)
        e = 0.0
        if u < p_market:                               # market order hits the opposite queue
            if side:
                bid_q -= size; e -= size
            else:
                ask_q -= size; e += size
        elif u < p_market + p_cancel:
            if side:
                bid_q -= min(size, bid_q * 0.5); e -= min(size, bid_q)
            else:
                ask_q -= min(size, ask_q * 0.5); e += min(size, ask_q)
        else:
            if side:
                bid_q += size; e += size
            else:
                ask_q += size; e -= size
        if bid_q <= 0:
            mid -= 1.0; bid_q = depth0 * rng.uniform(0.5, 1.5); dmid[n] = -1.0
        if ask_q <= 0:
            mid += 1.0; ask_q = depth0 * rng.uniform(0.5, 1.5); dmid[n] = +1.0
        ofi[n] = e
    return ofi, dmid


def run(cfg) -> Result:
    res = Result(name="hypotheses.h05_ofi_law", title="H5 Price changes are linear in order-flow imbalance")
    rng = np.random.default_rng(cfg.seed)
    n_events = cfg.sizes["n_book_events"]
    ofi, dmid = simulate_queue_book(rng, n_events)
    events_per_s = 100
    r2s = {}
    for horizon_s in (1, 10, 60):
        win = horizon_s * events_per_s
        m = (len(ofi) // win) * win
        if m < 5 * win:
            continue
        o = ofi[:m].reshape(-1, win).sum(axis=1); d = dmid[:m].reshape(-1, win).sum(axis=1)
        b, t, r2 = ols(d, o)
        r2s[horizon_s] = (b[0], t[0], r2)
        res.add(f"h5.beta_{horizon_s}s", b[0], expected=0.0, expected_hi=1e9, source="AT-II eq. OFI: beta > 0")
        res.add(f"h5.tstat_{horizon_s}s", t[0], expected=5.0, expected_hi=1e9)
        res.add(f"h5.r2_{horizon_s}s", r2, expected=0.2, expected_hi=1.0,
                source="Cont-Kukanov-Stoikov: R^2 ~ 0.6 at short horizons")
    res.data_origin = "simulation"
    res.note(f"queue-reactive book, {n_events} events (~{n_events // events_per_s} s at 100 events/s); "
             "OFI and mid change per window, OLS with intercept")
    ok = all(v[1] > 5 and v[2] > 0.2 for v in r2s.values()) and len(r2s) >= 2
    verdict_from(res, supported=ok, inconclusive=(len(r2s) < 2))
    return res
