"""H8 -- Expansion is one rate at all distances after the linear-field split (AT-III Sec. 7).

The velocity field of galaxies splits exactly into a bulk flow, a linear field M and internal motion
(AT-III Thm 3.7); expansion is the trace of M.  On the Hubble diagram this is one rate H0 at all
distances.  The test fits H0 on Pantheon+ (real, if the GitHub host answers) in distance bins and asks
whether the binned rates are consistent with one constant (χ² against the pooled rate, 6 bins:
AT-III: H0 = 73.25 ± 1.40 km/s/Mpc, χ² = 5.7 for 6 dof); with a synthetic Hubble flow plus a 290 km/s
bulk flow and shear it checks that the split recovers the planted rate and bulk flow.
"""
from __future__ import annotations
import io
import numpy as np

from ..core import identities as I
from ..data.common import fetch_text
from ..result import Result
from ._common import verdict_from

C_KMS = 299792.458
URL = ("https://raw.githubusercontent.com/PantheonPlusSH0ES/DataRelease/main/Pantheon%2B_Data/"
       "4_DISTANCES_AND_COVAR/Pantheon%2BSH0ES.dat")


def load_pantheon(cfg):
    text, origin = fetch_text(URL, cfg, "pantheon_plus_sh0es.dat", timeout=cfg.timeout)
    if text is None:
        return None, None
    try:
        import pandas as pd
        df = pd.read_csv(io.StringIO(text), sep=r"\s+")
        zc = "zHD" if "zHD" in df.columns else "zCMB"
        d = df[[zc, "MU_SH0ES", "MU_SH0ES_ERR_DIAG"]].dropna()
        d = d[(d[zc] > 0.023) & (d[zc] < 0.15)]
        return d.rename(columns={zc: "z", "MU_SH0ES": "mu", "MU_SH0ES_ERR_DIAG": "dmu"}), "real"
    except Exception:  # noqa: BLE001
        return None, None


def synthetic_hubble(rng, n, H0=73.25):
    z = rng.uniform(0.023, 0.15, n)
    dL = C_KMS * z / H0 * (1 + 0.5 * (1 - (-0.55)) * z)          # q0 ≈ −0.55
    mu = 5 * np.log10(dL) + 25 + rng.normal(0, 0.12, n)
    return {"z": z, "mu": mu, "dmu": np.full(n, 0.12)}


def fit_H0(z, mu, dmu, nbins=6, sigma_v=250.0):
    """Per-supernova Hubble rate H = cz (1 + (1 - q0) z / 2) / d_L with d_L from the distance modulus;
    the error of each rate combines the distance-modulus error and a peculiar-velocity floor sigma_v
    (250 km/s, the usual allowance for the motion that the velocity-field split would remove).
    Inverse-variance pooled H0; chi^2 of the six distance-bin rates against the pooled rate."""
    dL = 10 ** ((mu - 25) / 5)
    q0 = -0.55
    v = C_KMS * z * (1 + 0.5 * (1 - q0) * z)             # low-z Hubble law: d_L = (cz/H0)(1 + (1-q0) z/2)
    H_each = v / dL
    var = (H_each * dmu * np.log(10) / 5) ** 2 + (sigma_v / dL) ** 2
    w = 1 / var
    H0 = np.sum(w * H_each) / np.sum(w)
    edges = np.quantile(dL, np.linspace(0, 1, nbins + 1))
    chi2 = 0.0
    rates = []
    for k in range(nbins):
        m = (dL >= edges[k]) & (dL <= edges[k + 1])
        if m.sum() < 3:
            continue
        hk = np.sum(w[m] * H_each[m]) / np.sum(w[m]); sk = np.sqrt(1 / np.sum(w[m]))
        rates.append((hk, sk)); chi2 += ((hk - H0) / max(sk, 1e-9)) ** 2
    return H0, rates, chi2


def run(cfg) -> Result:
    res = Result(name="hypotheses.h08_one_expansion_rate",
                 title="H8 Expansion is one rate at all distances after the linear-field split")
    rng = np.random.default_rng(cfg.seed)
    data, origin = load_pantheon(cfg)
    if data is None:
        s = synthetic_hubble(rng, cfg.sizes["n_galaxies"]); origin = "synthetic"
        z, mu, dmu = s["z"], s["mu"], s["dmu"]
    else:
        z, mu, dmu = data["z"].to_numpy(), data["mu"].to_numpy(), data["dmu"].to_numpy()
    H0, rates, chi2 = fit_H0(z, mu, dmu)
    res.add("h8.H0", H0, expected=73.25, tol=0.05, unit="km/s/Mpc", source="AT-III Sec. 7.2: 73.25 +/- 1.40")
    res.add("h8.chi2_one_rate", chi2, expected=0.0, expected_hi=16.8, source="AT-III: chi^2 = 5.7 for 6 dof (16.8 = 99% point; velocity floor 250 km/s instead of the gravity-model correction)")
    res.add("h8.n_sne", len(z), source=f"Pantheon+ ({origin}), 0.023 < z < 0.15")
    # the exact split on a synthetic local volume: Hubble flow + bulk flow + shear + internal motion
    n = cfg.sizes["n_galaxies"]
    pos = rng.uniform(-100, 100, (n, 3))
    M_true = np.diag([H0 / 1000 * 10] * 3) + np.array([[0, 2, 0], [0, 0, 1], [1, 0, 0]]) * 0.05
    V0_true = np.array([290.0, 0.0, 0.0])
    vel = V0_true + pos @ M_true.T + rng.normal(0, 50, (n, 3))
    sp = I.linear_field_split(pos, vel)
    res.add("h8.split_bulk_flow_kms", float(np.linalg.norm(sp["V0"])), expected=290.0, tol=0.1, unit="km/s",
            source="AT-III Sec. 7.3: bulk flow 290 km/s (planted)")
    res.add("h8.split_expansion_rel_err", abs(I.expansion_rate(sp["M"]) - I.expansion_rate(M_true)) / I.expansion_rate(M_true),
            expected=0.0, abs_tol=0.1, source="AT-III Thm 3.7: expansion = trace of the linear field")
    res.add("h8.split_internal_share", sp["share_internal"])
    res.data_origin = origin
    res.note("Hubble rate per supernova from the distance modulus with the first-order kinematic correction; "
             "six distance bins; chi^2 of the binned rates against the pooled rate")
    if origin != "real":
        res.note("Pantheon+ host not reached: the Hubble diagram is synthetic (planted H0 = 73.25) -- the test "
                 "shows the method, not the sky; verdict inconclusive")
    verdict_from(res, supported=(chi2 < 16.8 and abs(H0 - 73.25) < 3.0), inconclusive=(origin != "real"))
    return res
