"""H9 -- Zeros of Z(t) are where the Riemann-Siegel units cancel; spacings follow GUE (AT-III Sec. 9).

Z(t) = 2 Σ_{n ≤ √(t/2π)} n^{-1/2} cos(θ(t) − t log n) + remainder is an aggregate of units; its sign
changes on the critical line are the zeros.  The test evaluates Z(t) on a grid up to T
(numpy Riemann-Siegel with the first remainder term, tmrw_lab.core.riemann_siegel), counts sign
changes, compares with the Riemann-von Mangoldt count N(T) = (T/2π) log(T/2πe) + 7/8 and with the first
zeros from mpmath.zetazero, checks that the units cancel at a zero, and compares the unfolded spacings
with the GUE Wigner surmise (AT-III: 1,747,146 zeros to height 10^6, none missing; a check, not a proof).
"""
from __future__ import annotations
import numpy as np

from ..core import riemann_siegel as RS
from ..result import Result
from ._common import verdict_from


def run(cfg) -> Result:
    res = Result(name="hypotheses.h09_zeta_aggregate", title="H9 Zeros of Z(t) as cancellation of units; GUE spacings")
    T = float(cfg.sizes["zeta_height"]); n_check = min(int(cfg.sizes["zeta_n_zeros"]), 60)
    zeros, step = RS.zeros_up_to(T, t0=50.0)
    expected_smooth = RS.riemann_von_mangoldt(T) - RS.riemann_von_mangoldt(50.0)
    import mpmath as mp
    mp.mp.dps = 15
    try:
        expected = int(mp.nzeros(T)) - int(mp.nzeros(50.0))      # exact count (Backlund)
        count_src = "exact count mpmath.nzeros(T) - nzeros(50)"
    except Exception:  # noqa: BLE001
        expected = int(round(expected_smooth)); count_src = "Riemann-von Mangoldt N(T) - N(50)"
    missing = max(0, expected - len(zeros))
    # check against the first zeros from mpmath (above t0 = 50: zeros 11.. )
    ok = 0; checked = 0
    for k in range(11, 11 + n_check):
        zk = float(mp.im(mp.zetazero(k)))
        if zk > T:
            break
        checked += 1
        if np.min(np.abs(zeros - zk)) < 2 * step:
            ok += 1
    # cancellation: |Z| at zeros relative to the unit-amplitude sum
    sample = zeros[: min(50, len(zeros))]
    ratio = [abs(float(RS.Z(np.array([z]))[0])) / np.sum(np.abs(RS.units(z))) for z in sample]
    res.add("h9.height_T", T)
    res.add("h9.n_zeros_found", len(zeros), expected=expected, abs_tol=0, source=count_src)
    res.add("h9.n_zeros_smooth_count", expected_smooth, source="Riemann-von Mangoldt N(T) - N(50)")
    res.add("h9.missing", missing, expected=0, abs_tol=0, source="AT-III Sec. 9.2: missing = 0 to height 10^6")
    res.add("h9.share_checked_zeros_found", ok / max(checked, 1), expected=1.0, abs_tol=0.0,
            source=f"zeros 11..{10 + checked} from mpmath.zetazero")
    res.add("h9.mean_abs_Z_at_zero_over_unit_sum", float(np.mean(ratio)), expected=0.0, abs_tol=1e-6,
            source="at a zero the units cancel")
    s = RS.unfolded_spacings(zeros)
    s = s[s > 0]
    xs = np.sort(s); F_emp = np.arange(1, len(xs) + 1) / len(xs)
    ks = float(np.max(np.abs(F_emp - RS.gue_wigner_cdf(xs))))
    res.add("h9.gue_ks_distance", ks, expected=0.0, expected_hi=0.1, source="AT-III Sec. 9.2: random-matrix (GUE) statistics")
    res.add("h9.spacing_mean", float(np.mean(s)), expected=1.0, tol=0.1, source="unfolded spacings average 1")
    res.data_origin = "analytic"
    res.note(f"Z(t) on a grid of step {step:.3f} on [50, {T:.0f}]; zeros refined by bisection; "
             f"{len(zeros)} zeros against the exact count {expected}; a check, not a proof")
    verdict_from(res, supported=(missing == 0 and ok == checked and ks < 0.1))
    return res
