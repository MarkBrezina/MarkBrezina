"""H4 -- Impact is concave in size, I(Q) ≈ Y σ_d √(Q/V_d) (AT-II Known 5.6 / Hyp. 5.8).

Mechanism test on a latent-liquidity book (Tóth et al. 2011; AT-II §5.3 "the order book as a potential
landscape"): if the available liquidity density grows linearly with the distance from the price,
ρ(x) = λ x, a metaorder of size Q that eats the liquidity in its way moves the price by
Q = ∫_0^I λx dx  ⇒  I = √(2Q/λ): a square-root law with exponent 1/2.  A constant-depth book
(ρ(x) = λ) gives linear impact.  The test executes metaorders of many sizes on both books (with
noise and partial refilling) and fits the exponent δ in log I = log Y + δ log(Q/V).
"""
from __future__ import annotations
import numpy as np

from ..result import Result
from ._common import ols, verdict_from


def execute(rng, Q, kind, n_slices=20, lam=1.0, refill=0.3):
    """Walk a metaorder of size Q through a book with density lam*x (kind='linear') or lam (kind='const'),
    slice by slice; the displacement per slice inverts the eaten liquidity in closed form."""
    x = 0.0
    q = Q / n_slices
    for _ in range(n_slices):
        if kind == "linear":
            dx = np.sqrt(x * x + 2 * q / lam) - x
        else:
            dx = q / lam
        x += dx
        x -= refill * dx * rng.uniform(0.0, 0.5)      # some liquidity refills behind the price
    return x


def run(cfg) -> Result:
    res = Result(name="hypotheses.h04_sqrt_impact",
                 title="H4 Impact is concave in size, I(Q) = Y sigma_d sqrt(Q/V_d)")
    rng = np.random.default_rng(cfg.seed)
    n = max(20, cfg.sizes["n_trials"] * 2)
    Qs = np.exp(rng.uniform(np.log(1.0), np.log(1000.0), n))
    I_lin = np.array([execute(rng, Q, "linear") for Q in Qs]) * np.exp(rng.normal(0, 0.1, n))
    I_const = np.array([execute(rng, Q, "const", refill=0.0) for Q in Qs]) * np.exp(rng.normal(0, 0.1, n))
    b_lin, t_lin, r2_lin = ols(np.log(I_lin), np.log(Qs))
    b_con, t_con, r2_con = ols(np.log(I_const), np.log(Qs))
    res.add("h4.exponent_linear_depth", b_lin[0], expected=0.5, abs_tol=0.1,
            source="AT-II Known 5.6: delta = 1/2 (latent linear liquidity)")
    res.add("h4.exponent_constant_depth", b_con[0], expected=1.0, abs_tol=0.1,
            source="control: constant depth gives linear impact")
    res.add("h4.r2_linear_depth", r2_lin, expected=0.9, expected_hi=1.0)
    res.add("h4.concavity_gap", b_con[0] - b_lin[0], expected=0.5, abs_tol=0.15,
            source="the concavity comes from liquidity growing with distance")
    res.data_origin = "simulation"
    res.note(f"{n} metaorders of size 1..1000 on a latent linear-liquidity book and on a constant-depth book; "
             "exponent from log I on log Q with intercept (Y) free")
    verdict_from(res, supported=(abs(b_lin[0] - 0.5) < 0.1 and b_con[0] > 0.8))
    return res
