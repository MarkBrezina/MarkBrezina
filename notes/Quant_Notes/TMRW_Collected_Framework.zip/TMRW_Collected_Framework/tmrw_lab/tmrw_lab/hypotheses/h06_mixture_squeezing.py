"""H6 -- Aggregate responses fit the impact-weighted mixture law, and the squeezed share rises with
bin length (P2; AT-III Thms 3.5-3.6, Sec. 5).

Units respond to one event with the same logistic response shifted by their own lag τ_i and scaled by
their impact c_i.  The aggregate is R(t)/A = Σ c_i f(t − τ_i); it lies between f(t − τ_max) and
f(t − τ_min); a bin of length Δ around the event captures at least 1 − (spread)/Δ of the response.
The test builds such aggregates with gamma-distributed lags, fits the mixture law with the lag
distribution's two parameters free (R² ≥ 0.99 expected, AT-III: 0.992 / 0.993 / 1.0000), and
measures the squeezed share against Δ (AT-III: 0.01 daily → 0.93 yearly for the first COVID wave).
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from scipy.stats import gamma as gamma_dist

from ..core import identities as I
from ..result import Result
from ._common import verdict_from


def logistic(u, width=3.0):
    return 1.0 / (1.0 + np.exp(-u / width))


def run(cfg) -> Result:
    res = Result(name="hypotheses.h06_mixture_squeezing",
                 title="H6 Mixture law and squeezing of event responses (P2)")
    rng = np.random.default_rng(cfg.seed)
    n_units = cfg.sizes["n_units"]; n_events = max(5, cfg.sizes["n_events"] // 5)
    t = np.arange(-20, 400, 1.0)
    r2s, bounds_ok, shares_fine, shares_coarse, bound_ok = [], [], [], [], []
    for _ in range(n_events):
        shape = rng.uniform(1.5, 6.0); scale = rng.uniform(3.0, 15.0)
        tau = rng.gamma(shape, scale, n_units)
        c = rng.pareto(2.0, n_units) + 1
        R = I.mixture_law(t, c, tau, lambda u: logistic(u))
        R_obs = R + rng.normal(0, 0.003, len(t))
        lo, hi = I.mixture_bounds(t, tau, lambda u: logistic(u))
        bounds_ok.append(np.all(R >= lo - 1e-9) and np.all(R <= hi + 1e-9))
        # fit the lag distribution (gamma) by least squares, unit response known
        def loss(p):
            a, s = np.exp(p)
            qs = gamma_dist.ppf(np.linspace(0.005, 0.995, 60), a, scale=s)
            Rf = I.mixture_law(t, np.ones(60), qs, lambda u: logistic(u))
            return np.sum((Rf - R_obs) ** 2)
        best = minimize(loss, x0=np.log([2.0, 8.0]), method="Nelder-Mead", options={"maxiter": 400, "xatol": 1e-3, "fatol": 1e-9})
        a, s = np.exp(best.x)
        qs = gamma_dist.ppf(np.linspace(0.005, 0.995, 60), a, scale=s)
        Rf = I.mixture_law(t, np.ones(60), qs, lambda u: logistic(u))
        r2s.append(1 - np.sum((Rf - R_obs) ** 2) / np.sum((R_obs - R_obs.mean()) ** 2))
        # squeezing: the response increments dR captured by one bin [0, Δ) that contains the event
        dR = np.diff(R, prepend=R[0])
        spread = tau.max() - tau.min() + 6 * 3.0
        for d, store in ((5.0, shares_fine), (400.0, shares_coarse)):
            sh = I.squeezed_share(t, dR, 0.0, d)
            store.append(sh)
            bound_ok.append(sh >= I.squeezing_bound(spread, d) - 1e-9)
    res.add("h6.mixture_fit_r2_min", min(r2s), expected=0.99, expected_hi=1.0, source="AT-III Sec. 5: R^2 = 0.992, 0.993, 1.0000")
    res.add("h6.mixture_fit_r2_mean", float(np.mean(r2s)))
    res.add("h6.bounds_hold_share", float(np.mean(bounds_ok)), expected=1.0, abs_tol=0.0, source="AT-III Thm 3.5")
    res.add("h6.squeezed_share_fine_bin", float(np.mean(shares_fine)), expected=0.0, expected_hi=0.3,
            source="AT-III: 0.01 with daily bins")
    res.add("h6.squeezed_share_coarse_bin", float(np.mean(shares_coarse)), expected=0.8, expected_hi=1.0,
            source="AT-III: 0.93 with yearly bins")
    res.add("h6.squeezing_bound_holds_share", float(np.mean(bound_ok)), expected=1.0, abs_tol=0.0, source="AT-III Thm 3.6")
    res.data_origin = "simulation"
    res.note(f"{n_events} events, {n_units} units each, gamma lags, logistic unit response; mixture fitted with the lag distribution free")
    verdict_from(res, supported=(min(r2s) > 0.98 and all(bounds_ok) and all(bound_ok)
                                 and np.mean(shares_coarse) > np.mean(shares_fine)))
    return res
