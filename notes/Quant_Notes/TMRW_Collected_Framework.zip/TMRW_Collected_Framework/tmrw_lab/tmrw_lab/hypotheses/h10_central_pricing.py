"""H10 -- Central pricing (Conjecture 2): P_{T+1} = α I_T + (1 − α) H_T + ε with α identifiable and
significant from N > 3 assets and a history window H ≥ 5.

Identification test: simulate N assets whose next price is a convex combination of an impact
component I (linear in signed order flow) and a history component H (the mean of the last H prices)
plus noise; estimate α by pooled OLS under the constraint that the coefficients sum to one
(regress P_{T+1} − H_T on I_T − H_T); check that α̂ is close to the planted α with t > 3, and that a
control with α = 0 gives an insignificant estimate.
"""
from __future__ import annotations
import numpy as np

from ..result import Result
from ._common import ols, verdict_from


def simulate(rng, n_assets, n_steps, alpha, H=5, beta_impact=0.5, noise=0.2):
    P = np.zeros((n_steps + 1, n_assets)); P[0] = 100 + rng.normal(0, 5, n_assets)
    flow = rng.normal(size=(n_steps, n_assets))
    I_all = np.zeros((n_steps, n_assets)); H_all = np.zeros((n_steps, n_assets))
    for t in range(n_steps):
        hist = P[max(0, t - H + 1): t + 1].mean(axis=0)
        imp = P[t] + beta_impact * flow[t]
        I_all[t] = imp; H_all[t] = hist
        P[t + 1] = alpha * imp + (1 - alpha) * hist + rng.normal(0, noise, n_assets)
    return P, I_all, H_all


def estimate(P, I_all, H_all, burn=10):
    y = (P[burn + 1:] - H_all[burn:]).ravel()
    x = (I_all[burn:] - H_all[burn:]).ravel()
    b, t, r2 = ols(y, x)
    return b[0], t[0], r2


def run(cfg) -> Result:
    res = Result(name="hypotheses.h10_central_pricing", title="H10 Central pricing: P_{T+1} = alpha I + (1-alpha) H + eps")
    rng = np.random.default_rng(cfg.seed)
    n_assets = max(4, min(cfg.sizes["n_assets"], 50)); n_steps = min(cfg.sizes["n_steps"], 5000)
    alpha_true = 0.6
    P, I_all, H_all = simulate(rng, n_assets, n_steps, alpha_true, H=5)
    a_hat, t_hat, r2 = estimate(P, I_all, H_all)
    P0, I0, H0 = simulate(rng, n_assets, n_steps, 0.0, H=5)
    a0, t0, _ = estimate(P0, I0, H0)
    # the window condition: with H < 5 the history term is noisier -> weaker identification
    P3, I3, H3 = simulate(rng, n_assets, n_steps, alpha_true, H=2)
    a3, t3, _ = estimate(P3, I3, H3)
    res.add("h10.alpha_hat", a_hat, expected=alpha_true, tol=0.1, source="C2 (planted alpha = 0.6; N > 3, H = 5)")
    res.add("h10.alpha_tstat", t_hat, expected=3.0, expected_hi=1e9, source="C2: alpha significant")
    res.add("h10.r2", r2)
    res.add("h10.control_alpha_hat", a0, expected=0.0, abs_tol=0.1, source="control: no impact term")
    res.add("h10.alpha_hat_H2", a3, expected=alpha_true, tol=0.2, source="C2 asks H >= 5; H = 2 for comparison")
    res.add("h10.n_assets", n_assets, expected=4, expected_hi=1e9, source="C2: N > 3")
    res.data_origin = "simulation"
    res.note(f"{n_assets} assets, {n_steps} steps, pooled OLS on P_(T+1) - H_T = alpha (I_T - H_T) + eps")
    verdict_from(res, supported=(abs(a_hat - alpha_true) < 0.1 and t_hat > 3 and abs(a0) < 0.1))
    return res
