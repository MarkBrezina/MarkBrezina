"""H12 -- A linear inventory skew keeps inventory inside the limit 99% of the session, and a taking
layer cuts PnL (NB-01: inventory inside ±79 for 99% of the session; taking cut PnL 2,300 → 1,600).

Self-contained range-bound market-making simulation in the NB-01 setting: mid ≈ 10,000 mean-reverting
around a fair value, spread 20 (half-spread h = 10), inventory limit ±80, quotes r ± h with the
reservation price r = fair − k q (linear skew, k = 0.125 ticks per unit = 10 ticks at the limit);
fills arrive as Poisson events whose intensity decays with the distance of the quote from the market;
an optional taking layer crosses the spread (paying the half-spread and a taker fee of 2 ticks) when
the market is 6-10 ticks from fair and the trade reduces inventory.  The desk's fair value is a slow EMA of the mid; PnL is marked to the last mid.
"""
from __future__ import annotations
import numpy as np

from ..result import Result
from ._common import verdict_from


def simulate(rng, n_ticks, skew_k=0.125, limit=80, h=10.0, taking=False, sigma=2.0, theta=0.02, A=0.9, kappa=0.25, taker_fee=2.0, ema=0.05):
    fair = 10_000.0; mid = fair; q = 0; cash = 0.0
    fair_est = fair                                             # the desk's fair value: a slow EMA of the mid
    inv = np.zeros(n_ticks)
    for t in range(n_ticks):
        mid += theta * (fair - mid) + sigma * rng.normal()     # mean-reverting market price around fair
        fair_est += ema * (mid - fair_est)
        r = fair_est - skew_k * q
        bid, ask = r - h, r + h
        # fills: a buy order arrives at the bid with probability decaying in distance below the market
        if q < limit and rng.random() < A * np.exp(-kappa * max(0.0, mid - bid)):
            q += 1; cash -= bid
        if q > -limit and rng.random() < A * np.exp(-kappa * max(0.0, ask - mid)):
            q -= 1; cash += ask
        if taking:
            d = mid - fair_est
            if 6 <= d <= 10 and q > 0:          # market rich: sell inventory by crossing the spread (hit the bid)
                q -= 1; cash += mid - h - taker_fee
            elif -10 <= d <= -6 and q < 0:      # market cheap: buy back by lifting the ask
                q += 1; cash -= mid + h + taker_fee
        inv[t] = q
    pnl = cash + q * mid
    return pnl, inv


def run(cfg) -> Result:
    res = Result(name="hypotheses.h12_inventory_skew", title="H12 Linear inventory skew and the taking layer (NB-01)")
    rng = np.random.default_rng(cfg.seed)
    n_ticks = cfg.sizes["n_ticks"]; n_sessions = cfg.sizes["n_sessions"]
    rows = {"no_skew": [], "skew": [], "skew_taking": []}
    inside = []
    for _ in range(n_sessions):
        p0, _ = simulate(rng, n_ticks, skew_k=0.0); rows["no_skew"].append(p0)
        p1, inv = simulate(rng, n_ticks, skew_k=0.125); rows["skew"].append(p1)
        inside.append(np.mean(np.abs(inv) <= 79))
        p2, _ = simulate(rng, n_ticks, skew_k=0.125, taking=True); rows["skew_taking"].append(p2)
    m = {k: float(np.mean(v)) for k, v in rows.items()}
    res.add("h12.share_inside_79", float(np.mean(inside)), expected=0.99, expected_hi=1.0, source="NB-01: inside +/-79 for 99% of the session")
    res.add("h12.pnl_no_skew", m["no_skew"]); res.add("h12.pnl_skew", m["skew"]); res.add("h12.pnl_skew_taking", m["skew_taking"])
    res.add("h12.taking_pnl_rel_change", (m["skew_taking"] - m["skew"]) / abs(m["skew"]) if m["skew"] else np.nan,
            expected=-0.3, abs_tol=0.3, source="NB-01: taking layer cut PnL 2,300 -> 1,600 (-30%)")
    res.add("h12.skew_pnl_rel_change", (m["skew"] - m["no_skew"]) / abs(m["no_skew"]) if m["no_skew"] else np.nan)
    res.data_origin = "simulation"
    res.note(f"{n_sessions} sessions of {n_ticks} ticks; NB-01 parameters (h = 10, limit 80, k = 0.125)")
    verdict_from(res, supported=(np.mean(inside) >= 0.99 and m["skew_taking"] < m["skew"]))
    return res
