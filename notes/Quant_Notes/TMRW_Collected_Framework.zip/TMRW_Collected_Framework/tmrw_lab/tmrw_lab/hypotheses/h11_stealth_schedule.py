"""H11 -- Under a concave cost g(x) = c√x the stealth-optimal schedule spreads a parent order across
children/venues with an interior optimum (Conjecture 3: Q = 1,000,000 USD, N_max = 100).

√x is subadditive, so splitting raises the summed impact cost Σ c√x_i, while detection/timing risk
(a convex penalty in child size, λ Σ x_i²) falls with splitting.  J(N) = c√(QN) + λ Q²/N for an equal
split has an interior minimiser N* = (2λQ^{3/2}/c)^{2/3}; the test solves the split numerically
(equal, front-loaded and random schedules; the optimal N under the penalty) and checks that the
optimum is interior for λ > 0 and N* = 1 for λ = 0, and that for a fixed N the equal split is the
cheapest among the schedules with the same N.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize

from ..result import Result
from ._common import verdict_from

Q = 1_000_000.0; N_MAX = 100


def cost(x, c, lam):
    x = np.asarray(x, float)
    return c * np.sum(np.sqrt(np.maximum(x, 0))) + lam * np.sum(x ** 2)


def best_for_n(n, c, lam, rng):
    x0 = np.full(n, Q / n)
    cons = ({"type": "eq", "fun": lambda x: np.sum(x) - Q},)
    r = minimize(lambda x: cost(x, c, lam), x0 * (1 + 0.1 * rng.normal(size=n)), bounds=[(0, Q)] * n,
                 constraints=cons, method="SLSQP", options={"maxiter": 200})
    return r.fun if r.success else cost(x0, c, lam), r.x if r.success else x0


def run(cfg) -> Result:
    res = Result(name="hypotheses.h11_stealth_schedule", title="H11 Stealth-optimal schedule under concave cost")
    rng = np.random.default_rng(cfg.seed)
    c = 1.0; lam = 8e-8                      # scales so that N* ~ 30 is interior
    Ns = np.unique(np.round(np.geomspace(1, N_MAX, 25)).astype(int))
    J = np.array([cost(np.full(n, Q / n), c, lam) for n in Ns])
    n_star = int(Ns[np.argmin(J)])
    n_star_formula = (2 * lam * Q ** 1.5 / c) ** (2 / 3)
    J0 = np.array([cost(np.full(n, Q / n), c, 0.0) for n in Ns])
    n_star_lam0 = int(Ns[np.argmin(J0)])
    # schedules with the same N = n_star: equal vs front-loaded vs random vs numerical optimum
    n = max(2, n_star)
    equal = np.full(n, Q / n)
    front = Q * np.linspace(2, 0.1, n); front *= Q / front.sum()
    rand = rng.dirichlet(np.ones(n)) * Q
    J_eq, J_fr, J_rd = cost(equal, c, lam), cost(front, c, lam), cost(rand, c, lam)
    J_opt, x_opt = best_for_n(n, c, lam, rng)
    res.add("h11.n_star_grid", n_star, expected=2, expected_hi=N_MAX - 1, source="C3: interior optimum, N <= N_max = 100")
    res.add("h11.n_star_formula", n_star_formula, source="(2 lambda Q^{3/2} / c)^{2/3}")
    res.add("h11.n_star_lambda0", n_star_lam0, expected=1, abs_tol=0, source="no penalty: concavity says do not split")
    res.add("h11.cost_equal_over_front", J_eq / J_fr, expected=0.0, expected_hi=1.0, source="equal split is cheapest for a convex-plus-concave symmetric cost")
    res.add("h11.cost_equal_over_random", J_eq / J_rd, expected=0.0, expected_hi=1.0)
    res.add("h11.numerical_optimum_rel_gap", (J_opt - J_eq) / J_eq, expected=0.0, abs_tol=1e-3, source="SLSQP optimum equals the equal split")
    res.add("h11.max_child_share", float(x_opt.max() / Q), expected=0.0, expected_hi=0.5)
    res.data_origin = "simulation"
    res.note(f"Q = {Q:.0f} USD, c = {c}, lambda = {lam}; J(N) on 25 values of N in [1, 100]; same-N schedules compared")
    verdict_from(res, supported=(1 < n_star < N_MAX and n_star_lam0 == 1 and J_eq <= J_fr and J_eq <= J_rd))
    return res
