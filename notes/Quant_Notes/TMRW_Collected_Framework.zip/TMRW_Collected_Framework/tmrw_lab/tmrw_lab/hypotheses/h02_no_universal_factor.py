"""H2 -- "There is a universal speed factor (such as one half) when units aggregate" (P1 as first stated).

AT-III Thm 3.1-3.2: the speed ratio φ, the collective share κ and the turbulence ratio Ψ are all ≤ 1,
and Ψ² = H + (1−H)ρ̄ exactly -- so the factor is set by concentration H and mean correlation ρ̄ and is
a *domain parameter*, not a constant.  The test measures φ, κ, Ψ across simulated domains spanning
ρ̄ ∈ [0, 0.95] and N ∈ {5, ..., n_units}, and compares with the hindsight values of AT-III Table 3
(κ = 0.116 counties, 0.402 countries, 0.727 metros).
"""
from __future__ import annotations
import numpy as np

from ..core import identities as I
from ..result import Result
from ._common import correlated_factor_panel, verdict_from

HINDSIGHT = {"covid_us_counties": 0.116, "world_gdp": 0.402, "case_shiller_metros": 0.727}


def run(cfg) -> Result:
    res = Result(name="hypotheses.h02_no_universal_factor",
                 title="H2 A universal speed factor such as one half (P1 as first stated)")
    rng = np.random.default_rng(cfg.seed)
    n_units = cfg.sizes["n_units"]; n_steps = cfg.sizes["n_steps"]
    phis, kappas, psis, idents = [], [], [], []
    for rho in np.linspace(0.0, 0.95, 8):
        for n in sorted(set([5, 20, 100, n_units])):
            x, w = correlated_factor_panel(rng, n, n_steps, rho=rho)
            # per-period speed ratio / collective share, averaged over time
            ph = np.mean([I.speed_ratio(x[t], w) for t in range(0, n_steps, max(1, n_steps // 200))])
            ka = np.mean([I.collective_share(x[t], w) for t in range(0, n_steps, max(1, n_steps // 200))])
            sig = x.std(axis=0)
            R = np.corrcoef(x.T) if n > 1 else np.eye(1)
            d = I.turbulence_identity(sig, w, R)
            phis.append(ph); kappas.append(ka); psis.append(np.sqrt(d["Psi2_direct"]))
            idents.append(abs(d["Psi2_direct"] - d["Psi2_identity"]))
    phis, kappas, psis = map(np.array, (phis, kappas, psis))
    res.add("h2.phi_min", phis.min(), expected=0.0, expected_hi=1.0, source="AT-III Thm 3.1 (phi <= 1)")
    res.add("h2.phi_max", phis.max(), expected=0.0, expected_hi=1.0, source="AT-III Thm 3.1")
    res.add("h2.phi_range", phis.max() - phis.min(), expected=0.3, expected_hi=1.0,
            source="a universal factor would give range 0")
    res.add("h2.kappa_le_phi2_violations", int(np.sum(kappas > phis ** 2 + 1e-9)), expected=0, abs_tol=0,
            source="AT-III Thm 3.1 (kappa <= phi^2)")
    res.add("h2.turbulence_identity_max_residual", max(idents), expected=0.0, abs_tol=1e-9,
            source="AT-III Thm 3.2 (Psi^2 = H + (1-H) rho_bar)")
    hs = np.array(list(HINDSIGHT.values()))
    res.add("h2.hindsight_kappa_spread", hs.max() - hs.min(), expected=0.611, abs_tol=1e-6,
            source="AT-III Table 3: kappa = 0.116 / 0.402 / 0.727")
    res.add("h2.share_within_10pct_of_half", float(np.mean(np.abs(phis - 0.5) < 0.05)), expected=1.0, abs_tol=0.0,
            source="the 'one half' reading of P1 predicts 1.0")
    res.data_origin = "simulation"
    res.note("phi, kappa and Psi vary across the simulated domains by more than the whole [0, 1] range allows a "
             "constant to explain; the hindsight collective shares of AT-III (0.116, 0.402, 0.727) span 0.61. "
             "The universal-factor reading is refuted; the bounds and the turbulence identity hold in every case.")
    verdict_from(res, supported=(phis.max() - phis.min() < 0.1))
    return res
