"""H7 -- Bound composites with 1/r binding are lighter than their parts; free composites and confined
ones are heavier (P3; AT-II Thm 3.7 invariant mass, AT-III Known 3.9 sign law, Hyp. 6.1).

Three checks: (i) every isotope in the AME-based table of the `periodictable` package has a positive
mass defect (lighter than Z protons + N neutrons), and hydrogen's binding is 13.6 eV; (ii) the light
hadrons in the PDG table of the `particle` package are heavier than their current quarks (confinement);
(iii) a simulated Kepler pair has E_int = −K (lighter) and a simulated free pair has invariant mass
above the sum of its parts.  Falls back to a built-in table of 20 nuclei and 15 hadrons if the
packages are missing (noted in data_origin).
"""
from __future__ import annotations
import numpy as np

from ..core import identities as I
from ..result import Result
from ._common import verdict_from

M_P, M_N, M_E = 938.272088, 939.565420, 0.510998950     # MeV
U_MEV = 931.494102
QUARK = {"u": 2.16, "d": 4.67, "s": 93.4}                # MeV, current masses (PDG)
BUILTIN_NUCLEI = [  # (Z, A, atomic mass in u) from AME2020, a few across the table
    (1, 2, 2.014101778), (2, 4, 4.002603254), (3, 7, 7.016003437), (6, 12, 12.0), (7, 14, 14.003074004),
    (8, 16, 15.994914620), (11, 23, 22.989769282), (13, 27, 26.981538408), (14, 28, 27.976926535),
    (20, 40, 39.962590851), (26, 56, 55.934936326), (28, 58, 57.935341650), (29, 63, 62.929597119),
    (47, 107, 106.905091611), (50, 120, 119.902202557), (56, 138, 137.905247059), (79, 197, 196.966570103),
    (82, 208, 207.976652005), (92, 238, 238.050788423), (94, 244, 244.064204401)]
BUILTIN_HADRONS = [  # (name, quark content, mass MeV) PDG
    ("p", "uud", 938.272), ("n", "udd", 939.565), ("pi+", "ud", 139.570), ("pi0", "uu", 134.977),
    ("K+", "us", 493.677), ("K0", "ds", 497.611), ("eta", "uu", 547.862), ("rho", "ud", 775.26),
    ("omega", "uu", 782.66), ("phi", "ss", 1019.461), ("Lambda", "uds", 1115.683), ("Sigma+", "uus", 1189.37),
    ("Xi0", "uss", 1314.86), ("Omega-", "sss", 1672.45), ("Delta++", "uuu", 1232.0)]


def nuclei_table():
    try:
        import periodictable as pt
        rows = []
        for el in pt.elements:
            if el.number == 0:
                continue
            for iso in el:
                try:
                    m = float(iso.mass)
                except Exception:  # noqa: BLE001
                    continue
                if m > 0 and iso.isotope > 0:
                    rows.append((el.number, iso.isotope, m))
        if len(rows) > 100:
            return rows, "real"
    except Exception:  # noqa: BLE001
        pass
    return BUILTIN_NUCLEI, "builtin"


def hadron_table():
    try:
        from particle import Particle
        rows = []
        for name, q, m in BUILTIN_HADRONS:
            try:
                p = Particle.from_name({"p": "p", "n": "n", "pi+": "pi+", "pi0": "pi0", "K+": "K+", "K0": "K0",
                                        "eta": "eta", "rho": "rho(770)0", "omega": "omega(782)", "phi": "phi(1020)",
                                        "Lambda": "Lambda", "Sigma+": "Sigma+", "Xi0": "Xi0", "Omega-": "Omega-",
                                        "Delta++": "Delta(1232)++"}[name])
                rows.append((name, q, float(p.mass)))
            except Exception:  # noqa: BLE001
                rows.append((name, q, m))
        return rows, "real"
    except Exception:  # noqa: BLE001
        return BUILTIN_HADRONS, "builtin"


def run(cfg) -> Result:
    res = Result(name="hypotheses.h07_bound_free_composites",
                 title="H7 Bound 1/r composites are lighter than their parts; free and confined ones heavier")
    rng = np.random.default_rng(cfg.seed)
    nuc, o1 = nuclei_table()
    nuc = nuc[: cfg.sizes["n_nuclei"]] if len(nuc) > cfg.sizes["n_nuclei"] else nuc
    defects = []
    for Z, A, m_u in nuc:
        N = A - Z
        parts = Z * (M_P + M_E) + N * M_N          # atomic mass includes the electrons
        defects.append(parts - m_u * U_MEV)
    defects = np.array(defects)
    had, o2 = hadron_table()
    heavier = [m - sum(QUARK[c] for c in q) for _, q, m in had]
    # hydrogen binding from the Rydberg constant (AT-III §6.1 quotes 13.6 eV)
    alpha = 7.2973525693e-3
    mu = M_E * M_P / (M_E + M_P)
    E_H = 0.5 * mu * alpha ** 2 * 1e6              # eV
    # simulated Kepler pair (n = -1): virial 2K + U = 0 -> E_int = -K
    K = 1.0; E_int = I.sign_law(-1, K)
    # free pair: two particles with opposite momenta
    E = np.array([5.0, 5.0]); p = np.array([[3.0, 0, 0], [-3.0, 0, 0]])
    M, msum, gap = I.mass_superadditivity_gap(E, p)
    res.add("h7.nuclei_n", len(defects), source=f"nuclear masses ({o1})")
    res.add("h7.nuclei_share_lighter", float(np.mean(defects > 0)), expected=1.0, abs_tol=1e-12,
            source="AT-III Sec. 6.1: all 2,938 nuclei lighter than their parts")
    res.add("h7.hydrogen_binding_eV", E_H, expected=13.6, tol=0.01, unit="eV", source="AT-III Sec. 6.1")
    res.add("h7.hadrons_share_heavier", float(np.mean(np.array(heavier) > 0)), expected=1.0, abs_tol=1e-12,
            source="AT-III Sec. 6.1: all 15 hadrons heavier than their quarks")
    res.add("h7.kepler_E_int_over_K", E_int / K, expected=-1.0, abs_tol=1e-12, source="AT-III Known 3.9 (n = -1)")
    res.add("h7.free_pair_mass_gap_rel", gap, expected=0.0, expected_hi=1.0, source="AT-II Thm 3.7 (invariant mass superadditive)")
    res.data_origin = "real" if (o1 == "real" and o2 == "real") else "synthetic"
    res.note(f"nuclei: {len(defects)} isotopes from {o1}; hadrons: {len(had)} from {o2}; Kepler and free pairs analytic")
    verdict_from(res, supported=(np.all(defects > 0) and np.all(np.array(heavier) > 0) and gap > 0 and abs(E_H - 13.6) < 0.1))
    return res
