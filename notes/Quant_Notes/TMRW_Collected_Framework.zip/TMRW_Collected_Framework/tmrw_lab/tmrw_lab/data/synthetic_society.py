"""Synthetic societies with planted answers, in the real loaders' formats (AT-III Sections 4-5).

Used when AGG_OFFLINE=1 or a host does not answer.  Every generator plants the numbers AT-III quotes,
with the structure the theory describes: a velocity (growth rate) = common factor + group factor +
idiosyncratic part, with heterogeneous weights.  The idiosyncratic and common scales are calibrated
in-sample so that the planted collective share κ (Thm 3.1) and mean correlation ρ̄ (Thm 3.2) are hit
to ~1e-3; N_eff is planted through the weight distribution.

    counties(cfg, rng)      weekly new cases per county, counties nested in states (Table 3, row 1):
                            κ(counties→US) = 0.116; states as units: N_eff = 21.3, ρ̄ = 0.296, Ψ = 0.574
    first_wave(cfg, rng)    daily new cases per county for one wave (Table 4, row 1):
                            lag IQR ≈ 44 d, unit rise ≈ 61 d, aggregate rise ≈ 83 d
    countries_gdp(cfg, rng) annual GDP per country 1990-2023 (Table 3, row 3): κ = 0.402, N_eff = 22.6,
                            ρ̄ = 0.338; world log growth 1.525 vs weighted mean of the parts 1.235 (Sec. 4)
    case_shiller(cfg, rng)  monthly metro indices with the Composite-20 weights (Table 3, row 4):
                            κ = 0.727, N_eff = 10.2, ρ̄ = 0.692; the 2005-11 crash (Table 4, row 4)

The helpers growth_rates / panel_kappa / group_series are the P1 formulas (Table 2: weight = last
period's level, velocity = growth of the level); the experiment uses the same functions.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from tmrw_lab.core import identities as I

# ----------------------------------------------------------------------------------------------
# geography
# ----------------------------------------------------------------------------------------------
CENSUS_REGION = {
    "Northeast": ["Connecticut", "Maine", "Massachusetts", "New Hampshire", "Rhode Island", "Vermont",
                  "New Jersey", "New York", "Pennsylvania"],
    "Midwest": ["Illinois", "Indiana", "Michigan", "Ohio", "Wisconsin", "Iowa", "Kansas", "Minnesota",
                "Missouri", "Nebraska", "North Dakota", "South Dakota"],
    "South": ["Delaware", "District of Columbia", "Florida", "Georgia", "Maryland", "North Carolina",
              "South Carolina", "Virginia", "West Virginia", "Alabama", "Kentucky", "Mississippi",
              "Tennessee", "Arkansas", "Louisiana", "Oklahoma", "Texas"],
    "West": ["Arizona", "Colorado", "Idaho", "Montana", "Nevada", "New Mexico", "Utah", "Wyoming",
             "Alaska", "California", "Hawaii", "Oregon", "Washington"],
}
REGION_OF_STATE = {s: r for r, ss in CENSUS_REGION.items() for s in ss}
US_STATES = sorted(REGION_OF_STATE)

# World Bank regions by ISO-3 code (aggregate rows of the GDP file are dropped with WB_AGGREGATES).
WB_REGIONS = {
    "East Asia & Pacific": "ASM AUS BRN KHM CHN FJI PYF GUM HKG IDN JPN KIR KOR LAO MAC MYS MHL FSM MNG MMR "
                           "NRU NCL NZL MNP PLW PNG PHL WSM SGP SLB THA TLS TON TUV VUT VNM PRK",
    "Europe & Central Asia": "ALB AND ARM AUT AZE BLR BEL BIH BGR HRV CYP CZE DNK EST FRO FIN FRA GEO DEU GIB "
                             "GRC GRL HUN ISL IRL IMN ITA KAZ XKX KGZ LVA LIE LTU LUX MDA MCO MNE NLD MKD NOR "
                             "POL PRT ROU RUS SMR SRB SVK SVN ESP SWE CHE TJK TUR TKM UKR GBR UZB CHI",
    "Latin America & Caribbean": "ATG ARG ABW BHS BRB BLZ BOL BRA VGB CYM CHL COL CRI CUB CUW DMA DOM ECU SLV "
                                 "GRD GTM GUY HTI HND JAM MEX NIC PAN PRY PER PRI SXM KNA LCA MAF VCT SUR TTO "
                                 "TCA URY VEN VIR",
    "Middle East & North Africa": "DZA BHR DJI EGY IRN IRQ ISR JOR KWT LBN LBY MLT MAR OMN QAT SAU SYR TUN ARE "
                                  "PSE YEM",
    "North America": "BMU CAN USA",
    "South Asia": "AFG BGD BTN IND MDV NPL PAK LKA",
    "Sub-Saharan Africa": "AGO BEN BWA BFA BDI CPV CMR CAF TCD COM COD COG CIV GNQ ERI SWZ ETH GAB GMB GHA GIN "
                          "GNB KEN LSO LBR MDG MWI MLI MRT MUS MOZ NAM NER NGA RWA STP SEN SYC SLE SOM ZAF SSD "
                          "SDN TZA TGO UGA ZMB ZWE",
}
REGION_OF_ISO3 = {c: r for r, cs in WB_REGIONS.items() for c in cs.split()}
WB_AGGREGATES = set(("AFE AFW ARB CEB CSS EAP EAR EAS ECA ECS EMU EUU FCS HIC HPC IBD IBT IDA IDB IDX INX LAC LCN "
                     "LDC LIC LMC LMY LTE MEA MIC MNA NAC OED OSS PRE PSS PST SAS SSA SSF SST TEA TEC TLA TMN TSA "
                     "TSS UMC WLD").split())

# S&P CoreLogic Case-Shiller Composite-20: (FRED series, metro, approximate 2000-base weight, census region)
CASE_SHILLER_METROS = [
    ("ATXRSA", "GA-Atlanta", 2.30, "South"), ("BOXRSA", "MA-Boston", 7.43, "Northeast"),
    ("CRXRSA", "NC-Charlotte", 1.29, "South"), ("CHXRSA", "IL-Chicago", 8.89, "Midwest"),
    ("CEXRSA", "OH-Cleveland", 0.74, "Midwest"), ("DAXRSA", "TX-Dallas", 1.95, "South"),
    ("DNXRSA", "CO-Denver", 3.69, "West"), ("DEXRSA", "MI-Detroit", 2.67, "Midwest"),
    ("LVXRSA", "NV-Las Vegas", 1.47, "West"), ("LXXRSA", "CA-Los Angeles", 21.19, "West"),
    ("MIXRSA", "FL-Miami", 4.97, "South"), ("MNXRSA", "MN-Minneapolis", 2.98, "Midwest"),
    ("NYXRSA", "NY-New York", 27.24, "Northeast"), ("PHXRSA", "AZ-Phoenix", 2.59, "West"),
    ("POXRSA", "OR-Portland", 1.51, "West"), ("SDXRSA", "CA-San Diego", 5.49, "West"),
    ("SFXRSA", "CA-San Francisco", 7.43, "West"), ("SEXRSA", "WA-Seattle", 4.78, "West"),
    ("TPXRSA", "FL-Tampa", 1.01, "South"), ("WDXRSA", "DC-Washington", 7.78, "South"),
]


# ----------------------------------------------------------------------------------------------
# the P1 formulas on a panel of levels (Table 2)
# ----------------------------------------------------------------------------------------------
def growth_rates(levels):
    """Velocity x_t = L_t / L_{t-1} − 1 and weight w_t = L_{t-1} per unit (Table 2: last period's level
    as the weight, so the aggregate Σ w x / Σ w is exactly the growth of the total).  levels: array
    (T, N) ≥ 0.  Units with L_{t-1} = 0 get x = 0 and w = 0.  Returns (x, w) of shape (T-1, N)."""
    L = np.asarray(levels, dtype=float)
    prev, cur = L[:-1], L[1:]
    w = np.where(prev > 0, prev, 0.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        x = np.where(prev > 0, cur / np.where(prev > 0, prev, 1.0) - 1.0, 0.0)
    return x, w


def panel_kappa(x, w):
    """κ and φ with numerators and denominators summed over time (Thm 3.1), weights per period."""
    W = w / np.maximum(w.sum(axis=1, keepdims=True), 1e-300)
    X = (W * x).sum(axis=1)
    kappa = float((X ** 2).sum() / max((W * x ** 2).sum(), 1e-300))
    phi = float(np.abs(X).sum() / max((W * np.abs(x)).sum(), 1e-300))
    return kappa, phi


def group_series(x, w, groups):
    """Aggregate a panel to groups period by period: X_g,t = Σ_{i∈g} w x / W_g and W_g,t.
    Returns (labels, Xg (T, G), Wg (T, G))."""
    labels, inv = np.unique(np.asarray(groups), return_inverse=True)
    G = len(labels)
    T = x.shape[0]
    Xg = np.zeros((T, G)); Wg = np.zeros((T, G))
    for t in range(T):
        Wg[t] = np.bincount(inv, weights=w[t], minlength=G)
        Xg[t] = np.bincount(inv, weights=w[t] * x[t], minlength=G) / np.maximum(Wg[t], 1e-300)
    return labels, Xg, Wg


def turbulence_of(Xg, Wg):
    """Ψ, H, ρ̄, N_eff of group series with constant weights = average group share (Thm 3.2)."""
    wbar = Wg.mean(axis=0); wbar = wbar / wbar.sum()
    sig = Xg.std(axis=0, ddof=1)
    ok = sig > 0
    R = np.corrcoef(Xg[:, ok].T)
    out = I.turbulence_identity(sig[ok], wbar[ok], R)
    return out


# ----------------------------------------------------------------------------------------------
# calibration helpers
# ----------------------------------------------------------------------------------------------
def _bisect_decreasing(fun, target, lo, hi, n=22):
    """Geometric bisection for a decreasing fun(s) = target on [lo, hi]."""
    for _ in range(n):
        mid = float(np.sqrt(lo * hi))
        if fun(mid) > target:
            lo = mid
        else:
            hi = mid
    return float(np.sqrt(lo * hi))


def _lognormal_weights(rng, n, n_eff, lo=0.05, hi=4.0):
    """Lognormal weights whose in-sample N_eff = 1/Σ w² equals n_eff (bisection on the log-sd)."""
    z = rng.standard_normal(n)
    def neff(s):
        w = np.exp(s * z); w /= w.sum()
        return I.n_effective(w)
    s = _bisect_decreasing(neff, min(n_eff, 0.98 * n), lo, hi)
    w = np.exp(s * z)
    return w / w.sum()


def _calibrate_two(build, target_kappa, target_rho, s_e0=1.0, s_g0=1.0, rounds=5):
    """Alternate: scale s_e of the idiosyncratic part for κ, scale s_g of the common part for ρ̄.
    build(s_e, s_g) -> (kappa, rho_bar).  Both maps are monotone (κ falls with s_e, ρ̄ falls with
    s_e and rises with s_g)."""
    s_e, s_g = s_e0, s_g0
    for _ in range(rounds):
        s_e = _bisect_decreasing(lambda s: build(s, s_g)[0], target_kappa, s_e / 50, s_e * 50, n=20)
        if target_rho is not None:
            s_g = 1.0 / _bisect_decreasing(lambda u: build(s_e, 1.0 / u)[1], target_rho, 1 / (s_g * 50),
                                           50 / s_g, n=20)
    return s_e, s_g


def _ar1(rng, T, phi, n=1):
    e = rng.standard_normal((T, n))
    out = np.zeros_like(e)
    for t in range(1, T):
        out[t] = phi * out[t - 1] + e[t] * np.sqrt(1 - phi ** 2)
    return out[:, 0] if n == 1 else out


# ----------------------------------------------------------------------------------------------
# COVID-19 counties: weekly cases with counties nested in states
# ----------------------------------------------------------------------------------------------
def counties(cfg, rng, n_weeks=104, kappa=0.116, rho_states=0.296, neff_states=21.3):
    """Weekly new cases per county (2020-03-01 on), counties nested in US states.
    Planted (AT-III Table 3, COVID-19 counties → US): κ = 0.116 with weights = last week's cases;
    with states as units and average case shares as constant weights N_eff = 21.3, ρ̄ = 0.296, hence
    Ψ = sqrt(H + (1−H)ρ̄) = 0.574.  County noise is a scale mixture (rare large jumps) so that the
    speed ratio φ ≈ 0.54 sits well above sqrt(κ), as in the data."""
    N = int(cfg.sizes["n_units"])
    states = np.array(US_STATES)
    S = len(states)
    # state sizes with planted N_eff, counties spread over states in proportion to size
    state_w = _lognormal_weights(rng, S, neff_states)
    state_of = rng.choice(S, size=N, p=state_w)
    for s in range(S):                                 # every state gets at least one county
        if not np.any(state_of == s):
            state_of[rng.integers(N)] = s
    P = np.exp(1.2 * rng.standard_normal(N))
    for s in range(S):
        m = state_of == s
        P[m] *= state_w[s] / P[m].sum()
    P = P / P.sum() * 2.0e5                            # ~2e5 weekly cases nationally
    # common log level: two epidemic waves plus AR(1) wobble (the national growth-rate factor)
    t = np.arange(n_weeks + 1)
    dm = 0.16 * np.sin(2 * np.pi * t / 30.0) + 0.07 * _ar1(rng, n_weeks + 1, 0.6)
    m = np.cumsum(dm)
    v = rng.standard_normal((n_weeks + 1, S))          # state factor (iid in time)
    z = rng.standard_normal((n_weeks + 1, N))
    jump = (rng.random((n_weeks + 1, N)) < 0.02) * 7.0 # scale mixture: 2 % of county-weeks jump 8x
    u = z * (1.0 + jump)

    def levels(s_e, s_g):
        logc = np.log(P)[None, :] + m[:, None] * s_g + 0.6 * v[:, state_of] * s_e + 0.25 * u * s_e
        return np.maximum(np.round(np.exp(logc)), 0.0)

    def build(s_e, s_g):
        x, w = growth_rates(levels(s_e, s_g))
        k, _ = panel_kappa(x, w)
        _, Xg, Wg = group_series(x, w, state_of)
        return k, turbulence_of(Xg, Wg)["rho_bar"]

    s_e, s_g = _calibrate_two(build, kappa, rho_states, 1.0, 1.0, rounds=4)
    C = levels(s_e, s_g)
    ids = [f"{states[s]}/county{i:04d}" for i, s in enumerate(state_of)]
    dates = pd.date_range("2020-03-01", periods=n_weeks + 1, freq="7D")
    weekly = pd.DataFrame(C, index=dates, columns=ids)
    state = pd.Series(states[state_of], index=ids, name="state")
    return {"weekly_new": weekly, "state": state, "daily_new": first_wave(cfg, rng, ids=ids, scale=P),
            "planted": {"kappa": kappa, "rho_bar_states": rho_states, "n_eff_states": neff_states,
                        "s_e": s_e, "s_g": s_g}}


def first_wave(cfg, rng, ids=None, scale=None, start="2020-03-01", n_days=107):
    """Daily new cases per county for one wave (AT-III Table 4, first US wave): each county's
    cumulative curve is a logistic rising over ~61 days (10-90 %), reached at its own half-time;
    the impact-weighted half-times have an IQR ≈ 44 d with most weight early and a long tail, so the
    aggregate rises over ≈ 83 d.  Daily counts carry Poisson noise."""
    N = int(cfg.sizes["n_units"]) if ids is None else len(ids)
    if ids is None:
        ids = [f"county{i:04d}" for i in range(N)]
    a = np.exp(1.4 * rng.standard_normal(N)) if scale is None else np.asarray(scale, dtype=float) / np.mean(scale)
    a = a / a.mean() * 400.0                           # cases per county in the wave
    rise = 61.0                                        # unit 10-90 % rise (days)
    s = rise / np.log(81.0)
    core = rng.random(N) < 0.55                        # a synchronised core and a late tail
    tau = np.where(core, 34.0 + 9.0 * rng.standard_normal(N), 30.0 + 60.0 * rng.random(N))
    # heavier counties sit in the core (the big early outbreaks)
    order = np.argsort(-a)
    tau[order[: N // 8]] = 30.0 + 8.0 * rng.standard_normal(N // 8)
    day = np.arange(n_days + 1, dtype=float)
    F = 1.0 / (1.0 + np.exp(-(day[:, None] - tau[None, :]) / s))
    cum = a[None, :] * F
    daily = np.diff(cum, axis=0)
    daily = rng.poisson(np.maximum(daily, 0.0)).astype(float)
    dates = pd.date_range(start, periods=n_days, freq="D")
    return pd.DataFrame(daily, index=dates, columns=ids)


# ----------------------------------------------------------------------------------------------
# world GDP: annual levels per country
# ----------------------------------------------------------------------------------------------
def countries_gdp(cfg, rng, kappa=0.402, rho=0.338, neff=22.6, n_years=34):
    """Annual GDP (current US$) per country 1990-2023 (AT-III Table 3, countries → world):
    κ = 0.402, N_eff = 22.6, ρ̄ = 0.338 (so Ψ = 0.606); the world's log growth 1.525 against a
    GDP-weighted mean of the countries' log growth 1.235 (the Jensen gap, Thm 3.3b) and 0.84 of the
    starting GDP in countries that grew less than the world (a few fast growers carry the mean)."""
    N = min(int(cfg.sizes["n_units"]), 200)
    w0 = _lognormal_weights(rng, N, neff)
    g = _ar1(rng, n_years, 0.3)                        # common factor of annual growth
    e = rng.standard_normal((n_years, N))
    # persistent country drifts: right-skewed so that most weight trails the world
    drift = 0.012 * (np.exp(0.9 * rng.standard_normal(N)) - np.exp(0.9 ** 2 / 2))
    mu = 0.046

    def levels(s_e, s_g):
        x = mu + drift[None, :] + 0.04 * s_g * g[:, None] + 0.055 * s_e * e
        x = np.maximum(x, -0.6)
        L = np.empty((n_years + 1, N))
        L[0] = w0 * 3.0e13
        L[1:] = L[0] * np.cumprod(1.0 + x, axis=0)
        return L

    def build(s_e, s_g):
        x, w = growth_rates(levels(s_e, s_g))
        k, _ = panel_kappa(x, w)
        return k, turbulence_of(x, w)["rho_bar"]

    s_e, s_g = _calibrate_two(build, kappa, rho, 1.0, 1.0, rounds=4)
    L = levels(s_e, s_g)
    years = np.arange(1990, 1990 + n_years + 1)
    codes = [f"C{i:03d}" for i in range(N)]
    regions = rng.choice(list(WB_REGIONS), size=N)
    gdp = pd.DataFrame(L, index=years, columns=codes)
    region = pd.Series(regions, index=codes, name="region")
    return {"gdp": gdp, "region": region, "planted": {"kappa": kappa, "rho_bar": rho, "n_eff": neff,
                                                       "s_e": s_e, "s_g": s_g}}


# ----------------------------------------------------------------------------------------------
# Case-Shiller metros: monthly indices and the composite weights
# ----------------------------------------------------------------------------------------------
def case_shiller(cfg, rng, kappa=0.727, rho=0.692, start="2000-01-01", n_months=318):
    """Twenty metro indices 2000-01 to 2026-06 and the fixed Composite-20 weights (AT-III Table 3,
    metros → Composite-20: κ = 0.727, ρ̄ = 0.692, N_eff = 10.2, Ψ = 0.850).  Levels carry a common
    cycle with the 2005-11 crash as a logistic fall reached at metro-specific peak months (2005-09 to
    2007-08, lag IQR ≈ 5.5 months, 10-90 % fall ≈ 15 months; Table 4, housing crash), a common factor
    and idiosyncratic noise, calibrated in-sample to the planted κ and ρ̄."""
    metros = CASE_SHILLER_METROS
    N = len(metros)
    omega = np.array([m[2] for m in metros]); omega = omega / omega.sum()
    t = np.arange(n_months)
    dates = pd.date_range(start, periods=n_months, freq="MS")
    # common cycle in log level: boom to 2006, crash, recovery
    boom = 0.55 * (1 - np.exp(-t / 40.0)) * (t < 78) + 0.55 * (t >= 78)
    recovery = 0.0055 * np.maximum(t - 150, 0)
    peak = 78 + np.round(np.clip(6.5 * rng.standard_normal(N), -11, 13))   # months, around 2006-07
    peak[np.argmax(omega)] = 79
    amp = np.clip(0.32 + 0.12 * rng.standard_normal(N), 0.1, 0.6)
    s_fall = 14.9 / np.log(81.0)
    crash = -amp[None, :] / (1.0 + np.exp(-(t[:, None] - peak[None, :] - 10.0) / s_fall))
    g = _ar1(rng, n_months, 0.5)
    e = rng.standard_normal((n_months, N))
    beta = np.clip(1.0 + 0.35 * rng.standard_normal(N), 0.4, 1.8)        # exposure to the common factor

    def levels(s_e, s_g):
        logp = np.log(100.0) + boom[:, None] + recovery[:, None] + crash + \
            np.cumsum(0.004 * s_g * g[:, None] * beta[None, :] + 0.004 * s_e * e, axis=0)
        return np.exp(logp)

    def build(s_e, s_g):
        P = levels(s_e, s_g)
        x, w = growth_rates(P * omega[None, :])
        k, _ = panel_kappa(x, w)
        return k, turbulence_of(x, w)["rho_bar"]

    s_e, s_g = _calibrate_two(build, kappa, rho, 1.0, 1.0, rounds=4)
    P = levels(s_e, s_g)
    names = [m[1] for m in metros]
    idx = pd.DataFrame(P, index=dates, columns=names)
    comp = pd.Series(idx.values @ omega, index=dates, name="Composite-20")
    weights = pd.Series(omega, index=names, name="weight")
    region = pd.Series([m[3] for m in metros], index=names, name="region")
    return {"metros": idx, "composite": comp, "weights": weights, "region": region,
            "planted": {"kappa": kappa, "rho_bar": rho, "s_e": s_e, "s_g": s_g}}
