"""Synthetic market data with planted answers (used when a host is unreachable or AGG_OFFLINE=1).

Every generator plants the numbers the compendium expects, so the pipeline can be checked end to end:

* ``sp500_like``        one factor + sectors + idiosyncratic noise, cap weights, planted so that the index's
                        collective share is κ ≈ 0.3 (AT-II Table 3: 0.2–0.4) and the turbulence ratio
                        Ψ = σ_I / Σ w σ ≈ 0.68 (0.6–0.75).
* ``crypto_basket``     one-second prices of a basket of coins whose responses to a common factor arrive with
                        lags of a few seconds, so that κ(Δ) ≈ κ∞ Δ/(Δ+τ) with τ ≈ 5 s and κ∞ ≈ 0.81
                        (AT-II Hyp 4.4 / Table 1: 0.745 at 1 min, 0.82 at 15 min — the Epps effect as aggregation).
* ``hawkes_order_book`` a Hawkes-timed level-1 book: order signs with Hurst H ≈ 0.85, a propagator-driven latent
                        price (G(ℓ) ∝ ℓ^{-β}, β = (1-γ)/2 so prices stay diffusive, AT-II Known 5.7), square-root
                        impact in size (Known 5.6), price changes linear in OFI with R² ≈ 0.6 at 1 s (Known 5.2)
                        and a mid that is pushed far beyond the microprice offset within a second and settles to
                        it after a few seconds (AT-II §5.3, Table 3: k ≫ 1, flattening after seconds).
* ``btc_minutes``       BTC/USDT-like one-minute bars with a weak transient (half-life 5 bars) on top of a random
                        walk: the small short-horizon reversal of AT-II Table 1 (IC −0.035…−0.087, break-even
                        0.3–3.3 bp against a 10 bp cost) that AT-III §10 keeps from the AT-0 Bitcoin study.

All generators are deterministic given ``rng`` and take their sizes from ``cfg.sizes``.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

__all__ = ["sp500_like", "crypto_basket", "hawkes_order_book", "btc_minutes", "fgn", "hawkes_times"]

SECTORS = ["Information Technology", "Health Care", "Financials", "Consumer Discretionary",
           "Communication Services", "Industrials", "Consumer Staples", "Energy", "Utilities",
           "Real Estate", "Materials"]
COINS = ["BTC", "ETH", "BNB", "SOL", "XRP", "ADA", "DOGE", "AVAX", "LINK", "LTC"]


# ----------------------------------------------------------------------------------------------
# building blocks
# ----------------------------------------------------------------------------------------------
def fgn(n: int, H: float, rng) -> np.ndarray:
    """Fractional Gaussian noise with Hurst exponent H by circulant embedding (Davies–Harte), unit variance."""
    n = int(n)
    if n < 2:
        return rng.standard_normal(n)
    k = np.arange(n + 1, dtype=float)
    gamma = 0.5 * (np.abs(k + 1) ** (2 * H) - 2 * np.abs(k) ** (2 * H) + np.abs(k - 1) ** (2 * H))
    row = np.concatenate([gamma[:n + 1], gamma[n - 1:0:-1]])          # length 2n
    lam = np.fft.fft(row).real
    lam = np.maximum(lam, 0.0)                                          # tiny negative round-off only
    m = 2 * n
    z = rng.standard_normal(m) + 1j * rng.standard_normal(m)
    w = np.fft.fft(np.sqrt(lam / m) * z)
    return w.real[:n]


def hawkes_times(T: float, rate: float, branching: float, decay: float, rng, max_events=None) -> np.ndarray:
    """Event times of a Hawkes process on [0, T] with exponential kernel (cluster construction):
    immigrants at rate μ = rate·(1−branching), each event spawns Poisson(branching) children with
    Exp(decay) delays.  Mean rate = rate.  Returns sorted times."""
    mu = rate * (1.0 - branching)
    n_imm = rng.poisson(mu * T)
    times = [np.sort(rng.uniform(0.0, T, n_imm))]
    parents = times[0]
    total = n_imm
    while parents.size and total < (max_events or np.inf) * 4:
        n_child = rng.poisson(branching, parents.size)
        if n_child.sum() == 0:
            break
        child = np.repeat(parents, n_child) + rng.exponential(1.0 / decay, n_child.sum())
        child = child[child < T]
        if child.size == 0:
            break
        times.append(child)
        parents = child
        total += child.size
    t = np.sort(np.concatenate(times))
    if max_events is not None and t.size > max_events:
        t = t[:max_events]
    return t


def _ewm(x: np.ndarray, phi: float) -> np.ndarray:
    """y_t = φ y_{t−1} + x_t, vectorised with scipy's lfilter."""
    from scipy.signal import lfilter
    return lfilter([1.0], [1.0, -phi], x)


# ----------------------------------------------------------------------------------------------
# S&P 500-like basket
# ----------------------------------------------------------------------------------------------
def sp500_like(cfg, rng, n_assets=None, n_days=None) -> pd.DataFrame:
    """Daily simple returns of N stocks from a one-factor + sector + idiosyncratic model with Zipf-like
    market-cap weights (attrs: ``weights0``, ``sector``, ``shares``, ``price0``, ``planted``).
    Planted: κ ≈ 0.3 and Ψ = σ_I/Σ w σ ≈ 0.68 (AT-II Table 3), compound growth gap > 0 (AT-III Thm 3.3b)."""
    N = int(n_assets or cfg.sizes["n_assets"])
    T = int(n_days or min(cfg.sizes["n_bars"], 2520))
    sector = np.array([SECTORS[i % len(SECTORS)] for i in rng.permutation(N)])
    sec_id = np.array([SECTORS.index(s) for s in sector])
    # volatilities: lognormal with a wide dispersion (CV ≈ 0.6) — the dispersion is what separates κ from Ψ²
    sigma = 0.016 * np.exp(0.55 * rng.standard_normal(N) - 0.55 ** 2 / 2)
    sigma = np.clip(sigma, 0.006, 0.06)
    sigma_f, sigma_g = 0.0105, 0.0045                                   # market and sector factor vol per day
    beta = np.clip(1.0 + 0.25 * rng.standard_normal(N), 0.3, 2.0) * np.sqrt(sigma / sigma.mean())
    gam = np.clip(1.0 + 0.3 * rng.standard_normal(N), 0.2, 2.0)
    var_sys = (beta * sigma_f) ** 2 + (gam * sigma_g) ** 2
    scale = np.where(var_sys > 0.8 * sigma ** 2, np.sqrt(0.8 * sigma ** 2 / var_sys), 1.0)
    beta, gam = beta * scale, gam * scale
    var_sys = (beta * sigma_f) ** 2 + (gam * sigma_g) ** 2
    sigma_eps = np.sqrt(np.maximum(sigma ** 2 - var_sys, 1e-10))
    f = sigma_f * rng.standard_t(5, T) / np.sqrt(5 / 3)
    g = sigma_g * rng.standard_normal((T, len(SECTORS)))
    eps = sigma_eps * rng.standard_t(4, (T, N)) / np.sqrt(2.0)
    mu = 0.0003 + 0.0002 * rng.standard_normal(N)                       # ≈ 8 %/yr with dispersion
    r = mu + beta * f[:, None] + gam * g[:, sec_id] + eps
    r = np.clip(r, -0.5, 1.0)
    price0 = np.exp(rng.uniform(np.log(20), np.log(400), N))
    cap0 = 1e9 * (np.arange(1, N + 1) ** -0.8)[rng.permutation(N)] * np.exp(0.3 * rng.standard_normal(N))
    shares = cap0 / price0
    start = pd.Timestamp("2016-01-04")
    idx = pd.bdate_range(start, periods=T)
    names = [f"S{i:03d}" for i in range(N)]
    df = pd.DataFrame(r, index=idx, columns=names)
    df.attrs.update({"weights0": cap0 / cap0.sum(), "sector": sector, "shares": shares, "price0": price0,
                     "planted": {"kappa": 0.3, "sigma_ratio": 0.68, "sigma_f": sigma_f}})
    return df


# ----------------------------------------------------------------------------------------------
# crypto basket at one-second resolution
# ----------------------------------------------------------------------------------------------
def crypto_basket(cfg, rng, n_coins=None, n_seconds=None) -> pd.DataFrame:
    """One-second close prices of a basket of coins.  A common factor (i.i.d. Gaussian shocks per second plus
    rare market-wide jumps) reaches coin i after a fixed lag ℓ_i (BTC first at 0 s, the slowest ≈ 9 s, lag IQR
    ≈ 5 s as in AT-III Table 7) and spreads over a rise time ρ_i of 1–3 s (the mixture law, AT-III Thm 3.5).
    Idiosyncratic noise gives a pairwise correlation ρ∞ ≈ 0.79 at long Δ, so κ∞ ≈ 0.81 for ten equal-weighted
    coins and κ(Δ) ≈ κ∞ Δ/(Δ+τ) with τ ≈ 5 s (AT-II Hyp 4.4; Table 1: 0.745 at 1 min, 0.82 at 15 min).
    attrs: ``resolution_s`` = 1, ``lags``, ``planted``."""
    N = int(n_coins or cfg.sizes["n_coins"])
    cap = max(60_000, 12_000_000 // N)
    T = int(n_seconds or min(60 * cfg.sizes["n_bars"], cap))
    names = [COINS[i] if i < len(COINS) else f"COIN{i + 1:02d}" for i in range(N)]
    # lags: BTC 0, LTC slowest (9 s), the others spread in between; extra coins uniform on [0, 10]
    base = np.array([0.0, 1.0, 2.0, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 9.0])
    lags = np.concatenate([base[:min(N, 10)], rng.uniform(0.5, 9.5, max(N - 10, 0))])
    rise = np.clip(1.0 + 1.5 * rng.random(N), 1.0, 3.0)                 # rise time in seconds
    sigma_f = 7.5e-5                                                    # ≈ 42 %/yr factor vol per second
    rho_inf = 0.79
    c = 1.0 / rho_inf - 1.0                                             # idiosyncratic / factor variance
    f = sigma_f * rng.standard_t(4, T) / np.sqrt(2.0)
    n_jumps = max(1, T // 20_000)
    jt = rng.integers(0, T, n_jumps)
    f[jt] += rng.choice([-1.0, 1.0], n_jumps) * 25 * sigma_f            # market-wide jumps
    vol_scale = np.clip(1.0 + 0.3 * rng.standard_normal(N), 0.6, 1.8)   # coin-specific vol scale
    vol_scale[0] = 1.0
    r = np.empty((T, N))
    for i in range(N):
        k = int(round(rise[i]))
        kern = np.full(k, 1.0 / k)
        resp = np.convolve(f, kern)[:T]                                 # spread over the rise time
        d = int(round(lags[i]))
        resp = np.concatenate([np.zeros(d), resp[:T - d]])              # arrive after the lag
        idio = np.sqrt(c) * sigma_f * rng.standard_t(4, T) / np.sqrt(2.0)
        r[:, i] = vol_scale[i] * (resp + idio)
    logp = np.cumsum(r, axis=0)
    p0 = np.array([100_000, 3_500, 650, 180, 2.2, 0.8, 0.2, 35, 15, 90] + [10.0] * max(N - 10, 0))[:N]
    prices = p0 * np.exp(logp - logp[0])
    idx = pd.date_range("2026-01-05 00:00:00", periods=T, freq="s", tz="UTC")
    df = pd.DataFrame(prices, index=idx, columns=names)
    df.attrs.update({"resolution_s": 1, "lags": lags, "rise": rise, "weights": np.full(N, 1.0 / N),
                     "planted": {"tau": 5.0, "kappa_inf": 0.81, "rho_inf": rho_inf}})
    return df


# ----------------------------------------------------------------------------------------------
# Hawkes-driven level-1 order book
# ----------------------------------------------------------------------------------------------
def hawkes_order_book(cfg, rng, n_events=None, **planted) -> pd.DataFrame:
    """Level-1 book events (columns: time [s], bid, ask, bid_size, ask_size, trade_sign, trade_size) in
    price units with tick ``attrs['tick']``.

    Mechanism (reduced form, every ingredient planted):
      * event times: a Hawkes process (branching 0.85, 60 ms kernel): bursts of activity;
      * market-order signs ε: thresholded fractional Gaussian noise with Hurst H = 0.85 (AT-II Table 1 /
        Known 5.7); sizes v lognormal; signed flow u = ε √v;
      * the latent price moves by λ × the *surprise* s = u − E[u | past flow] (the predictable part of a
        long-memory flow is anticipated, Known 5.7), so prices stay diffusive while impact is √size
        (Known 5.6);
      * the mid is the latent price plus an overshoot A λ s that decays with time constant θ: the push that
        carries the mid far beyond the microprice offset within a second; it settles after a few seconds
        (AT-II §5.3, Table 3: k ≫ 1 for BTC, flattening after seconds);
      * the queues see the information first: imbalance = tanh(c₁ · position of the latent price inside the
        spread + c₂ · the next few surprises + noise), with a slowly varying total depth; OFI (Known 5.2)
        is then linear in the price change with R² ≈ 0.6 at 1 s.
    attrs: ``tick``, ``planted``."""
    N = int(n_events or cfg.sizes["n_book_events"])
    rate = float(np.clip(N / 20_000.0, 0.25, 20.0))                     # mean events per second
    T = N / rate
    t = hawkes_times(T, rate, branching=0.85, decay=1.0 / 0.06, rng=rng, max_events=N)
    n = t.size
    tick = 0.01
    H = planted.get("sign_hurst", 0.85)
    lam = planted.get("lam", 0.35)            # permanent impact per unit surprise (ticks)
    A = planted.get("A", 5.0)                 # overshoot multiple
    theta = planted.get("theta", 1.5)         # overshoot time constant (s)
    is_trade = rng.random(n) < 0.45
    sign = np.sign(fgn(n, H, rng))
    sign[sign == 0] = 1.0
    sign[~is_trade] = 0.0
    size = np.exp(0.9 * rng.standard_normal(n) - 0.9 ** 2 / 2)          # mean 1
    size[~is_trade] = 0.0
    u = sign * np.sqrt(size)
    # the market's expectation of the flow (an EMA of the past flow; the sign series has long memory)
    ema = _ewm(0.10 * u, 0.90)
    uhat = 0.75 * np.concatenate([[0.0], ema[:-1]])
    s = u - uhat                                                        # the surprise
    F = np.cumsum(lam * s + 0.08 * rng.standard_normal(n))              # latent price in ticks
    # overshoot: O_n = O_{n-1} e^{-(t_n - t_{n-1})/θ} + A λ s_n  (wall-clock decay)
    dt = np.diff(t, prepend=t[0])
    dec = np.exp(-dt / theta)
    O = np.empty(n)
    acc = 0.0
    for i in range(n):                                                  # short loop, n ≤ a few million
        acc = acc * dec[i] + A * lam * s[i]
        O[i] = acc
    mtil = F + O
    spread = rng.choice([1, 2, 3, 4], size=n, p=[0.25, 0.4, 0.25, 0.10]).astype(float)
    # quotes around the pushed latent price; the latent price sits inside the spread
    bid = np.floor(mtil - spread / 2.0 + 0.5)
    ask = bid + spread
    mid = 0.5 * (bid + ask)
    # information in the queues: where the latent price sits inside the spread + the next few surprises
    K, om = 8, 0.75
    fut = np.zeros(n)
    for j in range(1, K + 1):
        fut[:-j] += (om ** j) * s[j:]
    inside = np.clip((F - mid) / (spread / 2.0), -1, 1)
    imb = np.tanh(planted.get("c1", 1.2) * inside + planted.get("c2", 0.55) * fut
                  + planted.get("noise", 0.45) * rng.standard_normal(n))
    xi = _ewm(0.12 * rng.standard_normal(n), 0.95)
    depth = 20.0 * np.exp(xi)
    qb = np.maximum(depth * (1 + imb) / 2 * np.exp(0.12 * rng.standard_normal(n)), 0.2)
    qa = np.maximum(depth * (1 - imb) / 2 * np.exp(0.12 * rng.standard_normal(n)), 0.2)
    P0 = 100_000.0
    df = pd.DataFrame({"time": t, "bid": P0 + tick * bid, "ask": P0 + tick * ask,
                       "bid_size": qb, "ask_size": qa, "trade_sign": sign, "trade_size": size})
    df.attrs.update({"tick": tick, "rate": rate, "span_s": T,
                     "planted": {"sign_hurst": H, "impact_exponent": 0.5, "ofi_r2_1s": 0.6,
                                 "k_100ms": ">2", "k_60s": 1.0, "overshoot_theta_s": theta,
                                 "overshoot_A": A, "lambda_ticks": lam}})
    return df


# ----------------------------------------------------------------------------------------------
# BTC one-minute bars with a weak transient
# ----------------------------------------------------------------------------------------------
def btc_minutes(cfg, rng, n_bars=None) -> pd.DataFrame:
    """BTC/USDT-like one-minute OHLCV bars.  log price = random walk (σ ≈ 7 bp/min with GARCH-like clustering)
    + an AR(1) transient with half-life 5 bars and σ ≈ 12 bp: a weak reversal whose break-even cost is a few
    basis points (AT-II Table 1), below the 5–10 bp round trip.  attrs: ``planted``."""
    T = int(n_bars or cfg.sizes["n_bars"])
    phi = 0.5 ** (1.0 / 5.0)                                            # half-life 5 bars
    sig_rw, sig_x = 7e-4, 12e-4
    h = _ewm(np.abs(rng.standard_normal(T)) - np.sqrt(2 / np.pi), 0.97) * 0.3
    vol = sig_rw * np.exp(np.clip(h, -1.5, 1.5))
    rw = np.cumsum(vol * rng.standard_t(4, T) / np.sqrt(2.0))
    x = _ewm(np.sqrt(1 - phi ** 2) * sig_x * rng.standard_normal(T), phi)
    logp = np.log(95_000.0) + rw + x
    close = np.exp(logp)
    open_ = np.concatenate([[close[0]], close[:-1]])
    wig = np.abs(rng.standard_normal(T)) * vol * 0.6
    high = np.maximum(open_, close) * np.exp(wig)
    low = np.minimum(open_, close) * np.exp(-wig)
    volume = np.exp(3.0 + 0.8 * rng.standard_normal(T)) * (1 + 50 * np.abs(np.diff(logp, prepend=logp[0])))
    idx = pd.date_range("2026-01-01 00:00:00", periods=T, freq="min", tz="UTC")
    df = pd.DataFrame({"open": open_, "high": high, "low": low, "close": close, "volume": volume}, index=idx)
    df.index.name = "timestamp"
    df.attrs.update({"planted": {"half_life": 5.0, "transient_sigma": sig_x, "rw_sigma": sig_rw}})
    return df
