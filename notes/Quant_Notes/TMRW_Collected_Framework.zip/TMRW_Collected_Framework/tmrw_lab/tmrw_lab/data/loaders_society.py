"""Society data: NYT COVID-19 counties, JHU world series, the GDP table (real when the GitHub raw host
answers), Case-Shiller (FRED not reachable -> synthetic).  Every loader returns (data, origin) and never
raises; synthetic fallbacks come from tmrw_lab.data.synthetic_society with planted answers.
"""
from __future__ import annotations
import io

import numpy as np
import pandas as pd

from .common import fetch_text
from . import synthetic_society as SS

NYT = "https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-counties-2020.csv"
JHU = ("https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/"
       "csse_covid_19_time_series/time_series_covid19_confirmed_global.csv")
GDP = "https://raw.githubusercontent.com/datasets/gdp/main/data/gdp.csv"


def load_nyt_counties(cfg, rng=None):
    """dict(weekly_new (T, N), daily_new, state (N,), ...) of new cases per county, 2020."""
    text, origin = fetch_text(NYT, cfg, "nyt_us_counties_2020.csv", timeout=cfg.timeout)
    if text is not None:
        try:
            df = pd.read_csv(io.StringIO(text), usecols=["date", "county", "state", "fips", "cases"])
            df = df.dropna(subset=["fips"])
            df["date"] = pd.to_datetime(df["date"])
            piv = df.pivot_table(index="date", columns="fips", values="cases", aggfunc="max").ffill().fillna(0.0)
            daily = piv.diff().clip(lower=0).fillna(0.0)
            n = cfg.sizes["n_units"] * 20
            if daily.shape[1] > n:            # keep the largest counties when the preset is small
                keep = daily.sum().sort_values(ascending=False).index[:n]
                daily = daily[keep]
            state = df.drop_duplicates("fips").set_index("fips").loc[daily.columns, "state"].to_numpy()
            weekly = daily.resample("W").sum()
            return {"weekly_new": weekly.to_numpy(), "daily_new": daily.to_numpy(), "state": state,
                    "dates": daily.index, "planted": None}, "real"
        except Exception:  # noqa: BLE001
            pass
    rng = rng or np.random.default_rng(cfg.seed)
    return SS.counties(cfg, rng), "synthetic"


def load_world_gdp(cfg, rng=None):
    """dict(gdp (T, N) current USD by country-year, region (N,))."""
    text, origin = fetch_text(GDP, cfg, "gdp.csv", timeout=cfg.timeout)
    if text is not None:
        try:
            df = pd.read_csv(io.StringIO(text))
            cols = {c.lower(): c for c in df.columns}
            code = cols.get("country code", "Country Code"); year = cols.get("year", "Year"); val = cols.get("value", "Value")
            df = df[~df[code].isin(SS.WB_AGGREGATES if hasattr(SS, "WB_AGGREGATES") else [])]
            piv = df.pivot_table(index=year, columns=code, values=val)
            piv = piv.loc[piv.index >= 1980].dropna(axis=1)                       # complete series only
            growth = piv.pct_change().abs().max()
            piv = piv.loc[:, growth < 5.0]                                        # drop series with > 500% jumps (data errors)
            region_map = {c: r for r, codes in SS.WB_REGIONS.items() for c in codes.split()} if hasattr(SS, "WB_REGIONS") else {}
            region = np.array([region_map.get(c, "Other") for c in piv.columns])
            return {"gdp": piv.to_numpy(), "region": region, "years": piv.index.to_numpy(), "planted": None}, "real"
        except Exception:  # noqa: BLE001
            pass
    rng = rng or np.random.default_rng(cfg.seed)
    return SS.countries_gdp(cfg, rng), "synthetic"


def load_case_shiller(cfg, rng=None):
    """FRED is not reachable from the build machine: synthetic metros with the planted kappa = 0.727."""
    rng = rng or np.random.default_rng(cfg.seed)
    return SS.case_shiller(cfg, rng), "synthetic"


def load_jhu_world(cfg):
    text, origin = fetch_text(JHU, cfg, "jhu_confirmed_global.csv", timeout=cfg.timeout)
    if text is None:
        return None, None
    try:
        df = pd.read_csv(io.StringIO(text))
        ser = df.drop(columns=["Province/State", "Lat", "Long"]).groupby("Country/Region").sum().T
        ser.index = pd.to_datetime(ser.index)
        return ser, "real"
    except Exception:  # noqa: BLE001
        return None, None
