"""Market data: a US stock basket (Stooq daily CSV), crypto minute closes and level-1 book updates
(Binance public REST), BTC minute bars (Binance).  Each loader tries the host for cfg.timeout seconds,
caches what it gets, and otherwise returns the synthetic generator with planted answers.
Returns (data, origin) with origin "real" or "synthetic"; never raises.
"""
from __future__ import annotations
import io
import json

import numpy as np
import pandas as pd

from .common import fetch_text
from . import synthetic_markets as SM

STOOQ = "https://stooq.com/q/d/l/?s={sym}.us&i=d"
BINANCE_KLINES = "https://api.binance.com/api/v3/klines?symbol={sym}&interval=1m&limit=1000"
BINANCE_TRADES = "https://api.binance.com/api/v3/trades?symbol=BTCUSDT&limit=1000"
STOCKS = ["aapl", "msft", "amzn", "googl", "jpm", "xom", "jnj", "pg", "v", "unh", "hd", "cvx", "ko", "pfe", "csco",
          "pep", "wmt", "mrk", "dis", "ba", "mcd", "nke", "ibm", "cat", "ge", "intc", "t", "vz", "mmm", "gs"]
COINS = ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT", "ADAUSDT", "DOGEUSDT", "AVAXUSDT", "LTCUSDT", "LINKUSDT"]


def load_sp500_constituents(cfg, rng=None):
    """DataFrame of daily simple returns (columns = tickers) with attrs['weights0'] (cap-like weights)."""
    frames = {}
    if not cfg.offline:
        for sym in STOCKS[: max(5, min(len(STOCKS), cfg.sizes["n_assets"]))]:
            text, _ = fetch_text(STOOQ.format(sym=sym), cfg, f"stooq_{sym}.csv", timeout=cfg.timeout)
            if text and "Close" in text:
                try:
                    df = pd.read_csv(io.StringIO(text), parse_dates=["Date"]).set_index("Date")["Close"]
                    frames[sym.upper()] = df
                except Exception:  # noqa: BLE001
                    pass
            if not text and len(frames) == 0:
                break                       # host not answering: do not wait for every symbol
    if len(frames) >= 5:
        px = pd.concat(frames, axis=1).dropna().iloc[-cfg.sizes["n_bars"]:]
        ret = px.pct_change().dropna()
        ret.attrs["weights0"] = (px.iloc[-1] / px.iloc[-1].sum()).to_numpy()
        ret.attrs["planted"] = None
        return ret, "real"
    rng = rng or np.random.default_rng(cfg.seed)
    return SM.sp500_like(cfg, rng), "synthetic"


def load_crypto_minutes(cfg, rng=None):
    """DataFrame of close prices (columns = coins) at 1 min (real) or 1 s (synthetic; attrs['resolution_s'])."""
    cols = {}
    if not cfg.offline:
        for sym in COINS[: max(3, cfg.sizes["n_coins"])]:
            text, _ = fetch_text(BINANCE_KLINES.format(sym=sym), cfg, f"binance_{sym}_1m.json", timeout=cfg.timeout)
            if not text:
                break
            try:
                rows = json.loads(text)
                cols[sym.replace("USDT", "")] = pd.Series([float(r[4]) for r in rows], index=pd.to_datetime([r[0] for r in rows], unit="ms"))
            except Exception:  # noqa: BLE001
                pass
    if len(cols) >= 3:
        df = pd.concat(cols, axis=1).dropna()
        df.attrs.update({"resolution_s": 60, "planted": None, "weights": np.full(df.shape[1], 1.0 / df.shape[1])})
        return df, "real"
    rng = rng or np.random.default_rng(cfg.seed)
    return SM.crypto_basket(cfg, rng), "synthetic"


def load_order_book_events(cfg, rng=None):
    """Level-1 events DataFrame(time, bid, ask, bid_size, ask_size, trade_sign, trade_size).
    Binance's REST gives recent trades only (no level-1 history): used to calibrate the synthetic book's
    trade-size distribution when reachable; the events themselves are synthetic."""
    rng = rng or np.random.default_rng(cfg.seed)
    df = SM.hawkes_order_book(cfg, rng)
    if not cfg.offline:
        text, _ = fetch_text(BINANCE_TRADES, cfg, "binance_btc_trades.json", timeout=cfg.timeout)
        if text:
            try:
                q = np.array([float(r["qty"]) for r in json.loads(text)])
                df.attrs["real_trade_size_mean"] = float(q.mean())
                df.attrs["calibration"] = "binance recent trades (sizes only)"
            except Exception:  # noqa: BLE001
                pass
    return df, "synthetic"


def load_btc_minutes(cfg, rng=None):
    """BTC minute bars DataFrame(open, high, low, close, volume)."""
    if not cfg.offline:
        text, _ = fetch_text(BINANCE_KLINES.format(sym="BTCUSDT"), cfg, "binance_BTCUSDT_1m.json", timeout=cfg.timeout)
        if text:
            try:
                rows = json.loads(text)
                df = pd.DataFrame({k: [float(r[i]) for r in rows] for i, k in ((1, "open"), (2, "high"), (3, "low"), (4, "close"), (5, "volume"))},
                                  index=pd.to_datetime([r[0] for r in rows], unit="ms"))
                df.attrs["planted"] = None
                return df, "real"
            except Exception:  # noqa: BLE001
                pass
    rng = rng or np.random.default_rng(cfg.seed)
    return SM.btc_minutes(cfg, rng), "synthetic"
