"""Shared helpers for the data loaders: a small cache and a guarded download.

    text, origin = fetch_text(url, cfg, "nyt_counties.csv")   # origin: "cache" | "real" | None
Returns (None, None) when offline or when the host does not answer within cfg.timeout.
"""
from __future__ import annotations
import io
from pathlib import Path

import pandas as pd


def fetch_text(url: str, cfg, cache_name: str, timeout: float | None = None):
    """Return (text, origin) with origin 'cache' or 'real'; (None, None) if unavailable."""
    cache = Path(cfg.cache_dir) / cache_name
    if cache.exists() and cache.stat().st_size > 0:
        return cache.read_text(errors="replace"), "cache"
    if cfg.offline:
        return None, None
    try:
        import requests
        r = requests.get(url, timeout=timeout or cfg.timeout, headers={"User-Agent": "tmrw_lab/0.1"})
        if r.status_code != 200 or not r.text:
            return None, None
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(r.text)
        return r.text, "real"
    except Exception:  # noqa: BLE001 - any network failure means "not available"
        return None, None


def cached_csv(url: str, cfg, cache_name: str, **read_csv_kwargs):
    """DataFrame from a cached/downloaded CSV, or (None, None)."""
    text, origin = fetch_text(url, cfg, cache_name)
    if text is None:
        return None, None
    try:
        return pd.read_csv(io.StringIO(text), **read_csv_kwargs), ("real" if origin == "real" else "real")
    except Exception:  # noqa: BLE001
        return None, None


def fetch_bytes(url: str, cfg, cache_name: str, timeout: float | None = None):
    """Binary variant of fetch_text (for zipped or binary files)."""
    cache = Path(cfg.cache_dir) / cache_name
    if cache.exists() and cache.stat().st_size > 0:
        return cache.read_bytes(), "cache"
    if cfg.offline:
        return None, None
    try:
        import requests
        r = requests.get(url, timeout=timeout or cfg.timeout, headers={"User-Agent": "tmrw_lab/0.1"})
        if r.status_code != 200 or not r.content:
            return None, None
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_bytes(r.content)
        return r.content, "real"
    except Exception:  # noqa: BLE001
        return None, None
