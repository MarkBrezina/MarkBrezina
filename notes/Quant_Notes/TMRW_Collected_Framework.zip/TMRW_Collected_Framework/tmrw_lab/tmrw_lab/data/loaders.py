"""All data loaders in one namespace: every loader returns (data, origin) and never raises."""
from .loaders_society import load_nyt_counties, load_world_gdp, load_case_shiller, load_jhu_world  # noqa: F401
from .loaders_markets import load_sp500_constituents, load_crypto_minutes, load_order_book_events, load_btc_minutes  # noqa: F401
from ..hypotheses.h08_one_expansion_rate import load_pantheon  # noqa: F401
from ..hypotheses.h07_bound_free_composites import nuclei_table, hadron_table  # noqa: F401
