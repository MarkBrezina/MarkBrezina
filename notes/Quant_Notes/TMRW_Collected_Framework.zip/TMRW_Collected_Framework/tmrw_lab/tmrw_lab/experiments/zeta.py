"""D: the Riemann zeta function as an aggregate (AT-III Sec. 9).

Z(t) = 2 sum_{n <= sqrt(t/2pi)} n^{-1/2} cos(theta(t) - t log n) + remainder: the units are the terms,
the aggregate is their sum, the zeros are where the units cancel.  The experiment counts the zeros of
Z on [50, T] (sign changes + bisection, numpy Riemann-Siegel), compares with the exact count
(mpmath.nzeros) and the smooth Riemann-von Mangoldt count, shows the layers (partial sums) near a zero,
and compares the unfolded spacings with the GUE Wigner surmise (AT-III: 1,747,146 zeros to height
10^6, none missing, GUE statistics; a check, not a proof).
"""
from __future__ import annotations
import numpy as np

from ..core import riemann_siegel as RS
from ..result import Result
from ._plot import figure, save


def run(cfg) -> Result:
    res = Result(name="experiments.zeta", title="D: zeros of the zeta function as cancellation of units")
    T = float(cfg.sizes["zeta_height"])
    zeros, step = RS.zeros_up_to(T, t0=50.0)
    import mpmath as mp
    mp.mp.dps = 15
    try:
        exact = int(mp.nzeros(T)) - int(mp.nzeros(50.0))
    except Exception:  # noqa: BLE001
        exact = int(round(RS.riemann_von_mangoldt(T) - RS.riemann_von_mangoldt(50.0)))
    smooth = RS.riemann_von_mangoldt(T) - RS.riemann_von_mangoldt(50.0)
    missing = max(0, exact - len(zeros))
    res.add("zeta.height_T", T, source="AT-III ran to 10^6 (full preset)")
    res.add("zeta.n_zeros_found", len(zeros), expected=exact, abs_tol=0, source="exact count (mpmath.nzeros)")
    res.add("zeta.n_zeros_smooth", smooth, source="Riemann-von Mangoldt")
    res.add("zeta.missing", missing, expected=0, abs_tol=0, source="AT-III Sec. 9.2: missing 0")
    res.add("zeta.share_on_line", 1.0 - missing / max(exact, 1), expected=1.0, abs_tol=0.0, source="AT-III: all zeros on the critical line (counted)")
    # layers near one zero: partial sums of the units
    z0 = zeros[len(zeros) // 2]
    u = RS.units(z0)
    layers = np.cumsum(u)
    res.add("zeta.units_at_mid_zero", len(u))
    res.add("zeta.partial_sum_at_zero_over_amplitude", float(abs(layers[-1] + RS.remainder(z0)) / np.sum(np.abs(u))), expected=0.0, abs_tol=1e-6,
            source="units cancel at a zero")
    s = RS.unfolded_spacings(zeros); s = s[s > 0]
    xs = np.sort(s); F = np.arange(1, len(xs) + 1) / len(xs)
    ks = float(np.max(np.abs(F - RS.gue_wigner_cdf(xs))))
    res.add("zeta.gue_ks", ks, expected=0.0, expected_hi=0.1, source="AT-III Sec. 9.2: GUE statistics")
    res.add("zeta.spacing_var", float(np.var(s)), expected=0.18, tol=0.3, source="GUE Wigner surmise: variance 3pi/8 - 1 = 0.178")
    res.data_origin = "analytic"
    res.note(f"{len(zeros)} zeros on [50, {T:.0f}] against the exact count {exact} (smooth {smooth:.1f}); grid step {step:.3f}; a check, not a proof")
    fig, ax = figure(cfg, "zeta", 3, ncols=3)
    tt = np.linspace(max(50.0, z0 - 30), z0 + 30, 1500)
    ax[0].plot(tt, RS.Z(tt), lw=0.8); ax[0].axhline(0, color="k", lw=0.5)
    zz = zeros[(zeros > tt[0]) & (zeros < tt[-1])]; ax[0].plot(zz, np.zeros_like(zz), "r.", ms=4); ax[0].set_title("Z(t) with its zeros")
    ax[1].bar(np.arange(1, len(u) + 1), u, width=0.8); ax[1].plot(np.arange(1, len(u) + 1), layers, "k.-", ms=3, label="partial sums")
    ax[1].legend(); ax[1].set_title(f"units and layers at t = {z0:.2f}")
    grid = np.linspace(0, 3, 200)
    ax[2].hist(s, bins=30, density=True, alpha=0.6, label="unfolded spacings")
    ax[2].plot(grid, 32 / np.pi ** 2 * grid ** 2 * np.exp(-4 * grid ** 2 / np.pi), "r-", label="GUE Wigner surmise"); ax[2].legend(); ax[2].set_title(f"KS = {ks:.3f}")
    res.figures.append(save(fig, cfg, "zeta"))
    return res
