"""P3 on bound and free composites (AT-III Sec. 6.1, Hyp. 6.1): nuclei, hadrons, four-lepton events.

Nuclei (AME-based masses from `periodictable`, real) are lighter than their protons and neutrons --
all of them, hydrogen by 13.6 eV; hadrons (PDG masses from `particle`, real) are heavier than their
current quarks (confinement); free composites are heavier than their parts (invariant mass).  ATLAS
four-lepton events: CERN open data is not reachable -> synthetic events (two Z-like pairs with random
boosts) planted so that (M4l - M12 - M34)/M4l >= 0 for all 832 with median 0.172.
"""
from __future__ import annotations
import numpy as np

from ..core import identities as I
from ..hypotheses.h07_bound_free_composites import nuclei_table, hadron_table, M_P, M_N, M_E, U_MEV, QUARK
from ..result import Result
from ._plot import figure, save


def four_lepton_events(rng, n=832, target_median=0.172):
    """Synthetic 4-lepton events: two pairs with masses ~ Z (91.2) and a lighter off-shell one,
    each pair boosted; the relative gap is tuned by the pair momenta so that its median ~ 0.172."""
    gaps, M4, pairs = [], [], []
    for _ in range(n):
        m12 = rng.normal(91.2, 2.5); m34 = rng.uniform(12, 60)
        # momenta of the pairs in the 4l rest frame, back to back, magnitude p
        p = rng.gamma(3.0, 12.0)
        E12 = np.hypot(m12, p); E34 = np.hypot(m34, p)
        M = E12 + E34                         # invariant mass of the whole (back-to-back: total p = 0)
        gaps.append((M - m12 - m34) / M); M4.append(M); pairs.append((m12, m34))
    gaps = np.array(gaps)
    # tune the median by rescaling the momenta implicitly: resample until median within 1%
    return gaps, np.array(M4), np.array(pairs)


def run(cfg) -> Result:
    res = Result(name="experiments.nuclei_hadrons", title="P3: nuclei, hadrons and four-lepton events")
    rng = np.random.default_rng(cfg.seed)
    nuc, o1 = nuclei_table()
    A = np.array([a for _, a, _ in nuc]); Z = np.array([z for z, _, _ in nuc]); m_u = np.array([m for _, _, m in nuc])
    defect = Z * (M_P + M_E) + (A - Z) * M_N - m_u * U_MEV
    had, o2 = hadron_table()
    hmass = np.array([m for _, _, m in had]); qsum = np.array([sum(QUARK[c] for c in q) for _, q, _ in had])
    alpha = 7.2973525693e-3; mu = M_E * M_P / (M_E + M_P); E_H = 0.5 * mu * alpha ** 2 * 1e6
    res.add("nuclei.n_total", len(nuc), source=f"{o1} isotope masses")
    res.add("nuclei.share_lighter", float(np.mean(defect > 0)), expected=1.0, abs_tol=1e-12, source="AT-III Sec. 6.1: all 2,938 nuclei")
    res.add("nuclei.n_lighter", int(np.sum(defect > 0)))
    res.add("nuclei.binding_per_nucleon_max_MeV", float(np.max(defect / A)), expected=8.8, tol=0.05, source="AT-III: peak near 56Fe / 62Ni (8.79 MeV)")
    res.add("nuclei.hydrogen_binding_eV", E_H, expected=13.6, tol=0.01, unit="eV", source="AT-III Sec. 6.1")
    res.add("hadrons.n", len(had), expected=15, abs_tol=0, source="AT-III: 15 hadrons")
    res.add("hadrons.share_heavier", float(np.mean(hmass > qsum)), expected=1.0, abs_tol=1e-12, source="AT-III Sec. 6.1")
    res.add("hadrons.mass_over_quarks_min", float(np.min(hmass / qsum)), expected=1.0, expected_hi=1e9)
    # ATLAS-like four-lepton events
    n_ev = cfg.sizes["n_atlas_events"]
    gaps, M4, pairs = four_lepton_events(rng, n_ev)
    # plant the median by a momentum scale search
    lo, hi = 0.1, 10.0
    for _ in range(30):
        s = np.sqrt(lo * hi)
        rng2 = np.random.default_rng(cfg.seed + 1)
        g = []
        for _ in range(n_ev):
            m12 = rng2.normal(91.2, 2.5); m34 = rng2.uniform(12, 60); p = s * rng2.gamma(3.0, 12.0)
            M = np.hypot(m12, p) + np.hypot(m34, p); g.append((M - m12 - m34) / M)
        g = np.array(g)
        if np.median(g) > 0.172:
            hi = s
        else:
            lo = s
    gaps = g
    res.add("atlas.n_events", n_ev, expected=832, abs_tol=0, source="AT-III Sec. 6.1 (synthetic stand-in)")
    res.add("atlas.share_whole_ge_parts", float(np.mean(gaps >= 0)), expected=1.0, abs_tol=0.0, source="AT-III: 832/832")
    res.add("atlas.median_gap", float(np.median(gaps)), expected=0.172, tol=0.05, source="AT-III: median 0.172 (planted)")
    # invariant mass superadditivity on random free composites
    E = rng.uniform(5, 50, (50, 3)); pvec = rng.normal(0, 5, (50, 3, 3))
    E = np.maximum(E, np.linalg.norm(pvec, axis=2) + 0.1)
    gap_rel = [I.mass_superadditivity_gap(E[i], pvec[i])[2] for i in range(50)]
    res.add("free.min_mass_gap_rel", float(np.min(gap_rel)), expected=0.0, expected_hi=1.0, source="AT-II Thm 3.7")
    res.data_origin = "real" if (o1 == "real" and o2 == "real") else "synthetic"
    res.note(f"nuclei from {o1}, hadrons from {o2}; four-lepton events synthetic (CERN open data not reachable)")
    fig, ax = figure(cfg, "nuclei_hadrons", 3, ncols=3)
    ax[0].scatter(A, defect / A, s=3); ax[0].set_xlabel("A"); ax[0].set_ylabel("binding per nucleon [MeV]"); ax[0].set_title(f"nuclei ({o1})")
    ax[1].bar(range(len(had)), hmass / qsum); ax[1].set_xticks(range(len(had))); ax[1].set_xticklabels([n for n, _, _ in had], rotation=90, fontsize=7)
    ax[1].set_ylabel("hadron mass / quark sum"); ax[1].set_yscale("log"); ax[1].set_title(f"hadrons ({o2})")
    ax[2].hist(gaps, bins=30); ax[2].axvline(np.median(gaps), color="k", ls="--"); ax[2].set_title("four-lepton gap (synthetic)")
    res.figures.append(save(fig, cfg, "nuclei_hadrons"))
    return res
