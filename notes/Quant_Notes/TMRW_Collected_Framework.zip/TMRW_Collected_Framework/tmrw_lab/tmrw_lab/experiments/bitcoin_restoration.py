"""The AT-0 Bitcoin study restored as a special case (AT-III Sec. 10; AT-0 Sec. 9-13).

AT-0 Hypothesis 9.1 (aggregation lowers the mean) is refuted as stated -- the mean is preserved; what
the Bitcoin minute-bar study actually measured was short-horizon mean reversion: Hurst ~ 0.16 of the
returns, a half-life of ~5 steps, a decile past-return -> future-return profile that reverses, rank
information coefficients of a few hundredths, and an out-of-sample reversal of 0.3-3.3 bp per trade
against a round-trip cost of ~10 bp.  The module reproduces those diagnostics on BTC minute bars
(Binance when reachable, else the synthetic bars with the planted half-life) and shows that the
reversal sits below costs.
"""
from __future__ import annotations
import numpy as np

from ..core import impact as IM
from ..data import loaders_markets as LM
from ..result import Result
from ._plot import figure, save

HORIZONS = (1, 5, 10, 30, 60, 100)


def half_life(r):
    """AR(1) half-life of the cumulative-return deviation (mean reversion of the transient)."""
    x = np.cumsum(r); x = x - np.convolve(x, np.ones(60) / 60, mode="same")
    phi = np.corrcoef(x[:-1], x[1:])[0, 1]
    return -np.log(2) / np.log(abs(phi)) if 0 < abs(phi) < 1 else np.inf


def rank_ic(past, future):
    from scipy.stats import spearmanr
    return float(spearmanr(past, future).correlation)


def run(cfg) -> Result:
    res = Result(name="experiments.bitcoin_restoration", title="The Bitcoin study as a special case (refuted hypothesis restored)")
    rng = np.random.default_rng(cfg.seed)
    df, origin = LM.load_btc_minutes(cfg, rng)
    close = np.asarray(df["close"], float); r = np.diff(np.log(close))
    hu = IM.hurst_exponent(r)
    res.add("bitcoin.hurst_returns", float(hu["H_av"]), expected=0.0, expected_hi=0.5, source="AT-0 / earlier run: 0.159 (mean reverting: H < 0.5)")
    res.add("bitcoin.halflife_steps", half_life(r), expected=5.0, tol=0.8, unit="min", source="AT-0: ~5 steps")
    # decile profile: past 5-min return deciles -> future h-step returns
    past = np.convolve(r, np.ones(5), mode="valid")[:-max(HORIZONS)]
    prof = {}
    ics = {}
    for h in HORIZONS:
        fut = np.array([np.sum(r[i + 5:i + 5 + h]) for i in range(len(past))])
        dec = np.digitize(past, np.quantile(past, np.linspace(0, 1, 11)[1:-1]))
        prof[h] = np.array([fut[dec == d].mean() for d in range(10)])
        ics[h] = rank_ic(past, fut)
        res.add(f"bitcoin.rank_ic_{h}", ics[h], expected=-0.15, expected_hi=-0.0, source="AT-III Sec. 10: -0.035 .. -0.087 (reversal)")
    res.add("bitcoin.decile_reversal_1", float(prof[1][0] - prof[1][-1]), expected=0.0, expected_hi=1.0, source="bottom minus top decile future return > 0")
    # naive reversal rule, walk-forward, with a 10 bp round-trip cost
    n = len(r); split = n // 2
    sig = -np.sign(np.convolve(r, np.ones(5), mode="full")[:n])          # short the past 5-min winners
    pos = np.r_[0, sig[:-1]]
    gross = pos * r
    trades = np.abs(np.diff(pos, prepend=0)) / 2
    bp_per_trade = 1e4 * gross[split:].sum() / max(trades[split:].sum(), 1)
    net = gross - trades * 10e-4
    oos = net[split:]
    sharpe = oos.mean() / (oos.std() + 1e-12) * np.sqrt(60 * 24 * 365)
    res.add("bitcoin.reversal_bp_per_trade", bp_per_trade, expected=0.0, expected_hi=10.0, source="AT-III Sec. 10: 0.3-3.3 bp vs 10 bp cost")
    res.add("bitcoin.oos_sharpe_after_costs", sharpe, expected=-1e6, expected_hi=0.0, source="below costs")
    res.add("bitcoin.n_bars", n, source=f"{origin}")
    res.data_origin = origin
    res.note("AT-0 Hypothesis 9.1 as stated is refuted: the aggregate mean is preserved; what aggregation lowers is turbulence. "
             "The restoration places the study inside P1: a short-lived internal motion (mean reversion) below the cost of trading it.")
    res.note(f"bars: {origin}; horizons {HORIZONS}; walk-forward split at the midpoint; 10 bp round-trip")
    fig, ax = figure(cfg, "bitcoin_restoration", 2)
    for h in (1, 5, 30):
        ax[0].plot(range(1, 11), 1e4 * prof[h], "o-", label=f"h = {h}")
    ax[0].set_xlabel("decile of past 5-min return"); ax[0].set_ylabel("future return [bp]"); ax[0].legend(); ax[0].set_title(f"decile profile ({origin})")
    ax[1].plot(np.cumsum(net[split:]) * 1e4, label="net of 10 bp"); ax[1].plot(np.cumsum(gross[split:]) * 1e4, label="gross"); ax[1].legend(); ax[1].set_ylabel("bp"); ax[1].set_title("reversal rule, out of sample")
    res.figures.append(save(fig, cfg, "bitcoin_restoration"))
    return res
