"""Toy models for the five conjectures (compendium Part IV): each toy is a small model in which the
conjecture's mechanism can be switched on, with the numbers the conjecture itself states as targets.
"""
from __future__ import annotations
import numpy as np

from ..conjectures import c1_path_switching as C1, c2_central_pricing as C2, c3_stealth_execution as C3
from ..conjectures import c4_hybrid_mfg as C4, c5_final_problem as C5
from ..result import Result
from ._plot import figure, save


def run(cfg) -> Result:
    res = Result(name="experiments.conjecture_toys", title="Toy models for Conjectures 1-5")
    rng = np.random.default_rng(cfg.seed)
    out = {}
    for name, mod in (("c1", C1), ("c2", C2), ("c3", C3), ("c4", C4), ("c5", C5)):
        try:
            out[name] = mod.simulate(cfg, rng)
            res.note(f"{name}: {mod.describe()}")
        except Exception as e:  # noqa: BLE001
            out[name] = None
            res.note(f"{name} failed: {type(e).__name__}: {e}")
    d = out.get("c1")
    if d:
        res.add("c1.gain_timely", d["gain_timely"], expected=0.0, expected_hi=1e9, source="C1: switching in time beats either fixed path")
        res.add("c1.gain_lagged", d["gain_lagged"], expected=-1e9, expected_hi=0.0, source="C1: switching late loses")
        res.add("c1.breakeven_lag", d["breakeven_lag"], expected=0.0, expected_hi=d.get("regime_duration", 100), unit="steps",
                source="C1: the lag beyond which switching stops paying (regime duration)")
    d = out.get("c2")
    if d:
        res.add("c2.alpha_hat", d["alpha_hat"], expected=d["alpha_planted"], tol=0.1, source="C2: P_{T+1} = alpha I + (1-alpha) H + eps (planted alpha)")
        res.add("c2.alpha_tstat", d["alpha_tstat"], expected=3.0, expected_hi=1e9, source="C2: alpha significant")
        res.add("c2.r2", d["r2"])
        res.add("c2.coverage_band", d.get("coverage", np.nan), expected=0.85, expected_hi=1.0, source="C2: 1 - delta coverage of the conformal band (delta = 0.1)")
        res.add("c2.rmse_ratio_vs_random_walk", d.get("rmse_ratio", np.nan), expected=0.0, expected_hi=1.0, source="C2: beats the random walk")
        res.add("c2.n_assets", d["n_assets"], expected=4, expected_hi=1e9, source="C2: N > 3")
    d = out.get("c3")
    if d:
        res.add("c3.cost_equal", d["cost_equal"]); res.add("c3.cost_front", d["cost_front"])
        res.add("c3.cost_equal_over_front", d["cost_equal"] / d["cost_front"], expected=0.0, expected_hi=1.0, source="C3: equal split cheapest under the symmetric cost")
        res.add("c3.optimal_n", d["optimal_n"], expected=1, expected_hi=d["n_max"], source="C3: N <= N_max = 100")
        res.add("c3.sqrt_exponent_check", d["sqrt_exponent"], expected=0.5, abs_tol=0.02, source="C3: g(x) ~ c sqrt(x)")
        res.add("c3.q_usd", d["q"], expected=1_000_000, abs_tol=0, source="C3: Q = 1,000,000 USD")
    d = out.get("c4")
    if d:
        res.add("c4.exploitability_final", d["exploitability_final"], expected=0.0, abs_tol=1e-3, source="C4: equilibrium exists (exploitability -> 0)")
        res.add("c4.iterations_to_converge", d["iterations_to_converge"], expected=1, expected_hi=cfg.sizes["n_mfg_iter"] * 10)
        res.add("c4.fixed_point_residual", d["fixed_point_residual"], expected=0.0, abs_tol=1e-6)
        res.add("c4.jump_flux", d.get("jump_flux", np.nan), source="mass crossing the guard per step (hybrid reset map)")
    d = out.get("c5")
    if d:
        res.add("c5.utility_optimal", d["utility_optimal"]); res.add("c5.utility_naive", d["utility_naive"])
        res.add("c5.improvement", d["improvement"], expected=0.0, expected_hi=1e9, source="C5: highest expected utility under shared limits beats naive")
        res.add("c5.limits_respected", d["limits_respected"], expected=1.0, abs_tol=0.0, source="C5: shared limits")
        res.add("c5.free_energy_optimal", d["free_energy_optimal"], expected=0.0, expected_hi=d["free_energy_naive"] + 1e-9,
                source="C5: minimise free energy (risk) -- at or below the naive allocation's")
    res.data_origin = "simulation"
    fig, ax = figure(cfg, "conjecture_toys", 5, ncols=3)
    d = out.get("c1")
    if d:
        ax[0].plot(d["lags"], d["gain"], "o-"); ax[0].axhline(0, color="k", lw=0.5); ax[0].set_xlabel("switching lag"); ax[0].set_title("C1: gain from switching")
    d = out.get("c2")
    if d:
        ax[1].errorbar(range(len(d["per_asset_alpha"])), d["per_asset_alpha"], yerr=d["per_asset_se"], fmt="o", ms=3); ax[1].axhline(d["alpha_planted"], color="r"); ax[1].set_title("C2: alpha per asset")
    d = out.get("c3")
    if d:
        ax[2].plot(d["ns"], d["cost_vs_n"], "o-"); ax[2].axvline(d["optimal_n"], color="r", ls="--"); ax[2].set_xlabel("N children"); ax[2].set_title("C3: cost vs N")
    d = out.get("c4")
    if d:
        ax[3].semilogy(d["residuals"]); ax[3].set_title("C4: fixed-point residual"); ax[3].set_xlabel("iteration")
    d = out.get("c5")
    if d:
        ax[4].bar(range(d["n_positions"]), d["x"]); ax[4].set_title("C5: optimal allocation")
    res.figures.append(save(fig, cfg, "conjecture_toys"))
    return res
