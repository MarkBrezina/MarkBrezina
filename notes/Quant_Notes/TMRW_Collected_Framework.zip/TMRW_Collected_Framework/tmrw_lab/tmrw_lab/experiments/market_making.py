"""The worked case of NB-01 (compendium ch. nb-mm): no skew vs linear skew vs band skew, the taking
layer, the tuning grid.  Expected: inventory inside +/-79 for 99% of the session with the skew; the taking
layer cut PnL 2,300 -> 1,600 (-30%); the best cell of the grid risk_aversion x inventory_limit.
"""
from __future__ import annotations
import numpy as np

from ..micro import mm_simulator as MM
from ..result import Result
from ._plot import figure, save


def run(cfg) -> Result:
    res = Result(name="experiments.market_making", title="Market making: skew, bands, taking, tuning (NB-01)")
    n_ticks = int(cfg.sizes["n_ticks"]); n_paths = int(cfg.sizes["n_sessions"])
    runs = {}
    for label, params in (("no_skew", dict(skew="none")), ("linear_skew", dict(skew="linear")),
                          ("band_skew", dict(skew="band")), ("linear_skew_taking", dict(skew="linear", taking=True))):
        rng = np.random.default_rng(cfg.seed)          # common random numbers across variants
        runs[label] = MM.simulate(params, n_ticks, rng, n_paths)
    for label, r in runs.items():
        res.add(f"mm.pnl_{label}", float(r["pnl_mean"]), unit="ticks", source="NB-01 worked case")
        res.add(f"mm.share_inside_79_{label}", float(r["share_inside_79_mean"]), source="NB-01")
    res.add("mm.share_inside_79", float(runs["linear_skew"]["share_inside_79_mean"]), expected=0.99, expected_hi=1.0,
            source="NB-01: inside +/-79 for 99% of the session (linear skew)")
    base = runs["linear_skew"]["pnl_mean"]; tak = runs["linear_skew_taking"]["pnl_mean"]
    res.add("mm.taking_layer_pnl_rel_change", (tak - base) / abs(base) if base else np.nan, expected=-0.3, abs_tol=0.3,
            source="NB-01: taking cut PnL 2,300 -> 1,600 (-30%)")
    res.add("mm.skew_vs_no_skew_pnl_rel_change", (base - runs["no_skew"]["pnl_mean"]) / abs(runs["no_skew"]["pnl_mean"]) if runs["no_skew"]["pnl_mean"] else np.nan)
    dec = runs["linear_skew"]["decomposition"]
    parts = {k: float(np.mean(v)) for k, v in dec.items()}
    total = parts.get("spread_capture", 0) - parts.get("overtrading", 0) - parts.get("adverse_selection", 0) - parts.get("inventory_risk", 0) - parts.get("inventory_cost", 0) + parts.get("inventory_risk", 0) * 0
    res.add("mm.decomposition_identity_residual", abs(base - (parts.get("spread_capture", 0) - parts.get("overtrading", 0) - parts.get("adverse_selection", 0) - parts.get("inventory_cost", parts.get("inventory_risk", 0)))),
            expected=0.0, abs_tol=1e-6, source="NB-01 rule: PnL = spread capture - adverse selection - inventory cost - overtrading (exact)")
    for k, v in parts.items():
        res.add(f"mm.decomp_{k}", v, unit="ticks")
    # tuning grid
    grid = MM.tuning_grid(None, n_ticks, seed=cfg.seed, n_paths=max(1, n_paths // 2))
    best = grid.get("best", {}) if isinstance(grid, dict) else {}
    if best:
        res.add("mm.grid_best_risk_aversion", float(best.get("risk_aversion", np.nan)), expected=0.3, expected_hi=1.0, source="NB-01 grid [0.3, 0.5, 0.7, 1.0]")
        res.add("mm.grid_best_inventory_limit", float(best.get("inventory_limit", np.nan)), expected=40, expected_hi=80, source="NB-01 grid [40, 60, 80]")
    res.data_origin = "simulation"
    res.note(f"{n_paths} sessions of {n_ticks} ticks; variants share the same market path (common random numbers)")
    res.note("the NB-01 absolute numbers (PnL 2,300 / 1,600) are from the note's own session; the bench compares the variants on its own synthetic market")
    fig, ax = figure(cfg, "market_making", 4)
    for label in ("no_skew", "linear_skew", "band_skew"):
        ax[0].plot(runs[label]["inventory"][0], lw=0.8, label=label)
    ax[0].axhline(79, color="r", ls="--", lw=0.6); ax[0].axhline(-79, color="r", ls="--", lw=0.6); ax[0].legend(fontsize=7); ax[0].set_title("inventory, session 1")
    for label in ("linear_skew", "linear_skew_taking"):
        ax[1].plot(runs[label]["pnl_path"][0], lw=0.8, label=label)
    ax[1].legend(fontsize=7); ax[1].set_title("PnL path, session 1")
    ax[2].bar(list(parts.keys()), list(parts.values())); ax[2].tick_params(axis="x", labelrotation=30, labelsize=7); ax[2].set_title("PnL decomposition (linear skew)")
    ax[3].bar(list(runs.keys()), [runs[k]["pnl_mean"] for k in runs]); ax[3].tick_params(axis="x", labelrotation=20, labelsize=7); ax[3].set_title("mean PnL by variant")
    res.figures.append(save(fig, cfg, "market_making"))
    return res
