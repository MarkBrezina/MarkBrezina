"""The exact layer, checked to rounding error (group "exact").

On random hierarchies (random weights, random correlated velocities) every identity of
AT-III section 3 / AT-II section 3 is evaluated and its residual recorded with expected = 0 and
abs_tol = 1e−9: the König split, φ ≤ 1 and κ ≤ φ², the turbulence identity Ψ² = H + (1 − H)ρ̄, mean
preservation, the Jensen gap ≥ 0, the cascade factorisation, the mixture law with its bounds, the
squeezing bound, the linear-field split (planted M and V₀, expansion = tr M/d, Oort constants),
invariant-mass superadditivity, volatility subadditivity with the gap identity, the virial sign law
(E_int = (1 + 2/n)K on a Kepler and a harmonic orbit), the lumping theorem (lumpable and
non-lumpable examples, AT-0 sections U–W), and the Epps law recovery (κ∞ = 0.8, τ = 5 s planted).
"""
from __future__ import annotations
import numpy as np

from tmrw_lab.result import Result
from tmrw_lab.core import identities as I
from tmrw_lab.core import lumping as LU
from tmrw_lab.core import matching as MA
from tmrw_lab.core.mfg import contest_value_split

NAME = "exact_layer"
ABS_TOL = 1e-9


def _rec(res, key, value, source, expected=0.0, abs_tol=ABS_TOL, unit="", tol=None, expected_hi=None):
    return res.add(f"exact.{key}", value, expected=expected, expected_hi=expected_hi, unit=unit,
                   source=source, tol=tol, abs_tol=abs_tol)


def _nested_partitions(rng, n, n_levels):
    """Random nested partitions: level ℓ has about n^{(L−ℓ)/L} groups, the last level one group."""
    counts = [max(1, int(round(n ** ((n_levels - l) / n_levels)))) for l in range(1, n_levels + 1)]
    counts[-1] = 1
    labels = rng.integers(0, counts[0], n)
    parts = [labels.copy()]
    for g in counts[1:]:
        upmap = rng.integers(0, g, parts[-1].max() + 1)
        parts.append(upmap[parts[-1]])
    return parts


def _nested_series(rng, T, parts, sig=(0.5, 0.5, 0.5, 1.0)):
    """Correlated velocities with the hierarchy built in: common + per-group factors + noise."""
    n = len(parts[0])
    x = sig[-1] * rng.standard_normal((T, n)) + sig[0] * rng.standard_normal((T, 1))
    for k, lab in enumerate(parts[:-1]):
        F = rng.standard_normal((T, lab.max() + 1))
        x += sig[min(k + 1, len(sig) - 2)] * F[:, lab]
    return x * rng.lognormal(0.0, 0.4, n)[None, :]            # heterogeneous unit volatilities


def _nested_snapshot(rng, parts, d=3):
    n = len(parts[0])
    v = rng.standard_normal((n, d)) + rng.standard_normal((1, d))
    for lab in parts[:-1]:
        F = rng.standard_normal((lab.max() + 1, d))
        v += F[lab]
    return v


def _expected_squeezed_share(t, R, t0, delta):
    """E_U[share] for a bin [t0 − UΔ, t0 + (1 − U)Δ) with U uniform (AT-III Thm 3.6 proof):
    a point at offset δ from t0 is inside with probability (1 − |δ|/Δ)₊."""
    p = np.clip(1.0 - np.abs(np.asarray(t) - t0) / delta, 0.0, None)
    return float(np.sum(R * p) / np.sum(R))


def _lorentz_boost(E, p, beta_vec):
    """Boost four-momenta (E, p) by velocity β (c = 1)."""
    b = np.asarray(beta_vec, dtype=float)
    b2 = b @ b
    g = 1.0 / np.sqrt(1.0 - b2)
    bp = p @ b
    E2 = g * (E - bp)
    p2 = p + ((g - 1.0) * bp / b2 - g * E)[:, None] * b[None, :]
    return E2, p2


def _kepler_averages(e=0.6, GM=1.0, a=1.0, n=1024):
    """Time averages over one period of K and U on the exact Kepler orbit, sampled uniformly in time
    through the eccentric anomaly (dt ∝ (1 − e cos E) dE)."""
    Ea = np.linspace(0, 2 * np.pi, n, endpoint=False)
    wt = 1.0 - e * np.cos(Ea)
    r = a * wt
    K = 0.5 * GM * (2.0 / r - 1.0 / a)
    U = -GM / r
    return float(np.mean(K * wt)), float(np.mean(U * wt))


def _harmonic_averages(A=1.0, B=0.4, omega=1.3, n=1024):
    """Time averages of K and V = ½ω²r² on x = A cos ωt, y = B sin ωt over one period."""
    t = np.linspace(0, 2 * np.pi / omega, n, endpoint=False)
    vx, vy = -A * omega * np.sin(omega * t), B * omega * np.cos(omega * t)
    x, y = A * np.cos(omega * t), B * np.sin(omega * t)
    return float(np.mean(0.5 * (vx ** 2 + vy ** 2))), float(np.mean(0.5 * omega ** 2 * (x ** 2 + y ** 2)))


def _lumpable_random(rng, n, k):
    """A random A with A(ker C) ⊆ ker C for a random full-row-rank C (block upper triangular in the
    basis [ker C, (ker C)⊥])."""
    C = rng.standard_normal((k, n))
    K = LU.kernel_basis(C)
    Q = np.column_stack([K, np.linalg.qr(np.column_stack([K, rng.standard_normal((n, k))]))[0][:, n - k:]])
    Bt = rng.standard_normal((n, n))
    Bt[n - k:, :n - k] = 0.0                       # the (⊥, ker) block vanishes → ker C invariant
    A = Q @ Bt @ Q.T - 1.5 * np.eye(n)
    return A, C


def _lumpable_markov(rng, blocks, P_hat):
    """A strongly lumpable chain: P[i, j] = P̂[b(i), b(j)] · u_i(j) with u_i a law over block b(j)."""
    n = len(blocks)
    P = np.zeros((n, n))
    for i in range(n):
        for J in range(P_hat.shape[1]):
            idx = np.where(blocks == J)[0]
            u = rng.random(len(idx))
            P[i, idx] = P_hat[blocks[i], J] * u / u.sum()
    return P


def run(cfg) -> Result:
    res = Result(name="experiments.exact_layer", title="The exact layer, checked to rounding error")
    res.data_origin = "analytic"
    rng = np.random.default_rng(cfg.seed)
    n_units = int(cfg.sizes["n_units"])
    n_levels = int(cfg.sizes["n_levels"])
    N = min(n_units, 4000)
    T = min(int(cfg.sizes["n_steps"]), 1000)
    if N < n_units or T < int(cfg.sizes["n_steps"]):
        res.note(f"hierarchy capped at N={N} units x T={T} steps (the Ψ² identity needs an N×N correlation matrix)")
    parts = _nested_partitions(rng, N, n_levels)
    w = I.normalise_weights(rng.lognormal(0.0, 1.0, N))
    x = _nested_series(rng, T, parts)                       # (T, N) velocities
    v = _nested_snapshot(rng, parts, d=3)                   # (N, 3) velocities
    src3 = "AT-III Thm 3.1 / AT-II Thm 3.4"

    # ---- König split, φ ≤ 1, κ ≤ φ² ------------------------------------------------------------
    total, coll, internal = I.konig_split(v, w)
    _rec(res, "konig.residual", abs(total - coll - internal) / total, src3)
    phi, kappa = I.speed_ratio(v, w), I.collective_share(v, w)
    _rec(res, "phi.excess_over_one", max(0.0, phi - 1.0), "AT-III Thm 3.1")
    _rec(res, "kappa.excess_over_phi2", max(0.0, kappa - phi ** 2), "AT-III Thm 3.1")
    _rec(res, "kappa.below_zero", max(0.0, -kappa), "AT-III Thm 3.1")
    res.extra["phi_snapshot"], res.extra["kappa_snapshot"] = phi, kappa

    # ---- hierarchy walk (time series): φ, κ, Ψ² by level, cascade, internal share, additivity ----
    rep = MA.match_report(x, parts, w, time_series=True)
    _rec(res, "hierarchy.additive_mismatch", float(rep["additive_mismatch"].max()), "AT-II Prop 3.1")
    _rec(res, "hierarchy.psi2_identity_residual", float(np.max(np.abs(rep["Psi2"] - rep["Psi2_identity"]))),
         "AT-III Thm 3.2")
    _rec(res, "hierarchy.psi2_excess_over_one", float(max(0.0, np.max(rep["Psi2"] - 1.0))), "AT-III Thm 3.2")
    _rec(res, "hierarchy.internal_share_decrease", float(max(0.0, np.max(-np.diff(rep["internal_share"])))),
         "AT-II Thm 3.6")
    _rec(res, "hierarchy.factor_excess", float(max(0.0, np.max(rep["speed_factor"]) - 1.0,
                                                   np.max(rep["energy_factor"]) - 1.0)), "AT-III Thm 3.4")
    _rec(res, "cascade.speed_product_residual", abs(float(np.prod(rep["speed_factor"])) - rep["phi"][0]),
         "AT-III Thm 3.4")
    _rec(res, "cascade.energy_product_residual", abs(float(np.prod(rep["energy_factor"])) - rep["kappa"][0]),
         "AT-III Thm 3.4")
    _rec(res, "hierarchy.kappa_excess_over_phi2", float(max(0.0, np.max(rep["kappa"] - rep["phi"] ** 2))),
         "AT-III Thm 3.1")
    for key in ("phi", "kappa", "Psi2", "H", "N_eff", "internal_share", "n_groups", "speed_factor", "energy_factor"):
        res.extra[f"by_level.{key}"] = [float(u) for u in rep[key]]
    # snapshot cascade through identities.cascade_factors
    S, factors, prod, phi_direct = I.cascade_factors(v, w, parts)
    _rec(res, "cascade.snapshot_residual", abs(prod - phi_direct), "AT-III Thm 3.4")
    _rec(res, "cascade.snapshot_factor_excess", max(0.0, float(factors.max()) - 1.0), "AT-III Thm 3.4")

    # ---- turbulence identity at the unit level, from the series itself ----------------------------
    sig = x.std(axis=0)
    R = np.corrcoef(x.T)
    ti = I.turbulence_identity(sig, w, R)
    X_series = x @ w
    psi2_series = float(np.var(X_series) / (w @ sig) ** 2)
    _rec(res, "turbulence.identity_residual", abs(ti["Psi2_direct"] - ti["Psi2_identity"]), "AT-III Thm 3.2")
    _rec(res, "turbulence.series_vs_formula", abs(psi2_series - ti["Psi2_direct"]), "AT-III Thm 3.2")
    _rec(res, "turbulence.psi_excess_over_one", max(0.0, np.sqrt(ti["Psi2_direct"]) - 1.0), "AT-III Thm 3.2")
    res.extra["N_eff_units"], res.extra["rho_bar_units"], res.extra["Psi2_units"] = ti["N_eff"], ti["rho_bar"], ti["Psi2_direct"]

    # ---- mean preservation and the Jensen gap ---------------------------------------------------
    m_agg, agg_m = I.mean_preserved(x, w)
    _rec(res, "mean.residual", abs(m_agg - agg_m), "AT-III Thm 3.3a")
    r = 0.01 * x                                            # simple returns of a few per cent
    g_whole, g_parts, gap = I.jensen_growth_gap(r, w)
    _rec(res, "jensen.violation", max(0.0, -gap), "AT-III Thm 3.3b")
    lr = np.log1p(r)
    half_var = 0.5 * float(np.mean(lr ** 2 @ w - (lr @ w) ** 2))
    _rec(res, "jensen.gap_over_half_variance", gap / half_var, "AT-III Thm 3.3b (gap ≈ ½ Var_w log R)",
         expected=1.0, abs_tol=None, tol=0.1)

    # ---- index return is the weighted sum (AT-II Cor 3.2) --------------------------------------
    n_sh = rng.integers(1, 100, N).astype(float)
    p = 100.0 * np.exp(np.cumsum(0.01 * x, axis=0))
    idx = p @ n_sh / 10.0
    r_idx = idx[1:] / idx[:-1] - 1.0
    rets = p[1:] / p[:-1] - 1.0
    wts = p[:-1] * n_sh
    r_rebuilt = np.array([I.index_return(rets[t], wts[t]) for t in range(len(rets))])
    _rec(res, "index.residual", float(np.max(np.abs(r_idx - r_rebuilt))), "AT-II Cor 3.2")

    # ---- leftover dispersion in [0, 1] and its link to the kept energy (AT-II Def 4.2) ----------
    lab = parts[0]
    _, W1, Xg = I.group_aggregate(x.T, w, lab)
    Xg_series = Xg.T                                        # (T, G)
    gidx = np.searchsorted(np.unique(lab), lab)
    num = float(np.sum(w * (x - Xg_series[:, gidx]) ** 2))
    den = float(np.sum(w * (x - X_series[:, None]) ** 2))
    leftover = num / den
    _rec(res, "leftover.range_violation", max(0.0, leftover - 1.0, -leftover), "AT-II Def 4.2")
    kk = rep["kappa_kept"]
    _rec(res, "leftover.identity_residual", abs(leftover - (1.0 - kk[1]) / (1.0 - kk[-1])), "AT-II Def 4.2 / Thm 3.6")

    # ---- mixture law and its bounds (AT-III Thm 3.5) --------------------------------------------
    n_ev = max(5, min(N, 200))
    t = np.linspace(-20, 60, 801)
    tau = rng.uniform(0, 30, n_ev)
    a = rng.uniform(0.5, 2.0, n_ev)
    we = I.normalise_weights(rng.random(n_ev))
    f = lambda u: 1.0 / (1.0 + np.exp(-u / 2.0))           # noqa: E731 - the shared logistic unit response
    R_agg = np.sum(we[:, None] * a[:, None] * f(t[None, :] - tau[:, None]), axis=0)
    A = float(we @ a)
    mix = I.mixture_law(t, we * a, tau, f)
    _rec(res, "mixture.residual", float(np.max(np.abs(R_agg / A - mix))), "AT-III Thm 3.5")
    lo, hi = I.mixture_bounds(t, tau, f)
    _rec(res, "mixture.bound_violation", float(max(0.0, np.max(lo - mix), np.max(mix - hi))), "AT-III Thm 3.5")

    # ---- squeezing (AT-III Thm 3.6) -------------------------------------------------------------
    t0, a_sq, b_sq, delta = 0.0, 1.5, 2.5, 10.0
    tt = np.linspace(-8, 8, 1601)
    Rsq = np.clip(1.0 - np.abs(tt - 0.5) / 2.0, 0.0, None) * ((tt >= t0 - a_sq) & (tt <= t0 + b_sq))
    bound = I.squeezing_bound(a_sq + b_sq, delta)
    exp_share = _expected_squeezed_share(tt, Rsq, t0, delta)
    _rec(res, "squeezing.violation", max(0.0, bound - exp_share), "AT-III Thm 3.6")
    U = rng.random(int(cfg.sizes["n_boot"]))
    mc_share = float(np.mean([I.squeezed_share(tt, Rsq, t0 - u * delta, delta) for u in U]))
    _rec(res, "squeezing.mc_share", mc_share, "AT-III Thm 3.6 (share ≥ 1 − (a+b)/Δ)",
         expected=bound, expected_hi=1.0, abs_tol=0.05)
    _rec(res, "squeezing.limit_one", max(0.0, 1.0 - _expected_squeezed_share(tt, Rsq, t0, 1e12)), "AT-III Thm 3.6")

    # ---- linear-field split, expansion, Oort constants (AT-III Thm 3.7) ---------------------------
    for d in (3, 2):
        n_f = min(N, 500)
        pos = rng.standard_normal((n_f, d))
        wf = I.normalise_weights(rng.random(n_f))
        V0 = rng.standard_normal(d)
        M = rng.standard_normal((d, d))
        xbar = wf @ pos
        y = pos - xbar
        rr = rng.standard_normal((n_f, d))
        rr -= wf @ rr                                        # Σ w r = 0
        sw = np.sqrt(wf)[:, None]
        Mr, *_ = np.linalg.lstsq(y * sw, rr * sw, rcond=None)
        rr -= y @ Mr                                         # Σ w r yᵀ = 0: r is the internal motion
        vel = V0 + y @ M.T + rr
        sp = I.linear_field_split(pos, vel, wf)
        tot = float(wf @ np.sum(vel ** 2, axis=1))
        lin = y @ sp["M"].T
        _rec(res, f"linear_field.split_residual_{d}d",
             abs(tot - (sp["V0"] @ sp["V0"] + wf @ np.sum(lin ** 2, axis=1) + wf @ np.sum(sp["r"] ** 2, axis=1))) / tot,
             "AT-III Thm 3.7")
        _rec(res, f"linear_field.M_recovery_{d}d", float(np.linalg.norm(sp["M"] - M) / np.linalg.norm(M)), "AT-III Thm 3.7")
        _rec(res, f"linear_field.V0_recovery_{d}d", float(np.linalg.norm(sp["V0"] - V0) / np.linalg.norm(V0)), "AT-III Thm 3.7")
        _rec(res, f"linear_field.expansion_residual_{d}d", abs(I.expansion_rate(sp["M"]) - np.trace(M) / d), "AT-III Thm 3.7")
        _rec(res, f"linear_field.share_sum_{d}d", abs(sp["share_bulk"] + sp["share_linear"] + sp["share_internal"] - 1.0),
             "AT-III Thm 3.7")
        if d == 2:
            oc = I.oort_constants(sp["M"])
            M_oort = np.array([[oc["K"] + oc["C"], oc["A"] - oc["B"]], [oc["A"] + oc["B"], oc["K"] - oc["C"]]])
            _rec(res, "linear_field.oort_reconstruction", float(np.linalg.norm(M_oort - sp["M"])), "AT-III Thm 3.7")
            _rec(res, "linear_field.oort_K_is_expansion", abs(oc["K"] - I.expansion_rate(sp["M"])), "AT-III Thm 3.7")

    # ---- invariant mass: superadditivity and frame invariance (AT-II Thm 3.7 / AT-III Thm 3.8) ----
    n_p = 8
    masses = rng.uniform(0.1, 2.0, n_p)
    mom = rng.standard_normal((n_p, 3))
    E = np.sqrt(masses ** 2 + np.sum(mom ** 2, axis=1))
    Mtot, msum, gap_m = I.mass_superadditivity_gap(E, mom)
    _rec(res, "mass.superadditivity_violation", max(0.0, msum - Mtot) / Mtot, "AT-II Thm 3.7")
    E2, p2 = _lorentz_boost(E, mom, 0.6 * rng.standard_normal(3) / np.sqrt(3))
    _rec(res, "mass.frame_invariance", abs(I.invariant_mass(E2, p2) - Mtot) / Mtot, "AT-II Thm 3.7")
    res.extra["mass_gap_rel"] = gap_m
    # equality when the parts move together: same velocity for all → M = Σ m
    beta_c = np.array([0.3, -0.2, 0.1])
    gam = 1.0 / np.sqrt(1 - beta_c @ beta_c)
    E_c, p_c = gam * masses, gam * masses[:, None] * beta_c[None, :]
    Mc, msc, _ = I.mass_superadditivity_gap(E_c, p_c)
    _rec(res, "mass.equality_when_together", abs(Mc - msc) / Mc, "AT-II Thm 3.7")

    # ---- volatility subadditivity and the gap identity (AT-II Thm 3.8) ---------------------------
    sX, swsig = I.vol_subadditivity(sig, w, R)
    _rec(res, "vol.subadditivity_violation", max(0.0, sX - swsig), "AT-II Thm 3.8")
    lhs, rhs = I.vol_gap_identity(sig, w, R)
    _rec(res, "vol.gap_identity_residual", abs(lhs - rhs), "AT-II Thm 3.8")
    _rec(res, "vol.series_vs_formula", abs(float(np.std(X_series)) - sX), "AT-II Thm 3.8")
    res.extra["vol_ratio"] = sX / swsig

    # ---- virial sign law on a Kepler (n = −1) and a harmonic (n = 2) orbit --------------------------
    Kk, Uk = _kepler_averages(e=0.6)
    _rec(res, "virial.kepler_residual", abs((Kk + Uk) - I.sign_law(-1, Kk)) / abs(Kk), "AT-III Known 3.9")
    _rec(res, "virial.kepler_2K_plus_U", abs(2 * Kk + Uk) / abs(Kk), "AT-II Known 3.9")
    _rec(res, "virial.kepler_sign", float(np.sign(Kk + Uk)), "AT-III Known 3.9 (bound: lighter)", expected=-1.0)
    Kh, Vh = _harmonic_averages()
    _rec(res, "virial.harmonic_residual", abs((Kh + Vh) - I.sign_law(2, Kh)) / abs(Kh), "AT-III Known 3.9")
    _rec(res, "virial.harmonic_sign", float(np.sign(Kh + Vh)), "AT-III Known 3.9 (confined: heavier)", expected=1.0)

    # ---- lumping theorem (AT-0 sections U–W) ------------------------------------------------------
    sd = LU.example_supply_demand()
    _rec(res, "lumping.supply_demand_residual", sd["residual"], "AT-0 Sec. U (CA = BC)")
    _rec(res, "lumping.supply_demand_B", sd["B"], "AT-0 Sec. U (B = −3)", expected=-3.0)
    _rec(res, "lumping.supply_demand_same_future", sd["y_difference"], "AT-0 Sec. U.1")
    _rec(res, "lumping.supply_demand_closed_form", abs(sd["y_state1"] - sd["y_closed_form"]), "AT-0 Sec. U (y = 2e^{−3t})")
    cx = LU.example_counterexample()
    _rec(res, "lumping.counterexample_false_closure", float(cx["lumpable"]), "AT-0 Sec. V")
    _rec(res, "lumping.counterexample_residual", cx["residual"], "AT-0 Sec. V (CA = [−1 2] vs [b −b])",
         expected=np.sqrt(0.5))
    _rec(res, "lumping.counterexample_ydot_state1", cx["ydot_state1"], "AT-0 Sec. V", expected=1.0)
    _rec(res, "lumping.counterexample_ydot_state2", cx["ydot_state2"], "AT-0 Sec. V", expected=46.0)
    sn = LU.example_sine_alone()
    _rec(res, "lumping.sine_residual", sn["residual"], "AT-0 Sec. S.2 (CA = [0 1] vs [b 0])", expected=1.0)
    _rec(res, "lumping.sine_second_order", sn["second_order_residual"], "AT-0 Sec. S.2 (ÿ = −y)")
    ro = LU.example_rotation()
    _rec(res, "lumping.rotation_dynamics", ro["dynamics_residual"], "AT-0 Sec. S (ż = A_rot z)")
    _rec(res, "lumping.rotation_no_real_line", float(ro["n_real_invariant_lines"]), "AT-0 Sec. S.1")
    A_l, C_l = _lumpable_random(rng, 6, 2)
    B_l, res_l = LU.lumped_generator(A_l, C_l)
    _rec(res, "lumping.random_lumpable_residual", res_l / np.linalg.norm(C_l @ A_l), "AT-0 Thm W.1")
    _rec(res, "lumping.random_lumpable_flag", 1.0 - float(LU.is_exactly_lumpable(A_l, C_l)), "AT-0 Thm W.1")
    loss_l = LU.information_loss(A_l, C_l, rng.standard_normal(6), 2.0)
    _rec(res, "lumping.random_lumpable_drift", loss_l["max_rel"], "AT-0 Sec. W.2 (Ce^{At} = e^{Bt}C)")
    A_n = rng.standard_normal((6, 6)) - 1.5 * np.eye(6)
    _rec(res, "lumping.random_nonlumpable_false_closure", float(LU.is_exactly_lumpable(A_n, C_l)), "AT-0 Thm W.1")
    res.extra["nonlumpable_drift"] = LU.information_loss(A_n, C_l, rng.standard_normal(6), 2.0)["max_rel"]
    blocks = np.array([0, 0, 1, 1, 1, 2, 2])
    P_hat = rng.random((3, 3)); P_hat /= P_hat.sum(axis=1, keepdims=True)
    P = _lumpable_markov(rng, blocks, P_hat)
    ok_m, P_rec, dev = LU.markov_lumpable(P, blocks)
    _rec(res, "lumping.markov_residual", dev, "Kemeny–Snell strong lumpability (AT-0 Thm W.1 with A = Pᵀ)")
    _rec(res, "lumping.markov_recovery", float(np.linalg.norm(P_rec - P_hat)), "Kemeny–Snell strong lumpability")

    # ---- contest conservation (AT-0 Prop I.2) ------------------------------------------------------
    rewards = contest_value_split(rng.random(50), 7.0)
    _rec(res, "contest.conservation", abs(rewards.sum() - 7.0), "AT-0 Prop I.2")

    # ---- Epps law recovery (AT-II Hyp 4.3) --------------------------------------------------------
    delta = np.array([1.0, 2.0, 5.0, 10.0, 30.0, 60.0, 300.0, 900.0])
    kap = I.epps_law(delta, 0.8, 5.0)
    kinf, tau_e = I.epps_tau_fit(delta, kap)
    _rec(res, "epps.kappa_inf", kinf, "AT-II Hyp 4.3 (planted 0.8)", expected=0.8, unit="")
    _rec(res, "epps.tau", tau_e, "AT-II Hyp 4.3 (planted 5 s; Fig. 1b τ ≈ 5 s)", expected=5.0, unit="s")
    kap_noisy = kap * (1.0 + 0.01 * rng.standard_normal(len(kap)))
    kinf_n, tau_n = I.epps_tau_fit(delta, kap_noisy)
    _rec(res, "epps.kappa_inf_noisy", kinf_n, "AT-II Hyp 4.3 (1% noise)", expected=0.8, abs_tol=None, tol=0.05)
    _rec(res, "epps.tau_noisy", tau_n, "AT-II Hyp 4.3 (1% noise)", expected=5.0, abs_tol=None, tol=0.15, unit="s")

    # ---- figure --------------------------------------------------------------------------------------
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig = plt.figure(figsize=(10, 6))
        gs = fig.add_gridspec(2, 2, height_ratios=[1.2, 1.0])
        ax = fig.add_subplot(gs[0, :])
        ident = [n for n in res.numbers if n.expected == 0.0 and n.abs_tol == ABS_TOL]
        vals = np.maximum([abs(n.value) for n in ident], 1e-18)
        ax.bar(np.arange(len(ident)), vals, color="#4c72b0")
        ax.set_yscale("log")
        ax.axhline(ABS_TOL, color="#c44e52", ls="--", lw=1, label="tolerance 1e-9")
        ax.set_xticks(np.arange(len(ident)))
        ax.set_xticklabels([n.key.replace("exact.", "") for n in ident], rotation=90, fontsize=5)
        ax.set_ylabel("identity residual")
        ax.set_title("(a) residuals of the exact layer on a random hierarchy")
        ax.legend(fontsize=7, loc="upper right")
        ax2 = fig.add_subplot(gs[1, 0])
        lv = rep["level"]
        ax2.plot(lv, rep["phi"], "o-", label="φ = S_L/S_ℓ")
        ax2.plot(lv, rep["kappa"], "s-", label="κ = E_L/E_ℓ")
        ax2.plot(lv, rep["Psi2"], "^-", label="Ψ² (level-ℓ parts)")
        ax2.plot(lv, rep["internal_share"], "d--", label="internal share")
        ax2.set_xlabel("aggregation level (0 = units)")
        ax2.set_ylim(-0.02, 1.05)
        ax2.set_title("(b) φ, κ, Ψ² by level")
        ax2.legend(fontsize=7)
        ax3 = fig.add_subplot(gs[1, 1])
        dd = np.geomspace(0.5, 2000, 200)
        ax3.semilogx(dd, I.epps_law(dd, 0.8, 5.0), "-", color="#55a868", label="planted κ∞=0.8, τ=5 s")
        ax3.semilogx(delta, kap_noisy, "o", color="#8172b2", label="sampled (1% noise)")
        ax3.semilogx(dd, I.epps_law(dd, kinf_n, tau_n), ":", color="#8172b2",
                     label=f"recovered κ∞={kinf_n:.3f}, τ={tau_n:.2f} s")
        ax3.set_xlabel("Δ (s)")
        ax3.set_ylabel("κ(Δ)")
        ax3.set_title("(c) Epps law recovery")
        ax3.legend(fontsize=7)
        fig.tight_layout()
        fig_dir = cfg.results_dir / "figures"
        fig_dir.mkdir(parents=True, exist_ok=True)
        path = fig_dir / f"{NAME}.png"
        fig.savefig(path, dpi=130)
        plt.close(fig)
        res.figures.append(str(path))
    except Exception as e:  # noqa: BLE001
        res.note(f"figure skipped: {e!r}")

    nm, nj = res.n_match()
    res.note(f"{nm}/{nj} numbers match; hierarchy N={N}, T={T}, levels={n_levels} with group counts "
             f"{[int(u) for u in rep['n_groups']]}; Ψ² at the unit level {ti['Psi2_direct']:.3f} "
             f"(N_eff={ti['N_eff']:.1f}, ρ̄={ti['rho_bar']:.3f})")
    res.note("virial averages use the exact Kepler orbit sampled uniformly in time (eccentric anomaly) and an "
             "anisotropic harmonic orbit; the planted linear field has its internal motion projected to satisfy "
             "the normal equations so M and V0 are recovered exactly")
    return res
