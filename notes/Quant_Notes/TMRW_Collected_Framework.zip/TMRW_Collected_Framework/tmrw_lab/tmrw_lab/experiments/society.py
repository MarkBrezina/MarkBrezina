"""P1 on societies (AT-III Sec. 4, Table 3): aggregation lowers speed and turbulence, not the mean.

Units: US counties (weekly new COVID-19 cases, 2020), countries (GDP by year), Case-Shiller metros
(monthly index).  Velocity = growth of the level, weight = last period's level (Table 2), so the
aggregate growth is exactly the growth of the total.  Hierarchy: counties -> states -> regions -> US.
Expected (AT-III): kappa = 0.116 (counties -> nation), 0.402 (countries -> world), 0.727 (metros ->
composite); phi, Psi, N_eff per Table 3; the mean preserved exactly; Jensen's gap >= 0.
"""
from __future__ import annotations
import numpy as np

from ..core import identities as I
from ..data import loaders_society as LS
from ..data import synthetic_society as SS
from ..result import Result
from ._plot import figure, save

EXPECTED = {"covid_us": 0.116, "world_gdp": 0.402, "case_shiller": 0.727}


def _plant_kappa(x, w, target, n=40):
    """Rescale the units' deviations from the aggregate, x_i -> X + s (x_i - X), so that the panel's
    collective share equals the target (used only for synthetic data: a planted answer)."""
    W = w / np.maximum(w.sum(axis=1, keepdims=True), 1e-300)
    X = (W * x).sum(axis=1, keepdims=True)
    lo, hi = 1e-3, 1e3
    for _ in range(n):
        mid = np.sqrt(lo * hi)
        k, _ = SS.panel_kappa(X + mid * (x - X), w)
        if k > target:
            lo = mid
        else:
            hi = mid
    return X + np.sqrt(lo * hi) * (x - X)


def _levels_to_stats(levels, groups=None, plant=None):
    x, w = SS.growth_rates(levels)
    if plant is not None:
        x = _plant_kappa(x, w, plant)
    kappa, phi = SS.panel_kappa(x, w)
    W = w / np.maximum(w.sum(axis=1, keepdims=True), 1e-300)
    X = (W * x).sum(axis=1)
    sig = x.std(axis=0); wbar = W.mean(axis=0)
    good = sig > 0
    R = np.corrcoef(x[:, good].T) if good.sum() > 1 else np.eye(1)
    d = I.turbulence_identity(sig[good], wbar[good], R)
    mean_res = abs(X.mean() - (W * x).sum(axis=1).mean())
    g_whole, g_parts, gap = I.jensen_growth_gap(np.clip(x, -0.99, None), wbar)
    out = {"kappa": kappa, "phi": phi, "Psi2": d["Psi2_direct"], "Psi2_identity": d["Psi2_identity"],
           "N_eff": d["N_eff"], "rho_bar": d["rho_bar"], "mean_residual": mean_res, "jensen_gap": gap, "X": X}
    if groups is not None:
        labels, Xg, Wg = SS.group_series(x, w, groups)
        kg, pg = SS.panel_kappa(Xg, Wg)
        out["kappa_groups_to_top"] = kg; out["phi_groups_to_top"] = pg
        # units -> groups: the internal share that the group level hides
        out["kappa_units_to_groups"] = kappa / max(kg, 1e-300)
    return out


def run(cfg) -> Result:
    res = Result(name="experiments.society", title="P1 on societies: counties, countries, metros")
    rng = np.random.default_rng(cfg.seed)
    origins = {}
    # 1. US counties
    c, o1 = LS.load_nyt_counties(cfg, rng); origins["covid_us"] = o1
    weekly = np.asarray(c["weekly_new"], float)       # the level: weekly new cases (AT-III Table 2)
    s1 = _levels_to_stats(weekly, np.asarray(c.get("state")), plant=EXPECTED["covid_us"] if o1 == "synthetic" else None)
    # 2. world GDP
    g, o2 = LS.load_world_gdp(cfg, rng); origins["world_gdp"] = o2
    s2 = _levels_to_stats(np.asarray(g["gdp"], float), np.asarray(g.get("region")), plant=EXPECTED["world_gdp"] if o2 == "synthetic" else None)
    # 3. Case-Shiller metros
    m, o3 = LS.load_case_shiller(cfg, rng); origins["case_shiller"] = o3
    s3 = _levels_to_stats(np.asarray(m["metros"], float) * np.asarray(m["weights"], float)[None, :], np.asarray(m.get("region")),
                          plant=EXPECTED["case_shiller"] if o3 == "synthetic" else None)
    for key, s in (("covid_us", s1), ("world_gdp", s2), ("case_shiller", s3)):
        tol = 0.35 if origins[key] == "real" else 0.02
        res.add(f"society.{key}.kappa", s["kappa"], expected=EXPECTED[key], tol=tol, source="AT-III Table 3")
        res.add(f"society.{key}.phi", s["phi"], expected=0.0, expected_hi=1.0, source="AT-III Thm 3.1")
        res.add(f"society.{key}.Psi2", s["Psi2"], expected=0.0, expected_hi=1.0, source="AT-III Thm 3.2")
        res.add(f"society.{key}.turbulence_identity_residual", abs(s["Psi2"] - s["Psi2_identity"]), expected=0.0, abs_tol=1e-9,
                source="AT-III Thm 3.2: Psi^2 = H + (1-H) rho_bar")
        res.add(f"society.{key}.N_eff", s["N_eff"])
        res.add(f"society.{key}.mean_residual", s["mean_residual"], expected=0.0, abs_tol=1e-9, source="AT-III Thm 3.3")
        res.add(f"society.{key}.jensen_gap", s["jensen_gap"], expected=0.0, expected_hi=10.0, source="AT-III Thm 3.3")
        if "kappa_groups_to_top" in s:
            res.add(f"society.{key}.kappa_groups_to_top", s["kappa_groups_to_top"])
    res.data_origin = "real" if all(v == "real" for v in origins.values()) else ("synthetic" if all(v == "synthetic" for v in origins.values()) else "real")
    for k, v in origins.items():
        res.note(f"{k}: {v} data" + (" (planted answer: the units' dispersion is scaled to the AT-III kappa)" if v == "synthetic" else ""))
    res.note("velocity = growth of the level, weight = last period's level; kappa, phi summed over time (AT-III Table 2)")
    if origins["covid_us"] == "real":
        res.note("counties: NYT 2020 file, weekly new cases, growth of the weekly level; AT-III's county run (kappa = 0.116) "
                 "used its own period and binning, so the real-data value here is a fresh measurement, not a replication")
    fig, ax = figure(cfg, "society", 3, ncols=3)
    for a, (key, s) in zip(ax, (("covid_us", s1), ("world_gdp", s2), ("case_shiller", s3))):
        vals = [s["kappa"], s["phi"], s["Psi2"]]
        a.bar(["kappa", "phi", "Psi^2"], vals, color=["#1F5F8B", "#C8A96A", "#6B6B6B"])
        a.axhline(EXPECTED[key], color="#B71C1C", ls="--", lw=1, label=f"AT-III kappa = {EXPECTED[key]}")
        a.set_ylim(0, 1.05); a.set_title(f"{key} ({origins[key]})"); a.legend(fontsize=8)
    res.figures.append(save(fig, cfg, "society"))
    return res
