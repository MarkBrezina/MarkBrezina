"""The strategy blueprints of the working notes (NB-05 stat-arb, NB-06 trend, NB-07 architecture /
cost-aware allocation) on synthetic data with planted properties: a cointegrated pair with half-life
20 bars, a series with alternating drift regimes, and an allocation problem under limits.
"""
from __future__ import annotations
import numpy as np

from ..result import Result
from ..strategies import statarb_pipeline as SA, trend_ensemble as TE, cost_aware_optimiser as CO
from ._plot import figure, save

HORIZON_LAYERS = [("L1 micro", "ms-s", "order book, microprice, OFI, queue position"),
                  ("L2 intraday", "min-h", "mean reversion, pairs, market making inventory"),
                  ("L3 swing", "days-weeks", "trend ensemble, stat-arb baskets, vol regimes"),
                  ("L4 allocation", "weeks-months", "cost-aware allocation under shared limits (C5)")]


def run(cfg) -> Result:
    res = Result(name="experiments.blueprints", title="Blueprints: stat-arb, trend ensemble, cost-aware allocation (NB-05/06/07)")
    rng = np.random.default_rng(cfg.seed)
    n = int(cfg.sizes["n_bars"])
    # stat-arb
    x, y = SA.synthetic_pair(rng, n, halflife=20.0)
    eg = SA.engle_granger(x, y)
    hl = SA.half_life(eg["spread"])
    bt = SA.backtest(eg["spread"])
    res.add("statarb.hedge_ratio", eg["beta"], expected=1.5, tol=0.1, source="planted beta = 1.5")
    res.add("statarb.adf_t", eg["adf_t"], expected=-1e9, expected_hi=-3.34, source="NB-05: Engle-Granger cointegration (5% critical value -3.34)")
    res.add("statarb.halflife_hat", hl, expected=20.0, tol=0.3, unit="bars", source="NB-05 (planted 20)")
    res.add("statarb.sharpe_oos", bt["sharpe_oos"], source="z-score bands 2.0/0.5, 5 bp cost")
    res.add("statarb.trades", bt["trades"])
    # trend
    close = TE.synthetic_trending(rng, n)
    tb = TE.backtest(close)
    res.add("trend.sharpe_oos", tb["sharpe_oos"], expected=0.0, expected_hi=1e9, source="NB-06: positive on trending regimes (synthetic)")
    res.add("trend.max_drawdown", tb["max_drawdown"], unit="log-return")
    res.add("trend.turnover", tb["turnover"])
    # cost-aware allocation
    k = int(cfg.sizes["n_assets"])
    mu = rng.normal(0.01, 0.02, k); A = rng.normal(size=(k, k)); Sigma = (A @ A.T / k + np.eye(k) * 0.1) * 0.01
    co = CO.optimise(mu, Sigma, rng.uniform(0.001, 0.01, k), rng=rng)
    res.add("optimiser.improvement", co["improvement"], expected=0.0, expected_hi=1e9, source="NB-07 / C5: beats naive proportional allocation")
    res.add("optimiser.limits_respected", co["limits_respected"], expected=1.0, abs_tol=0.0)
    res.add("optimiser.utility", co["utility"]); res.add("optimiser.utility_naive", co["utility_naive"])
    res.data_origin = "simulation"
    res.note("four horizon layers (NB-07): " + "; ".join(f"{a} ({b}): {c}" for a, b, c in HORIZON_LAYERS))
    res.note(f"{n} bars; stat-arb pair with planted half-life 20; trend series with 6 alternating drift regimes; {k}-asset allocation")
    fig, ax = figure(cfg, "blueprints", 4)
    ax[0].plot(eg["spread"], lw=0.6); ax[0].set_title(f"stat-arb spread, half-life {hl:.1f}")
    ax[1].plot(np.cumsum(bt["ret"]), lw=0.8); ax[1].set_title(f"stat-arb PnL, Sharpe OOS {bt['sharpe_oos']:.2f}")
    ax[2].plot(close, lw=0.6); ax[2].set_title("trend series (regimes)")
    ax[3].plot(np.cumsum(tb["ret"]), lw=0.8); ax[3].set_title(f"trend ensemble, Sharpe OOS {tb['sharpe_oos']:.2f}")
    res.figures.append(save(fig, cfg, "blueprints"))
    return res
