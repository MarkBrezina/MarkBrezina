"""The Prosperity quoting rules of 5 April 2025 (NB-03) on a synthetic two-product feed, with the
position penalty and the crash-risk measures NCSKEW / DUVOL of the team log.  The note's own numbers
(PnL ~ 3,500 stable vs ~ 2,800 drifting) are from the competition feed; the bench's feed is synthetic,
so the comparison is of the ranking and the limit discipline, not the level.
"""
from __future__ import annotations
import numpy as np

from ..micro import prosperity as PR
from ..result import Result
from ._plot import figure, save


def run(cfg) -> Result:
    res = Result(name="experiments.prosperity", title="Prosperity quoting rules on a synthetic feed (NB-02/03)")
    rng = np.random.default_rng(cfg.seed)
    n_ticks = int(min(cfg.sizes["n_ticks"], 20_000))
    feed = PR.synthetic_feed(rng, n_ticks)
    pnl, pos, takes, makes = PR.run_strategy(feed, rng)
    res.add("prosperity.pnl_stable", pnl["STABLE"], source="NB-03 (5 Apr 2025) reported ~3,500 on the competition feed; synthetic feed here, level not comparable")
    res.add("prosperity.pnl_drifting", pnl["DRIFT"], source="NB-03 reported ~2,800; synthetic feed here")
    res.add("prosperity.note_pnl_stable_2025", 3500.0, source="NB-03, 5 April 2025 (the competition's own feed)")
    res.add("prosperity.note_pnl_drifting_2025", 2800.0, source="NB-03, 5 April 2025")
    res.add("prosperity.stable_beats_drifting", float(pnl["STABLE"] > pnl["DRIFT"]), expected=1.0, abs_tol=0.0, source="NB-03: the fixed-fair product earns more")
    res.add("prosperity.limits_respected", float(all(abs(q) <= PR.LIMIT for q in pos.values())), expected=1.0, abs_tol=0.0, source="position limit 50")
    res.add("prosperity.takes", takes); res.add("prosperity.makes", makes)
    drift = np.array([p["DRIFT"]["true"] for p in feed]); r = np.diff(np.log(drift))
    res.add("prosperity.ncskew_drift", PR.ncskew(r), source="Chen-Hong-Stein 2001 (NB-03)")
    res.add("prosperity.duvol_drift", PR.duvol(r), source="Chen-Hong-Stein 2001 (NB-03)")
    res.data_origin = "simulation"
    res.note(f"{n_ticks} ticks, two products (fixed-value and drifting), takes strictly inside fair, makes one tick inside the touch with the position penalty")
    fig, ax = figure(cfg, "prosperity", 2)
    ax[0].bar(["STABLE", "DRIFT"], [pnl["STABLE"], pnl["DRIFT"]]); ax[0].set_title("PnL by product (synthetic feed)")
    ax[1].plot(drift); ax[1].set_title("drifting product: true value")
    res.figures.append(save(fig, cfg, "prosperity"))
    return res
