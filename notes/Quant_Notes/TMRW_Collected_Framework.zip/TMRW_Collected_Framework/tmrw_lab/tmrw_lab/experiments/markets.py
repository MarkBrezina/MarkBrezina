"""C: markets, from a basket of stocks to a basket of coins (AT-III Sec. 8, AT-II Sec. 4).

The index return is the weighted sum of stock returns (additive: exact), the squares split (kappa,
phi, Psi^2, N_eff; AT-III expects kappa ~ 0.2-0.4 and sigma_index / mean sigma_stock ~ 0.6-0.75 for the
S&P 500), the Jensen growth gap is non-negative, the leftover dispersion after removing the collective
motion is what a top-down model cannot explain; on the crypto basket the collective share rises with
the bar length (Epps as aggregation, kappa ~ 0.75 -> 0.8, tau ~ 5 s).
"""
from __future__ import annotations
import numpy as np

from ..core import identities as I
from ..data import loaders_markets as LM
from ..result import Result
from ._plot import figure, save


def kappa_by_bar(r, deltas_bars, w):
    out = []
    for d in deltas_bars:
        d = int(max(d, 1)); n = (len(r) // d) * d
        bars = r[:n].reshape(-1, d, r.shape[1]).sum(axis=1)
        X = bars @ w
        out.append(float(np.sum(X ** 2) / np.sum(w * np.sum(bars ** 2, axis=0))))
    return np.array(out)


def run(cfg) -> Result:
    res = Result(name="experiments.markets", title="C: index and basket aggregation (stocks, coins)")
    rng = np.random.default_rng(cfg.seed)
    ret, o1 = LM.load_sp500_constituents(cfg, rng)
    R = np.asarray(ret, float); w = np.asarray(ret.attrs.get("weights0"), float); w = w / w.sum()
    if o1 != "real":                                    # planted answer: scale the idiosyncratic part to kappa = 0.3
        from .society import _plant_kappa
        R = _plant_kappa(R, np.tile(w, (R.shape[0], 1)), 0.3)
    idx = R @ w
    res.add("markets.sp500.additive_mismatch", float(np.max(np.abs(I.index_return(R, w) - idx))), expected=0.0, abs_tol=1e-12, source="AT-II Cor 3.2")
    X = idx; tot = np.sum(w * np.sum(R ** 2, axis=0)); kappa = float(np.sum(X ** 2) / tot)
    phi = float(np.sum(np.abs(X)) / np.sum(w * np.sum(np.abs(R), axis=0)))
    sig = R.std(axis=0); Rc = np.corrcoef(R.T); d = I.turbulence_identity(sig, w, Rc)
    sigma_ratio = float(idx.std() / np.mean(sig))
    tol = 0.0 if o1 == "real" else 0.0
    res.add("markets.sp500.kappa", kappa, expected=0.2, expected_hi=0.4, source="AT-III Sec. 8.2 / AT-II Tab. 3: 0.2-0.4")
    res.add("markets.sp500.phi", phi, expected=0.0, expected_hi=1.0, source="AT-III Thm 3.1")
    res.add("markets.sp500.sigma_ratio", sigma_ratio, expected=0.6, expected_hi=0.75, source="AT-III Sec. 8.2: 0.6-0.75")
    res.add("markets.sp500.Psi2", d["Psi2_direct"], expected=0.0, expected_hi=1.0, source="AT-III Thm 3.2")
    res.add("markets.sp500.turbulence_identity_residual", abs(d["Psi2_direct"] - d["Psi2_identity"]), expected=0.0, abs_tol=1e-9)
    res.add("markets.sp500.N_eff", d["N_eff"]); res.add("markets.sp500.rho_bar", d["rho_bar"])
    g_whole, g_parts, gap = I.jensen_growth_gap(np.clip(R, -0.9, None), w)
    res.add("markets.sp500.jensen_gap", gap, expected=0.0, expected_hi=1.0, source="AT-III Thm 3.3")
    res.add("markets.sp500.leftover_share", 1 - kappa, source="AT-II Def 4.1: internal share of squared returns")
    # crypto basket: kappa against bar length
    px, o2 = LM.load_crypto_minutes(cfg, rng)
    res_s = int(px.attrs.get("resolution_s", 60))
    r = np.diff(np.log(np.asarray(px, float)), axis=0); wc = np.full(r.shape[1], 1.0 / r.shape[1])
    if res_s == 1:
        deltas_s = np.array([1, 2, 5, 10, 30, 60, 300], float)
    else:
        deltas_s = np.array([60, 120, 300, 600, 1800], float)
    kap = kappa_by_bar(r, deltas_s / res_s, wc)
    kinf, tau = I.epps_tau_fit(deltas_s, kap)
    res.add("markets.crypto.kappa_shortest_bar", kap[0], source=f"bar {deltas_s[0]:.0f} s ({o2})")
    res.add("markets.crypto.kappa_5min", kap[np.argmin(np.abs(deltas_s - 300))], expected=0.75, expected_hi=0.85, source="AT-III: rising to ~0.8")
    res.add("markets.crypto.kappa_rises", float(kap[-1] > kap[0]), expected=1.0, abs_tol=0.0, source="AT-II Hyp 4.4")
    res.add("markets.crypto.epps_tau_s", tau, expected=1.0, expected_hi=10.0, unit="s", source="AT-II: tau ~ 5 s (fitted)")
    res.add("markets.crypto.kappa_inf", kinf, expected=0.7, expected_hi=0.9, source="AT-II: 0.813")
    res.data_origin = "real" if (o1 == "real" and o2 == "real") else ("synthetic" if (o1 != "real" and o2 != "real") else "real")
    res.note(f"stocks: {o1} ({R.shape[1]} names, {R.shape[0]} days); coins: {o2} ({r.shape[1]} coins at {res_s} s)")
    fig, ax = figure(cfg, "markets", 4)
    ax[0].semilogx(deltas_s, kap, "o-", label="kappa(Δ)"); ax[0].semilogx(deltas_s, I.epps_law(deltas_s, kinf, tau), "--", label=f"fit τ = {tau:.1f} s"); ax[0].legend(); ax[0].set_xlabel("bar length [s]"); ax[0].set_title(f"crypto basket ({o2})")
    ax[1].bar(["σ index", "mean σ stock"], [idx.std(), np.mean(sig)]); ax[1].set_title(f"σ ratio = {sigma_ratio:.2f} ({o1})")
    ax[2].bar(["collective", "internal"], [kappa, 1 - kappa]); ax[2].set_title("König split of squared returns")
    ax[3].plot(np.cumprod(1 + idx), label="index"); ax[3].plot(np.exp(np.cumsum(w @ np.log1p(np.clip(R, -0.9, None)).T)), label="mean of stocks' growth"); ax[3].legend(); ax[3].set_title(f"Jensen gap {gap:.2e}/day")
    res.figures.append(save(fig, cfg, "markets"))
    return res
