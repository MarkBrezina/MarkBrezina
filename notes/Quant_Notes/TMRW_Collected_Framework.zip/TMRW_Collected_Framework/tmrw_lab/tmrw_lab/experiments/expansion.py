"""B: gravity, collective motion and the expansion of space (AT-III Sec. 7).

(1) Pantheon+ (real when the GitHub host answers): the Hubble rate from the distance modulus, one rate
    at all distances (H0 = 73.25 +/- 1.40 km/s/Mpc, chi^2 = 5.7 for 6 dof); synthetic fallback plants it.
(2) The exact velocity-field split on a synthetic local volume: bulk flow (290 km/s planted), linear
    field whose trace is the expansion, internal motion.
(3) A synthetic star field with a planted hierarchy (stars in clusters in associations) reproducing
    the internal-share ladder 0 -> 0.63 -> 0.77 -> 0.80 (AT-III Sec. 7.3, Gaia) and Upsilon = M_dyn/M_vis
    for bound open clusters (1-5) and random field-star groups (~1e5) with the virial mass.
"""
from __future__ import annotations
import numpy as np

from ..core import identities as I
from ..hypotheses.h08_one_expansion_rate import load_pantheon, synthetic_hubble, fit_H0
from ..result import Result
from ._plot import figure, save

G_PC = 4.30091e-3   # pc (km/s)^2 / Msun


def star_field(rng, n_stars, n_clusters, ladder=(0.63, 0.77, 0.80)):
    """Stars grouped in clusters grouped in associations: v = V + a u_assoc + b u_cluster + c u_int with
    unit-variance components and shares c^2 = 0.63, b^2 = 0.14, a^2 = 0.03, |V|^2 = 0.20 of the total,
    so that the internal share is 0.63 at the cluster level, 0.77 at the association level and 0.80
    for the whole field (AT-III Sec. 7.3).  Returns velocities in km/s-like units (scale 1) and labels."""
    n_assoc = max(2, n_clusters // 5)
    assoc_of_cluster = rng.integers(0, n_assoc, n_clusters)
    cluster_of_star = rng.integers(0, n_clusters, n_stars)
    def unit(x):
        return x / np.sqrt(np.mean(np.sum(x ** 2, axis=1)))
    u_a = unit(rng.normal(0, 1, (n_assoc, 3)))[assoc_of_cluster[cluster_of_star]]
    u_c = unit(rng.normal(0, 1, (n_clusters, 3)))[cluster_of_star]
    u_i = rng.normal(0, 1, (n_stars, 3)); u_i -= u_i.mean(axis=0); u_i = unit(u_i)
    c2 = ladder[0]; b2 = ladder[1] - ladder[0]; a2 = ladder[2] - ladder[1]; v2 = 1 - ladder[2]
    V = np.array([1.0, 0.0, 0.0]) * np.sqrt(v2)
    vel = V + np.sqrt(a2) * u_a + np.sqrt(b2) * u_c + np.sqrt(c2) * u_i
    tot = np.mean(np.sum(vel ** 2, axis=1))
    _, Wc, Xc = I.group_aggregate(vel, None, cluster_of_star)
    share1 = (tot - np.sum(Wc[:, None] * Xc ** 2)) / tot
    _, Wa, Xa = I.group_aggregate(vel, None, assoc_of_cluster[cluster_of_star])
    share2 = (tot - np.sum(Wa[:, None] * Xa ** 2)) / tot
    X = vel.mean(axis=0); share3 = (tot - X @ X) / tot
    return vel, cluster_of_star, assoc_of_cluster, (share1, share2, share3)


def run(cfg) -> Result:
    res = Result(name="experiments.expansion", title="B: expansion, bulk flow and the stellar hierarchy")
    rng = np.random.default_rng(cfg.seed)
    data, origin = load_pantheon(cfg)
    if data is None:
        s = synthetic_hubble(rng, cfg.sizes["n_galaxies"]); origin = "synthetic"
        z, mu, dmu = s["z"], s["mu"], s["dmu"]
    else:
        z, mu, dmu = data["z"].to_numpy(), data["mu"].to_numpy(), data["dmu"].to_numpy()
    H0, rates, chi2 = fit_H0(z, mu, dmu)
    res.add("expansion.H0", H0, expected=73.25, tol=0.03, unit="km/s/Mpc", source="AT-III Sec. 7.2: 73.25 +/- 1.40")
    res.add("expansion.chi2_const_rate", chi2, expected=0.0, expected_hi=16.8, source="AT-III: 5.7 for 6 dof (16.8 = 99% point; peculiar-velocity floor 250 km/s here instead of the gravity-model correction)")
    res.add("expansion.dof", len(rates), expected=6, abs_tol=0, source="AT-III: 6 distance bins")
    res.add("expansion.n_sne", len(z), source=f"Pantheon+ ({origin})")
    # velocity-field split on a synthetic local volume
    n = cfg.sizes["n_galaxies"]
    pos = rng.uniform(-100, 100, (n, 3))
    M_true = np.eye(3) * (H0 / 1000 * 10) + np.array([[0, 2, 0], [0, 0, 1], [1, 0, 0]]) * 0.05
    vel = np.array([290.0, 0, 0]) + pos @ M_true.T + rng.normal(0, 50, (n, 3))
    sp = I.linear_field_split(pos, vel)
    res.add("expansion.bulk_flow_kms", float(np.linalg.norm(sp["V0"])), expected=290.0, tol=0.15, unit="km/s", source="AT-III Sec. 7.3 (planted)")
    res.add("expansion.rate_from_split_rel_err", abs(I.expansion_rate(sp["M"]) / I.expansion_rate(M_true) - 1), expected=0.0, abs_tol=0.1,
            source="AT-III Thm 3.7")
    res.add("expansion.split_shares_sum", sp["share_bulk"] + sp["share_linear"] + sp["share_internal"], expected=1.0, abs_tol=0.05,
            source="exact split (cross terms vanish in the least-squares split)")
    # stellar hierarchy and Upsilon
    velS, cl, ac, shares = star_field(rng, cfg.sizes["n_stars"], cfg.sizes["n_clusters"])
    for k, (sh, exp) in enumerate(zip(shares, (0.63, 0.77, 0.80)), start=1):
        res.add(f"gaia.internal_share_level{k}", sh, expected=exp, tol=0.1, source="AT-III Sec. 7.3: 0 -> 0.63 -> 0.77 -> 0.80 (planted)")
    # Upsilon with physical scales (planted): open clusters sigma ~ 0.5 km/s, R ~ 3 pc, ~1 Msun per star;
    # random field-star groups: sigma ~ 15 km/s, R ~ 100 pc -- the virial mass then exceeds the visible mass ~1e5 times
    ups_b, ups_f = [], []
    for c in range(min(cfg.sizes["n_clusters"], 50)):
        m = cl == c
        n_m = int(m.sum())
        if n_m < 5:
            continue
        M_vis = 200.0 * rng.uniform(0.7, 1.4)          # visible mass of a ~200 Msun open cluster
        sig_b = 0.5 * rng.uniform(0.7, 1.4); R_b = 3.0 * rng.uniform(0.7, 1.4)
        ups_b.append(I.virial_mass(sig_b, R_b, k=3.0) / M_vis)
        sig_f = 15.0 * rng.uniform(0.8, 1.2); R_f = 100.0 * rng.uniform(0.8, 1.2)
        ups_f.append(I.virial_mass(sig_f, R_f, k=3.0) / M_vis)
    res.add("gaia.upsilon_open_clusters_median", float(np.median(ups_b)), expected=1.0, expected_hi=5.0, source="AT-III Table 6: 1-5")
    res.add("gaia.upsilon_field_groups_median", float(np.median(ups_f)), expected=1e4, expected_hi=1e6, source="AT-III Table 6: ~1e5")
    res.data_origin = origin if origin == "real" else "synthetic"
    res.note(f"Pantheon+: {origin}; local-volume split and stellar hierarchy synthetic with planted answers")
    fig, ax = figure(cfg, "expansion", 4)
    dL = 10 ** ((mu - 25) / 5)
    ax[0].scatter(dL, 299792.458 * z, s=3); ax[0].plot(np.sort(dL), H0 * np.sort(dL), "r-", lw=1, label=f"H0 = {H0:.2f}"); ax[0].legend(); ax[0].set_xlabel("d_L [Mpc]"); ax[0].set_ylabel("cz [km/s]"); ax[0].set_title(f"Hubble diagram ({origin})")
    ax[1].errorbar(range(len(rates)), [r[0] for r in rates], yerr=[r[1] for r in rates], fmt="o"); ax[1].axhline(H0, color="r"); ax[1].set_title(f"rate by distance bin, chi2 = {chi2:.1f}")
    ax[2].bar(["bulk", "linear", "internal"], [sp["share_bulk"], sp["share_linear"], sp["share_internal"]]); ax[2].set_title("velocity-field split")
    ax[3].plot([0, 1, 2, 3], [0, *shares], "o-", label="measured"); ax[3].plot([0, 1, 2, 3], [0, 0.63, 0.77, 0.80], "x--", label="AT-III"); ax[3].legend(); ax[3].set_title("internal share by level")
    res.figures.append(save(fig, cfg, "expansion"))
    return res
