"""P2 and P3 on physical systems (AT-III Sec. 5-6): a simulated gas, a beam in a magnet, an epidemic wave.

(a) Gas: 2-d hard-disc gas started with a collective drift; elastic collisions turn the collective
    motion into heat while total energy is conserved (AT-III Sec. 6.2: conserved to 1.11e-16).
(b) Beam: particles entering a magnet with a spread of arrival times; each deflects along the same
    logistic-like curve shifted by its lag; the aggregate is the impact-weighted mixture (R^2 = 1.0000)
    and coarse bins squeeze it into "no reaction, then all reaction" (AT-III Sec. 5).
(c) Wave: the first COVID-19 wave (NYT counties when reachable, else the synthetic first wave) fitted by
    the mixture law (R^2 = 0.992) with the squeezed share 0.01 (daily) -> 0.93 (yearly).
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from scipy.stats import gamma as gamma_dist

from ..core import identities as I
from ..data import loaders_society as LS
from ..data import synthetic_society as SS
from ..result import Result
from ._plot import figure, save


def gas(rng, n, steps=400, dt=0.02, L=20.0, r=0.15, drift=1.5):
    pos = rng.uniform(r, L - r, (n, 2)); vel = rng.normal(0, 0.3, (n, 2)); vel[:, 0] += drift
    m = np.ones(n)
    E0 = 0.5 * np.sum(vel ** 2)
    kappas, E = [], []
    cell = int(L / (2 * r))
    for _ in range(steps):
        pos += vel * dt
        for d in range(2):                                     # walls
            hit = (pos[:, d] < r) | (pos[:, d] > L - r)
            vel[hit, d] *= -1; pos[:, d] = np.clip(pos[:, d], r, L - r)
        # collisions via cell lists
        idx = np.minimum((pos / (2 * r)).astype(int), cell - 1)
        key = idx[:, 0] * cell + idx[:, 1]
        order = np.argsort(key); ks = key[order]
        starts = np.flatnonzero(np.r_[True, ks[1:] != ks[:-1]])
        for a, b in zip(starts, np.r_[starts[1:], len(ks)]):
            if b - a < 2:
                continue
            ids = order[a:b]
            for i in range(len(ids)):
                for j in range(i + 1, len(ids)):
                    p, q = ids[i], ids[j]
                    dx = pos[p] - pos[q]; dist = np.hypot(*dx)
                    if 0 < dist < 2 * r:
                        nvec = dx / dist; dv = vel[p] - vel[q]
                        if dv @ nvec < 0:
                            vel[p] -= (dv @ nvec) * nvec; vel[q] += (dv @ nvec) * nvec
        kappas.append(I.collective_share(vel, m)); E.append(0.5 * np.sum(vel ** 2))
    return np.array(kappas), np.array(E), E0


def logistic(u, w=3.0):
    return 1.0 / (1.0 + np.exp(-u / w))


def fit_mixture(t, R_obs, width=3.0):
    def loss(p):
        a, s = np.exp(p)
        qs = gamma_dist.ppf(np.linspace(0.005, 0.995, 80), a, scale=s)
        return np.sum((I.mixture_law(t, np.ones(80), qs, lambda u: logistic(u, width)) - R_obs) ** 2)
    best = minimize(loss, np.log([2.0, 10.0]), method="Nelder-Mead", options={"maxiter": 500, "xatol": 1e-3, "fatol": 1e-10})
    a, s = np.exp(best.x)
    qs = gamma_dist.ppf(np.linspace(0.005, 0.995, 80), a, scale=s)
    Rf = I.mixture_law(t, np.ones(80), qs, lambda u: logistic(u, width))
    r2 = 1 - np.sum((Rf - R_obs) ** 2) / max(np.sum((R_obs - R_obs.mean()) ** 2), 1e-300)
    return Rf, r2, (a, s)


def run(cfg) -> Result:
    res = Result(name="experiments.gas_beam", title="P2/P3 on a gas, a beam and an epidemic wave")
    rng = np.random.default_rng(cfg.seed)
    # (a) gas
    kap, E, E0 = gas(rng, min(cfg.sizes["n_particles"], 2000))
    res.add("gas.energy_conservation_rel", float(np.max(np.abs(E - E0)) / E0), expected=0.0, abs_tol=1e-10,
            source="AT-III Sec. 6.2: 1.11e-16")
    res.add("gas.kappa_initial", kap[0], expected=0.5, expected_hi=1.0, source="started with a collective drift")
    res.add("gas.kappa_final", kap[-1], expected=0.0, expected_hi=0.05, source="AT-III Sec. 6.2: collective motion becomes heat")
    # (b) beam
    n = cfg.sizes["n_units"]
    t = np.arange(-20, 200, 0.5)
    lags = rng.gamma(4.0, 5.0, n); c = rng.lognormal(0, 0.3, n)
    R = I.mixture_law(t, c, lags, lambda u: logistic(u))
    Rf, r2b, _ = fit_mixture(t, R)
    dR = np.diff(R, prepend=R[0])
    sq_fine = I.squeezed_share(t, dR, 0.0, 2.0); sq_coarse = I.squeezed_share(t, dR, 0.0, 200.0)
    res.add("beam.mixture_r2", r2b, expected=1.0, abs_tol=1e-3, source="AT-III Sec. 5: 1.0000")
    res.add("beam.squeezed_share_fine", sq_fine, expected=0.0, expected_hi=0.2, source="AT-III Thm 3.6")
    res.add("beam.squeezed_share_coarse", sq_coarse, expected=0.9, expected_hi=1.0, source="AT-III Thm 3.6")
    spread = lags.max() - lags.min() + 6 * 3.0
    res.add("beam.bound_holds", float(sq_coarse >= I.squeezing_bound(spread, 200.0)), expected=1.0, abs_tol=0.0)
    # (c) first wave
    data, origin = LS.load_nyt_counties(cfg, rng)
    if origin == "real":
        daily = np.asarray(data["daily_new"], float)[:120]
        wave = daily.sum(axis=1)
    else:
        fw = SS.first_wave(cfg, rng)
        daily = np.column_stack([np.asarray(v, float) for k, v in fw.items() if k != "planted"])
        wave = daily.sum(axis=1)
    cum = np.cumsum(wave); cum = cum / max(cum[-1], 1e-300)
    tw = np.arange(len(cum), dtype=float)
    Rw, r2w, _ = fit_mixture(tw, cum, width=4.0)
    dRw = np.diff(cum, prepend=0.0)
    res.add("waves.mixture_r2", r2w, expected=0.992, tol=0.03, source="AT-III Sec. 5 (first US wave)")
    res.add("waves.squeezed_share_daily", I.squeezed_share(tw, dRw, float(np.argmax(dRw)), 1.0), expected=0.01, abs_tol=0.06,
            source="AT-III Table 4: 0.01 (daily bins)")
    res.add("waves.squeezed_share_yearly", I.squeezed_share(tw, dRw, 0.0, 365.0), expected=0.93, abs_tol=0.1,
            source="AT-III Table 4: 0.93 (yearly bins)")
    res.data_origin = "real" if origin == "real" else "simulation"
    res.note(f"gas: {min(cfg.sizes['n_particles'], 2000)} hard discs; beam: {n} particles with gamma lags; wave: {origin} county data")
    fig, ax = figure(cfg, "gas_beam", 4)
    ax[0].plot(kap); ax[0].set_title("gas: collective share of kinetic energy"); ax[0].set_xlabel("step")
    ax[1].plot((E - E0) / E0); ax[1].set_title("gas: relative energy error"); ax[1].set_xlabel("step")
    ax[2].plot(t, R, label="aggregate"); ax[2].plot(t, Rf, "--", label=f"mixture fit R²={r2b:.4f}"); ax[2].legend(); ax[2].set_title("beam in a magnet")
    ax[3].plot(tw, cum, label="cumulative wave"); ax[3].plot(tw, Rw, "--", label=f"mixture fit R²={r2w:.3f}"); ax[3].legend(); ax[3].set_title(f"first wave ({origin})")
    res.figures.append(save(fig, cfg, "gas_beam"))
    return res
