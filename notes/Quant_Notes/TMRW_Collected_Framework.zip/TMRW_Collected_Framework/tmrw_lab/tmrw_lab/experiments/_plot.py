"""Tiny plotting helper shared by the experiment modules (matplotlib, Agg)."""
from __future__ import annotations
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


def figure(cfg, name, n_panels, ncols=2, width=11, height=3.4):
    nrows = (n_panels + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(width, height * nrows), squeeze=False)
    return fig, axes.ravel()


def save(fig, cfg, name):
    out = Path(cfg.results_dir) / "figures"
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{name}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return str(path)
