"""C at the order-book level (AT-II Sec. 5, AT-III Sec. 8.2): OFI law, microprice, sign memory,
square-root impact, the book as a potential landscape, the propagator.

Level-1 events (Binance gives no level-1 history: the events are synthetic -- a Hawkes-driven book with
planted sign Hurst 0.85, OFI R^2 ~ 0.6 at 1 s, mid move / microprice offset >> 1 at 100 ms and ~1 after
a minute, square-root impact).  Expected values from AT-II Table 1/3 and AT-III Sec. 8.2.
"""
from __future__ import annotations
import numpy as np

from ..core import impact as IM
from ..data import loaders_markets as LM
from ..result import Result
from ._plot import figure, save


def _time_windows(t, values, horizon_s):
    """Sum values over consecutive windows of horizon_s seconds; returns (sums, index of window ends)."""
    edges = np.arange(t[0], t[-1] + horizon_s, horizon_s)
    idx = np.searchsorted(t, edges)
    sums = np.add.reduceat(np.r_[values, 0.0], np.minimum(idx[:-1], len(values)))[: len(idx) - 1]
    return sums, idx


def run(cfg) -> Result:
    res = Result(name="experiments.order_book", title="C at the order book: OFI, microprice, memory, impact")
    rng = np.random.default_rng(cfg.seed)
    df, origin = LM.load_order_book_events(cfg, rng)
    t = df["time"].to_numpy(float); bid = df["bid"].to_numpy(float); ask = df["ask"].to_numpy(float)
    qb = df["bid_size"].to_numpy(float); qa = df["ask_size"].to_numpy(float)
    tick = float(df.attrs.get("tick", 0.01))
    mid = 0.5 * (bid + ask); micro = IM.microprice(bid, ask, qb, qa)
    e = IM.ofi(bid, qb, ask, qa)
    # OFI regression at horizons
    for h in (1.0, 10.0, 60.0):
        ofi_h, idx = _time_windows(t[1:], e, h)
        ends = np.minimum(idx[1:], len(mid) - 1); starts = np.minimum(idx[:-1], len(mid) - 1)
        dP = (mid[ends] - mid[starts]) / tick
        n = min(len(dP), len(ofi_h))
        if n > 20:
            reg = IM.ofi_regression(dP[:n], ofi_h[:n])
            key = f"{int(h)}s"
            res.add(f"order_book.ofi_beta_{key}", reg["beta"], expected=0.0, expected_hi=1e9, source="AT-II eq. OFI: beta > 0")
            res.add(f"order_book.ofi_r2_{key}", reg["r2"], expected=0.5 if h == 1.0 else 0.2, expected_hi=1.0,
                    source="AT-II Known 5.2 / Cont-Kukanov-Stoikov: R^2 ~ 0.6 at 1 s")
    # mid move over microprice offset at horizons
    offset = micro - mid
    for h in (0.1, 1.0, 10.0, 60.0):
        j = np.searchsorted(t, t + h); j = np.minimum(j, len(t) - 1)
        ok = (j > np.arange(len(t))) & (np.abs(offset) > 0.1 * tick)
        if ok.sum() > 50:
            move = (mid[j[ok]] - mid[ok]); k = np.sum(move * offset[ok]) / np.sum(offset[ok] ** 2)
            key = "100ms" if h == 0.1 else f"{int(h)}s"
            if h == 0.1:
                res.add("order_book.mid_over_microprice_100ms", k, expected=2.0, expected_hi=1e6, source="AT-II Tab. 3 / AT-III Sec. 8.2: far above 1 for BTC")
            elif h == 60.0:
                res.add("order_book.mid_over_microprice_60s", k, expected=1.0, tol=0.6, source="AT-III: flat (~1) after seconds")
            else:
                res.add(f"order_book.mid_over_microprice_{key}", k)
    # sign memory
    signs = df["trade_sign"].to_numpy(float); signs = signs[signs != 0]
    hu = IM.hurst_exponent(signs)
    ac = IM.sign_autocorrelation(signs, 100)
    res.add("order_book.sign_hurst", float(hu["H_rs"]), expected=0.85, tol=0.12, source="AT-II Table 1: H ~ 0.85-0.9 (planted 0.85)")
    res.add("order_book.sign_acf_gamma", float(ac["gamma"]), expected=0.5, tol=0.6, source="AT-II Known 5.7: gamma ~ 0.5")
    # square-root impact: the mid move after a trade against the trade's size (planted: impact ~ sqrt(size))
    tr = np.flatnonzero(df["trade_sign"].to_numpy(float) != 0); tr = tr[tr > 0]
    s_tr = df["trade_sign"].to_numpy(float)[tr]; v_tr = df["trade_size"].to_numpy(float)[tr]
    imp = s_tr * (mid[tr] - mid[tr - 1]) / tick          # the mid move the trade produces (contemporaneous)
    bins = np.quantile(v_tr, np.linspace(0, 1, 13))
    Q, Imp = [], []
    for lo, hi in zip(bins[:-1], bins[1:]):
        m = (v_tr >= lo) & (v_tr < hi)
        if m.sum() > 30:
            Q.append(float(np.mean(v_tr[m]))); Imp.append(float(np.mean(imp[m])))
    Q = np.array(Q); Imp = np.array(Imp)
    good = Imp > 0
    if good.sum() > 5:
        fit = IM.fit_sqrt_impact(Q[good], Imp[good])
        res.add("order_book.impact_exponent", fit["delta"], expected=0.5, tol=0.4, source="AT-II Known 5.6: 1/2 (planted per-trade sqrt(size))")
        res.add("order_book.impact_Y", fit["Y"])
    # the book as a potential landscape and the propagator
    prof = np.r_[np.histogram(-(mid - bid) / tick, bins=10, weights=qb)[0][::-1], np.histogram((ask - mid) / tick, bins=10, weights=qa)[0]]
    pot = IM.potential_from_book(prof + 1e-9)
    res.add("order_book.potential_depth", float(np.max(pot["U"]) - np.min(pot["U"])), source="AT-II Sec. 5.3: U = -D log rho")
    dmid = np.diff(mid) / tick
    prop = IM.propagator_fit(df["trade_sign"].to_numpy(float)[1:], dmid, 30)
    res.add("order_book.propagator_G1", float(prop["G"][1]) if len(prop["G"]) > 1 else np.nan, expected=0.0, expected_hi=1e9, source="AT-II Known 5.7")
    res.data_origin = "synthetic"
    res.note("the level-1 events are a synthetic stand-in (no level-1 history is reachable): the OFI R^2 and the "
             "mid/microprice ratios test the measurement path, not BTC; the AT-III expectations are kept for the real run")
    res.note(f"events: {origin} ({len(df)} events over {t[-1] - t[0]:.0f} s); Binance level-1 history is not available, trade sizes {'calibrated from recent trades' if 'calibration' in df.attrs else 'synthetic'}")
    fig, ax = figure(cfg, "order_book", 4)
    ofi_1, idx = _time_windows(t[1:], e, 1.0); ends = np.minimum(idx[1:], len(mid) - 1); starts = np.minimum(idx[:-1], len(mid) - 1)
    dP1 = (mid[ends] - mid[starts]) / tick; n = min(len(dP1), len(ofi_1))
    ax[0].scatter(ofi_1[:n], dP1[:n], s=3); ax[0].set_xlabel("OFI (1 s)"); ax[0].set_ylabel("Δmid [ticks]"); ax[0].set_title("OFI law")
    ax[1].plot(ac["lags"], ac["acf"], "."); ax[1].set_xscale("log"); ax[1].set_yscale("log"); ax[1].set_title(f"sign autocorrelation, H = {hu['H_rs']:.2f}")
    if good.sum() > 5:
        ax[2].loglog(Q[good], Imp[good], "o", ms=4); qq = np.geomspace(Q[good].min(), Q[good].max(), 50); ax[2].loglog(qq, fit["Y"] * qq ** fit["delta"], "r-", label=f"δ = {fit['delta']:.2f}"); ax[2].legend()
    ax[2].set_title("impact by trade size"); ax[2].set_xlabel("size"); ax[2].set_ylabel("ticks")
    ax[3].plot(pot["x"], pot["U"]); ax[3].set_title("book as a potential U = −D log ρ")
    res.figures.append(save(fig, cfg, "order_book"))
    return res
