"""The exact layer of Aggregation Theory, as functions.

Every function implements one statement of the compendium (chapter and theorem in the docstring):
the König split, the speed ratio φ and collective share κ (AT-III Thm 3.1), the turbulence identity
Ψ² = H + (1−H)ρ̄ (AT-III Thm 3.2), preserved mean and the Jensen growth gap (AT-III Thm 3.3), the cascade
factorisation (Thm 3.4), the mixture law and the squeezing bound (Thms 3.5-3.6), the linear-field split with
the Oort constants (Thm 3.7), invariant-mass superadditivity (AT-II Thm 3.6), volatility subadditivity with
the gap identity (AT-II Thm 3.7), the virial mass and the sign law (AT-II Known 3.8 / AT-III Known 3.9),
the leftover dispersion (AT-II Def 4.1), the index return (AT-II Cor 3.2) and the Epps law (AT-II Hyp 4.3).

Conventions: units i = 1..N carry weights w_i ≥ 0 (normalised inside each function) and "velocities"
x_i ∈ R^d given as an array of shape (N,) or (N, d).  The aggregate is X = Σ w_i x_i.
"""
from __future__ import annotations
import numpy as np

__all__ = [
    "normalise_weights", "aggregate", "konig_split", "speed_ratio", "collective_share", "herfindahl",
    "n_effective", "mean_correlation", "turbulence_ratio", "turbulence_identity", "mean_preserved",
    "jensen_growth_gap", "cascade_factors", "mixture_law", "mixture_bounds", "squeezing_bound",
    "squeezed_share", "linear_field_split", "oort_constants", "expansion_rate", "invariant_mass",
    "mass_superadditivity_gap", "vol_subadditivity", "vol_gap_identity", "virial_mass", "sign_law",
    "leftover_dispersion", "index_return", "epps_law", "epps_tau_fit", "group_aggregate",
]


# ----------------------------------------------------------------------------------------------
# basics
# ----------------------------------------------------------------------------------------------
def normalise_weights(w, n=None):
    """Weights as a non-negative array summing to one; None → uniform."""
    if w is None:
        if n is None:
            raise ValueError("n required when w is None")
        return np.full(n, 1.0 / n)
    w = np.asarray(w, dtype=float)
    if np.any(w < 0):
        raise ValueError("weights must be non-negative")
    s = w.sum()
    if s <= 0:
        raise ValueError("weights must not all be zero")
    return w / s


def _as_vectors(x):
    x = np.asarray(x, dtype=float)
    return x[:, None] if x.ndim == 1 else x


def aggregate(x, w=None):
    """X = Σ_i w_i x_i  (AT-III Def 2.1).  Returns shape (d,) (or a scalar when x is 1-d)."""
    xv = _as_vectors(x)
    w = normalise_weights(w, xv.shape[0])
    X = w @ xv
    return X[0] if np.asarray(x).ndim == 1 else X


def group_aggregate(x, w, groups):
    """Group weights W_g = Σ_{i∈g} w_i and group velocities X_g = W_g^{-1} Σ_{i∈g} w_i x_i for a
    partition given as an integer label per unit.  Returns (labels, W, X) with X of shape (G, d)."""
    xv = _as_vectors(x)
    w = normalise_weights(w, xv.shape[0])
    labels = np.unique(groups)
    W = np.array([w[groups == g].sum() for g in labels])
    X = np.array([(w[groups == g] @ xv[groups == g]) / max(w[groups == g].sum(), 1e-300) for g in labels])
    return labels, W, X


# ----------------------------------------------------------------------------------------------
# König split, speed ratio, collective share
# ----------------------------------------------------------------------------------------------
def konig_split(x, w=None):
    """König's split (AT-II Thm 3.4):  Σ w_i|x_i|² = |X|² + Σ w_i|x_i − X|².
    Returns (total, collective, internal); total == collective + internal to rounding."""
    xv = _as_vectors(x)
    w = normalise_weights(w, xv.shape[0])
    X = w @ xv
    total = float(w @ np.sum(xv ** 2, axis=1))
    collective = float(X @ X)
    internal = float(w @ np.sum((xv - X) ** 2, axis=1))
    return total, collective, internal


def speed_ratio(x, w=None):
    """φ = |X| / Σ w_i |x_i| ≤ 1 (AT-III Thm 3.1, the triangle inequality)."""
    xv = _as_vectors(x)
    w = normalise_weights(w, xv.shape[0])
    denom = float(w @ np.linalg.norm(xv, axis=1))
    return float(np.linalg.norm(w @ xv) / denom) if denom > 0 else np.nan


def collective_share(x, w=None):
    """κ = |X|² / Σ w_i |x_i|² ≤ φ² ≤ 1 (AT-III Thm 3.1): the share of the squared motion that is collective."""
    total, collective, _ = konig_split(x, w)
    return collective / total if total > 0 else np.nan


# ----------------------------------------------------------------------------------------------
# turbulence identity
# ----------------------------------------------------------------------------------------------
def herfindahl(a):
    """H = Σ a_i² / (Σ a_i)² for non-negative a_i."""
    a = np.asarray(a, dtype=float)
    s = a.sum()
    return float((a ** 2).sum() / s ** 2) if s > 0 else np.nan


def n_effective(a):
    """N_eff = 1/H."""
    H = herfindahl(a)
    return 1.0 / H if H > 0 else np.nan


def mean_correlation(a, R):
    """ρ̄ = Σ_{i≠j} a_i a_j ρ_ij / Σ_{i≠j} a_i a_j, the a-weighted mean off-diagonal correlation."""
    a = np.asarray(a, dtype=float)
    R = np.asarray(R, dtype=float)
    off = np.ones_like(R) - np.eye(len(a))
    num = float(a @ (R * off) @ a)
    den = float(a @ off @ a)
    return num / den if den > 0 else np.nan


def turbulence_ratio(sigma, w=None, R=None):
    """Ψ = σ_X / Σ w_i σ_i with σ_X² = aᵀ R a, a_i = w_i σ_i (AT-III Thm 3.2; Minkowski gives Ψ ≤ 1)."""
    sigma = np.asarray(sigma, dtype=float)
    w = normalise_weights(w, len(sigma))
    a = w * sigma
    R = np.eye(len(a)) if R is None else np.asarray(R, dtype=float)
    sx = float(np.sqrt(max(a @ R @ a, 0.0)))
    return sx / a.sum() if a.sum() > 0 else np.nan


def turbulence_identity(sigma, w=None, R=None):
    """Ψ² = H + (1 − H) ρ̄ exactly (AT-III Thm 3.2).  Returns dict(Psi2_direct, Psi2_identity, H, rho_bar, N_eff)."""
    sigma = np.asarray(sigma, dtype=float)
    w = normalise_weights(w, len(sigma))
    a = w * sigma
    R = np.eye(len(a)) if R is None else np.asarray(R, dtype=float)
    H = herfindahl(a)
    rho = mean_correlation(a, R)
    psi2 = turbulence_ratio(sigma, w, R) ** 2
    return {"Psi2_direct": psi2, "Psi2_identity": H + (1 - H) * rho, "H": H, "rho_bar": rho, "N_eff": 1 / H}


# ----------------------------------------------------------------------------------------------
# mean and compound growth
# ----------------------------------------------------------------------------------------------
def mean_preserved(x, w=None):
    """With constant weights the aggregate of the time-means equals the time-mean of the aggregate
    (AT-III Thm 3.3a).  x has shape (T, N).  Returns (mean_of_aggregate, aggregate_of_means)."""
    x = np.asarray(x, dtype=float)
    w = normalise_weights(w, x.shape[1])
    X = x @ w
    return float(X.mean()), float(w @ x.mean(axis=0))


def jensen_growth_gap(r, w=None):
    """Compound growth of the whole minus the weighted mean of the parts' compound growth ≥ 0
    (AT-III Thm 3.3b, Jensen).  r: simple returns of shape (T, N).  Returns (g_whole, g_parts_mean, gap)
    with g = mean log(1+return)."""
    r = np.asarray(r, dtype=float)
    w = normalise_weights(w, r.shape[1])
    g_whole = float(np.mean(np.log1p(r @ w)))
    g_parts = float(w @ np.mean(np.log1p(r), axis=0))
    return g_whole, g_parts, g_whole - g_parts


# ----------------------------------------------------------------------------------------------
# cascade
# ----------------------------------------------------------------------------------------------
def cascade_factors(x, w, partitions):
    """Cascade factorisation (AT-III Thm 3.4): for a chain of partitions P_0 ≺ P_1 ≺ ... ≺ P_L, the
    speed per unit S_ℓ = Σ_{g∈P_ℓ} W_g |X_g| is non-increasing in ℓ, and the overall speed ratio
    φ = S_L/S_0 is the product of the factors S_{ℓ+1}/S_ℓ, each ≤ 1.
    partitions: list of integer label arrays, coarsest last (the top level has one group).
    Returns (S, factors, product_of_factors, phi_direct)."""
    xv = _as_vectors(x)
    w = normalise_weights(w, xv.shape[0])
    S = [float(w @ np.linalg.norm(xv, axis=1))]
    for labels in partitions:
        _, W, X = group_aggregate(xv, w, np.asarray(labels))
        S.append(float(W @ np.linalg.norm(X, axis=1)))
    S = np.array(S)
    factors = S[1:] / S[:-1]
    return S, factors, float(np.prod(factors)), S[-1] / S[0]


# ----------------------------------------------------------------------------------------------
# events: mixture law and squeezing
# ----------------------------------------------------------------------------------------------
def mixture_law(t, c, tau, f):
    """R(t)/A = Σ_i c_i f_i(t − τ_i) (AT-III Thm 3.5): the aggregate response to one event is the
    impact-weighted mixture of the unit responses.  f: a callable f(u) (shared unit response) or a list
    of callables; c: impacts (normalised to sum 1 by A); tau: lags."""
    t = np.asarray(t, dtype=float)
    c = np.asarray(c, dtype=float)
    tau = np.asarray(tau, dtype=float)
    A = c.sum()
    out = np.zeros_like(t)
    for i in range(len(c)):
        fi = f[i] if isinstance(f, (list, tuple)) else f
        out += c[i] * fi(t - tau[i])
    return out / A


def mixture_bounds(t, tau, f_monotone, c=None):
    """For a monotone unit response the mixture lies between the two shifted copies
    f(t − τ_max) ≤ R(t)/A ≤ f(t − τ_min) (AT-III Thm 3.5)."""
    t = np.asarray(t, dtype=float)
    tau = np.asarray(tau, dtype=float)
    return f_monotone(t - tau.max()), f_monotone(t - tau.min())


def squeezing_bound(spread, delta):
    """Share of the response that a bin of length Δ containing the event captures:
    ≥ 1 − (a + b)/Δ where a + b is the spread of the lag distribution plus the rise time (AT-III Thm 3.6)."""
    return max(0.0, 1.0 - float(spread) / float(delta))


def squeezed_share(t, R, t0, delta):
    """Measured counterpart: the share of the total response that falls inside the bin [t0, t0+Δ)."""
    t = np.asarray(t, dtype=float)
    R = np.asarray(R, dtype=float)
    tot = R.sum()
    inside = R[(t >= t0) & (t < t0 + delta)].sum()
    return inside / tot if tot != 0 else np.nan


# ----------------------------------------------------------------------------------------------
# velocity fields: linear-field split, Oort constants, expansion
# ----------------------------------------------------------------------------------------------
def linear_field_split(pos, vel, w=None):
    """v_i = V_0 + M (x_i − x̄) + r_i (AT-III Thm 3.7): the weighted least-squares split of a velocity
    field into a bulk flow V_0, a linear field M (shear, rotation, expansion) and the internal motion r.
    Returns dict(V0, M, r, xbar, share_bulk, share_linear, share_internal) where the shares are of Σ w|v|²."""
    pos = _as_vectors(pos)
    vel = _as_vectors(vel)
    n, d = pos.shape
    w = normalise_weights(w, n)
    xbar = w @ pos
    V0 = w @ vel
    dx = pos - xbar
    dv = vel - V0
    # weighted least squares M (d x d): dv ≈ dx Mᵀ
    sw = np.sqrt(w)[:, None]
    M, *_ = np.linalg.lstsq(dx * sw, dv * sw, rcond=None)
    M = M.T
    lin = dx @ M.T
    r = dv - lin
    tot = float(w @ np.sum(vel ** 2, axis=1))
    return {"V0": V0, "M": M, "r": r, "xbar": xbar,
            "share_bulk": float(V0 @ V0) / tot if tot > 0 else np.nan,
            "share_linear": float(w @ np.sum(lin ** 2, axis=1)) / tot if tot > 0 else np.nan,
            "share_internal": float(w @ np.sum(r ** 2, axis=1)) / tot if tot > 0 else np.nan}


def oort_constants(M):
    """Oort's A, B, C, K from a 2-d linear field M = [[K + C, A − B], [A + B, K − C]]
    (AT-III Thm 3.7): K = tr M / 2 (expansion), C = (M11 − M22)/2, A = (M12 + M21)/2, B = (M21 − M12)/2."""
    M = np.asarray(M, dtype=float)
    if M.shape != (2, 2):
        raise ValueError("Oort constants are defined for a 2x2 linear field")
    K = (M[0, 0] + M[1, 1]) / 2
    C = (M[0, 0] - M[1, 1]) / 2
    A = (M[0, 1] + M[1, 0]) / 2
    B = (M[1, 0] - M[0, 1]) / 2
    return {"A": A, "B": B, "C": C, "K": K}


def expansion_rate(M):
    """Expansion is the trace of the linear field: H = tr M / d (AT-III Thm 3.7; Hubble's law in 3-d)."""
    M = np.asarray(M, dtype=float)
    return float(np.trace(M) / M.shape[0])


# ----------------------------------------------------------------------------------------------
# mass: invariant mass, superadditivity, virial, sign law
# ----------------------------------------------------------------------------------------------
def invariant_mass(E, p):
    """M² = (Σ E_i)² − |Σ p_i|² (c = 1).  E: shape (N,), p: shape (N, 3)."""
    E = np.asarray(E, dtype=float)
    p = _as_vectors(p)
    m2 = E.sum() ** 2 - float(np.sum(p.sum(axis=0) ** 2))
    return float(np.sqrt(max(m2, 0.0)))


def mass_superadditivity_gap(E, p):
    """Free composites are heavier than their parts (AT-II Thm 3.6): M ≥ Σ m_i.  Returns (M, Σm_i, gap/M)."""
    E = np.asarray(E, dtype=float)
    p = _as_vectors(p)
    m = np.sqrt(np.maximum(E ** 2 - np.sum(p ** 2, axis=1), 0.0))
    M = invariant_mass(E, p)
    return M, float(m.sum()), (M - m.sum()) / M if M > 0 else np.nan


def vol_subadditivity(sigma, w=None, R=None):
    """σ_X ≤ Σ w_i σ_i (AT-II Thm 3.7, Minkowski).  Returns (σ_X, Σ w σ)."""
    sigma = np.asarray(sigma, dtype=float)
    w = normalise_weights(w, len(sigma))
    a = w * sigma
    R = np.eye(len(a)) if R is None else np.asarray(R, dtype=float)
    return float(np.sqrt(max(a @ R @ a, 0.0))), float(a.sum())


def vol_gap_identity(sigma, w=None, R=None):
    """The gap identity (AT-II Thm 3.7): (Σ w σ)² − σ_X² = Σ_{i,j} a_i a_j (1 − ρ_ij).
    Returns (lhs, rhs)."""
    sigma = np.asarray(sigma, dtype=float)
    w = normalise_weights(w, len(sigma))
    a = w * sigma
    R = np.eye(len(a)) if R is None else np.asarray(R, dtype=float)
    lhs = a.sum() ** 2 - float(a @ R @ a)
    rhs = float(a @ (1.0 - R) @ a)
    return lhs, rhs


def virial_mass(sigma_v, R, G=4.30091e-3, k=1.0):
    """Virial (dynamical) mass M_dyn = k σ_v² R / G for a self-gravitating system in equilibrium
    (AT-II Known 3.8; G in pc (km/s)² / M_sun by default, so σ_v in km/s and R in pc give M in M_sun).
    k depends on the mass profile (k ≈ 3 for an isotropic uniform sphere with the 1-d dispersion; k = 1 is
    the order-of-magnitude convention used in AT-III's Υ = M_dyn/M_vis)."""
    return float(k * sigma_v ** 2 * R / G)


def sign_law(n, K):
    """The virial sign law (AT-III Known 3.9): for a potential homogeneous of degree n, 2K = n U, so the
    internal energy is E_int = K + U = (1 + 2/n) K: negative for n = −1 (gravity, Coulomb: bound composites
    are lighter than their parts), positive for n > 0 (confinement: heavier)."""
    return (1.0 + 2.0 / n) * K


# ----------------------------------------------------------------------------------------------
# leftover dispersion, index return, Epps
# ----------------------------------------------------------------------------------------------
def leftover_dispersion(x, w=None, X=None):
    """What is left after removing the collective motion: Σ w_i |x_i − X|² (AT-II Def 4.1); with a
    model X given, the leftover after removing the model instead."""
    xv = _as_vectors(x)
    w = normalise_weights(w, xv.shape[0])
    Xc = w @ xv if X is None else np.asarray(X, dtype=float)
    return float(w @ np.sum((xv - Xc) ** 2, axis=1))


def index_return(returns, w):
    """Index returns are weighted sums of stock returns (AT-II Cor 3.2): r_I = Σ w_i r_i, exactly."""
    returns = np.asarray(returns, dtype=float)
    w = np.asarray(w, dtype=float)
    return returns @ (w / w.sum())


def epps_law(delta, kappa_inf, tau):
    """κ(Δ) = κ_∞ Δ / (Δ + τ) (AT-II Hyp 4.3): the collective share rises with the sampling interval Δ
    because unit responses arrive with lags of order τ."""
    delta = np.asarray(delta, dtype=float)
    return kappa_inf * delta / (delta + tau)


def epps_tau_fit(delta, kappa):
    """Fit κ_∞ and τ by least squares on the linearised law 1/κ = (1/κ_∞)(1 + τ/Δ).  Returns (κ_∞, τ)."""
    delta = np.asarray(delta, dtype=float)
    kappa = np.asarray(kappa, dtype=float)
    ok = (kappa > 0) & (delta > 0)
    y = 1.0 / kappa[ok]
    Xd = np.column_stack([np.ones(ok.sum()), 1.0 / delta[ok]])
    b, *_ = np.linalg.lstsq(Xd, y, rcond=None)
    kinf = 1.0 / b[0]
    tau = b[1] * kinf
    return float(kinf), float(tau)
