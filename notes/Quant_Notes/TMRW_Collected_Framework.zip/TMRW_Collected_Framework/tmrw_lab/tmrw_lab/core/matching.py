"""The matching rule as a checker (AT-II, section 3 and Proposition 3.10; section 6).

Three kinds of quantity (AT-II Definition 2.4): additive quantities match exactly between a group
and its parts (Proposition 3.1); squared quantities split exactly into a collective and an internal
part, the König split (Theorem 3.4), and the internal share can only grow up a hierarchy
(Theorem 3.6); emergent quantities leave a two-sided residual — superadditive for invariant mass,
subadditive for volatility (Theorems 3.7–3.8).  `match_report` walks a hierarchy and reports
φ, κ, Ψ², N_eff, the additive mismatch and the internal share level by level with the functions of
`tmrw_lab.core.identities`; `two_sided_match` is the simulated method of moments of
Definitions 6.1–6.2 (match the simulated fingerprint to the data's by Nelder–Mead).
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize

from tmrw_lab.core.identities import (
    normalise_weights, aggregate, group_aggregate, konig_split, speed_ratio, collective_share,
    turbulence_identity, herfindahl, n_effective,
)

__all__ = ["classify_quantity", "match_report", "two_sided_match"]


def classify_quantity(parts, whole, w=None, kind="additive", tol=1e-9):
    """The matching rule (AT-II Proposition 3.10) for one group and its parts.
    kind="additive": Φ(g) = Σ_j Φ(h_j) (weighted by w when given: V_g = Σ (M_h/M_g) V_h, Prop 3.1);
    returns the relative mismatch, ≈ 0.
    kind="squared": the König split of the parts' velocities (Thm 3.4): total = collective + internal;
    returns the three terms, the gap (≈ 0), κ, the internal share and the mismatch of a given whole.
    kind="emergent": the two-sided residual whole − Σ parts (Σ w·parts when weighted): > 0 superadditive
    (invariant mass, Thm 3.7), < 0 subadditive (volatility, Thm 3.8), 0 when the parts move together."""
    p = np.asarray(parts, dtype=float)
    if kind == "additive":
        comb = p.sum(axis=0) if w is None else np.tensordot(np.asarray(w, dtype=float), p, axes=(0, 0))
        wh = np.asarray(whole, dtype=float)
        mismatch = float(np.linalg.norm(np.atleast_1d(wh - comb)) / max(np.linalg.norm(np.atleast_1d(wh)), 1e-300))
        return {"kind": kind, "combined": comb, "whole": wh, "mismatch": mismatch, "ok": mismatch <= tol}
    if kind == "squared":
        total, collective, internal = konig_split(p, w)
        X = aggregate(p, w)
        gap = total - collective - internal
        out = {"kind": kind, "total": total, "collective": collective, "internal": internal,
               "gap": float(gap), "gap_rel": float(abs(gap) / max(total, 1e-300)),
               "kappa": collective / total if total > 0 else np.nan,
               "internal_share": internal / total if total > 0 else np.nan, "aggregate": X}
        if whole is not None:
            wh = np.asarray(whole, dtype=float)
            out["whole_mismatch"] = float(np.linalg.norm(np.atleast_1d(wh - X)) / max(np.linalg.norm(np.atleast_1d(X)), 1e-300))
        out["ok"] = out["gap_rel"] <= tol
        return out
    if kind == "emergent":
        naive = p.sum(axis=0) if w is None else np.tensordot(np.asarray(w, dtype=float), p, axes=(0, 0))
        wh = np.asarray(whole, dtype=float)
        resid = wh - naive
        rel = float(np.linalg.norm(np.atleast_1d(resid)) / max(np.linalg.norm(np.atleast_1d(wh)), 1e-300))
        signed = float(np.sum(np.atleast_1d(resid)))
        direction = "superadditive" if signed > tol * abs(float(np.sum(np.atleast_1d(wh)))) else (
            "subadditive" if signed < -tol * abs(float(np.sum(np.atleast_1d(wh)))) else "additive")
        return {"kind": kind, "naive": naive, "whole": wh, "residual": resid, "residual_rel": rel,
                "direction": direction}
    raise ValueError("kind must be additive, squared or emergent")


def _level_stats(X, W, time_series):
    """Speed S = Σ W|X| and energy E = Σ W|X|² of one level (summed over time for a series)."""
    if time_series:                      # X: (T, G)
        S = float(np.sum(W * np.abs(X)))
        E = float(np.sum(W * X ** 2))
    else:                                # X: (G, d)
        S = float(W @ np.linalg.norm(X, axis=1))
        E = float(W @ np.sum(X ** 2, axis=1))
    return S, E


def match_report(groups, levels, w=None, time_series=None):
    """Walk a hierarchy P_0 ≺ P_1 ≺ … ≺ P_L (AT-III Definition 2.1; AT-II Definition 2.3) and report,
    level by level, the matching parameters of the exact layer using `tmrw_lab.core.identities`.
    groups: the unit velocities, shape (N,) or (N, d) for one snapshot, or (T, N) for a time series
    (the Ψ² block needs a series); levels: partitions as integer labels per unit, finer first; w: weights.
    Per level ℓ (0 = the units): n_groups; phi = S_L/S_ℓ and kappa = E_L/E_ℓ (speed ratio and collective
    share of the top aggregate relative to the level-ℓ parts, AT-III Thm 3.1); phi_kept = S_ℓ/S_0 and
    kappa_kept = E_ℓ/E_0 (the share kept at that level, Thm 3.4, Figure 1a); speed_factor and
    energy_factor (the cascade factors S_ℓ/S_{ℓ−1}, E_ℓ/E_{ℓ−1} ≤ 1); internal_share = 1 − E_ℓ/E_0 (the
    energy moved from collective to internal by level ℓ, non-decreasing, AT-II Thm 3.6);
    additive_mismatch (the aggregate rebuilt from level-ℓ groups against the aggregate of the units,
    and the weight sum against one, Prop 3.1); and for a series Psi2 = var(X)/(Σ W_g σ_g)² with its
    identity value H + (1 − H)ρ̄, H, rho_bar and N_eff (Thm 3.2).  Returns a dict of arrays."""
    x = np.asarray(groups, dtype=float)
    labels = [np.asarray(l) for l in levels]
    N = len(labels[0]) if labels else (x.shape[1] if (x.ndim == 2 and time_series) else x.shape[0])
    if x.ndim == 1:
        ts = False
    elif time_series is None:
        ts = (x.shape[0] != N) and (x.shape[1] == N)
    else:
        ts = bool(time_series)
    w = normalise_weights(w, N)
    xv = x if ts else (x[:, None] if x.ndim == 1 else x)
    if ts:
        X_top = xv @ w                                   # (T,)
        level_data = [(w, xv)]
    else:
        X_top = w @ xv                                   # (d,)
        level_data = [(w, xv)]
    for lab in labels:
        if ts:
            _, W, Xg = group_aggregate(xv.T, w, lab)     # Xg: (G, T)
            level_data.append((W, Xg.T))
        else:
            _, W, Xg = group_aggregate(xv, w, lab)       # Xg: (G, d)
            level_data.append((W, Xg))
    S, E, ng, add_mis = [], [], [], []
    psi2, psi2_id, Hs, rhos, neffs = [], [], [], [], []
    for W, X in level_data:
        s, e = _level_stats(X, W, ts)
        S.append(s)
        E.append(e)
        ng.append(len(W))
        rebuilt = X @ W if ts else W @ X
        mis = np.linalg.norm(np.atleast_1d(rebuilt - X_top)) / max(np.linalg.norm(np.atleast_1d(X_top)), 1e-300)
        add_mis.append(float(max(mis, abs(W.sum() - 1.0))))
        if ts:
            sig = X.std(axis=0)
            if len(W) > 1 and np.all(sig > 0):
                R = np.corrcoef(X.T)
                ti = turbulence_identity(sig, W, R)
                denom = float(W @ sig)
                direct = float(np.var(X_top) / denom ** 2) if denom > 0 else np.nan
                psi2.append(direct)
                psi2_id.append(ti["Psi2_identity"])
                Hs.append(ti["H"])
                rhos.append(ti["rho_bar"])
                neffs.append(ti["N_eff"])
            else:
                a = W * sig
                psi2.append(1.0)
                psi2_id.append(1.0)
                Hs.append(herfindahl(a) if a.sum() > 0 else 1.0)
                rhos.append(np.nan)
                neffs.append(n_effective(a) if a.sum() > 0 else 1.0)
        else:
            psi2.append(np.nan); psi2_id.append(np.nan); Hs.append(np.nan); rhos.append(np.nan); neffs.append(np.nan)
    S, E = np.array(S), np.array(E)
    out = {
        "level": np.arange(len(S)), "n_groups": np.array(ng), "S": S, "E": E,
        "phi": S[-1] / S, "kappa": E[-1] / E, "phi_kept": S / S[0], "kappa_kept": E / E[0],
        "speed_factor": np.concatenate([[1.0], S[1:] / S[:-1]]),
        "energy_factor": np.concatenate([[1.0], E[1:] / E[:-1]]),
        "internal_share": 1.0 - E / E[0], "additive_mismatch": np.array(add_mis),
        "Psi2": np.array(psi2), "Psi2_identity": np.array(psi2_id), "H": np.array(Hs),
        "rho_bar": np.array(rhos), "N_eff": np.array(neffs), "time_series": ts,
    }
    if not ts:
        # the snapshot ratios through identities.speed_ratio / collective_share agree with S_L/S_ℓ, E_L/E_ℓ
        out["phi_identities"] = np.array([speed_ratio(X, W) for W, X in level_data])
        out["kappa_identities"] = np.array([collective_share(X, W) for W, X in level_data])
    return out


def two_sided_match(sim_fn, data_stats, theta0, n_iter=200, W=None, x_tol=1e-6, f_tol=1e-12):
    """Two-sided match (AT-II Definitions 6.1–6.2, simulated method of moments): θ̂ = argmin_θ
    (F̂ − F̄(θ))ᵀ W (F̂ − F̄(θ)) where F̂ are the data's fingerprint statistics, F̄(θ) = sim_fn(θ) the same
    statistics on the simulated model and W a weighting (identity by default; a vector is a diagonal,
    e.g. inverse bootstrap variances).  Nelder–Mead on scipy, at most n_iter iterations.
    Returns dict(theta, objective, success, n_eval, F_sim, F_data, message)."""
    F_hat = np.asarray(data_stats, dtype=float)
    if W is None:
        Wm = np.eye(len(F_hat))
    else:
        Wa = np.asarray(W, dtype=float)
        Wm = np.diag(Wa) if Wa.ndim == 1 else Wa

    def obj(theta):
        d = np.asarray(sim_fn(theta), dtype=float) - F_hat
        return float(d @ Wm @ d)

    res = minimize(obj, np.asarray(theta0, dtype=float), method="Nelder-Mead",
                   options={"maxiter": int(n_iter), "maxfev": 4 * int(n_iter) + 100,
                            "xatol": x_tol, "fatol": f_tol})
    return {"theta": res.x, "objective": float(res.fun), "success": bool(res.success),
            "n_eval": int(res.nfev), "F_sim": np.asarray(sim_fn(res.x), dtype=float), "F_data": F_hat,
            "message": str(res.message)}
