"""The Riemann-Siegel Z function as an aggregate of units (AT-III Sec. 9, eq. riemannsiegel).

    Z(t) = 2 Σ_{n=1}^{N} n^{-1/2} cos(θ(t) − t log n) + R(t),   N = ⌊√(t/2π)⌋,

with the Riemann-Siegel theta function θ(t) and the first remainder term
R(t) ≈ (−1)^{N−1} (t/2π)^{−1/4} Ψ(p),  Ψ(p) = cos(2π(p² − p − 1/16)) / cos(2πp),  p = √(t/2π) − N.
Vectorised in numpy; accurate to O(t^{-3/4}), which is enough to locate sign changes for t ≳ 50.
mpmath.siegelz is used only to refine a zero when asked.
"""
from __future__ import annotations
import numpy as np


def theta(t):
    """Riemann-Siegel theta, asymptotic series (good to ~1e-10 for t > 50)."""
    t = np.asarray(t, dtype=float)
    return (t / 2 * np.log(t / (2 * np.pi)) - t / 2 - np.pi / 8 + 1 / (48 * t) + 7 / (5760 * t ** 3)
            + 31 / (80640 * t ** 5))


def units(t):
    """The units of the sum at height t: the array 2 n^{-1/2} cos(θ(t) − t log n), n = 1..N."""
    t = float(t)
    N = int(np.floor(np.sqrt(t / (2 * np.pi))))
    n = np.arange(1, N + 1, dtype=float)
    return 2 * n ** -0.5 * np.cos(theta(t) - t * np.log(n))


def remainder(t):
    t = np.asarray(t, dtype=float)
    a = np.sqrt(t / (2 * np.pi))
    N = np.floor(a)
    p = a - N
    psi = np.cos(2 * np.pi * (p ** 2 - p - 1 / 16)) / np.cos(2 * np.pi * p)
    return (-1) ** (N - 1) * (t / (2 * np.pi)) ** -0.25 * psi


def Z(t):
    """Vectorised Z(t) with the first remainder term."""
    t = np.atleast_1d(np.asarray(t, dtype=float))
    out = np.empty_like(t)
    th = theta(t)
    Nmax = int(np.floor(np.sqrt(t.max() / (2 * np.pi))))
    n = np.arange(1, Nmax + 1, dtype=float)
    logn = np.log(n)
    inv_sqrt = n ** -0.5
    N = np.floor(np.sqrt(t / (2 * np.pi))).astype(int)
    # group t by N to keep the sums exact (cos terms beyond N must not be included)
    for Nk in np.unique(N):
        m = N == Nk
        if Nk == 0:
            out[m] = 0.0
            continue
        phase = th[m][:, None] - np.outer(t[m], logn[:Nk])
        out[m] = 2 * (np.cos(phase) * inv_sqrt[:Nk]).sum(axis=1)
    return out + remainder(t)


def zeros_up_to(T, t0=14.0, oversample=6, refine=True):
    """Zeros of Z on [t0, T] from sign changes on a grid with `oversample` points per mean spacing;
    each refined by bisection on Z (numpy) -- the remainder is accurate enough for t > 50."""
    spacing = 2 * np.pi / np.log(max(T, 20.0) / (2 * np.pi))
    step = spacing / oversample
    t = np.arange(t0, T, step)
    z = Z(t)
    idx = np.where(np.sign(z[:-1]) * np.sign(z[1:]) < 0)[0]
    zeros = []
    for i in idx:
        a, b = t[i], t[i + 1]
        if refine:
            fa = z[i]
            for _ in range(30):
                c = 0.5 * (a + b)
                fc = float(Z(np.array([c]))[0])
                if np.sign(fc) == np.sign(fa):
                    a, fa = c, fc
                else:
                    b = c
        zeros.append(0.5 * (a + b))
    return np.array(zeros), step


def riemann_von_mangoldt(T):
    """N(T) = (T/2π) log(T/(2πe)) + 7/8, the smooth count of zeros up to height T."""
    return T / (2 * np.pi) * np.log(T / (2 * np.pi * np.e)) + 7 / 8


def gue_wigner_cdf(s):
    """CDF of the GUE Wigner surmise p(s) = (32/π²) s² exp(−4s²/π)."""
    from scipy.special import erf
    s = np.asarray(s, dtype=float)
    return erf(2 * s / np.sqrt(np.pi)) - (4 * s / np.pi) * np.exp(-4 * s ** 2 / np.pi)


def unfolded_spacings(zeros):
    """Nearest-neighbour spacings scaled by the local density log(t/2π)/(2π)."""
    zeros = np.asarray(zeros, dtype=float)
    return np.diff(zeros) * np.log(zeros[:-1] / (2 * np.pi)) / (2 * np.pi)
