"""Exact linear lumping (AT-0, sections Q–W).

For a linear microscopic law ż = Az (section R) and an aggregation y = Cz with C of full row rank
(section T), an exact closed law ẏ = By exists iff CA = BC, iff A(ker C) ⊆ ker C (Theorem W.1);
B is then unique, y(t) = e^{Bt} C z(0) and C e^{At} = e^{Bt} C (W.2).  Sections S–V give the worked
examples: the rotation z = (sin t, cos t) whose first component does not close, the supply–demand
imbalance y = S − D that closes with B = −(α + β), and the counterexample where it does not.
Strong lumpability of a Markov chain (Kemeny–Snell) is the same condition with A = Pᵀ and C the
block indicator.
"""
from __future__ import annotations
import numpy as np
from scipy.linalg import expm, null_space

__all__ = [
    "kernel_basis", "invariant_subspace_check", "is_exactly_lumpable", "lumped_generator",
    "markov_lumpable", "information_loss", "example_rotation", "example_sine_alone",
    "example_supply_demand", "example_counterexample",
]


def kernel_basis(C, tol=None):
    """Orthonormal basis K (n × (n − k)) of ker C = {v : Cv = 0}, the state differences the
    aggregation cannot detect (section W), via the SVD."""
    C = np.atleast_2d(np.asarray(C, dtype=float))
    return null_space(C, rcond=tol)


def invariant_subspace_check(A, V, tol=1e-10):
    """Is span(V) invariant under A, i.e. A·span(V) ⊆ span(V)?  (The kernel condition of Theorem W.1
    with V a basis of ker C.)  Returns (bool, residual) with residual = ‖(I − P_V) A V‖_F / (‖A‖_F ‖V‖_F),
    P_V the orthogonal projector onto span(V); the trivial subspace is invariant."""
    A = np.asarray(A, dtype=float)
    V = np.asarray(V, dtype=float)
    V = V[:, None] if V.ndim == 1 else V
    if V.size == 0 or V.shape[1] == 0:
        return True, 0.0
    Q, _ = np.linalg.qr(V)
    AV = A @ V
    resid = AV - Q @ (Q.T @ AV)
    scale = max(np.linalg.norm(A) * np.linalg.norm(V), 1e-300)
    r = float(np.linalg.norm(resid) / scale)
    return bool(r <= tol), r


def is_exactly_lumpable(A, C, tol=1e-10):
    """Theorem W.1 (statement 3): A(ker C) ⊆ ker C.  With K a basis of ker C this is CAK = 0
    (Av ∈ ker C ⟺ CAv = 0); checked as ‖CAK‖_F ≤ tol·‖C‖_F‖A‖_F.  An injective C (k = n) closes trivially."""
    A = np.asarray(A, dtype=float)
    C = np.atleast_2d(np.asarray(C, dtype=float))
    K = kernel_basis(C)
    if K.shape[1] == 0:
        return True
    r = np.linalg.norm(C @ A @ K) / max(np.linalg.norm(C) * np.linalg.norm(A), 1e-300)
    return bool(r <= tol)


def lumped_generator(A, C):
    """B = C A C⁺: the unique B with CA = BC when the kernel condition holds (Theorem W.1; C of full
    row rank), the least-squares solution of BC = CA otherwise.  Returns (B, residual) with
    residual = ‖CA − BC‖_F, zero exactly when the aggregate closes (section T)."""
    A = np.asarray(A, dtype=float)
    C = np.atleast_2d(np.asarray(C, dtype=float))
    B = C @ A @ np.linalg.pinv(C)
    return B, float(np.linalg.norm(C @ A - B @ C))


def markov_lumpable(P, partition, tol=1e-10):
    """Strong lumpability of a Markov chain (Kemeny–Snell): for a transition matrix P (rows sum to one)
    and a partition (block label per state), the block-sums Σ_{j∈J} P[i, j] must be equal for all states
    i of the same block I; the lumped chain is then P̂[I, J] = those sums.  This is Theorem W.1 with
    A = Pᵀ and C the block indicator (C Pᵀ = P̂ᵀ C).  Returns (bool, P_hat, max_deviation)."""
    P = np.asarray(P, dtype=float)
    labels = np.asarray(partition)
    blocks = np.unique(labels)
    idx = np.searchsorted(blocks, labels)
    V = np.zeros((P.shape[0], len(blocks)))
    V[np.arange(P.shape[0]), idx] = 1.0
    S = P @ V                                    # block-sums per state
    P_hat = np.array([S[idx == b].mean(axis=0) for b in range(len(blocks))])
    dev = float(np.max(np.abs(S - P_hat[idx])))
    return bool(dev <= tol), P_hat, dev


def information_loss(A, C, x0, T, n_t=200):
    """Section W.2 and the counterexample of section V: the exact aggregate y(t) = C e^{At} z(0) against
    the lumped prediction ŷ(t) = e^{Bt} C z(0) with B = lumped_generator(A, C).  They coincide
    (C e^{At} = e^{Bt} C) iff the kernel condition holds; otherwise the discarded directions feed back
    into the retained rate and the two drift apart.  Returns dict(t, y_exact, y_lumped, max_abs,
    max_rel, final_abs, lumpable, residual)."""
    A = np.asarray(A, dtype=float)
    C = np.atleast_2d(np.asarray(C, dtype=float))
    x0 = np.asarray(x0, dtype=float)
    B, resid = lumped_generator(A, C)
    t = np.linspace(0.0, float(T), int(n_t))
    y_exact = np.array([C @ expm(A * tk) @ x0 for tk in t])
    y_lump = np.array([expm(B * tk) @ (C @ x0) for tk in t])
    diff = np.abs(y_exact - y_lump)
    scale = max(float(np.max(np.abs(y_exact))), 1e-300)
    return {"t": t, "y_exact": y_exact, "y_lumped": y_lump, "max_abs": float(diff.max()),
            "max_rel": float(diff.max() / scale), "final_abs": float(diff[-1].max()),
            "lumpable": is_exactly_lumpable(A, C), "residual": resid}


# ----------------------------------------------------------------------------------------------
# worked examples of sections S–V
# ----------------------------------------------------------------------------------------------
def example_rotation(omega=1.0, n_samples=256):
    """Sections S and S.1.  z(t) = (sin ωt, cos ωt) obeys ż = ωJz with J = [[0, 1], [−1, 0]] (the two
    components are closed under differentiation).  "Reconstruction from one scalar", z = v h(t), is
    impossible: z(0) = (0, 1) and z(π/2ω) = (1, 0) are independent (det ≠ 0, trajectory rank 2); on the
    restricted set z = (1, 2)e^{−t} one scalar does suffice (rank 1).  A real rotation has no real
    invariant line (eigenvalues ±iω), so no single real coordinate closes: for y = x₁,
    ‖CA − BC‖ = ω.  Returns a dict of these numbers."""
    omega = float(omega)
    A = omega * np.array([[0.0, 1.0], [-1.0, 0.0]])
    t = np.linspace(0.0, 2 * np.pi / omega, int(n_samples), endpoint=False)
    Z = np.column_stack([np.sin(omega * t), np.cos(omega * t)])
    Zdot = np.column_stack([omega * np.cos(omega * t), -omega * np.sin(omega * t)])
    dyn_resid = float(np.max(np.abs(Zdot - Z @ A.T)))
    z0 = np.array([0.0, 1.0])
    zq = np.array([np.sin(np.pi / 2), np.cos(np.pi / 2)])
    det = float(np.linalg.det(np.column_stack([z0, zq])))
    rank_traj = int(np.linalg.matrix_rank(Z))
    Zr = np.outer(np.exp(-t), [1.0, 2.0])
    rank_restricted = int(np.linalg.matrix_rank(Zr))
    eig = np.linalg.eigvals(A)
    n_real_lines = int(np.sum(np.abs(eig.imag) < 1e-12))
    C = np.array([[1.0, 0.0]])
    B, resid = lumped_generator(A, C)
    return {"omega": omega, "dynamics_residual": dyn_resid, "det_z0_zquarter": det,
            "trajectory_rank": rank_traj, "one_scalar_reconstruction": int(rank_traj == 1),
            "restricted_rank": rank_restricted, "n_real_invariant_lines": n_real_lines,
            "lumpable_x1": int(is_exactly_lumpable(A, C)), "residual_x1": resid, "B_x1": float(B[0, 0]),
            "energy_drift": float(np.max(np.abs(np.sum(Z ** 2, axis=1) - 1.0)))}


def example_sine_alone(n_samples=256):
    """Section S.2, "keeping sine alone": y = sin t, C = [1 0].  ẏ = cos t is not a function of y:
    y(0) = y(π) = 0 while ẏ(0) = 1 and ẏ(π) = −1, so no first-order autonomous ẏ = G(y) exists.  The
    matrix criterion: CA_rot = [0 1] against BC = [b 0] — no b; the least-squares B is 0 with residual 1.
    ÿ = −y does hold but needs two initial data, so nothing was reduced.  Returns a dict."""
    A = np.array([[0.0, 1.0], [-1.0, 0.0]])
    C = np.array([[1.0, 0.0]])
    B, resid = lumped_generator(A, C)
    t = np.linspace(0.0, 2 * np.pi, int(n_samples), endpoint=False)
    y, ydot, yddot = np.sin(t), np.cos(t), -np.sin(t)
    return {"y_at_0": float(np.sin(0.0)), "y_at_pi": float(np.sin(np.pi)),
            "ydot_at_0": float(np.cos(0.0)), "ydot_at_pi": float(np.cos(np.pi)),
            "CA": (C @ A)[0].tolist(), "B_lsq": float(B[0, 0]), "residual": resid,
            "lumpable": int(is_exactly_lumpable(A, C)),
            "second_order_residual": float(np.max(np.abs(yddot + y))),
            "first_order_ambiguity": float(abs(ydot[0] - np.cos(np.pi))),   # same y, derivatives 1 and −1
            "state_dimension_needed": 2}


def example_supply_demand(alpha=2.0, beta=1.0, t_eval=1.0):
    """Sections U–U.2.  Ṡ = −αS + βD, Ḋ = βS − αD (α = 2, β = 1 in the text).  The imbalance y = S − D
    closes exactly: ẏ = −(α + β)y, B = −3 for the numerical example, CA_sym = [−3 3] = BC.  The discarded
    total q = S + D closes separately with −(α − β).  The states (5, 3) and (50, 48) share y(0) = 2 and the
    same future y(t) = 2e^{−3t} although their totals differ.  Returns a dict."""
    A = np.array([[-alpha, beta], [beta, -alpha]], dtype=float)
    C = np.array([[1.0, -1.0]])
    Cq = np.array([[1.0, 1.0]])
    B, resid = lumped_generator(A, C)
    Bq, resid_q = lumped_generator(A, Cq)
    z1, z2 = np.array([5.0, 3.0]), np.array([50.0, 48.0])
    E = expm(A * t_eval)
    y1, y2 = (C @ E @ z1).item(), (C @ E @ z2).item()
    return {"alpha": float(alpha), "beta": float(beta), "B": float(B[0, 0]), "B_expected": -(alpha + beta),
            "residual": resid, "lumpable": int(is_exactly_lumpable(A, C)),
            "Bq": float(Bq[0, 0]), "Bq_expected": -(alpha - beta), "residual_q": resid_q,
            "y0_state1": (C @ z1).item(), "y0_state2": (C @ z2).item(),
            "y_state1": y1, "y_state2": y2, "y_difference": abs(y1 - y2),
            "y_closed_form": float(2.0 * np.exp(-(alpha + beta) * t_eval)),
            "q0_state1": (Cq @ z1).item(), "q0_state2": (Cq @ z2).item()}


def example_counterexample(t_eval=1.0):
    """Section V, "imbalance need not close": Ṡ = −S, Ḋ = −2D with the same y = S − D.  Now
    ẏ = −S + 2D = (q − 3y)/2 depends on the discarded total; the two states with y = 2 have ẏ = 1 and 46.
    CA_asym = [−1 2] against BC = [b −b]: no b; the least-squares B is −3/2 with residual √½.
    Returns a dict including the information-loss drift of the lumped prediction."""
    A = np.array([[-1.0, 0.0], [0.0, -2.0]])
    C = np.array([[1.0, -1.0]])
    B, resid = lumped_generator(A, C)
    z1, z2 = np.array([5.0, 3.0]), np.array([50.0, 48.0])
    loss1 = information_loss(A, C, z1, t_eval)
    loss2 = information_loss(A, C, z2, t_eval)
    return {"ydot_state1": (C @ A @ z1).item(), "ydot_state2": (C @ A @ z2).item(),
            "CA": (C @ A)[0].tolist(), "B_lsq": float(B[0, 0]), "residual": resid,
            "residual_expected": float(np.sqrt(0.5)), "lumpable": int(is_exactly_lumpable(A, C)),
            "drift_state1": loss1["max_abs"], "drift_state2": loss2["max_abs"]}
