"""Order flow, impact and memory (AT-II, section 5: the dynamics of the parts).

The order-flow imbalance of Cont, Kukanov and Stoikov (section 5.2, Known result 5.2: ΔP ≈ β·OFI),
the microprice as the book's collective position (5.3), the square-root impact law I(Q) ≈ Y σ_d √(Q/V_d)
(Known result 5.6), the propagator G(ℓ) and the long memory of order signs C(ℓ) ∼ ℓ^{−γ}
(Known result 5.7), Hurst exponents (Table 1, Remark 5.5) and the order book read as a potential
landscape whose Fokker–Planck drift is −U′ (5.3–5.4, Known result 5.4).
"""
from __future__ import annotations
import numpy as np

__all__ = [
    "ofi", "ofi_windows", "microprice", "ofi_regression", "sqrt_impact", "fit_sqrt_impact",
    "propagator_fit", "sign_autocorrelation", "hurst_exponent", "potential_from_book",
]


def ofi(bid_px, bid_sz, ask_px, ask_sz):
    """Per-update order-flow imbalance (AT-II 5.2; Cont–Kukanov–Stoikov 2014):
    e_n = 1{Pb_n ≥ Pb_{n−1}} qb_n − 1{Pb_n ≤ Pb_{n−1}} qb_{n−1} − 1{Pa_n ≤ Pa_{n−1}} qa_n + 1{Pa_n ≥ Pa_{n−1}} qa_{n−1}
    from level-1 updates.  Returns e of length N − 1; the OFI of an interval is its sum, additive over
    time and therefore an exact aggregate."""
    bp, bq = np.asarray(bid_px, dtype=float), np.asarray(bid_sz, dtype=float)
    ap, aq = np.asarray(ask_px, dtype=float), np.asarray(ask_sz, dtype=float)
    return ((bp[1:] >= bp[:-1]) * bq[1:] - (bp[1:] <= bp[:-1]) * bq[:-1]
            - (ap[1:] <= ap[:-1]) * aq[1:] + (ap[1:] >= ap[:-1]) * aq[:-1])


def ofi_windows(e, window):
    """OFI per interval: sums of e over consecutive non-overlapping windows of `window` updates."""
    e = np.asarray(e, dtype=float)
    n = len(e) // int(window)
    return e[:n * int(window)].reshape(n, int(window)).sum(axis=1)


def microprice(bid, ask, bid_sz, ask_sz):
    """Microprice (Stoikov 2018; AT-II 5.3): the bid and ask weighted by the opposite queue sizes,
    (bid·qa + ask·qb)/(qb + qa) — the book's collective position, nearer the side with the larger queue."""
    bid, ask = np.asarray(bid, dtype=float), np.asarray(ask, dtype=float)
    qb, qa = np.asarray(bid_sz, dtype=float), np.asarray(ask_sz, dtype=float)
    return (bid * qa + ask * qb) / (qb + qa)


def ofi_regression(dP, ofi_values):
    """The order-flow imbalance law ΔP = α + β OFI + ε by OLS (Known result 5.2; β ∝ 1/depth).
    Returns dict(beta, alpha, r2, t_stat, se, n)."""
    y = np.asarray(dP, dtype=float)
    x = np.asarray(ofi_values, dtype=float)
    n = len(y)
    X = np.column_stack([np.ones(n), x])
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ coef
    ssr = float(resid @ resid)
    sst = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - ssr / sst if sst > 0 else np.nan
    sxx = float(np.sum((x - x.mean()) ** 2))
    s2 = ssr / max(n - 2, 1)
    se = np.sqrt(s2 / sxx) if sxx > 0 else np.nan
    return {"beta": float(coef[1]), "alpha": float(coef[0]), "r2": r2,
            "t_stat": float(coef[1] / se) if se and se > 0 else np.nan, "se": float(se), "n": n}


def sqrt_impact(Q, sigma_d, V_d, Y=1.0):
    """Square-root impact I(Q) = Y σ_d √(Q/V_d) of a metaorder of size Q against daily volatility σ_d and
    daily volume V_d, Y of order one (Known result 5.6; Tóth et al. 2011)."""
    return Y * sigma_d * np.sqrt(np.asarray(Q, dtype=float) / V_d)


def fit_sqrt_impact(Q, I, sigma_d=1.0, V_d=1.0):
    """Fit the impact curve in log form, log I = log(Y σ_d) + δ log(Q/V_d): δ ≈ 1/2 for the square-root
    law (δ = 1 would be linear impact; AT-III section 5 uses the exponent as the concavity test).
    Returns dict(Y, delta, r2, n) using the pairs with Q, I > 0."""
    Q = np.asarray(Q, dtype=float)
    I = np.asarray(I, dtype=float)
    ok = (Q > 0) & (I > 0)
    x = np.log(Q[ok] / V_d)
    y = np.log(I[ok])
    X = np.column_stack([np.ones(ok.sum()), x])
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    fit = X @ coef
    sst = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - float(np.sum((y - fit) ** 2)) / sst if sst > 0 else np.nan
    return {"Y": float(np.exp(coef[0]) / sigma_d), "delta": float(coef[1]), "r2": r2, "n": int(ok.sum())}


def _powerlaw_fit(lags, values):
    """Least squares of log values on log lags over the positive values: (amplitude, exponent, r2)
    for values ≈ c0 · lag^{−exponent}."""
    lags = np.asarray(lags, dtype=float)
    values = np.asarray(values, dtype=float)
    ok = (values > 0) & (lags > 0)
    if ok.sum() < 2:
        return np.nan, np.nan, np.nan
    x, y = np.log(lags[ok]), np.log(values[ok])
    X = np.column_stack([np.ones(ok.sum()), x])
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    fit = X @ coef
    sst = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - float(np.sum((y - fit) ** 2)) / sst if sst > 0 else np.nan
    return float(np.exp(coef[0])), float(-coef[1]), r2


def propagator_fit(signs, dP, max_lag):
    """Propagator model (Known result 5.7; Bouchaud et al. 2004): regress the price change ΔP_t on the
    lagged trade signs ε_{t−ℓ}, ℓ = 0..L, by least squares.  The kernel g(ℓ) is the marginal effect of
    a sign ℓ steps back, and the propagator G(ℓ) = Σ_{j<ℓ} g(j) is the mean price move ℓ steps after a
    unit-sign trade (price level p_t = Σ_{t′<t} G(t − t′) ε_{t′} + noise).  A power law G(ℓ) ≈ G₀ ℓ^{−β}
    is fitted on ℓ ≥ 1 (β ≈ (1 − γ)/2 keeps prices diffusive).
    Returns dict(lags, g, lags_G, G, beta, G0, r2_powerlaw, r2_regression)."""
    s = np.asarray(signs, dtype=float)
    y = np.asarray(dP, dtype=float)
    L = int(max_lag)
    n = len(y)
    rows = np.arange(L, n)
    X = np.column_stack([s[rows - lag] for lag in range(L + 1)])
    yy = y[rows]
    g, *_ = np.linalg.lstsq(X, yy, rcond=None)
    fit = X @ g
    sst = float(np.sum((yy - yy.mean()) ** 2))
    r2 = 1.0 - float(np.sum((yy - fit) ** 2)) / sst if sst > 0 else np.nan
    G = np.cumsum(g)
    lags_G = np.arange(1, L + 2)
    G0, beta, r2p = _powerlaw_fit(lags_G, G)
    return {"lags": np.arange(L + 1), "g": g, "lags_G": lags_G, "G": G, "beta": beta, "G0": G0,
            "r2_powerlaw": r2p, "r2_regression": r2}


def sign_autocorrelation(signs, max_lag):
    """Autocorrelation C(ℓ) of the order signs for ℓ = 1..L with the power-law fit C(ℓ) ≈ c₀ ℓ^{−γ}
    (Known result 5.7: γ ≈ 0.5, Lillo and Farmer 2004).  Returns dict(lags, acf, gamma, c0, r2)."""
    s = np.asarray(signs, dtype=float)
    s = s - s.mean()
    var = float(s @ s) / len(s)
    L = int(max_lag)
    acf = np.array([float(s[:-lag] @ s[lag:]) / (len(s) - lag) / var if var > 0 else np.nan
                    for lag in range(1, L + 1)])
    lags = np.arange(1, L + 1)
    c0, gamma, r2 = _powerlaw_fit(lags, acf)
    return {"lags": lags, "acf": acf, "gamma": gamma, "c0": c0, "r2": r2}


def hurst_exponent(x, min_block=8, n_scales=12):
    """Hurst exponent of an increment series (AT-II Table 1: H ≈ 0.85–0.9 for trade counts and volume;
    Remark 5.5: clustered arrivals worsen the counting precision as Δ^{2H−2}).  Two estimators:
    (a) rescaled range, ⟨R/S⟩(n) ∼ n^H over block lengths n; (b) aggregated variance, Var of block means
    of length m ∼ m^{2H−2}.  Returns dict(H_rs, H_av, scales, rs, agg_var)."""
    x = np.asarray(x, dtype=float)
    N = len(x)
    scales = np.unique(np.geomspace(min_block, max(N // 4, min_block + 1), int(n_scales)).astype(int))
    rs, av = [], []
    for n in scales:
        k = N // n
        blocks = x[:k * n].reshape(k, n)
        Y = np.cumsum(blocks - blocks.mean(axis=1, keepdims=True), axis=1)
        R = Y.max(axis=1) - Y.min(axis=1)
        S = blocks.std(axis=1)
        good = S > 0
        rs.append(float(np.mean(R[good] / S[good])) if good.any() else np.nan)
        av.append(float(np.var(blocks.mean(axis=1), ddof=1)) if k > 1 else np.nan)
    rs, av = np.array(rs), np.array(av)
    ok = np.isfinite(rs) & (rs > 0)
    H_rs = float(np.polyfit(np.log(scales[ok]), np.log(rs[ok]), 1)[0]) if ok.sum() >= 2 else np.nan
    ok2 = np.isfinite(av) & (av > 0)
    H_av = float(1.0 + 0.5 * np.polyfit(np.log(scales[ok2]), np.log(av[ok2]), 1)[0]) if ok2.sum() >= 2 else np.nan
    return {"H_rs": H_rs, "H_av": H_av, "scales": scales, "rs": rs, "agg_var": av}


def potential_from_book(depth_profile, x=None, D=1.0, dx=1.0, floor=1e-12):
    """The order book as a potential landscape (AT-II 5.3–5.4).  The depth profile ρ(x) across price
    levels (bid depth below and ask depth above the mid), normalised to a density, is read as the
    stationary law ρ_∞ ∝ e^{−U/D} of the overdamped motion ∂t ρ = ∂x(U′ρ) + D ∂x²ρ (eq. 5.2).  Then
    U = −D log ρ (up to a constant), the Fokker–Planck drift is −U′ (a well: mean reversion; a tilt:
    a trend), and the imaginary-time Schrödinger potential is V_s = (U′)²/(4D) − U″/2 with ground
    state ψ₀ = e^{−U/(2D)} of eigenvalue 0 (Known result 5.4).  Returns dict(x, rho, U, drift, V_s,
    psi0, well_centre, ground_state_residual)."""
    rho = np.asarray(depth_profile, dtype=float)
    x = np.arange(len(rho), dtype=float) * dx if x is None else np.asarray(x, dtype=float)
    rho = np.maximum(rho, 0.0)
    rho = rho / np.trapezoid(rho, x)
    U = -D * np.log(np.maximum(rho, floor))
    dU = np.gradient(U, x)
    d2U = np.gradient(dU, x)
    Vs = dU ** 2 / (4 * D) - d2U / 2
    psi0 = np.exp(-U / (2 * D))
    H_psi = -D * np.gradient(np.gradient(psi0, x), x) + Vs * psi0
    return {"x": x, "rho": rho, "U": U, "drift": -dU, "V_s": Vs, "psi0": psi0,
            "well_centre": float(x[np.argmin(U)]),
            "ground_state_residual": float(np.max(np.abs(H_psi)) / max(np.max(np.abs(psi0)), 1e-300))}
