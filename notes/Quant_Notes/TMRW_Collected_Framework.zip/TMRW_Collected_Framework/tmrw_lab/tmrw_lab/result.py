"""The Result object every experiment, hypothesis test and toy returns.

    res = Result(name="experiments.society", title="P1 on societies")
    res.add("society.covid_us.kappa", 0.118, expected=0.116, unit="", source="AT-III Table 1", tol=0.1)
    res.note("NYT county file downloaded (real)")
    res.figures.append(str(path))
    res.data_origin = "real"          # real | synthetic | simulation | analytic
    res.verdict = "supported"         # hypothesis modules only: supported | refuted | inconclusive

A Number's verdict:
    "measured"  no expectation was quoted;
    "match"     inside [expected - tol, expected_hi + tol] (range) or within the relative tolerance
                tol (default 0.15) of expected (point);
    "differs"   outside;
    "missing"   the value is None or not finite.
"""
from __future__ import annotations
import json
import math
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

DEFAULT_TOL = 0.15


def _finite(x) -> bool:
    try:
        return x is not None and math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


@dataclass
class Number:
    key: str
    value: Optional[float]
    expected: Optional[float] = None
    expected_hi: Optional[float] = None
    unit: str = ""
    source: str = ""
    tol: Optional[float] = None        # relative tolerance for a point expectation (default 0.15)
    abs_tol: Optional[float] = None    # absolute tolerance instead, when given

    def verdict(self) -> str:
        if not _finite(self.value):
            return "missing"
        if self.expected is None:
            return "measured"
        v = float(self.value)
        if self.expected_hi is not None:           # a range
            lo, hi = float(self.expected), float(self.expected_hi)
            slack = self.abs_tol if self.abs_tol is not None else (self.tol or 0.0) * max(abs(lo), abs(hi), 1e-12)
            return "match" if (lo - slack) <= v <= (hi + slack) else "differs"
        e = float(self.expected)
        if self.abs_tol is not None:
            return "match" if abs(v - e) <= self.abs_tol else "differs"
        tol = DEFAULT_TOL if self.tol is None else self.tol
        return "match" if abs(v - e) <= tol * max(abs(e), 1e-12) else "differs"

    def to_dict(self) -> dict:
        d = asdict(self)
        for k in ("value", "expected", "expected_hi"):
            if d[k] is not None:
                d[k] = float(d[k]) if _finite(d[k]) else None
        d["verdict"] = self.verdict()
        return d


@dataclass
class Result:
    name: str
    title: str
    status: str = "ok"                 # ok | skipped | failed
    data_origin: str = "analytic"      # real | synthetic | simulation | analytic
    verdict: Optional[str] = None      # supported | refuted | inconclusive (hypotheses)
    notes: list = field(default_factory=list)
    numbers: list = field(default_factory=list)
    figures: list = field(default_factory=list)
    extra: dict = field(default_factory=dict)

    def note(self, msg: str) -> None:
        self.notes.append(str(msg))

    def add(self, key: str, value, expected=None, expected_hi=None, unit: str = "", source: str = "",
            tol: Optional[float] = None, abs_tol: Optional[float] = None) -> Number:
        try:
            v = None if value is None else float(value)
        except (TypeError, ValueError):
            v = None
        n = Number(key=key, value=v, expected=None if expected is None else float(expected),
                   expected_hi=None if expected_hi is None else float(expected_hi), unit=unit,
                   source=source, tol=tol, abs_tol=abs_tol)
        self.numbers.append(n)
        return n

    def get(self, key: str) -> Optional[Number]:
        for n in self.numbers:
            if n.key == key:
                return n
        return None

    def n_match(self) -> tuple[int, int]:
        """(matches, numbers with an expectation)."""
        judged = [n for n in self.numbers if n.expected is not None]
        return sum(n.verdict() == "match" for n in judged), len(judged)

    def to_dict(self) -> dict:
        return {"name": self.name, "title": self.title, "status": self.status,
                "data_origin": self.data_origin, "verdict": self.verdict, "notes": list(self.notes),
                "numbers": [n.to_dict() for n in self.numbers], "figures": [str(f) for f in self.figures],
                "extra": dict(self.extra)}

    def save(self, path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, default=str))

    @classmethod
    def load(cls, path) -> "Result":
        d = json.loads(Path(path).read_text())
        r = cls(name=d["name"], title=d["title"], status=d.get("status", "ok"),
                data_origin=d.get("data_origin", "analytic"), verdict=d.get("verdict"),
                notes=d.get("notes", []), figures=d.get("figures", []), extra=d.get("extra", {}))
        for n in d.get("numbers", []):
            r.add(n["key"], n.get("value"), n.get("expected"), n.get("expected_hi"), n.get("unit", ""),
                  n.get("source", ""), n.get("tol"), n.get("abs_tol"))
        return r
