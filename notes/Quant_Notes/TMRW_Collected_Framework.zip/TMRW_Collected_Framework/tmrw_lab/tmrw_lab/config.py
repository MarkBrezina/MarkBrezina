"""Run configuration of the test bench: preset sizes, seed, offline flag, directories.

The preset is chosen by the environment variable TMRW_PRESET (quick | standard | full) or by
run_all.py --preset.  AGG_OFFLINE=1 (or --offline) forbids every network access: loaders then
return the synthetic generators with planted answers.  TMRW_SEED fixes the random seed.
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Every size an experiment may need.  Modules take sizes from cfg.sizes[key] and must not add keys
# without asking; derive other sizes from these.  quick: seconds per module; standard: < 2 min per
# module; full: the sizes quoted in the compendium (hours, needs the real data hosts).
PRESETS = {
    "quick": dict(
        mc_paths=200, n_units=200, n_steps=2_000, n_agents=100, n_events=50, n_particles=400,
        n_nuclei=300, n_hadrons=15, n_atlas_events=832, n_stars=300, n_clusters=20, n_galaxies=400,
        n_bars=3_000, n_assets=30, n_coins=10, n_book_events=60_000, n_ticks=3_000, n_sessions=4,
        grid_points=200, n_boot=100, horizon=60, n_trials=20, n_mfg_iter=50, n_blocks=20,
        zeta_height=2_000.0, zeta_n_zeros=300, n_levels=3, n_venues=5, n_products=3,
        n_children=100, n_bins=6, n_dimuons=5_000,
    ),
    "standard": dict(
        mc_paths=2_000, n_units=2_000, n_steps=20_000, n_agents=1_000, n_events=200, n_particles=2_000,
        n_nuclei=3_000, n_hadrons=15, n_atlas_events=832, n_stars=3_000, n_clusters=100, n_galaxies=1_700,
        n_bars=30_000, n_assets=100, n_coins=30, n_book_events=100_000, n_ticks=30_000, n_sessions=20,
        grid_points=800, n_boot=500, horizon=300, n_trials=100, n_mfg_iter=200, n_blocks=100,
        zeta_height=20_000.0, zeta_n_zeros=3_000, n_levels=4, n_venues=10, n_products=5,
        n_children=100, n_bins=8, n_dimuons=100_000,
    ),
    "full": dict(
        mc_paths=20_000, n_units=20_000, n_steps=200_000, n_agents=10_000, n_events=1_000, n_particles=10_000,
        n_nuclei=3_000, n_hadrons=15, n_atlas_events=832, n_stars=100_000, n_clusters=1_000, n_galaxies=1_701,
        n_bars=1_000_000, n_assets=500, n_coins=100, n_book_events=5_000_000, n_ticks=300_000, n_sessions=100,
        grid_points=2_000, n_boot=2_000, horizon=1_000, n_trials=500, n_mfg_iter=1_000, n_blocks=1_000,
        zeta_height=1_000_000.0, zeta_n_zeros=1_747_146, n_levels=5, n_venues=20, n_products=10,
        n_children=100, n_bins=10, n_dimuons=2_000_000,
    ),
}


@dataclass
class Config:
    preset: str = field(default_factory=lambda: os.environ.get("TMRW_PRESET", "standard"))
    seed: int = field(default_factory=lambda: int(os.environ.get("TMRW_SEED", "20261106")))
    offline: bool = field(default_factory=lambda: os.environ.get("AGG_OFFLINE", "0") not in ("", "0", "false", "False"))
    results_dir: Path = field(default_factory=lambda: Path(os.environ.get("TMRW_RESULTS", ROOT / "results")))
    cache_dir: Path = field(default_factory=lambda: Path(os.environ.get("TMRW_CACHE", ROOT / "cache")))
    timeout: float = field(default_factory=lambda: float(os.environ.get("TMRW_TIMEOUT", "8")))
    sizes: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.preset not in PRESETS:
            raise ValueError(f"unknown preset {self.preset!r}; choose from {list(PRESETS)}")
        self.sizes = dict(PRESETS[self.preset])
        self.results_dir = Path(self.results_dir)
        self.cache_dir = Path(self.cache_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def size(self, key: str, default=None):
        """Size by key, with a default for keys a preset does not define."""
        return self.sizes.get(key, default)


# The configuration of the current run; run_all.py replaces it.
CONFIG = None


def get_config() -> Config:
    global CONFIG
    if CONFIG is None:
        CONFIG = Config()
    return CONFIG
