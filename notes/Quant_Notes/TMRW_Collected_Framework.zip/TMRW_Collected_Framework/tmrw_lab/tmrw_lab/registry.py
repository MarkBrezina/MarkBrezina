"""What run_all.py runs, in order.

EXPERIMENTS: (dotted module, group).  Groups are the sections of the compendium's test-bench appendix:
    exact        the exact layer (identities checked to rounding error)
    hindsight    the hindsight tests of AT-III, domain by domain
    refuted      the refuted special case (the Bitcoin study restored inside the general picture)
    conjectures  toy models for Conjectures 1-5
    practice     the working-notes simulations (market making, Prosperity, blueprints)
HYPOTHESES: (dotted module, title).  Each sets Result.verdict to supported / refuted / inconclusive.
"""

EXPERIMENTS = [
    ("tmrw_lab.experiments.exact_layer", "exact"),
    ("tmrw_lab.experiments.society", "hindsight"),
    ("tmrw_lab.experiments.gas_beam", "hindsight"),
    ("tmrw_lab.experiments.nuclei_hadrons", "hindsight"),
    ("tmrw_lab.experiments.expansion", "hindsight"),
    ("tmrw_lab.experiments.zeta", "hindsight"),
    ("tmrw_lab.experiments.markets", "hindsight"),
    ("tmrw_lab.experiments.order_book", "hindsight"),
    ("tmrw_lab.experiments.bitcoin_restoration", "refuted"),
    ("tmrw_lab.experiments.conjecture_toys", "conjectures"),
    ("tmrw_lab.experiments.market_making", "practice"),
    ("tmrw_lab.experiments.prosperity", "practice"),
    ("tmrw_lab.experiments.blueprints", "practice"),
]

HYPOTHESES = [
    ("tmrw_lab.hypotheses.h01_mean_not_lowered",
     "H1  Aggregation lowers the mean (AT-0 Hyp. 9.1 as stated) -- the mean is preserved with fixed weights"),
    ("tmrw_lab.hypotheses.h02_no_universal_factor",
     "H2  There is a universal speed factor such as one half (P1 as first stated) -- the factor is a domain parameter"),
    ("tmrw_lab.hypotheses.h03_epps_aggregation",
     "H3  The Epps effect is aggregation: kappa(Delta) = kappa_inf Delta/(Delta+tau) with tau of a few seconds (AT-II Hyp. 4.3)"),
    ("tmrw_lab.hypotheses.h04_sqrt_impact",
     "H4  Impact is concave in size, I(Q) = Y sigma_d sqrt(Q/V_d) (AT-II Hyp. 5.8, Known 5.6)"),
    ("tmrw_lab.hypotheses.h05_ofi_law",
     "H5  Price changes are linear in order-flow imbalance, Delta P = beta OFI + noise, at short horizons (AT-II Known 5.2)"),
    ("tmrw_lab.hypotheses.h06_mixture_squeezing",
     "H6  Aggregate responses fit the impact-weighted mixture law and the squeezed share rises with bin length (P2)"),
    ("tmrw_lab.hypotheses.h07_bound_free_composites",
     "H7  Bound composites with 1/r binding are lighter than their parts; free composites are heavier (P3, AT-III Hyp. 6.1)"),
    ("tmrw_lab.hypotheses.h08_one_expansion_rate",
     "H8  Expansion is one rate at all distances after the linear-field split (AT-III Sec. 7)"),
    ("tmrw_lab.hypotheses.h09_zeta_aggregate",
     "H9  Zeros of Z(t) are where the Riemann-Siegel units cancel; spacings follow GUE (AT-III Sec. 9)"),
    ("tmrw_lab.hypotheses.h10_central_pricing",
     "H10 Central pricing: P_{T+1} = alpha I + (1-alpha) H + eps with alpha significant and H >= 5 (Conjecture 2)"),
    ("tmrw_lab.hypotheses.h11_stealth_schedule",
     "H11 Under a concave cost g(x) = c sqrt(x) the stealth-optimal schedule spreads an order across venues and time (Conjecture 3)"),
    ("tmrw_lab.hypotheses.h12_inventory_skew",
     "H12 A linear inventory skew keeps inventory inside the limit 99% of the session and taking cuts PnL (NB-01)"),
]
