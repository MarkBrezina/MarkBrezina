"""Conjecture 4 toy: a discrete-state hybrid mean-field game whose best-response iteration converges.

A finite instance of the hybrid state space X = M × S of C4 (compendium ch. C4, assumption 1:
flows plus reset maps; NB-08's discounted single-agent form J = E Σ γ^t (R − L)): K = 2 modes
("calm", "stressed") × M grid states x ∈ [−1, 1] (an exposure level).  Actions a ∈ {−m, 0, +m} move
the exposure one step of m cells (a random step with probability p_noise); a *guard* is crossed when
the calm mode reaches x ≥ x_g or the stressed mode reaches x ≤ −x_g, and the *reset map* flips the
mode keeping x: (k, x) ↦ (1 − k, x).  The reward is the mode's income 1 − ((x − x*_k)/0.5)² scaled by
the mode (the stressed mode pays less, so agents walk towards its guard to get back), minus an
action cost, minus a crowding term κ·ρ_k(x) in the mean field ρ (the density of all agents at the
same point: a monotone, Lasry–Lions type coupling).  Agents use the logit (soft-max) policy on the
soft Q-values at temperature τ.

The mean-field equilibrium is the fixed point μ = μ(softBR(μ)) of the damped best-response map
μ ← (1 − η) μ + η μ(softBR(μ)), with μ(π) the stationary distribution of the chain under π.
Exploitability is the entropy-regularised one, E_{x∼μ^π}[V*(x; μ^π) − V^π(x; μ^π)] ≥ 0, which is
zero exactly at the equilibrium (the HJB and Fokker–Planck halves agree).  simulate() returns the
final exploitability, the iterations to converge, the fixed-point residual and the equilibrium densities.
"""
from __future__ import annotations
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

GAMMA = 0.9          # discount
TAU = 0.5            # logit temperature
P_NOISE = 0.5        # probability of a random step instead of the chosen one
X_STAR = (0.6, -0.6) # income peaks of the two modes
INCOME = (1.0, 0.6)  # income scale of the two modes
X_GUARD = 0.85       # guard location (|x| ≥ x_g triggers the reset map)
KAPPA = 0.5          # crowding strength
CROWD_WIDTH = 0.2    # half-width of the neighbourhood over which agents feel the crowd
A_COST = 0.02        # cost per unit action
ETA = 0.5            # damping of the best-response iteration
TOL_FP = 1e-9        # fixed-point tolerance on ||μ(π) − μ||₁


def describe() -> str:
    return ("C4 hybrid MFG: 2 modes × M grid states with logit policies on soft Q-values, a crowding "
            "mean-field reward and a guard-triggered reset map between modes; damped best-response "
            "iteration to the mean-field equilibrium; entropy-regularised exploitability, iterations "
            "to converge and the fixed-point residual (expected 0).")


def _build(m_states):
    """Grid, next-state table nxt[k, x, a, j] with probabilities pr[j], guard/reset embedded."""
    xg = np.linspace(-1.0, 1.0, m_states)
    step = max(1, m_states // 50)
    acts = np.array([-step, 0, step])
    K = 2
    idx = np.arange(m_states)
    nxt = np.empty((K, m_states, 3, 3), dtype=np.int64)       # (mode, state, action, outcome)
    pr = np.array([1 - P_NOISE, P_NOISE / 2, P_NOISE / 2])
    for k in range(K):
        for a_i, a in enumerate(acts):
            for j, mv in enumerate([a, -step, step]):
                x_new = np.clip(idx + mv, 0, m_states - 1)
                k_new = np.full(m_states, k)
                guard = (xg[x_new] >= X_GUARD) if k == 0 else (xg[x_new] <= -X_GUARD)
                k_new = np.where(guard, 1 - k, k_new)                 # reset map: flip the mode, keep x
                nxt[k, :, a_i, j] = k_new * m_states + x_new
    income = np.stack([INCOME[k] * (1 - ((xg - X_STAR[k]) / 0.5) ** 2) for k in range(K)])  # (K, M)
    return xg, acts, nxt, pr, income


def _crowd_kernel(m_states):
    """Row-stochastic smoothing matrix: ρ_k(x) = (mass of mode k within |x' − x| ≤ w) / (2w)."""
    xg = np.linspace(-1.0, 1.0, m_states)
    Kmat = (np.abs(xg[:, None] - xg[None, :]) <= CROWD_WIDTH).astype(float)
    return Kmat / (2 * CROWD_WIDTH)


def _reward(income, mu, acts, m_states, kernel):
    """r[k, x, a] = income_k(x) − κ ρ_k(x) − A_COST·1{a ≠ 0}, ρ the smoothed density per unit x
    (uniform mass over the whole space gives ρ = 1/4; one mode's mass in one window gives ρ = 1/(2w))."""
    rho = mu.reshape(2, m_states) @ kernel.T
    base = income - KAPPA * rho
    a_cost = A_COST * (np.abs(acts) > 0).astype(float)
    return base[:, :, None] - a_cost[None, None, :]


def _soft_vi(r, nxt, pr, V0=None, tol=1e-11, max_iter=5000):
    """Soft value iteration: Q = r + γ Σ_j pr_j V[nxt_j], V = τ log Σ_a exp(Q/τ)."""
    K, M, A, _ = nxt.shape
    V = np.zeros(K * M) if V0 is None else V0.copy()
    for _ in range(max_iter):
        Q = r + GAMMA * np.einsum("j,kxaj->kxa", pr, V[nxt])
        Qs = Q / TAU
        mx = Qs.max(axis=-1, keepdims=True)
        Vn = (TAU * (mx[..., 0] + np.log(np.exp(Qs - mx).sum(axis=-1)))).ravel()
        if np.max(np.abs(Vn - V)) < tol:
            V = Vn
            break
        V = Vn
    Q = r + GAMMA * np.einsum("j,kxaj->kxa", pr, V[nxt])
    Qs = Q / TAU
    Qs -= Qs.max(axis=-1, keepdims=True)
    pi = np.exp(Qs)
    pi /= pi.sum(axis=-1, keepdims=True)
    return V, Q, pi


def _transition(pi, nxt, pr):
    """Sparse transition matrix P[s, s'] under the policy π."""
    K, M, A, J = nxt.shape
    n = K * M
    rows = np.repeat(np.arange(n), A * J)
    cols = nxt.reshape(n, A * J).ravel()
    vals = (pi.reshape(n, A)[:, :, None] * pr[None, None, :]).reshape(n, A * J).ravel()
    return sp.csr_matrix((vals, (rows, cols)), shape=(n, n))


def _stationary(P):
    """Stationary distribution: solve (Pᵀ − I) μ = 0 with Σ μ = 1 (last equation replaced)."""
    n = P.shape[0]
    A = (P.T - sp.identity(n, format="csr")).tolil()
    A[n - 1, :] = 1.0
    b = np.zeros(n)
    b[-1] = 1.0
    mu = spla.spsolve(A.tocsc(), b)
    mu = np.maximum(mu, 0.0)
    return mu / mu.sum()


def _policy_value(pi, r, nxt, pr):
    """Soft value of π: V = (I − γ P_π)^{-1} (r_π + τ H_π)."""
    K, M, A, _ = nxt.shape
    n = K * M
    P = _transition(pi, nxt, pr)
    r_pi = np.sum(pi * r, axis=-1).ravel()
    ent = -np.sum(pi * np.log(np.maximum(pi, 1e-300)), axis=-1).ravel()
    return spla.spsolve((sp.identity(n, format="csr") - GAMMA * P).tocsc(), r_pi + TAU * ent)


def exploitability(mu_pi, pi, r, nxt, pr, V0=None):
    """E_{μ^π}[V*(·; μ^π) − V^π(·; μ^π)] with both values computed against the mean field μ^π."""
    V_star, _, _ = _soft_vi(r, nxt, pr, V0=V0)
    V_pi = _policy_value(pi, r, nxt, pr)
    gap = V_star - V_pi
    return float(mu_pi @ gap), float(np.max(gap))


def simulate(cfg, rng) -> dict:
    m_states = int(max(20, cfg.sizes["grid_points"]))
    n_iter = int(cfg.sizes["n_mfg_iter"])
    xg, acts, nxt, pr, income = _build(m_states)
    kernel = _crowd_kernel(m_states)
    n = 2 * m_states
    mu = np.full(n, 1.0 / n)
    V = None
    residuals = []
    expl_hist = []
    converged_at = None
    for it in range(1, n_iter + 1):
        r = _reward(income, mu, acts, m_states, kernel)
        V, Q, pi = _soft_vi(r, nxt, pr, V0=V)
        mu_pi = _stationary(_transition(pi, nxt, pr))
        res = float(np.abs(mu_pi - mu).sum())
        residuals.append(res)
        if it <= 3 or it % 5 == 0 or res < TOL_FP:
            e, _ = exploitability(mu_pi, pi, _reward(income, mu_pi, acts, m_states, kernel), nxt, pr, V0=V)
            expl_hist.append((it, e))
        if res < TOL_FP and converged_at is None:
            converged_at = it
            mu = mu_pi
            break
        mu = (1 - ETA) * mu + ETA * mu_pi
    # final equilibrium quantities at the last policy and its own mean field
    r = _reward(income, mu, acts, m_states, kernel)
    V, Q, pi = _soft_vi(r, nxt, pr, V0=V)
    mu_pi = _stationary(_transition(pi, nxt, pr))
    residual_final = float(np.abs(mu_pi - mu).sum())
    expl_mean, expl_max = exploitability(mu_pi, pi, _reward(income, mu_pi, acts, m_states, kernel), nxt, pr, V0=V)
    dens = mu_pi.reshape(2, m_states)
    # mass crossing the guards per step (the hybrid jumps at equilibrium)
    mode_of_next = nxt // m_states
    flux = 0.0
    for k in range(2):
        jump = (mode_of_next[k] != k)                       # (M, A, J)
        flux += float(np.sum(dens[k][:, None, None] * pi[k][:, :, None] * pr[None, None, :] * jump))
    return {
        "exploitability_final": expl_mean, "exploitability_max": expl_max,
        "iterations_to_converge": converged_at if converged_at is not None else np.nan,
        "n_iter_run": len(residuals), "fixed_point_residual": residual_final, "residuals": np.array(residuals),
        "expl_history": expl_hist, "grid": xg, "density": dens, "mass_mode1": float(dens[1].sum()),
        "jump_flux": flux, "m_states": m_states, "n_modes": 2, "value": V.reshape(2, m_states),
        "params": dict(gamma=GAMMA, tau=TAU, p_noise=P_NOISE, x_star=X_STAR, income=INCOME, x_guard=X_GUARD,
                       kappa=KAPPA, a_cost=A_COST, eta=ETA, tol=TOL_FP),
    }
