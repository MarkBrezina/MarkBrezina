"""Conjecture 1 toy: path switching between two strategies under a noisy, lagged regime signal.

Implements the mixture of C1 §More concrete formulation (compendium ch. C1, eq. c1-mix),
    θ_t = (1 − w_t) θ¹ + w_t θ²,   w_t ∈ [0, 1],
with the realised utility  U = Σ_t [ x_t r_t − (γ/2) x_t² − c |x_t − x_{t−1}| ]  (P&L, a quadratic risk
charge and proportional transaction costs: the loss + cost functional E[L + C] of C1 eq. c1-obj).

The toy world: two regimes s_t ∈ {0, 1} alternating with durations D·LogNormal(0, σ_D) (a
characteristic lifetime, not memoryless), two persistent features f_t ∈ R², and returns
r_t = b f_t[s_t] + noise, so the regime-optimal parameter vectors are θ¹ = (b/γ, 0) and θ² = (0, b/γ):
in regime 0 only the first feature pays, in regime 1 only the second.  The switching rule sees the
regime through a signal y_t = (2 s_{t−L} − 1) + σ_sig ξ_t lagged by L steps, decides with a hysteresis
band (the "event at T₂"), and then moves w_t along a linear ramp of n_ramp steps (the transition on
[T₂, T₃]).  The *regime half-life* is h = D/2: a signal lagged by more than h is in the wrong regime
more often than in the right one, so the switched path should fall below both fixed paths there.

simulate() returns the gain of the switched path over the better fixed path as a function of the
lag, the timely and lagged gains, and the breakeven lag.
"""
from __future__ import annotations
import numpy as np

# toy parameters (recorded in the experiment's notes)
B_EDGE = 0.02        # expected return per unit feature in the paying regime
GAMMA = 0.02         # quadratic risk-aversion, so θ* = β/γ has unit scale and the edge is b²/(2γ)
SIGMA_R = 0.05       # return noise per step
PHI_F = 0.9          # AR(1) persistence of the features
COST = 0.001         # proportional transaction cost (10 bp of notional traded)
D_REGIME = 100       # median regime duration (steps)
SIGMA_D = 0.2        # log-normal jitter of the regime durations
SIGMA_SIG = 0.5      # noise of the regime signal
BAND = 0.5           # hysteresis band of the switching decision
N_RAMP = 5           # length of the linear transition ramp (T₃ − T₂)


def describe() -> str:
    return ("C1 path switching: two alternating regimes with regime-optimal parameter vectors θ¹, θ²; "
            "the mixed path θ_t = (1 − w_t)θ¹ + w_tθ² follows a hysteresis switch on a noisy regime "
            "signal lagged by L steps with a linear ramp; realised utility (P&L − risk charge − "
            "transaction costs) of the switched path against the better fixed path as a function of L. "
            "Expected: gain > 0 for a timely switch, < 0 once the lag exceeds the regime half-life h = D/2.")


def _regimes(rng, n_steps, n_rep):
    """Alternating regimes with durations D·LogNormal(0, σ_D), random start regime and phase."""
    n_dur = int(3 * n_steps / D_REGIME) + 10
    dur = np.maximum(2, np.round(D_REGIME * np.exp(SIGMA_D * rng.standard_normal((n_rep, n_dur))))).astype(int)
    s = np.empty((n_rep, n_steps), dtype=int)
    for r in range(n_rep):
        seq = np.repeat((np.arange(n_dur) + rng.integers(2)) % 2, dur[r])
        off = rng.integers(D_REGIME)
        s[r] = seq[off:off + n_steps]
    return s


def _features(rng, n_steps, n_rep):
    """Two persistent unit-variance AR(1) features, shape (n_rep, n_steps, 2)."""
    f = np.empty((n_rep, n_steps, 2))
    f[:, 0] = rng.standard_normal((n_rep, 2))
    innov = np.sqrt(1 - PHI_F ** 2) * rng.standard_normal((n_rep, n_steps, 2))
    for t in range(1, n_steps):
        f[:, t] = PHI_F * f[:, t - 1] + innov[:, t]
    return f


def _hysteresis(y):
    """w-decision z_t ∈ {0,1}: 1 after y > +BAND, 0 after y < −BAND, unchanged in between."""
    d = np.where(y > BAND, 1, np.where(y < -BAND, -1, 0))
    idx = np.where(d != 0, np.arange(y.shape[-1]), -1)
    last = np.maximum.accumulate(idx, axis=-1)
    z = np.where(last >= 0, np.take_along_axis(d, np.maximum(last, 0), axis=-1), 0)
    return (z > 0).astype(float)


def _ramp(z):
    """Linear ramp of N_RAMP steps towards the decision: moving average of z over the last N_RAMP steps."""
    c = np.cumsum(np.concatenate([np.zeros(z.shape[:-1] + (1,)), z], axis=-1), axis=-1)
    n = z.shape[-1]
    lo = np.maximum(np.arange(n) + 1 - N_RAMP, 0)
    return (c[..., 1:] - c[..., lo]) / (np.arange(n) + 1 - lo)


def _utility(x, r):
    """Realised utility per step of the position path x against returns r (last axis = time)."""
    dx = np.abs(np.diff(x, axis=-1, prepend=0.0))
    return x * r - 0.5 * GAMMA * x ** 2 - COST * dx


def simulate(cfg, rng) -> dict:
    n_steps = int(cfg.sizes["n_steps"])
    n_rep = int(max(8, min(32, cfg.sizes.get("mc_paths", 200) // 25)))
    s = _regimes(rng, n_steps, n_rep)                     # (R, T)
    f = _features(rng, n_steps, n_rep)                    # (R, T, 2)
    r = B_EDGE * np.take_along_axis(f, s[..., None], axis=-1)[..., 0] + SIGMA_R * rng.standard_normal((n_rep, n_steps))
    m = 2.0 * s - 1.0
    noise = SIGMA_SIG * rng.standard_normal((n_rep, n_steps))

    x1, x2 = f[..., 0], f[..., 1]                          # fixed paths θ¹ = (1, 0), θ² = (0, 1)
    u1 = _utility(x1, r).mean()
    u2 = _utility(x2, r).mean()
    half_life = D_REGIME / 2.0
    lags = np.arange(0, D_REGIME + 1)
    u_mixed = np.empty(len(lags))
    w_example = None
    for i, L in enumerate(lags):
        m_lag = np.concatenate([np.repeat(m[:, :1], L, axis=1), m[:, :n_steps - L]], axis=1) if L > 0 else m
        w = _ramp(_hysteresis(m_lag + noise))
        x = (1 - w) * x1 + w * x2
        u_mixed[i] = _utility(x, r).mean()
        if L == 1:
            w_example = w[0, :min(n_steps, 6 * D_REGIME)].copy()
    u_fixed_best = max(u1, u2)
    gain = u_mixed - u_fixed_best

    lag_timely = 1
    lag_lagged = int(round(1.5 * half_life))
    gain_timely = float(gain[lag_timely])
    gain_lagged = float(gain[min(lag_lagged, len(lags) - 1)])
    # breakeven: first lag at which the gain crosses zero from above (linear interpolation)
    breakeven = np.nan
    for i in range(1, len(lags)):
        if gain[i - 1] > 0 >= gain[i]:
            g0, g1 = gain[i - 1], gain[i]
            breakeven = float(lags[i - 1] + g0 / (g0 - g1))
            break
    return {
        "lags": lags, "gain": gain, "u_mixed": u_mixed, "u_fixed_1": float(u1), "u_fixed_2": float(u2),
        "u_fixed_best": float(u_fixed_best), "gain_timely": gain_timely, "gain_lagged": gain_lagged,
        "lag_timely": lag_timely, "lag_lagged": lag_lagged, "breakeven_lag": breakeven,
        "half_life": half_life, "regime_duration": D_REGIME, "n_rep": n_rep, "n_steps": n_steps,
        "edge_per_step": B_EDGE ** 2 / (2 * GAMMA), "regime_example": s[0, :min(n_steps, 6 * D_REGIME)],
        "w_example": w_example,
        "params": dict(b=B_EDGE, gamma=GAMMA, sigma_r=SIGMA_R, phi_f=PHI_F, cost=COST, D=D_REGIME,
                       sigma_D=SIGMA_D, sigma_sig=SIGMA_SIG, band=BAND, n_ramp=N_RAMP),
    }
