"""Conjecture 5 -- "the final problem" (NB-08, QB): several products and strategies under shared limits.

Action = the allocation with the highest expected utility; utility accounts for cost and groupings;
minimise free energy (risk), maximise conserved energy (return); a variational principle.
Toy: S strategies x P products with expected returns mu_sp, costs c_sp, a covariance Sigma across the
positions, shared limits (gross exposure, per-product cap, a risk budget) and a grouping penalty that
rewards concentration of a strategy within its own product family.  The allocation maximises
U(x) = mu.x - c.|x| - lambda x' Sigma x - gamma * grouping(x)  (the "free energy" F = lambda x'Sigma x is
minimised, the "conserved energy" mu.x maximised) under the limits, with scipy SLSQP; compared with the
naive proportional allocation.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize


def describe() -> str:
    return ("C5: maximise expected utility = return - cost - lambda*risk - gamma*grouping under shared limits "
            "(gross, per-product, risk budget); compare with naive proportional allocation.")


def simulate(cfg, rng) -> dict:
    P = int(cfg.sizes["n_products"]); S = max(2, P)
    n = S * P
    mu = rng.normal(0.02, 0.02, n)                      # expected returns per (strategy, product)
    c = rng.uniform(0.002, 0.01, n)                     # cost per unit exposure
    A = rng.normal(size=(n, n)); Sigma = A @ A.T / n + np.eye(n) * 0.05
    Sigma *= 0.02
    lam, gam = 2.0, 0.005
    family = np.repeat(np.arange(S), P)                 # strategy s is "at home" in products of its family
    product = np.tile(np.arange(P), S)
    home = (family % P == product).astype(float)

    def sabs(x):                                        # smooth |x| for the optimiser
        return np.sqrt(x * x + 1e-8)

    def grouping(x):                                    # exposure outside the home product family
        return float(np.sum(sabs(x) * (1 - home)))

    def utility(x):
        return float(mu @ x - c @ sabs(x) - lam * x @ Sigma @ x - gam * grouping(x))

    gross_limit = 1.0; cap = 0.4; risk_budget = 0.03
    cons = [{"type": "ineq", "fun": lambda x: gross_limit - np.sum(sabs(x))},
            {"type": "ineq", "fun": lambda x: risk_budget - x @ Sigma @ x}]
    for p in range(P):
        cons.append({"type": "ineq", "fun": lambda x, p=p: cap - np.sum(sabs(x[product == p]))})
    naive = np.sign(mu) * gross_limit / n
    best = None
    for trial in range(5):
        x0 = naive * rng.uniform(0.2, 0.8) + rng.normal(0, 0.02, n)
        r = minimize(lambda x: -utility(x), x0, method="SLSQP", constraints=cons, bounds=[(-cap, cap)] * n,
                     options={"maxiter": 500, "ftol": 1e-12})
        if best is None or (r.success and -r.fun > best[0]):
            best = (-r.fun, r.x) if r.success else best
    x = best[1] if best is not None else naive
    limits_ok = (np.sum(np.abs(x)) <= gross_limit + 1e-6 and x @ Sigma @ x <= risk_budget + 1e-6
                 and all(np.sum(np.abs(x[product == p])) <= cap + 1e-6 for p in range(P)))
    return {"utility_optimal": utility(x), "utility_naive": utility(naive),
            "improvement": utility(x) - utility(naive), "limits_respected": float(limits_ok),
            "free_energy_optimal": float(lam * x @ Sigma @ x), "free_energy_naive": float(lam * naive @ Sigma @ naive),
            "return_optimal": float(mu @ x), "return_naive": float(mu @ naive), "gross_optimal": float(np.sum(np.abs(x))),
            "grouping_optimal": grouping(x), "grouping_naive": grouping(naive), "x": x, "n_positions": n,
            "params": dict(lam=lam, gam=gam, gross_limit=gross_limit, cap=cap, risk_budget=risk_budget)}
