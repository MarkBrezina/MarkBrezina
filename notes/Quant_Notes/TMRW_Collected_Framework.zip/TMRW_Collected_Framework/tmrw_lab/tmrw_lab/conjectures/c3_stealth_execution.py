"""Conjecture 3 toy: the stealth-optimal split of a parent order under square-root impact.

Implements the square-root model of C3 (compendium ch. C3, ingredients 1–3 and the scalarised
objective J_λ): a parent order Q = 1,000,000 USD is split into N ≤ N_max = 100 child orders
x_1..x_N (Σ x_k = Q) routed round-robin over V venues and executed one child per venue per time slot.
The footprint of a child is the square-root law g(x) = c √x (impact per unit traded, concave in size:
H4); the child's execution cost is its size times its impact, x·g(x) = c x^{3/2}, plus a proportional
base cost k·x (ingredient 3).  A linear timing-risk penalty λ per time slot (the duration of the
schedule, ⌈N/V⌉ slots) is the cost functional's risk term, so

    J(N, x) = k Q + Σ_k c x_k^{3/2} + λ ⌈N/V⌉.

Because x·g(x) is convex for every concave power g, Jensen gives the equal split x_k = Q/N as the
minimiser of Σ_k x_k g(x_k) at fixed N (the equal split also minimises the largest single footprint
max_k g(x_k), the min-max stealth reading); the equal-split cost c Q^{3/2}/√N then trades off against
the timing penalty and gives an interior optimal number of children N* = (c Q^{3/2} V / (2λ))^{2/3}
capped at N_max.  simulate() compares equal, front-loaded and random schedules with Monte Carlo
impact noise, scans N, and fits the exponent δ of the realised per-unit cost x^δ (expected 1/2).

Note: the bare sum of a concave footprint Σ g(x_k) would be *maximised* by the equal split, so the
footprint has to enter per unit traded for the stealth premise of C3 (spread the order) to hold;
this choice is recorded in the experiment's notes.
"""
from __future__ import annotations
import numpy as np

Q_PARENT = 1_000_000.0   # USD
C_IMPACT = 5e-6          # impact per unit: a 1 M USD sweep moves the price by c√Q = 0.5 %
K_BASE = 5e-4            # proportional base cost (5 bp)
LAMBDA_T = 30.0          # timing-risk penalty per time slot (USD)
SIGMA_C = 0.2            # multiplicative noise of the realised child impact
FRONT_RATIO = 0.9        # geometric decay of the front-loaded schedule


def describe() -> str:
    return ("C3 stealth execution: Q = 1e6 USD into N ≤ 100 children over V venues; child cost "
            "x·g(x) = c x^{3/2} from the square-root footprint g(x) = c√x, base cost k·Q and a timing "
            "penalty λ per slot; equal vs front-loaded vs random splits, the optimal N under the penalty, "
            "and the fitted exponent δ of the per-unit cost (expected 0.5).")


def _slots(n, v):
    return int(np.ceil(n / v))


def expected_cost(x, v):
    """Expected total cost of a split x (array of child sizes) with V venues."""
    x = np.asarray(x, dtype=float)
    return float(K_BASE * x.sum() + C_IMPACT * np.sum(x ** 1.5) + LAMBDA_T * _slots(len(x), v))


def realised_cost(x, v, rng, n_trials):
    """Monte Carlo cost with multiplicative impact noise: returns (mean cost, child costs array)."""
    x = np.asarray(x, dtype=float)
    noise = 1.0 + SIGMA_C * rng.standard_normal((n_trials, len(x)))
    child = C_IMPACT * x[None, :] ** 1.5 * noise
    total = K_BASE * x.sum() + child.sum(axis=1) + LAMBDA_T * _slots(len(x), v)
    return float(total.mean()), child


def equal_split(n):
    return np.full(n, Q_PARENT / n)


def front_loaded(n):
    w = FRONT_RATIO ** np.arange(n)
    return Q_PARENT * w / w.sum()


def random_split(n, rng):
    return Q_PARENT * rng.dirichlet(np.ones(n))


def simulate(cfg, rng) -> dict:
    n_max = int(cfg.sizes.get("n_children", 100))
    v = int(max(1, cfg.sizes.get("n_venues", 5)))
    n_trials = int(max(10, cfg.sizes.get("n_trials", 20)))
    # optimal N under the penalty (equal split at each N)
    ns = np.arange(1, n_max + 1)
    cost_n = np.array([expected_cost(equal_split(n), v) for n in ns])
    n_opt = int(ns[np.argmin(cost_n)])
    n_opt_analytic = float((C_IMPACT * Q_PARENT ** 1.5 * v / (2 * LAMBDA_T)) ** (2 / 3))
    # schedules at the optimal N
    x_eq, x_fr = equal_split(n_opt), front_loaded(n_opt)
    cost_eq, child_eq = realised_cost(x_eq, v, rng, n_trials)
    cost_fr, child_fr = realised_cost(x_fr, v, rng, n_trials)
    rand_costs, rand_children, rand_sizes = [], [], []
    for _ in range(n_trials):
        x_r = random_split(n_opt, rng)
        c_r, ch = realised_cost(x_r, v, rng, 1)
        rand_costs.append(c_r)
        rand_children.append(ch[0])
        rand_sizes.append(x_r)
    cost_rand_mean = float(np.mean(rand_costs))
    cost_rand_min = float(np.min(rand_costs))
    # exponent of the per-unit cost: log(child cost / size) = log c + δ log size, over all child prints
    sizes = np.concatenate([np.tile(x_fr, n_trials), np.concatenate(rand_sizes)])
    costs = np.concatenate([child_fr.ravel(), np.concatenate(rand_children)])
    ok = (sizes > 1.0) & (costs > 0)
    A = np.column_stack([np.ones(ok.sum()), np.log(sizes[ok])])
    coef, *_ = np.linalg.lstsq(A, np.log(costs[ok] / sizes[ok]), rcond=None)
    delta_hat = float(coef[1])
    # stealth reading: the largest single footprint of each schedule
    fp_eq = C_IMPACT * np.sqrt(x_eq.max())
    fp_fr = C_IMPACT * np.sqrt(x_fr.max())
    return {
        "q": Q_PARENT, "n_max": n_max, "n_venues": v, "n_trials": n_trials,
        "ns": ns, "cost_vs_n": cost_n, "optimal_n": n_opt, "optimal_n_analytic": n_opt_analytic,
        "cost_equal": cost_eq, "cost_equal_expected": expected_cost(x_eq, v),
        "cost_front": cost_fr, "cost_front_expected": expected_cost(x_fr, v),
        "cost_random_mean": cost_rand_mean, "cost_random_min": cost_rand_min,
        "cost_single": expected_cost(equal_split(1), v), "sqrt_exponent": delta_hat,
        "max_footprint_equal": float(fp_eq), "max_footprint_front": float(fp_fr),
        "max_footprint_ratio": float(fp_fr / fp_eq), "x_equal": x_eq, "x_front": x_fr,
        "params": dict(c=C_IMPACT, k=K_BASE, lam=LAMBDA_T, sigma_c=SIGMA_C, front_ratio=FRONT_RATIO),
    }
