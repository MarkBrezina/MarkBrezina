"""Conjecture 2 toy: the central price as a mixture of an impact term and a history term.

Implements C2 Assumption 2 (compendium eq. c2-decomp) on a simulated panel of N > 3 assets,
    P_{t+1} = α I_t + (1 − α) H_t + ε_{t+1},
with the immediate term linear in the signed order flow (the OFI law, C2 Assumption 4 / H5),
I_t = P_t + β q_t, the history term the mean of the last H ≥ 5 prices (Assumption 3), the flow q_t
an AR(1) and ε mean-zero noise.  The central price map F_T is calibrated by pooled OLS,
    P_{t+1} − H_t = a + α (P_t − H_t) + (αβ) q_t + ε,
which identifies α (with its t-statistic and the R²) and β.  The confidence-region map C_T of the
conjecture is built as a split-conformal region for the next H_f = 5 steps (the joint band
{|P_{t+k} − P̂_{t+k}| ≤ q σ̂_k, k = 1..5}) and its out-of-sample coverage is checked against 1 − δ;
the random-walk baseline gives the RMSE ratio the conjecture asks to beat.
"""
from __future__ import annotations
import numpy as np

ALPHA = 0.6          # planted weight of the immediate term
BETA = 0.05          # impact per unit signed flow (price units)
PHI_Q = 0.3          # autocorrelation of the signed flow
SIGMA_EPS = 0.1      # noise of the next price
H_HIST = 10          # history window (H ≥ 5)
H_FORE = 5           # forecast horizon of the confidence region (H ≥ 5)
DELTA = 0.1          # miscoverage level of the region


def describe() -> str:
    return ("C2 central pricing: a panel of N > 3 assets with P_{t+1} = α I_t + (1 − α) H_t + ε, "
            "I_t = P_t + β q_t linear in the signed flow, H_t the mean of the last H ≥ 5 prices; "
            "α recovered by pooled OLS (α̂, t-statistic, R²), split-conformal 5-step regions with "
            "coverage checked against 1 − δ, and the random-walk baseline.")


def _simulate_panel(rng, n_assets, n_steps):
    P = np.empty((n_steps, n_assets))
    q = np.empty((n_steps, n_assets))
    P[:H_HIST] = 100.0 + 0.1 * rng.standard_normal((H_HIST, n_assets)).cumsum(axis=0)
    q[0] = rng.standard_normal(n_assets)
    inn = np.sqrt(1 - PHI_Q ** 2) * rng.standard_normal((n_steps, n_assets))
    eps = SIGMA_EPS * rng.standard_normal((n_steps, n_assets))
    for t in range(1, H_HIST):
        q[t] = PHI_Q * q[t - 1] + inn[t]
    for t in range(H_HIST - 1, n_steps - 1):
        if t >= H_HIST:
            q[t] = PHI_Q * q[t - 1] + inn[t]
        I = P[t] + BETA * q[t]
        Hm = P[t - H_HIST + 1:t + 1].mean(axis=0)
        P[t + 1] = ALPHA * I + (1 - ALPHA) * Hm + eps[t + 1]
    return P, q


def _ols(X, y):
    """OLS with intercept: returns (coef, se, r2); X has shape (n, k)."""
    Xd = np.column_stack([np.ones(len(y)), X])
    beta, *_ = np.linalg.lstsq(Xd, y, rcond=None)
    resid = y - Xd @ beta
    n, k = Xd.shape
    s2 = resid @ resid / (n - k)
    cov = s2 * np.linalg.inv(Xd.T @ Xd)
    r2 = 1 - resid @ resid / np.sum((y - y.mean()) ** 2)
    return beta, np.sqrt(np.diag(cov)), float(r2)


def _forecast_paths(P, q, t_idx, alpha, beta, phi):
    """k-step central prices P̂_{t+k}, k = 1..H_FORE, for the times t_idx: shape (H_FORE, len(t_idx), N)."""
    win = np.stack([P[t_idx - H_HIST + 1 + j] for j in range(H_HIST)], axis=0)   # (H, n_t, N)
    qf = q[t_idx].copy()
    out = np.empty((H_FORE,) + win.shape[1:])
    for k in range(H_FORE):
        Pt = win[-1]
        Pn = alpha * (Pt + beta * qf) + (1 - alpha) * win.mean(axis=0)
        out[k] = Pn
        win = np.concatenate([win[1:], Pn[None]], axis=0)
        qf = phi * qf
    return out


def simulate(cfg, rng) -> dict:
    n_assets = int(max(4, cfg.sizes["n_assets"]))
    n_steps = int(cfg.sizes["n_steps"])
    P, q = _simulate_panel(rng, n_assets, n_steps)
    t = np.arange(H_HIST - 1, n_steps - 1)
    Hm = np.stack([P[t - H_HIST + 1 + j] for j in range(H_HIST)], axis=0).mean(axis=0)
    y = (P[t + 1] - Hm).ravel()
    x1 = (P[t] - Hm).ravel()
    x2 = q[t].ravel()
    coef, se, r2 = _ols(np.column_stack([x1, x2]), y)
    alpha_hat, alpha_se = coef[1], se[1]
    beta_hat = coef[2] / coef[1] if coef[1] != 0 else np.nan
    # per-asset α̂ (for the figure: N > 3 assets)
    per_asset = np.empty(n_assets)
    per_asset_se = np.empty(n_assets)
    for i in range(n_assets):
        c_i, s_i, _ = _ols(np.column_stack([(P[t, i] - Hm[:, i]), q[t, i]]), P[t + 1, i] - Hm[:, i])
        per_asset[i], per_asset_se[i] = c_i[1], s_i[1]
    # baselines: one-step RMSE of the central price vs the random walk
    pred1 = Hm + alpha_hat * (P[t] - Hm) + coef[2] * q[t] + coef[0]
    rmse_model = float(np.sqrt(np.mean((P[t + 1] - pred1) ** 2)))
    rmse_rw = float(np.sqrt(np.mean((P[t + 1] - P[t]) ** 2)))
    # flow autocorrelation for multi-step forecasts
    qa, qb = q[t[:-1]].ravel(), q[t[1:]].ravel()
    phi_hat = float(qa @ qb / (qa @ qa))
    # split-conformal joint region over H_FORE steps: calibrate on the middle quarter, test on the last
    n_t = len(t)
    cal = t[n_t // 2: 3 * n_t // 4 - H_FORE]
    tst = t[3 * n_t // 4: n_t - H_FORE]
    coverage = np.nan
    width = np.nan
    band_example = None
    if len(cal) > 20 and len(tst) > 20:
        fc = _forecast_paths(P, q, cal, alpha_hat, beta_hat, phi_hat)
        err_c = np.stack([P[cal + k + 1] for k in range(H_FORE)], axis=0) - fc
        sig_k = err_c.reshape(H_FORE, -1).std(axis=1)
        score_c = (np.abs(err_c) / sig_k[:, None, None]).max(axis=0).ravel()
        n_c = len(score_c)
        level = min(1.0, np.ceil((n_c + 1) * (1 - DELTA)) / n_c)
        qhat = float(np.quantile(score_c, level))
        ft = _forecast_paths(P, q, tst, alpha_hat, beta_hat, phi_hat)
        err_t = np.stack([P[tst + k + 1] for k in range(H_FORE)], axis=0) - ft
        score_t = (np.abs(err_t) / sig_k[:, None, None]).max(axis=0).ravel()
        coverage = float(np.mean(score_t <= qhat))
        width = float(2 * qhat * sig_k[-1])
        j = tst[len(tst) // 2]
        band_example = {"t0": int(j), "path": P[j - 20:j + H_FORE + 1, 0],
                        "fc": ft[:, len(tst) // 2, 0], "half": qhat * sig_k}
    return {
        "alpha_hat": float(alpha_hat), "alpha_se": float(alpha_se), "alpha_tstat": float(alpha_hat / alpha_se),
        "alpha_planted": ALPHA, "beta_hat": float(beta_hat), "beta_planted": BETA, "r2": float(r2),
        "per_asset_alpha": per_asset, "per_asset_se": per_asset_se, "n_assets": n_assets, "n_steps": n_steps,
        "h_hist": H_HIST, "h_fore": H_FORE, "delta": DELTA, "coverage": coverage, "band_width_h5": width,
        "rmse_model": rmse_model, "rmse_rw": rmse_rw, "rmse_ratio": rmse_model / rmse_rw,
        "phi_hat": phi_hat, "n_obs": int(len(y)), "band_example": band_example,
        "params": dict(alpha=ALPHA, beta=BETA, phi_q=PHI_Q, sigma_eps=SIGMA_EPS, H=H_HIST, H_fore=H_FORE, delta=DELTA),
    }
