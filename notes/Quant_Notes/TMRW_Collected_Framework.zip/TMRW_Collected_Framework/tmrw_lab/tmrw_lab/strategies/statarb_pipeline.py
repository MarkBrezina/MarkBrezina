"""Statistical-arbitrage blueprint (NB-05): pair selection, cointegration, spread z-score bands,
half-life, walk-forward backtest with costs.
"""
from __future__ import annotations
import numpy as np


def hedge_ratio(x, y):
    X = np.column_stack([np.ones(len(x)), x])
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    return b[1], b[0]


def adf_stat(s, lags=1):
    """Augmented Dickey-Fuller t-statistic (no trend) by OLS on the differenced series."""
    ds = np.diff(s); lag = s[:-1]
    X = [np.ones(len(ds) - lags), lag[lags:]]
    for k in range(1, lags + 1):
        X.append(ds[lags - k:len(ds) - k])
    X = np.column_stack(X); y = ds[lags:]
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ b; s2 = resid @ resid / max(len(y) - X.shape[1], 1)
    se = np.sqrt(s2 * np.linalg.pinv(X.T @ X)[1, 1])
    return float(b[1] / se)


def engle_granger(x, y):
    beta, alpha = hedge_ratio(x, y)
    spread = y - alpha - beta * x
    return {"beta": beta, "alpha": alpha, "spread": spread, "adf_t": adf_stat(spread), "cointegrated": adf_stat(spread) < -3.34}


def half_life(spread):
    ds = np.diff(spread); lag = spread[:-1] - spread[:-1].mean()
    phi = (lag @ ds) / (lag @ lag)
    return float(-np.log(2) / np.log(1 + phi)) if -1 < phi < 0 else np.inf


def backtest(spread, entry=2.0, exit_=0.5, window=60, cost=0.0005, train_frac=0.5):
    """z-score bands on a rolling window; positions +/-1 on the spread; costs per unit traded."""
    n = len(spread); z = np.zeros(n)
    for t in range(window, n):
        w = spread[t - window:t]; z[t] = (spread[t] - w.mean()) / (w.std() + 1e-12)
    pos = np.zeros(n)
    for t in range(1, n):
        if pos[t - 1] == 0:
            pos[t] = -1 if z[t] > entry else (1 if z[t] < -entry else 0)
        else:
            pos[t] = 0 if abs(z[t]) < exit_ else pos[t - 1]
    ret = np.r_[0, pos[:-1] * np.diff(spread)] - cost * np.abs(np.diff(pos, prepend=0))
    split = int(n * train_frac)
    oos = ret[split:]
    sharpe = oos.mean() / (oos.std() + 1e-12) * np.sqrt(252)
    return {"ret": ret, "pos": pos, "z": z, "sharpe_oos": float(sharpe), "pnl_oos": float(oos.sum()),
            "trades": int(np.sum(np.abs(np.diff(pos, prepend=0)) > 0))}


def synthetic_pair(rng, n, halflife=20.0, beta=1.5, sigma=0.01):
    """Two cointegrated price series: y = alpha + beta x + spread, spread an AR(1) with the given half-life."""
    x = 100 + np.cumsum(rng.normal(0, 1.0, n))
    phi = np.exp(-np.log(2) / halflife)
    s = np.zeros(n)
    for t in range(1, n):
        s[t] = phi * s[t - 1] + rng.normal(0, 1.0)
    y = 10 + beta * x + s
    return x, y
