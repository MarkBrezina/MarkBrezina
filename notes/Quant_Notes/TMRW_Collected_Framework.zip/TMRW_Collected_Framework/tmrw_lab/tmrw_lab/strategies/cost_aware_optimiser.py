"""Cost-aware expected-utility allocation under limits (NB-07 / C5 form):
maximise mu.x - c.|x| - lambda x' Sigma x  subject to a gross limit and per-asset caps (scipy SLSQP).
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize


def optimise(mu, Sigma, cost, lam=1.0, gross=1.0, cap=0.3, rng=None):
    n = len(mu)
    sabs = lambda x: np.sqrt(x * x + 1e-10)
    util = lambda x: float(mu @ x - cost @ sabs(x) - lam * x @ Sigma @ x)
    cons = [{"type": "ineq", "fun": lambda x: gross - np.sum(sabs(x))}]
    naive = np.sign(mu) * gross / n
    best = (util(naive), naive)
    rng = rng or np.random.default_rng(0)
    for _ in range(4):
        x0 = naive * rng.uniform(0.3, 0.9)
        r = minimize(lambda x: -util(x), x0, method="SLSQP", constraints=cons, bounds=[(-cap, cap)] * n, options={"maxiter": 400})
        if r.success and -r.fun > best[0]:
            best = (-r.fun, r.x)
    x = best[1]
    ok = np.sum(np.abs(x)) <= gross + 1e-6 and np.all(np.abs(x) <= cap + 1e-6)
    return {"x": x, "utility": best[0], "utility_naive": util(naive), "improvement": best[0] - util(naive), "limits_respected": float(ok)}
