"""Trend-following blueprint (NB-06): moving-average crossovers at several horizons, breakout,
time-series momentum, ATR sizing, ensemble vote, backtest with costs.
"""
from __future__ import annotations
import numpy as np


def ema(x, span):
    a = 2.0 / (span + 1); out = np.empty_like(x); out[0] = x[0]
    for t in range(1, len(x)):
        out[t] = a * x[t] + (1 - a) * out[t - 1]
    return out


def atr(close, window=20):
    tr = np.abs(np.diff(close, prepend=close[0]))
    return ema(tr, window)


def signals(close, fast=(10, 20, 50), slow=(30, 60, 150), breakout=50, momentum=60):
    sig = []
    for f, s in zip(fast, slow):
        sig.append(np.sign(ema(close, f) - ema(close, s)))
    hi = np.array([close[max(0, t - breakout):t].max() if t > 0 else close[0] for t in range(len(close))])
    lo = np.array([close[max(0, t - breakout):t].min() if t > 0 else close[0] for t in range(len(close))])
    sig.append(np.where(close >= hi, 1.0, np.where(close <= lo, -1.0, 0.0)))
    mom = np.r_[np.zeros(momentum), np.sign(close[momentum:] - close[:-momentum])]
    sig.append(mom)
    return np.array(sig)


def backtest(close, cost=0.0005, target_vol=0.01, train_frac=0.5):
    S = signals(close)
    vote = S.mean(axis=0)
    a = atr(close) / close
    size = np.clip(target_vol / (a + 1e-9), 0, 5)          # ATR-based sizing
    pos = np.r_[0, (vote * size)[:-1]]
    r = np.diff(np.log(close), prepend=0.0)
    ret = pos * r - cost * np.abs(np.diff(pos, prepend=0))
    split = int(len(close) * train_frac); oos = ret[split:]
    eq = np.cumsum(oos); dd = float(np.max(np.maximum.accumulate(eq) - eq)) if len(eq) else np.nan
    return {"ret": ret, "pos": pos, "sharpe_oos": float(oos.mean() / (oos.std() + 1e-12) * np.sqrt(252)),
            "max_drawdown": dd, "turnover": float(np.mean(np.abs(np.diff(pos, prepend=0)))), "vote": vote}


def synthetic_trending(rng, n, n_regimes=6, drift=0.002, sigma=0.01):
    """Log-price with alternating drift regimes (trends) and noise."""
    bounds = np.linspace(0, n, n_regimes + 1).astype(int)
    r = np.zeros(n)
    for k in range(n_regimes):
        r[bounds[k]:bounds[k + 1]] = drift * (1 if k % 2 == 0 else -1) + rng.normal(0, sigma, bounds[k + 1] - bounds[k])
    return 100 * np.exp(np.cumsum(r))
