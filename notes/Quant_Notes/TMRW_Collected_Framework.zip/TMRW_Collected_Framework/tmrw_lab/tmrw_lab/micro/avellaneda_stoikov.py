"""Avellaneda–Stoikov quoting and the inventory-skew rules of NB-01 (compendium ch. nb-mm).

Implements, in the notation of NB-01 §Models and §Inventory skew:
    reservation price      r = s − q γ σ² (T − t)                          (eq. nb-as; stationary form T−t = 1)
    optimal total spread   δ = γ σ² (T − t) + (2/γ) ln(1 + γ/k)            (Avellaneda & Stoikov 2008)
    linear skew            r_t = f_t − k q_t, bid = r − h, ask = r + h      (eq. nb-skew; k = 0.125 m for h = 10, q_max = 80)
    band skew              the four-band scheme of table nb-bands (0–20 normal, 20–40 and 40–50 skew harder,
                           50–70 flattening ahead of spread, 70–80 flattening side only)
    quote()                bid/ask with the limit rule "at the limit, remove the order, do not just skew it".

All functions are plain numpy and accept scalars or arrays for ``fair``/``q`` (vectorised over paths).
"""
from __future__ import annotations
import numpy as np

# (upper |q| of the band, multiplier on the base skew k, size fraction on the risky side, quote the risky side?)
# The multipliers 1, 1.5, 2, 2.5, 3 are a choice: the note says only "normally / harder / harder / flattening ahead".
NOTE_BANDS = ((20, 1.0, 1.0, True), (40, 1.5, 1.0, True), (50, 2.0, 0.5, True),
              (70, 2.5, 0.25, True), (80, 3.0, 0.0, False))

DEFAULT_PARAMS = dict(h=10.0, q_max=80, inventory_limit=80, risk_aversion=1.0, mode="linear",
                      bands=NOTE_BANDS, base_size=25.0, clamp_to_fair=True)


def reservation_price(s, q, gamma, sigma2, T_minus_t=1.0):
    """r = s − q γ σ² (T − t): the A-S reservation price (NB-01 eq. nb-as; stationary form with T−t = 1)."""
    return np.asarray(s, dtype=float) - np.asarray(q, dtype=float) * gamma * sigma2 * T_minus_t


def optimal_spread(gamma, sigma2, k, T_minus_t=1.0):
    """Total optimal spread δᵃ + δᵇ = γ σ² (T − t) + (2/γ) ln(1 + γ/k) of Avellaneda–Stoikov (2008)."""
    return gamma * sigma2 * T_minus_t + (2.0 / gamma) * np.log1p(gamma / k)


def skew_per_unit(h=10.0, q_max=80, m=1.0):
    """k = m (h / q_max): the linear rule skew = m (q/q_max) h, so k = 0.125 m for h = 10, q_max = 80 (table nb-k)."""
    return m * h / q_max


def linear_skew(fair, q, k):
    """Centre of the quotes under the linear rule, r_t = f_t − k q_t (NB-01 eq. nb-skew)."""
    return np.asarray(fair, dtype=float) - k * np.asarray(q, dtype=float)


def band_rule(q, bands=NOTE_BANDS):
    """(multiplier, size fraction, quote-risky-side) of the band holding |q| (table nb-bands, four-band scheme).

    Vectorised: returns three arrays shaped like q."""
    aq = np.abs(np.asarray(q, dtype=float))
    uppers = np.array([b[0] for b in bands], dtype=float)
    idx = np.searchsorted(uppers, aq, side="left")           # first band whose upper bound >= |q|
    idx = np.minimum(idx, len(bands) - 1)
    mult = np.array([b[1] for b in bands])[idx]
    size = np.array([b[2] for b in bands])[idx]
    risky = np.array([b[3] for b in bands])[idx]
    return mult, size, risky


def band_skew(q, bands=NOTE_BANDS, h=10.0, q_max=80, m=1.0):
    """Skew in price units under the band scheme: multiplier(band) × m (q/q_max) h, signed like q."""
    mult, _, _ = band_rule(q, bands)
    return mult * skew_per_unit(h, q_max, m) * np.asarray(q, dtype=float)


def quote(fair, q, params=None):
    """(bid, ask) around ``fair`` for inventory ``q``: no skew, linear skew or band skew; NaN = order removed.

    params: h (half-spread), q_max (hard limit), inventory_limit (soft limit: one-sided quoting beyond it),
    risk_aversion m (k = m h / q_max unless 'k' is given), mode in {'none', 'linear', 'band'}, bands.
    Rules: r = f − k q (linear) or f − mult(band) k q (band); bid = r − h, ask = r + h; the flattening quote
    never crosses the fair (clamped to f, i.e. "at mid" as in table nb-quotes at ±80); at |q| ≥ inventory_limit
    the risky side is removed (rule nb-limit), as it is in the 70–80 band of the band scheme."""
    p = dict(DEFAULT_PARAMS)
    if params:
        p.update(params)
    f = np.asarray(fair, dtype=float)
    qq = np.asarray(q, dtype=float)
    h, qmax = float(p["h"]), float(p["q_max"])
    k = float(p["k"]) if p.get("k") is not None else skew_per_unit(h, qmax, float(p["risk_aversion"]))
    mode = p.get("mode", "linear")
    if mode == "none":
        r = f + 0.0 * qq
        risky = np.ones_like(qq, dtype=bool)
    elif mode == "band":
        mult, _, risky = band_rule(qq, p["bands"])
        r = f - mult * k * qq
    else:
        r = f - k * qq
        risky = np.ones_like(qq, dtype=bool)
    bid = r - h
    ask = r + h
    if p.get("clamp_to_fair", True):
        bid = np.minimum(bid, f)
        ask = np.maximum(ask, f)
    soft = float(p.get("inventory_limit", qmax))
    bid = np.where((qq >= soft) | (qq >= qmax) | ((qq > 0) & ~risky), np.nan, bid)
    ask = np.where((qq <= -soft) | (qq <= -qmax) | ((qq < 0) & ~risky), np.nan, ask)
    return bid, ask


def quote_sizes(q, params=None):
    """(bid_size, ask_size): base size, shrunk on the risky side by the band's size fraction (band mode),
    and capped by the remaining capacity to the hard limit (table nb-bands: full size at 0, reduced at 40,
    small at 60, zero on the risky side at 80)."""
    p = dict(DEFAULT_PARAMS)
    if params:
        p.update(params)
    qq = np.asarray(q, dtype=float)
    base, qmax = float(p["base_size"]), float(p["q_max"])
    bid_size = np.full_like(qq, base)
    ask_size = np.full_like(qq, base)
    if p.get("mode", "linear") == "band":
        _, frac, _ = band_rule(qq, p["bands"])
        bid_size = np.where(qq > 0, base * frac, base)       # long: the bid is the risky side
        ask_size = np.where(qq < 0, base * frac, base)
    bid_size = np.clip(np.minimum(bid_size, qmax - qq), 0, None)
    ask_size = np.clip(np.minimum(ask_size, qmax + qq), 0, None)
    return bid_size, ask_size


def quote_table(h=10.0, q_max=80, m=1.0, inventories=(0, 40, 80, -40, -80)):
    """The quote table of NB-01 §2 (table nb-quotes) for the full-strength linear rule: rows (q, skew, bid-mid, ask-mid)."""
    rows = []
    k = skew_per_unit(h, q_max, m)
    for q in inventories:
        bid, ask = quote(0.0, q, dict(h=h, q_max=q_max, risk_aversion=m, mode="linear", inventory_limit=q_max + 1))
        rows.append((q, k * q, float(bid), float(ask)))
    return rows
