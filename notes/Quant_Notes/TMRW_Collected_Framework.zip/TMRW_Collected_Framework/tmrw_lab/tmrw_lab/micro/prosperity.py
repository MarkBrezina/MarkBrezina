"""Prosperity-style quoting (NB-02/NB-03, 5 April 2025 rules) on a synthetic two-product feed, and the
crash-risk measures NCSKEW and DUVOL (Chen, Hong & Stein 2001) used in the 2025 team log.

Products: a *stable* one (true value fixed, e.g. 10,000; quotes oscillate around it) and a *drifting* one
(a slow random walk; fair = mid of the best quotes / a volume-weighted mid).  Rules: take any order
strictly better than fair (buy below, sell above) within the position limit; then make: post a bid one
tick inside the best bid below fair and an ask one tick inside the best ask above fair, with sizes
shrinking as the position approaches the limit (the position penalty).
"""
from __future__ import annotations
import numpy as np

LIMIT = 50


def synthetic_feed(rng, n_ticks, v_stable=10_000.0, v_drift0=5_000.0):
    """Per tick: for each product the best bid/ask with sizes, and a few 'orders' (price, qty) from
    other bots around the true value."""
    drift = v_drift0 + np.cumsum(rng.normal(0, 1.0, n_ticks))
    feed = []
    for t in range(n_ticks):
        prods = {}
        for name, v in (("STABLE", v_stable), ("DRIFT", drift[t])):
            spread = rng.choice([4, 6, 8, 10])
            noise = rng.normal(0, 2.0)
            bid = np.round(v + noise - spread / 2); ask = bid + spread
            # occasional mispriced orders (the taking opportunities)
            orders = []
            if rng.random() < 0.15:
                orders.append((np.round(v + rng.uniform(1, 4)), -int(rng.integers(5, 20))))   # someone bids above value: we can sell
            if rng.random() < 0.15:
                orders.append((np.round(v - rng.uniform(1, 4)), int(rng.integers(5, 20))))    # someone offers below value: we can buy
            prods[name] = dict(true=v, bid=bid, ask=ask, bid_size=int(rng.integers(10, 40)), ask_size=int(rng.integers(10, 40)), orders=orders)
        feed.append(prods)
    return feed


def fair_value(name, p, hist):
    if name == "STABLE":
        return 10_000.0
    return 0.5 * (p["bid"] + p["ask"])              # mid of the best quotes


def position_penalty(q, limit=LIMIT, base=15):
    """Quote size shrinks linearly as |q| approaches the limit (NB-03 position penalty)."""
    return max(1, int(round(base * (1 - abs(q) / limit))))


def run_strategy(feed, rng, limit=LIMIT, fill_prob=0.5):
    """Returns PnL per product, max |position| per product, number of takes/makes."""
    pos = {"STABLE": 0, "DRIFT": 0}; cash = {"STABLE": 0.0, "DRIFT": 0.0}
    takes = 0; makes = 0; hist = {}
    for p_t in feed:
        for name, p in p_t.items():
            fv = fair_value(name, p, hist)
            q = pos[name]
            # taking: orders strictly better than fair, inventory permitting
            for price, qty in p["orders"]:
                if qty > 0 and price < fv and q + qty <= limit:          # buy below fair
                    pos[name] += qty; cash[name] -= price * qty; takes += 1
                elif qty < 0 and price > fv and q + qty >= -limit:       # sell above fair
                    pos[name] += qty; cash[name] -= price * qty; takes += 1
            q = pos[name]
            # making: inside the best quotes, below / above fair
            my_bid = min(p["bid"] + 1, fv - 1); my_ask = max(p["ask"] - 1, fv + 1)
            size_b = min(position_penalty(q), limit - q); size_a = min(position_penalty(q), limit + q)
            if size_b > 0 and rng.random() < fill_prob * np.exp(-(fv - my_bid) / 4):
                pos[name] += size_b; cash[name] -= my_bid * size_b; makes += 1
            if size_a > 0 and rng.random() < fill_prob * np.exp(-(my_ask - fv) / 4):
                pos[name] -= size_a; cash[name] += my_ask * size_a; makes += 1
    last = feed[-1]
    pnl = {name: cash[name] + pos[name] * last[name]["true"] for name in pos}
    return pnl, pos, takes, makes


def ncskew(r):
    r = np.asarray(r, float); r = r - r.mean(); n = len(r)
    return float(-(n * (n - 1) ** 1.5 * np.sum(r ** 3)) / ((n - 1) * (n - 2) * np.sum(r ** 2) ** 1.5))


def duvol(r):
    r = np.asarray(r, float); d = r - r.mean()
    up = d[d > 0]; down = d[d < 0]
    nu, nd = len(up), len(down)
    return float(np.log(((nu - 1) * np.sum(down ** 2)) / max((nd - 1) * np.sum(up ** 2), 1e-300)))
