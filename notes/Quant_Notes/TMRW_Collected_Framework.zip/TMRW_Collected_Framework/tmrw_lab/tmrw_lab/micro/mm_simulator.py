"""Range-bound market-making simulator for the worked case of NB-01 (compendium ch. nb-mm, §Worked case).

The market.  A fair value that mean-reverts around 10,000 (dS = θ(μ−S)dt + σ dW + J dN, eq. nb-price), with
±30-point jumps, one planted sharp drop over ticks 16,000–17,000 of a 30,000-tick session (a burst of market
sells whose impact drags the fair down: where symmetric quoting accumulates a losing long position), and a
transient microstructure noise on the observed mid.  Buy and sell market orders arrive as Poisson streams
(A per tick per side, geometric sizes); each pushes the fair by ``impact`` per unit (the adverse-selection
channel).  The market's own touch sits at mid ± 10 (the fixed spread of about 20).

The maker.  Estimates fair value by a short EWMA of the mid, quotes one bid and one ask from
``avellaneda_stoikov.quote`` (no skew / linear skew / band skew) with the limit rule, and is filled with the
Avellaneda–Stoikov intensity A e^{−κ δ} (δ = distance of the quote from the mid): a market order at the
touch walks to our quote with probability e^{−κδ}.  The hard limit ±80 is never exceeded.  The optional
taking layer (NB-01 §5) crosses the spread only when the best ask (bid) is ``take_threshold`` ticks below
(above) fair *and* the trade reduces inventory.

Hard controls (NB-01 §8: "the book keeps hitting the ±80 limit, forcing a stop or a loss-making
liquidation").  At |q| = 80 the risk manager flattens ``liquidation_size`` units at the touch (paying the
half-spread), and the inventory left at the close is marked down by the half-spread (eq. nb-profit:
profit = fills × average spread captured − inventory at close × mark-to-market loss).

PnL and its exact decomposition (rule nb-pnl).  Marking to mid, PnL = Σ_fills edge + Σ_t q_t ΔS_t − close-out
with edge = (S − price) × size for buys (passive: spread capture ≥ 0; takes: −overtrading cost; forced
liquidation: −liquidation cost).  The holding term splits into adverse selection, Σ_fills size × (S_t − S_{t+H})
for buys (the mid move over the next H ticks after each fill), and the remainder, inventory risk; inventory
cost = inventory risk + liquidation (forced flattening and close-out).  So
    PnL = spread capture − overtrading − adverse selection − inventory cost     exactly.
"""
from __future__ import annotations
import numpy as np

from tmrw_lab.micro import avellaneda_stoikov as AS

DEFAULTS = dict(
    mid0=10_000.0, theta=0.001, sigma=1.0, noise=1.5,
    jump_prob=0.0015, jump_size=30.0,
    drop=True, drop_start=16 / 30, drop_end=17 / 30, drop_sell_rate=0.15,
    arrival=0.03, decay=0.12, order_size=2.0, impact=0.3,
    half_spread=10.0, q_max=80, inventory_limit=80, risk_aversion=1.0, skew="linear", bands=AS.NOTE_BANDS,
    base_size=25.0, ewma_alpha=0.3,
    taking=False, take_threshold=8.0, take_size=10.0,
    liquidation_size=20.0, close_out=True,
    horizon=20,
)


def _geometric_sizes(rng, mean, shape):
    """Market-order sizes: 1 + Geometric, with the given mean (≥ 1)."""
    p = 1.0 / max(mean, 1.0)
    return rng.geometric(p, size=shape).astype(float)


def generate_market(params, n_ticks, rng, n_paths=1):
    """The exogenous market: fair path, observed mid, market-order counts and sizes per tick (shape (P, n))."""
    p = dict(DEFAULTS)
    p.update(params or {})
    P, n = int(n_paths), int(n_ticks)
    A = float(p["arrival"])
    n_buy = rng.poisson(A, size=(P, n))
    n_sell = rng.poisson(A, size=(P, n))
    if p["drop"]:
        a, b = int(p["drop_start"] * n), int(p["drop_end"] * n)
        n_sell[:, a:b] += rng.poisson(float(p["drop_sell_rate"]), size=(P, max(b - a, 0)))
    size_buy = _geometric_sizes(rng, p["order_size"], (P, n))
    size_sell = _geometric_sizes(rng, p["order_size"], (P, n))
    v_buy, v_sell = n_buy * size_buy, n_sell * size_sell
    jumps = rng.random((P, n)) < float(p["jump_prob"])
    jump = np.where(jumps, rng.choice([-1.0, 1.0], size=(P, n)) * float(p["jump_size"]), 0.0)
    eps = rng.standard_normal((P, n)) * float(p["sigma"])
    fair = np.empty((P, n + 1))
    fair[:, 0] = p["mid0"]
    th, mu, imp = float(p["theta"]), float(p["mid0"]), float(p["impact"])
    for t in range(n):
        fair[:, t + 1] = fair[:, t] + th * (mu - fair[:, t]) + eps[:, t] + jump[:, t] + imp * (v_buy[:, t] - v_sell[:, t])
    noise = rng.standard_normal((P, n + 1)) * float(p["noise"])
    mid = fair + noise
    return dict(fair=fair, mid=mid, n_buy=n_buy, n_sell=n_sell, size_buy=size_buy, size_sell=size_sell, params=p)


def simulate(params=None, n_ticks=30_000, rng=None, n_paths=1, market=None):
    """Run the maker over ``n_paths`` independent sessions of ``n_ticks`` ticks (vectorised over sessions).

    Returns a dict: pnl (P,), pnl_path (P, n+1), inventory (P, n+1), decomposition (dict of (P,) arrays:
    spread_capture, adverse_selection, inventory_risk, overtrading), share_inside_79 (P,), trades (P,) fills,
    takes (P,), fill_rate (P,), max_drawdown (P,), units (P,), mid (P, n+1), params, and the means
    (pnl_mean, share_inside_79_mean, ...)."""
    rng = np.random.default_rng() if rng is None else rng
    mk = market if market is not None else generate_market(params, n_ticks, rng, n_paths)
    p = dict(mk["params"])
    p.update(params or {})
    mid, n_buy, n_sell = mk["mid"], mk["n_buy"], mk["n_sell"]
    size_buy, size_sell = mk["size_buy"], mk["size_sell"]
    P, n = n_buy.shape
    H = int(p["horizon"])
    h, qmax, kappa = float(p["half_spread"]), float(p["q_max"]), float(p["decay"])
    alpha = float(p["ewma_alpha"])
    qp = dict(h=h, q_max=qmax, inventory_limit=p["inventory_limit"], risk_aversion=p["risk_aversion"],
              mode=p["skew"], bands=p["bands"], base_size=p["base_size"])
    taking, thr, tsize = bool(p["taking"]), float(p["take_threshold"]), float(p["take_size"])
    liq = float(p["liquidation_size"])

    q = np.zeros(P)
    cash = np.zeros(P)
    f = mid[:, 0].copy()
    inv = np.zeros((P, n + 1))
    pnl_path = np.zeros((P, n + 1))
    spread_capture = np.zeros(P)
    overtrading = np.zeros(P)
    adverse = np.zeros(P)
    liquidation = np.zeros(P)
    hold = np.zeros(P)
    fills = np.zeros(P)
    takes = np.zeros(P)
    forced = np.zeros(P)
    units = np.zeros(P)
    for t in range(n):
        s = mid[:, t]
        s_fwd = mid[:, min(t + H, n)]
        f = alpha * s + (1 - alpha) * f
        # 0. hard control: at the hard limit the risk manager flattens a chunk at the touch (NB-01 §8)
        if liq > 0:
            at_top = q >= qmax
            v = np.where(at_top, np.minimum(q, liq), 0.0)
            cash += v * (s - h)
            q -= v
            liquidation += v * h
            adverse += v * (s_fwd - s)
            forced += at_top
            at_bot = q <= -qmax
            v = np.where(at_bot, np.minimum(-q, liq), 0.0)
            cash -= v * (s + h)
            q += v
            liquidation += v * h
            adverse += v * (s - s_fwd)
            forced += at_bot
        # 1. the taking layer: rare, high-threshold, inventory-reducing (NB-01 §5)
        if taking:
            buy = (q < 0) & (s + h <= f - thr)
            v = np.where(buy, np.minimum(-q, tsize), 0.0)
            cash -= v * (s + h)
            q += v
            overtrading += v * h
            adverse += v * (s - s_fwd)
            takes += buy
            units += v
            sell = (q > 0) & (s - h >= f + thr)
            v = np.where(sell, np.minimum(q, tsize), 0.0)
            cash += v * (s - h)
            q -= v
            overtrading += v * h
            adverse += v * (s_fwd - s)
            takes += sell
            units += v
        # 2. quotes around the fair estimate with the inventory skew and the limit rule
        bid, ask = AS.quote(f, q, qp)
        bsize, asize = AS.quote_sizes(q, qp)
        # 3. passive fills: each market sell walks to our bid with probability e^{-kappa * delta}
        d_b = np.where(np.isnan(bid), np.inf, np.maximum(s - bid, 0.0))
        p_b = np.where(np.isfinite(d_b), np.exp(-kappa * d_b), 0.0)
        hits = rng.binomial(n_sell[:, t], p_b)
        fill_b = np.minimum(hits * size_sell[:, t], np.minimum(bsize, qmax - q))
        fill_b = np.where(np.isnan(bid), 0.0, fill_b)
        price_b = np.where(np.isnan(bid), 0.0, bid)
        cash -= fill_b * price_b
        q += fill_b
        spread_capture += fill_b * (s - price_b)
        adverse += fill_b * (s - s_fwd)
        fills += fill_b > 0
        units += fill_b
        d_a = np.where(np.isnan(ask), np.inf, np.maximum(ask - s, 0.0))
        p_a = np.where(np.isfinite(d_a), np.exp(-kappa * d_a), 0.0)
        hits = rng.binomial(n_buy[:, t], p_a)
        fill_a = np.minimum(hits * size_buy[:, t], np.minimum(asize, qmax + q))
        fill_a = np.where(np.isnan(ask), 0.0, fill_a)
        price_a = np.where(np.isnan(ask), 0.0, ask)
        cash += fill_a * price_a
        q -= fill_a
        spread_capture += fill_a * (price_a - s)
        adverse += fill_a * (s_fwd - s)
        fills += fill_a > 0
        units += fill_a
        # 4. carry the inventory over the tick
        ds = mid[:, t + 1] - s
        hold += q * ds
        inv[:, t + 1] = q
        pnl_path[:, t + 1] = cash + q * mid[:, t + 1]
    if p.get("close_out", True):                      # inventory at close × mark-to-market loss (eq. nb-profit)
        liquidation += np.abs(q) * h
        pnl_path[:, n] -= np.abs(q) * h
    pnl = cash + q * mid[:, n] - (np.abs(q) * h if p.get("close_out", True) else 0.0)
    inventory_risk = -hold - adverse
    inventory_cost = inventory_risk + liquidation
    peak = np.maximum.accumulate(pnl_path, axis=1)
    mdd = np.max(peak - pnl_path, axis=1)
    share = np.mean(np.abs(inv) <= 79, axis=1)
    out = dict(pnl=pnl, pnl_path=pnl_path, inventory=inv, mid=mid, fair=mk["fair"],
               decomposition=dict(spread_capture=spread_capture, adverse_selection=adverse,
                                  inventory_cost=inventory_cost, overtrading=overtrading,
                                  inventory_risk=inventory_risk, liquidation=liquidation),
               share_inside_79=share, trades=fills, takes=takes, forced=forced, units=units,
               fill_rate=fills / n, max_drawdown=mdd, inventory_at_close=q, params=p)
    out.update(pnl_mean=float(pnl.mean()), share_inside_79_mean=float(share.mean()),
               max_drawdown_mean=float(mdd.mean()), fill_rate_mean=float(out["fill_rate"].mean()),
               takes_mean=float(takes.mean()))
    return out


def tuning_grid(params=None, n_ticks=30_000, seed=0, n_paths=1,
                risk_aversions=(0.3, 0.5, 0.7, 1.0), inventory_limits=(40, 60, 80), target_share=0.99):
    """The grid of NB-01 §8: risk_aversion (skew multiplier m) × inventory_limit (soft one-sided quoting
    limit); each cell records total_pnl, max_drawdown, fill_rate and the share of ticks with |q| ≤ 79.
    ``best`` is the lowest risk aversion whose share reaches ``target_share`` (ties: the higher PnL);
    if no cell reaches it, the cell with the highest share.  Common random numbers across cells."""
    cells = []
    for m in risk_aversions:
        for lim in inventory_limits:
            rng = np.random.default_rng(seed)
            pr = dict(params or {})
            pr.update(risk_aversion=m, inventory_limit=lim, skew="linear")
            r = simulate(pr, n_ticks, rng, n_paths)
            cells.append(dict(risk_aversion=m, inventory_limit=lim, total_pnl=r["pnl_mean"],
                              max_drawdown=r["max_drawdown_mean"], fill_rate=r["fill_rate_mean"],
                              share_inside_79=r["share_inside_79_mean"]))
    ok = [c for c in cells if c["share_inside_79"] >= target_share]
    if ok:
        best = sorted(ok, key=lambda c: (c["risk_aversion"], -c["total_pnl"]))[0]
    else:
        best = max(cells, key=lambda c: (c["share_inside_79"], c["total_pnl"]))
    return dict(cells=cells, best=best)
