"""tmrw_lab — the test bench of the Collected Framework (Tomorrow Capital Research)."""
__version__ = "0.1.0"
