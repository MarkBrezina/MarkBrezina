# Test bench report

preset: `quick`  offline: `False`  seed: `20261106`

## exact

### The exact layer, checked to rounding error

`experiments.exact_layer` — data: analytic, 1.23 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| exact.konig.residual | 1.631e-16 | 0 |  | match | AT-III Thm 3.1 / AT-II Thm 3.4 |
| exact.phi.excess_over_one | 0 | 0 |  | match | AT-III Thm 3.1 |
| exact.kappa.excess_over_phi2 | 0 | 0 |  | match | AT-III Thm 3.1 |
| exact.kappa.below_zero | 0 | 0 |  | match | AT-III Thm 3.1 |
| exact.hierarchy.additive_mismatch | 2.41e-16 | 0 |  | match | AT-II Prop 3.1 |
| exact.hierarchy.psi2_identity_residual | 1.11e-16 | 0 |  | match | AT-III Thm 3.2 |
| exact.hierarchy.psi2_excess_over_one | 0 | 0 |  | match | AT-III Thm 3.2 |
| exact.hierarchy.internal_share_decrease | 0 | 0 |  | match | AT-II Thm 3.6 |
| exact.hierarchy.factor_excess | 0 | 0 |  | match | AT-III Thm 3.4 |
| exact.cascade.speed_product_residual | 0 | 0 |  | match | AT-III Thm 3.4 |
| exact.cascade.energy_product_residual | 0 | 0 |  | match | AT-III Thm 3.4 |
| exact.hierarchy.kappa_excess_over_phi2 | 0 | 0 |  | match | AT-III Thm 3.1 |
| exact.cascade.snapshot_residual | 0 | 0 |  | match | AT-III Thm 3.4 |
| exact.cascade.snapshot_factor_excess | 0 | 0 |  | match | AT-III Thm 3.4 |
| exact.turbulence.identity_residual | 2.776e-17 | 0 |  | match | AT-III Thm 3.2 |
| exact.turbulence.series_vs_formula | 2.776e-17 | 0 |  | match | AT-III Thm 3.2 |
| exact.turbulence.psi_excess_over_one | 0 | 0 |  | match | AT-III Thm 3.2 |
| exact.mean.residual | 3.469e-18 | 0 |  | match | AT-III Thm 3.3a |
| exact.jensen.violation | 0 | 0 |  | match | AT-III Thm 3.3b |
| exact.jensen.gap_over_half_variance | 0.9997 | 1 |  | match | AT-III Thm 3.3b (gap ≈ ½ Var_w log R) |
| exact.index.residual | 6.08e-16 | 0 |  | match | AT-II Cor 3.2 |
| exact.leftover.range_violation | 0 | 0 |  | match | AT-II Def 4.2 |
| exact.leftover.identity_residual | 1.11e-16 | 0 |  | match | AT-II Def 4.2 / Thm 3.6 |
| exact.mixture.residual | 2.22e-16 | 0 |  | match | AT-III Thm 3.5 |
| exact.mixture.bound_violation | 0 | 0 |  | match | AT-III Thm 3.5 |
| exact.squeezing.violation | 0 | 0 |  | match | AT-III Thm 3.6 |
| exact.squeezing.mc_share | 0.9252 | 0.6 – 1 |  | match | AT-III Thm 3.6 (share ≥ 1 − (a+b)/Δ) |
| exact.squeezing.limit_one | 7.812e-13 | 0 |  | match | AT-III Thm 3.6 |
| exact.linear_field.split_residual_3d | 3.884e-16 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.M_recovery_3d | 5.084e-16 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.V0_recovery_3d | 3.419e-16 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.expansion_residual_3d | 4.441e-16 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.share_sum_3d | 4.441e-16 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.split_residual_2d | 0 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.M_recovery_2d | 1.747e-16 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.V0_recovery_2d | 4.421e-17 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.expansion_residual_2d | 5.551e-17 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.share_sum_2d | 1.11e-16 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.oort_reconstruction | 1.041e-17 | 0 |  | match | AT-III Thm 3.7 |
| exact.linear_field.oort_K_is_expansion | 0 | 0 |  | match | AT-III Thm 3.7 |
| exact.mass.superadditivity_violation | 0 | 0 |  | match | AT-II Thm 3.7 |
| exact.mass.frame_invariance | 2.153e-16 | 0 |  | match | AT-II Thm 3.7 |
| exact.mass.equality_when_together | 0 | 0 |  | match | AT-II Thm 3.7 |
| exact.vol.subadditivity_violation | 0 | 0 |  | match | AT-II Thm 3.8 |
| exact.vol.gap_identity_residual | 4.441e-16 | 0 |  | match | AT-II Thm 3.8 |
| exact.vol.series_vs_formula | 0 | 0 |  | match | AT-II Thm 3.8 |
| exact.virial.kepler_residual | 0 | 0 |  | match | AT-III Known 3.9 |
| exact.virial.kepler_2K_plus_U | 0 | 0 |  | match | AT-II Known 3.9 |
| exact.virial.kepler_sign | -1 | -1 |  | match | AT-III Known 3.9 (bound: lighter) |
| exact.virial.harmonic_residual | 2.265e-16 | 0 |  | match | AT-III Known 3.9 |
| exact.virial.harmonic_sign | 1 | 1 |  | match | AT-III Known 3.9 (confined: heavier) |
| exact.lumping.supply_demand_residual | 1.256e-15 | 0 |  | match | AT-0 Sec. U (CA = BC) |
| exact.lumping.supply_demand_B | -3 | -3 |  | match | AT-0 Sec. U (B = −3) |
| exact.lumping.supply_demand_same_future | 2.387e-15 | 0 |  | match | AT-0 Sec. U.1 |
| exact.lumping.supply_demand_closed_form | 5.398e-15 | 0 |  | match | AT-0 Sec. U (y = 2e^{−3t}) |
| exact.lumping.counterexample_false_closure | 0 | 0 |  | match | AT-0 Sec. V |
| exact.lumping.counterexample_residual | 0.7071 | 0.707107 |  | match | AT-0 Sec. V (CA = [−1 2] vs [b −b]) |
| exact.lumping.counterexample_ydot_state1 | 1 | 1 |  | match | AT-0 Sec. V |
| exact.lumping.counterexample_ydot_state2 | 46 | 46 |  | match | AT-0 Sec. V |
| exact.lumping.sine_residual | 1 | 1 |  | match | AT-0 Sec. S.2 (CA = [0 1] vs [b 0]) |
| exact.lumping.sine_second_order | 0 | 0 |  | match | AT-0 Sec. S.2 (ÿ = −y) |
| exact.lumping.rotation_dynamics | 0 | 0 |  | match | AT-0 Sec. S (ż = A_rot z) |
| exact.lumping.rotation_no_real_line | 0 | 0 |  | match | AT-0 Sec. S.1 |
| exact.lumping.random_lumpable_residual | 2.151e-16 | 0 |  | match | AT-0 Thm W.1 |
| exact.lumping.random_lumpable_flag | 0 | 0 |  | match | AT-0 Thm W.1 |
| exact.lumping.random_lumpable_drift | 5.884e-15 | 0 |  | match | AT-0 Sec. W.2 (Ce^{At} = e^{Bt}C) |
| exact.lumping.random_nonlumpable_false_closure | 0 | 0 |  | match | AT-0 Thm W.1 |
| exact.lumping.markov_residual | 5.551e-17 | 0 |  | match | Kemeny–Snell strong lumpability (AT-0 Thm W.1 with A = Pᵀ) |
| exact.lumping.markov_recovery | 7.85e-17 | 0 |  | match | Kemeny–Snell strong lumpability |
| exact.contest.conservation | 8.882e-16 | 0 |  | match | AT-0 Prop I.2 |
| exact.epps.kappa_inf | 0.8 | 0.8 |  | match | AT-II Hyp 4.3 (planted 0.8) |
| exact.epps.tau | 5 | 5 | s | match | AT-II Hyp 4.3 (planted 5 s; Fig. 1b τ ≈ 5 s) |
| exact.epps.kappa_inf_noisy | 0.8012 | 0.8 |  | match | AT-II Hyp 4.3 (1% noise) |
| exact.epps.tau_noisy | 5.006 | 5 | s | match | AT-II Hyp 4.3 (1% noise) |

- hierarchy capped at N=200 units x T=1000 steps (the Ψ² identity needs an N×N correlation matrix)
- 74/74 numbers match; hierarchy N=200, T=1000, levels=3 with group counts [200, 34, 6, 1]; Ψ² at the unit level 0.166 (N_eff=78.5, ρ̄=0.155)
- virial averages use the exact Kepler orbit sampled uniformly in time (eccentric anomaly) and an anisotropic harmonic orbit; the planted linear field has its internal motion projected to satisfy the normal equations so M and V0 are recovered exactly

![exact_layer](figures/exact_layer.png)

## hindsight

### P1 on societies: counties, countries, metros

`experiments.society` — data: real, 1.28 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| society.covid_us.kappa | 0.3209 | 0.116 |  | differs | AT-III Table 3 |
| society.covid_us.phi | 0.7033 | 0 – 1 |  | match | AT-III Thm 3.1 |
| society.covid_us.Psi2 | 0.3888 | 0 – 1 |  | match | AT-III Thm 3.2 |
| society.covid_us.turbulence_identity_residual | 5.551e-17 | 0 |  | match | AT-III Thm 3.2: Psi^2 = H + (1-H) rho_bar |
| society.covid_us.N_eff | 66.58 |  |  | measured |  |
| society.covid_us.mean_residual | 0 | 0 |  | match | AT-III Thm 3.3 |
| society.covid_us.jensen_gap | 0.1566 | 0 – 10 |  | match | AT-III Thm 3.3 |
| society.covid_us.kappa_groups_to_top | 0.5481 |  |  | measured |  |
| society.world_gdp.kappa | 0.4139 | 0.402 |  | match | AT-III Table 3 |
| society.world_gdp.phi | 0.7074 | 0 – 1 |  | match | AT-III Thm 3.1 |
| society.world_gdp.Psi2 | 0.3267 | 0 – 1 |  | match | AT-III Thm 3.2 |
| society.world_gdp.turbulence_identity_residual | 5.551e-17 | 0 |  | match | AT-III Thm 3.2: Psi^2 = H + (1-H) rho_bar |
| society.world_gdp.N_eff | 16.55 |  |  | measured |  |
| society.world_gdp.mean_residual | 0 | 0 |  | match | AT-III Thm 3.3 |
| society.world_gdp.jensen_gap | 0.003706 | 0 – 10 |  | match | AT-III Thm 3.3 |
| society.world_gdp.kappa_groups_to_top | 0.6007 |  |  | measured |  |
| society.case_shiller.kappa | 0.727 | 0.727 |  | match | AT-III Table 3 |
| society.case_shiller.phi | 0.8674 | 0 – 1 |  | match | AT-III Thm 3.1 |
| society.case_shiller.Psi2 | 0.7237 | 0 – 1 |  | match | AT-III Thm 3.2 |
| society.case_shiller.turbulence_identity_residual | 5.551e-16 | 0 |  | match | AT-III Thm 3.2: Psi^2 = H + (1-H) rho_bar |
| society.case_shiller.N_eff | 7.442 |  |  | measured |  |
| society.case_shiller.mean_residual | 0 | 0 |  | match | AT-III Thm 3.3 |
| society.case_shiller.jensen_gap | 2.695e-05 | 0 – 10 |  | match | AT-III Thm 3.3 |
| society.case_shiller.kappa_groups_to_top | 0.8807 |  |  | measured |  |

- covid_us: real data
- world_gdp: real data
- case_shiller: synthetic data (planted answer: the units' dispersion is scaled to the AT-III kappa)
- velocity = growth of the level, weight = last period's level; kappa, phi summed over time (AT-III Table 2)
- counties: NYT 2020 file, weekly new cases, growth of the weekly level; AT-III's county run (kappa = 0.116) used its own period and binning, so the real-data value here is a fresh measurement, not a replication

![society](figures/society.png)

### P2/P3 on a gas, a beam and an epidemic wave

`experiments.gas_beam` — data: real, 1.34 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| gas.energy_conservation_rel | 2.356e-16 | 0 |  | match | AT-III Sec. 6.2: 1.11e-16 |
| gas.kappa_initial | 0.9195 | 0.5 – 1 |  | match | started with a collective drift |
| gas.kappa_final | 0.0005161 | 0 – 0.05 |  | match | AT-III Sec. 6.2: collective motion becomes heat |
| beam.mixture_r2 | 0.9998 | 1 |  | match | AT-III Sec. 5: 1.0000 |
| beam.squeezed_share_fine | 0.01291 | 0 – 0.2 |  | match | AT-III Thm 3.6 |
| beam.squeezed_share_coarse | 0.9838 | 0.9 – 1 |  | match | AT-III Thm 3.6 |
| beam.bound_holds | 1 | 1 |  | match |  |
| waves.mixture_r2 | 0.9975 | 0.992 |  | match | AT-III Sec. 5 (first US wave) |
| waves.squeezed_share_daily | 0.02468 | 0.01 |  | match | AT-III Table 4: 0.01 (daily bins) |
| waves.squeezed_share_yearly | 1 | 0.93 |  | match | AT-III Table 4: 0.93 (yearly bins) |

- gas: 400 hard discs; beam: 200 particles with gamma lags; wave: real county data

![gas_beam](figures/gas_beam.png)

### P3: nuclei, hadrons and four-lepton events

`experiments.nuclei_hadrons` — data: real, 1.72 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| nuclei.n_total | 2939 |  |  | measured | real isotope masses |
| nuclei.share_lighter | 1 | 1 |  | match | AT-III Sec. 6.1: all 2,938 nuclei |
| nuclei.n_lighter | 2939 |  |  | measured |  |
| nuclei.binding_per_nucleon_max_MeV | 8.795 | 8.8 |  | match | AT-III: peak near 56Fe / 62Ni (8.79 MeV) |
| nuclei.hydrogen_binding_eV | 13.6 | 13.6 | eV | match | AT-III Sec. 6.1 |
| hadrons.n | 15 | 15 |  | match | AT-III: 15 hadrons |
| hadrons.share_heavier | 1 | 1 |  | match | AT-III Sec. 6.1 |
| hadrons.mass_over_quarks_min | 5.074 | 1 – 1e+09 |  | match |  |
| atlas.n_events | 832 | 832 |  | match | AT-III Sec. 6.1 (synthetic stand-in) |
| atlas.share_whole_ge_parts | 1 | 1 |  | match | AT-III: 832/832 |
| atlas.median_gap | 0.172 | 0.172 |  | match | AT-III: median 0.172 (planted) |
| free.min_mass_gap_rel | 0.00361 | 0 – 1 |  | match | AT-II Thm 3.7 |

- nuclei from real, hadrons from real; four-lepton events synthetic (CERN open data not reachable)

![nuclei_hadrons](figures/nuclei_hadrons.png)

### B: expansion, bulk flow and the stellar hierarchy

`experiments.expansion` — data: real, 0.25 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| expansion.H0 | 72.86 | 73.25 | km/s/Mpc | match | AT-III Sec. 7.2: 73.25 +/- 1.40 |
| expansion.chi2_const_rate | 13.13 | 0 – 16.8 |  | match | AT-III: 5.7 for 6 dof (16.8 = 99% point; peculiar-velocity floor 250 km/s here instead of the gravity-model correction) |
| expansion.dof | 6 | 6 |  | match | AT-III: 6 distance bins |
| expansion.n_sne | 496 |  |  | measured | Pantheon+ (real) |
| expansion.bulk_flow_kms | 291.5 | 290 | km/s | match | AT-III Sec. 7.3 (planted) |
| expansion.rate_from_split_rel_err | 0.00879 | 0 |  | match | AT-III Thm 3.7 |
| expansion.split_shares_sum | 1 | 1 |  | match | exact split (cross terms vanish in the least-squares split) |
| gaia.internal_share_level1 | 0.6513 | 0.63 |  | match | AT-III Sec. 7.3: 0 -> 0.63 -> 0.77 -> 0.80 (planted) |
| gaia.internal_share_level2 | 0.752 | 0.77 |  | match | AT-III Sec. 7.3: 0 -> 0.63 -> 0.77 -> 0.80 (planted) |
| gaia.internal_share_level3 | 0.8562 | 0.8 |  | match | AT-III Sec. 7.3: 0 -> 0.63 -> 0.77 -> 0.80 (planted) |
| gaia.upsilon_open_clusters_median | 2.456 | 1 – 5 |  | match | AT-III Table 6: 1-5 |
| gaia.upsilon_field_groups_median | 7.011e+04 | 10000 – 1e+06 |  | match | AT-III Table 6: ~1e5 |

- Pantheon+: real; local-volume split and stellar hierarchy synthetic with planted answers

![expansion](figures/expansion.png)

### D: zeros of the zeta function as cancellation of units

`experiments.zeta` — data: analytic, 2.04 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| zeta.height_T | 2000 |  |  | measured | AT-III ran to 10^6 (full preset) |
| zeta.n_zeros_found | 1507 | 1507 |  | match | exact count (mpmath.nzeros) |
| zeta.n_zeros_smooth | 1508 |  |  | measured | Riemann-von Mangoldt |
| zeta.missing | 0 | 0 |  | match | AT-III Sec. 9.2: missing 0 |
| zeta.share_on_line | 1 | 1 |  | match | AT-III: all zeros on the critical line (counted) |
| zeta.units_at_mid_zero | 13 |  |  | measured |  |
| zeta.partial_sum_at_zero_over_amplitude | 2.168e-11 | 0 |  | match | units cancel at a zero |
| zeta.gue_ks | 0.04454 | 0 – 0.1 |  | match | AT-III Sec. 9.2: GUE statistics |
| zeta.spacing_var | 0.1468 | 0.18 |  | match | GUE Wigner surmise: variance 3pi/8 - 1 = 0.178 |

- 1507 zeros on [50, 2000] against the exact count 1507 (smooth 1507.6); grid step 0.182; a check, not a proof

![zeta](figures/zeta.png)

### C: index and basket aggregation (stocks, coins)

`experiments.markets` — data: synthetic, 1.13 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| markets.sp500.additive_mismatch | 0 | 0 |  | match | AT-II Cor 3.2 |
| markets.sp500.kappa | 0.3 | 0.2 – 0.4 |  | match | AT-III Sec. 8.2 / AT-II Tab. 3: 0.2-0.4 |
| markets.sp500.phi | 0.6033 | 0 – 1 |  | match | AT-III Thm 3.1 |
| markets.sp500.sigma_ratio | 0.6237 | 0.6 – 0.75 |  | match | AT-III Sec. 8.2: 0.6-0.75 |
| markets.sp500.Psi2 | 0.3801 | 0 – 1 |  | match | AT-III Thm 3.2 |
| markets.sp500.turbulence_identity_residual | 0 | 0 |  | match |  |
| markets.sp500.N_eff | 13.06 |  |  | measured |  |
| markets.sp500.rho_bar | 0.3286 |  |  | measured |  |
| markets.sp500.jensen_gap | 9.2e-05 | 0 – 1 |  | match | AT-III Thm 3.3 |
| markets.sp500.leftover_share | 0.7 |  |  | measured | AT-II Def 4.1: internal share of squared returns |
| markets.crypto.kappa_shortest_bar | 0.1484 |  |  | measured | bar 1 s (synthetic) |
| markets.crypto.kappa_5min | 0.775 | 0.75 – 0.85 |  | match | AT-III: rising to ~0.8 |
| markets.crypto.kappa_rises | 1 | 1 |  | match | AT-II Hyp 4.4 |
| markets.crypto.epps_tau_s | 4.213 | 1 – 10 | s | match | AT-II: tau ~ 5 s (fitted) |
| markets.crypto.kappa_inf | 0.7347 | 0.7 – 0.9 |  | match | AT-II: 0.813 |

- stocks: synthetic (30 names, 2520 days); coins: synthetic (10 coins at 1 s)

![markets](figures/markets.png)

### C at the order book: OFI, microprice, memory, impact

`experiments.order_book` — data: synthetic, 0.82 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| order_book.ofi_beta_1s | 0.04619 | 0 – 1e+09 |  | match | AT-II eq. OFI: beta > 0 |
| order_book.ofi_r2_1s | 0.268 | 0.5 – 1 |  | differs | AT-II Known 5.2 / Cont-Kukanov-Stoikov: R^2 ~ 0.6 at 1 s |
| order_book.ofi_beta_10s | 0.02736 | 0 – 1e+09 |  | match | AT-II eq. OFI: beta > 0 |
| order_book.ofi_r2_10s | 0.164 | 0.2 – 1 |  | differs | AT-II Known 5.2 / Cont-Kukanov-Stoikov: R^2 ~ 0.6 at 1 s |
| order_book.ofi_beta_60s | 0.005728 | 0 – 1e+09 |  | match | AT-II eq. OFI: beta > 0 |
| order_book.ofi_r2_60s | 0.02551 | 0.2 – 1 |  | differs | AT-II Known 5.2 / Cont-Kukanov-Stoikov: R^2 ~ 0.6 at 1 s |
| order_book.mid_over_microprice_100ms | 1.346 | 2 – 1e+06 |  | differs | AT-II Tab. 3 / AT-III Sec. 8.2: far above 1 for BTC |
| order_book.mid_over_microprice_1s | 2.641 |  |  | measured |  |
| order_book.mid_over_microprice_10s | 3.37 |  |  | measured |  |
| order_book.mid_over_microprice_60s | 2.981 | 1 |  | differs | AT-III: flat (~1) after seconds |
| order_book.sign_hurst | 0.775 | 0.85 |  | match | AT-II Table 1: H ~ 0.85-0.9 (planted 0.85) |
| order_book.sign_acf_gamma | 0.4269 | 0.5 |  | match | AT-II Known 5.7: gamma ~ 0.5 |
| order_book.impact_exponent | 0.5669 | 0.5 |  | match | AT-II Known 5.6: 1/2 (planted per-trade sqrt(size)) |
| order_book.impact_Y | 1.866 |  |  | measured |  |
| order_book.potential_depth | 26.2 |  |  | measured | AT-II Sec. 5.3: U = -D log rho |
| order_book.propagator_G1 | 1.616 | 0 – 1e+09 |  | match | AT-II Known 5.7 |

- the level-1 events are a synthetic stand-in (no level-1 history is reachable): the OFI R^2 and the mid/microprice ratios test the measurement path, not BTC; the AT-III expectations are kept for the real run
- events: synthetic (60000 events over 19124 s); Binance level-1 history is not available, trade sizes synthetic

![order_book](figures/order_book.png)

## refuted

### The Bitcoin study as a special case (refuted hypothesis restored)

`experiments.bitcoin_restoration` — data: synthetic, 0.54 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| bitcoin.hurst_returns | 0.4155 | 0 – 0.5 |  | match | AT-0 / earlier run: 0.159 (mean reverting: H < 0.5) |
| bitcoin.halflife_steps | 8.415 | 5 | min | match | AT-0: ~5 steps |
| bitcoin.rank_ic_1 | -0.03927 | -0.15 – -0 |  | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_5 | -0.06443 | -0.15 – -0 |  | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_10 | -0.07456 | -0.15 – -0 |  | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_30 | -0.09227 | -0.15 – -0 |  | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_60 | -0.08763 | -0.15 – -0 |  | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.rank_ic_100 | -0.1179 | -0.15 – -0 |  | match | AT-III Sec. 10: -0.035 .. -0.087 (reversal) |
| bitcoin.decile_reversal_1 | 0.000298 | 0 – 1 |  | match | bottom minus top decile future return > 0 |
| bitcoin.reversal_bp_per_trade | 4.016 | 0 – 10 |  | match | AT-III Sec. 10: 0.3-3.3 bp vs 10 bp cost |
| bitcoin.oos_sharpe_after_costs | -62.98 | -1e+06 – 0 |  | match | below costs |
| bitcoin.n_bars | 2999 |  |  | measured | synthetic |

- AT-0 Hypothesis 9.1 as stated is refuted: the aggregate mean is preserved; what aggregation lowers is turbulence. The restoration places the study inside P1: a short-lived internal motion (mean reversion) below the cost of trading it.
- bars: synthetic; horizons (1, 5, 10, 30, 60, 100); walk-forward split at the midpoint; 10 bp round-trip

![bitcoin_restoration](figures/bitcoin_restoration.png)

## conjectures

### Toy models for Conjectures 1-5

`experiments.conjecture_toys` — data: simulation, 0.89 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| c1.gain_timely | 0.00875 | 0 – 1e+09 |  | match | C1: switching in time beats either fixed path |
| c1.gain_lagged | -0.004609 | -1e+09 – 0 |  | match | C1: switching late loses |
| c1.breakeven_lag | 49.51 | 0 – 100 | steps | match | C1: the lag beyond which switching stops paying (regime duration) |
| c2.alpha_hat | 0.5938 | 0.6 |  | match | C2: P_{T+1} = alpha I + (1-alpha) H + eps (planted alpha) |
| c2.alpha_tstat | 161.9 | 3 – 1e+09 |  | match | C2: alpha significant |
| c2.r2 | 0.3631 |  |  | measured |  |
| c2.coverage_band | 0.9051 | 0.85 – 1 |  | match | C2: 1 - delta coverage of the conformal band (delta = 0.1) |
| c2.rmse_ratio_vs_random_walk | 0.8862 | 0 – 1 |  | match | C2: beats the random walk |
| c2.n_assets | 30 | 4 – 1e+09 |  | match | C2: N > 3 |
| c3.cost_equal | 1492 |  |  | measured |  |
| c3.cost_front | 1921 |  |  | measured |  |
| c3.cost_equal_over_front | 0.7767 | 0 – 1 |  | match | C3: equal split cheapest under the symmetric cost |
| c3.optimal_n | 55 | 1 – 100 |  | match | C3: N <= N_max = 100 |
| c3.sqrt_exponent_check | 0.5002 | 0.5 |  | match | C3: g(x) ~ c sqrt(x) |
| c3.q_usd | 1e+06 | 1e+06 |  | match | C3: Q = 1,000,000 USD |
| c4.exploitability_final | 1.784e-11 | 0 |  | match | C4: equilibrium exists (exploitability -> 0) |
| c4.iterations_to_converge | 33 | 1 – 500 |  | match |  |
| c4.fixed_point_residual | 5.372e-11 | 0 |  | match |  |
| c4.jump_flux | 0.0004789 |  |  | measured | mass crossing the guard per step (hybrid reset map) |
| c5.utility_optimal | 0.01746 |  |  | measured |  |
| c5.utility_naive | 0.007453 |  |  | measured |  |
| c5.improvement | 0.01001 | 0 – 1e+09 |  | match | C5: highest expected utility under shared limits beats naive |
| c5.limits_respected | 1 | 1 |  | match | C5: shared limits |
| c5.free_energy_optimal | 0.006532 | 0 – 0.00826715 |  | match | C5: minimise free energy (risk) -- at or below the naive allocation's |

- c1: C1 path switching: two alternating regimes with regime-optimal parameter vectors θ¹, θ²; the mixed path θ_t = (1 − w_t)θ¹ + w_tθ² follows a hysteresis switch on a noisy regime signal lagged by L steps with a linear ramp; realised utility (P&L − risk charge − transaction costs) of the switched path against the better fixed path as a function of L. Expected: gain > 0 for a timely switch, < 0 once the lag exceeds the regime half-life h = D/2.
- c2: C2 central pricing: a panel of N > 3 assets with P_{t+1} = α I_t + (1 − α) H_t + ε, I_t = P_t + β q_t linear in the signed flow, H_t the mean of the last H ≥ 5 prices; α recovered by pooled OLS (α̂, t-statistic, R²), split-conformal 5-step regions with coverage checked against 1 − δ, and the random-walk baseline.
- c3: C3 stealth execution: Q = 1e6 USD into N ≤ 100 children over V venues; child cost x·g(x) = c x^{3/2} from the square-root footprint g(x) = c√x, base cost k·Q and a timing penalty λ per slot; equal vs front-loaded vs random splits, the optimal N under the penalty, and the fitted exponent δ of the per-unit cost (expected 0.5).
- c4: C4 hybrid MFG: 2 modes × M grid states with logit policies on soft Q-values, a crowding mean-field reward and a guard-triggered reset map between modes; damped best-response iteration to the mean-field equilibrium; entropy-regularised exploitability, iterations to converge and the fixed-point residual (expected 0).
- c5: C5: maximise expected utility = return - cost - lambda*risk - gamma*grouping under shared limits (gross, per-product, risk budget); compare with naive proportional allocation.

![conjecture_toys](figures/conjecture_toys.png)

## practice

### Market making: skew, bands, taking, tuning (NB-01)

`experiments.market_making` — data: simulation, 3.7 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| mm.pnl_no_skew | 1389 |  | ticks | measured | NB-01 worked case |
| mm.share_inside_79_no_skew | 1 |  |  | measured | NB-01 |
| mm.pnl_linear_skew | 1368 |  | ticks | measured | NB-01 worked case |
| mm.share_inside_79_linear_skew | 1 |  |  | measured | NB-01 |
| mm.pnl_band_skew | 1366 |  | ticks | measured | NB-01 worked case |
| mm.share_inside_79_band_skew | 1 |  |  | measured | NB-01 |
| mm.pnl_linear_skew_taking | 1329 |  | ticks | measured | NB-01 worked case |
| mm.share_inside_79_linear_skew_taking | 1 |  |  | measured | NB-01 |
| mm.share_inside_79 | 1 | 0.99 – 1 |  | match | NB-01: inside +/-79 for 99% of the session (linear skew) |
| mm.taking_layer_pnl_rel_change | -0.02851 | -0.3 |  | match | NB-01: taking cut PnL 2,300 -> 1,600 (-30%) |
| mm.skew_vs_no_skew_pnl_rel_change | -0.01552 |  |  | measured |  |
| mm.decomposition_identity_residual | 1.273e-11 | 0 |  | match | NB-01 rule: PnL = spread capture - adverse selection - inventory cost - overtrading (exact) |
| mm.decomp_spread_capture | 1197 |  | ticks | measured |  |
| mm.decomp_adverse_selection | 157.9 |  | ticks | measured |  |
| mm.decomp_inventory_cost | -329 |  | ticks | measured |  |
| mm.decomp_overtrading | 0 |  | ticks | measured |  |
| mm.decomp_inventory_risk | -416.5 |  | ticks | measured |  |
| mm.decomp_liquidation | 87.5 |  | ticks | measured |  |
| mm.grid_best_risk_aversion | 0.3 | 0.3 – 1 |  | match | NB-01 grid [0.3, 0.5, 0.7, 1.0] |
| mm.grid_best_inventory_limit | 40 | 40 – 80 |  | match | NB-01 grid [40, 60, 80] |

- 4 sessions of 3000 ticks; variants share the same market path (common random numbers)
- the NB-01 absolute numbers (PnL 2,300 / 1,600) are from the note's own session; the bench compares the variants on its own synthetic market

![market_making](figures/market_making.png)

### Prosperity quoting rules on a synthetic feed (NB-02/03)

`experiments.prosperity` — data: simulation, 0.19 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| prosperity.pnl_stable | 4.382e+04 |  |  | measured | NB-03 (5 Apr 2025) reported ~3,500 on the competition feed; synthetic feed here, level not comparable |
| prosperity.pnl_drifting | 3.921e+04 |  |  | measured | NB-03 reported ~2,800; synthetic feed here |
| prosperity.note_pnl_stable_2025 | 3500 |  |  | measured | NB-03, 5 April 2025 (the competition's own feed) |
| prosperity.note_pnl_drifting_2025 | 2800 |  |  | measured | NB-03, 5 April 2025 |
| prosperity.stable_beats_drifting | 1 | 1 |  | match | NB-03: the fixed-fair product earns more |
| prosperity.limits_respected | 1 | 1 |  | match | position limit 50 |
| prosperity.takes | 1355 |  |  | measured |  |
| prosperity.makes | 3200 |  |  | measured |  |
| prosperity.ncskew_drift | -0.01827 |  |  | measured | Chen-Hong-Stein 2001 (NB-03) |
| prosperity.duvol_drift | -0.04463 |  |  | measured | Chen-Hong-Stein 2001 (NB-03) |

- 3000 ticks, two products (fixed-value and drifting), takes strictly inside fair, makes one tick inside the touch with the position penalty

![prosperity](figures/prosperity.png)

### Blueprints: stat-arb, trend ensemble, cost-aware allocation (NB-05/06/07)

`experiments.blueprints` — data: simulation, 0.52 s

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| statarb.hedge_ratio | 1.498 | 1.5 |  | match | planted beta = 1.5 |
| statarb.adf_t | -7.318 | -1e+09 – -3.34 |  | match | NB-05: Engle-Granger cointegration (5% critical value -3.34) |
| statarb.halflife_hat | 20.03 | 20 | bars | match | NB-05 (planted 20) |
| statarb.sharpe_oos | 1.538 |  |  | measured | z-score bands 2.0/0.5, 5 bp cost |
| statarb.trades | 129 |  |  | measured |  |
| trend.sharpe_oos | 3.142 | 0 – 1e+09 |  | match | NB-06: positive on trending regimes (synthetic) |
| trend.max_drawdown | 0.1456 |  | log-return | measured |  |
| trend.turnover | 0.1152 |  |  | measured |  |
| optimiser.improvement | 0.02859 | 0 – 1e+09 |  | match | NB-07 / C5: beats naive proportional allocation |
| optimiser.limits_respected | 1 | 1 |  | match |  |
| optimiser.utility | 0.043 |  |  | measured |  |
| optimiser.utility_naive | 0.01441 |  |  | measured |  |

- four horizon layers (NB-07): L1 micro (ms-s): order book, microprice, OFI, queue position; L2 intraday (min-h): mean reversion, pairs, market making inventory; L3 swing (days-weeks): trend ensemble, stat-arb baskets, vol regimes; L4 allocation (weeks-months): cost-aware allocation under shared limits (C5)
- 3000 bars; stat-arb pair with planted half-life 20; trend series with 6 alternating drift regimes; 30-asset allocation

![blueprints](figures/blueprints.png)

## hypotheses

### H1 Aggregation lowers the mean (AT-0 Hyp. 9.1 as stated)

`hypotheses.h01_mean_not_lowered` — data: simulation, 0.17 s, verdict: **refuted**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h1.mean_residual_max | 1.952e-18 | 0 |  | match | AT-III Thm 3.3 (mean preserved exactly) |
| h1.share_trials_mean_lowered | 0 | 0 |  | match | AT-0 Hyp. 9.1 predicts 1.0 |
| h1.jensen_gap_min | 2.502e-05 | 0 – 1 |  | match | AT-III Thm 3.3 (Jensen: whole's compound growth >= parts' mean) |
| h1.jensen_gap_mean | 5.543e-05 |  |  | measured |  |

- 20 panels of 200 units x 2000 steps, correlation drawn in [0, 0.9]
- The mean of the aggregate equals the weighted mean of the unit means to machine precision in every trial; compound growth of the whole is never below the weighted mean of the parts'. The hypothesis as stated (aggregation lowers the mean) is refuted; the corrected statement (aggregation lowers speed and turbulence, not the mean) is H2.

### H2 A universal speed factor such as one half (P1 as first stated)

`hypotheses.h02_no_universal_factor` — data: simulation, 0.27 s, verdict: **refuted**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h2.phi_min | 0.1363 | 0 – 1 |  | match | AT-III Thm 3.1 (phi <= 1) |
| h2.phi_max | 0.9338 | 0 – 1 |  | match | AT-III Thm 3.1 |
| h2.phi_range | 0.7975 | 0.3 – 1 |  | match | a universal factor would give range 0 |
| h2.kappa_le_phi2_violations | 0 | 0 |  | match | AT-III Thm 3.1 (kappa <= phi^2) |
| h2.turbulence_identity_max_residual | 4.441e-16 | 0 |  | match | AT-III Thm 3.2 (Psi^2 = H + (1-H) rho_bar) |
| h2.hindsight_kappa_spread | 0.611 | 0.611 |  | match | AT-III Table 3: kappa = 0.116 / 0.402 / 0.727 |
| h2.share_within_10pct_of_half | 0.0625 | 1 |  | differs | the 'one half' reading of P1 predicts 1.0 |

- phi, kappa and Psi vary across the simulated domains by more than the whole [0, 1] range allows a constant to explain; the hindsight collective shares of AT-III (0.116, 0.402, 0.727) span 0.61. The universal-factor reading is refuted; the bounds and the turbulence identity hold in every case.

### H3 The Epps effect is aggregation: kappa(Delta) = kappa_inf Delta/(Delta+tau)

`hypotheses.h03_epps_aggregation` — data: simulation, 0.54 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h3.tau_hat_s | 1.655 | 1 – 10 | s | match | AT-II Hyp 4.4: tau of a few seconds (fitted; the planted adjustment time is 5 s) |
| h3.planted_adjustment_time_s | 5 |  | s | measured |  |
| h3.kappa_inf_hat | 0.7597 | 0.8 |  | match | AT-II: rho_inf = 0.813 on ten coins (planted 0.8) |
| h3.fit_r2 | 0.9455 | 0.9 – 1 |  | match | functional form kappa_inf Delta/(Delta+tau) (approximate for an exponential response) |
| h3.monotone_share | 1 | 1 |  | match | kappa rises with Delta |
| h3.kappa_1s | 0.2984 |  |  | measured |  |
| h3.kappa_600s | 0.8203 |  |  | measured |  |

- 10 simulated coins at 1 s, 180000 s, first-order response with time constants ~ Exp(5 s); variance-based kappa on bars 1 s .. 600 s fitted by the Epps form (the fitted tau is a few times smaller than the adjustment time constant, as for an exponential response)

### H4 Impact is concave in size, I(Q) = Y sigma_d sqrt(Q/V_d)

`hypotheses.h04_sqrt_impact` — data: simulation, 0.0 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h4.exponent_linear_depth | 0.5048 | 0.5 |  | match | AT-II Known 5.6: delta = 1/2 (latent linear liquidity) |
| h4.exponent_constant_depth | 1.012 | 1 |  | match | control: constant depth gives linear impact |
| h4.r2_linear_depth | 0.9934 | 0.9 – 1 |  | match |  |
| h4.concavity_gap | 0.5074 | 0.5 |  | match | the concavity comes from liquidity growing with distance |

- 40 metaorders of size 1..1000 on a latent linear-liquidity book and on a constant-depth book; exponent from log I on log Q with intercept (Y) free

### H5 Price changes are linear in order-flow imbalance

`hypotheses.h05_ofi_law` — data: simulation, 0.08 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h5.beta_1s | 0.006276 | 0 – 1e+09 |  | match | AT-II eq. OFI: beta > 0 |
| h5.tstat_1s | 13.59 | 5 – 1e+09 |  | match |  |
| h5.r2_1s | 0.2358 | 0.2 – 1 |  | match | Cont-Kukanov-Stoikov: R^2 ~ 0.6 at short horizons |
| h5.beta_10s | 0.0156 | 0 – 1e+09 |  | match | AT-II eq. OFI: beta > 0 |
| h5.tstat_10s | 14.14 | 5 – 1e+09 |  | match |  |
| h5.r2_10s | 0.7752 | 0.2 – 1 |  | match | Cont-Kukanov-Stoikov: R^2 ~ 0.6 at short horizons |
| h5.beta_60s | 0.01874 | 0 – 1e+09 |  | match | AT-II eq. OFI: beta > 0 |
| h5.tstat_60s | 7.355 | 5 – 1e+09 |  | match |  |
| h5.r2_60s | 0.8712 | 0.2 – 1 |  | match | Cont-Kukanov-Stoikov: R^2 ~ 0.6 at short horizons |

- queue-reactive book, 60000 events (~600 s at 100 events/s); OFI and mid change per window, OLS with intercept

### H6 Mixture law and squeezing of event responses (P2)

`hypotheses.h06_mixture_squeezing` — data: simulation, 0.39 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h6.mixture_fit_r2_min | 0.9996 | 0.99 – 1 |  | match | AT-III Sec. 5: R^2 = 0.992, 0.993, 1.0000 |
| h6.mixture_fit_r2_mean | 0.9997 |  |  | measured |  |
| h6.bounds_hold_share | 1 | 1 |  | match | AT-III Thm 3.5 |
| h6.squeezed_share_fine_bin | 0.05549 | 0 – 0.3 |  | match | AT-III: 0.01 with daily bins |
| h6.squeezed_share_coarse_bin | 0.979 | 0.8 – 1 |  | match | AT-III: 0.93 with yearly bins |
| h6.squeezing_bound_holds_share | 1 | 1 |  | match | AT-III Thm 3.6 |

- 10 events, 200 units each, gamma lags, logistic unit response; mixture fitted with the lag distribution free

### H7 Bound 1/r composites are lighter than their parts; free and confined ones heavier

`hypotheses.h07_bound_free_composites` — data: real, 1.37 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h7.nuclei_n | 300 |  |  | measured | nuclear masses (real) |
| h7.nuclei_share_lighter | 1 | 1 |  | match | AT-III Sec. 6.1: all 2,938 nuclei lighter than their parts |
| h7.hydrogen_binding_eV | 13.6 | 13.6 | eV | match | AT-III Sec. 6.1 |
| h7.hadrons_share_heavier | 1 | 1 |  | match | AT-III Sec. 6.1: all 15 hadrons heavier than their quarks |
| h7.kepler_E_int_over_K | -1 | -1 |  | match | AT-III Known 3.9 (n = -1) |
| h7.free_pair_mass_gap_rel | 0.2 | 0 – 1 |  | match | AT-II Thm 3.7 (invariant mass superadditive) |

- nuclei: 300 isotopes from real; hadrons: 15 from real; Kepler and free pairs analytic

### H8 Expansion is one rate at all distances after the linear-field split

`hypotheses.h08_one_expansion_rate` — data: real, 0.01 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h8.H0 | 72.86 | 73.25 | km/s/Mpc | match | AT-III Sec. 7.2: 73.25 +/- 1.40 |
| h8.chi2_one_rate | 13.13 | 0 – 16.8 |  | match | AT-III: chi^2 = 5.7 for 6 dof (16.8 = 99% point; velocity floor 250 km/s instead of the gravity-model correction) |
| h8.n_sne | 496 |  |  | measured | Pantheon+ (real), 0.023 < z < 0.15 |
| h8.split_bulk_flow_kms | 291.5 | 290 | km/s | match | AT-III Sec. 7.3: bulk flow 290 km/s (planted) |
| h8.split_expansion_rel_err | 0.00879 | 0 |  | match | AT-III Thm 3.7: expansion = trace of the linear field |
| h8.split_internal_share | 0.08082 |  |  | measured |  |

- Hubble rate per supernova from the distance modulus with the first-order kinematic correction; six distance bins; chi^2 of the binned rates against the pooled rate

### H9 Zeros of Z(t) as cancellation of units; GUE spacings

`hypotheses.h09_zeta_aggregate` — data: analytic, 4.85 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h9.height_T | 2000 |  |  | measured |  |
| h9.n_zeros_found | 1507 | 1507 |  | match | exact count mpmath.nzeros(T) - nzeros(50) |
| h9.n_zeros_smooth_count | 1508 |  |  | measured | Riemann-von Mangoldt N(T) - N(50) |
| h9.missing | 0 | 0 |  | match | AT-III Sec. 9.2: missing = 0 to height 10^6 |
| h9.share_checked_zeros_found | 1 | 1 |  | match | zeros 11..70 from mpmath.zetazero |
| h9.mean_abs_Z_at_zero_over_unit_sum | 3.936e-11 | 0 |  | match | at a zero the units cancel |
| h9.gue_ks_distance | 0.04454 | 0 – 0.1 |  | match | AT-III Sec. 9.2: random-matrix (GUE) statistics |
| h9.spacing_mean | 0.9997 | 1 |  | match | unfolded spacings average 1 |

- Z(t) on a grid of step 0.182 on [50, 2000]; zeros refined by bisection; 1507 zeros against the exact count 1507; a check, not a proof

### H10 Central pricing: P_{T+1} = alpha I + (1-alpha) H + eps

`hypotheses.h10_central_pricing` — data: simulation, 0.05 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h10.alpha_hat | 0.6007 | 0.6 |  | match | C2 (planted alpha = 0.6; N > 3, H = 5) |
| h10.alpha_tstat | 433.2 | 3 – 1e+09 |  | match | C2: alpha significant |
| h10.r2 | 0.7587 |  |  | measured |  |
| h10.control_alpha_hat | 0.0004007 | 0 |  | match | control: no impact term |
| h10.alpha_hat_H2 | 0.601 | 0.6 |  | match | C2 asks H >= 5; H = 2 for comparison |
| h10.n_assets | 30 | 4 – 1e+09 |  | match | C2: N > 3 |

- 30 assets, 2000 steps, pooled OLS on P_(T+1) - H_T = alpha (I_T - H_T) + eps

### H11 Stealth-optimal schedule under concave cost

`hypotheses.h11_stealth_schedule` — data: simulation, 0.01 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h11.n_star_grid | 32 | 2 – 99 |  | match | C3: interior optimum, N <= N_max = 100 |
| h11.n_star_formula | 29.47 |  |  | measured | (2 lambda Q^{3/2} / c)^{2/3} |
| h11.n_star_lambda0 | 1 | 1 |  | match | no penalty: concavity says do not split |
| h11.cost_equal_over_front | 0.946 | 0 – 1 |  | match | equal split is cheapest for a convex-plus-concave symmetric cost |
| h11.cost_equal_over_random | 0.8664 | 0 – 1 |  | match |  |
| h11.numerical_optimum_rel_gap | 1.273e-05 | 0 |  | match | SLSQP optimum equals the equal split |
| h11.max_child_share | 0.03165 | 0 – 0.5 |  | match |  |

- Q = 1000000 USD, c = 1.0, lambda = 8e-08; J(N) on 25 values of N in [1, 100]; same-N schedules compared

### H12 Linear inventory skew and the taking layer (NB-01)

`hypotheses.h12_inventory_skew` — data: simulation, 0.06 s, verdict: **supported**

| quantity | measured | expected | unit | verdict | source |
|---|---|---|---|---|---|
| h12.share_inside_79 | 1 | 0.99 – 1 |  | match | NB-01: inside +/-79 for 99% of the session |
| h12.pnl_no_skew | 8940 |  |  | measured |  |
| h12.pnl_skew | 7398 |  |  | measured |  |
| h12.pnl_skew_taking | 6238 |  |  | measured |  |
| h12.taking_pnl_rel_change | -0.1567 | -0.3 |  | match | NB-01: taking layer cut PnL 2,300 -> 1,600 (-30%) |
| h12.skew_pnl_rel_change | -0.1725 |  |  | measured |  |

- 4 sessions of 3000 ticks; NB-01 parameters (h = 10, limit 80, k = 0.125)
