"""Unit tests of the exact layer and the core modules (pytest -q)."""
import numpy as np
import pytest

from tmrw_lab.core import identities as I
from tmrw_lab.core import riemann_siegel as RS

rng = np.random.default_rng(0)


def test_konig_split_identity():
    x = rng.normal(size=(60, 3)); w = rng.random(60)
    t, c, i = I.konig_split(x, w)
    assert abs(t - c - i) < 1e-12 and c >= 0 and i >= 0


def test_speed_ratio_and_collective_share_bounds():
    for _ in range(20):
        x = rng.normal(size=(30, 2)); w = rng.random(30)
        phi = I.speed_ratio(x, w); kappa = I.collective_share(x, w)
        assert 0 <= phi <= 1 + 1e-12 and 0 <= kappa <= phi ** 2 + 1e-12


def test_turbulence_identity():
    sig = rng.random(15) + 0.1; A = rng.normal(size=(15, 15)); R = np.corrcoef(A @ A.T + np.eye(15))
    d = I.turbulence_identity(sig, None, R)
    assert abs(d["Psi2_direct"] - d["Psi2_identity"]) < 1e-12 and 0 < d["Psi2_direct"] <= 1


def test_mean_preserved_and_jensen():
    r = rng.normal(0, 0.02, size=(500, 8)); w = rng.random(8)
    a, b = I.mean_preserved(r, w)
    assert abs(a - b) < 1e-12
    assert I.jensen_growth_gap(r, w)[2] >= -1e-12


def test_cascade_factorisation():
    x = rng.normal(size=(50, 3)); w = rng.random(50)
    S, f, prod, phi = I.cascade_factors(x, w, [np.arange(50) // 5, np.arange(50) // 25, np.zeros(50, int)])
    assert abs(prod - phi) < 1e-12 and np.all(f <= 1 + 1e-12)


def test_mixture_bounds_and_squeezing():
    t = np.arange(-10, 100, 1.0); tau = rng.gamma(3, 4, 40); c = rng.random(40) + 0.1
    f = lambda u: 1 / (1 + np.exp(-u / 2))
    R = I.mixture_law(t, c, tau, f); lo, hi = I.mixture_bounds(t, tau, f)
    assert np.all(R >= lo - 1e-12) and np.all(R <= hi + 1e-12)
    assert I.squeezing_bound(10, 100) == pytest.approx(0.9)


def test_linear_field_split_recovers_field():
    pos = rng.normal(size=(400, 2)); M = np.array([[0.1, 0.3], [-0.2, 0.05]])
    vel = np.array([1.0, 2.0]) + pos @ M.T + 0.001 * rng.normal(size=(400, 2))
    s = I.linear_field_split(pos, vel)
    assert np.allclose(s["M"], M, atol=1e-2) and np.allclose(s["V0"], [1, 2], atol=1e-2)
    o = I.oort_constants(s["M"]); assert abs(o["K"] - 0.075) < 1e-2
    assert abs(I.expansion_rate(M) - 0.075) < 1e-12


def test_invariant_mass_superadditive():
    E = np.array([5.0, 5.0]); p = np.array([[3.0, 0, 0], [-3.0, 0, 0]])
    M, s, gap = I.mass_superadditivity_gap(E, p)
    assert M == pytest.approx(10.0) and s == pytest.approx(8.0) and gap > 0


def test_vol_subadditivity_and_gap():
    sig = rng.random(10) + 0.1; A = rng.normal(size=(10, 10)); R = np.corrcoef(A @ A.T + np.eye(10))
    sx, ssum = I.vol_subadditivity(sig, None, R); assert sx <= ssum + 1e-12
    lhs, rhs = I.vol_gap_identity(sig, None, R); assert abs(lhs - rhs) < 1e-12


def test_sign_law_and_virial():
    assert I.sign_law(-1, 2.0) == pytest.approx(-2.0) and I.sign_law(2, 2.0) == pytest.approx(4.0)
    assert I.virial_mass(1.0, 1.0, G=1.0, k=1.0) == pytest.approx(1.0)


def test_epps_fit_recovers():
    d = np.array([1, 2, 5, 10, 30, 60.0]); k, tau = I.epps_tau_fit(d, I.epps_law(d, 0.8, 5.0))
    assert k == pytest.approx(0.8, rel=1e-6) and tau == pytest.approx(5.0, rel=1e-6)


def test_index_return_additive():
    r = rng.normal(size=(100, 5)); w = rng.random(5)
    assert np.allclose(I.index_return(r, w), r @ (w / w.sum()))


def test_riemann_siegel_zeros():
    zeros, step = RS.zeros_up_to(100.0, t0=10.0)
    first = [14.134725, 21.022040, 25.010858, 30.424876, 32.935062]
    for z in first:
        assert np.min(np.abs(zeros - z)) < 2 * step


def test_lumping_module_imports():
    from tmrw_lab.core import lumping, mfg, impact, matching  # noqa: F401
