#!/usr/bin/env python3
"""Generate the compendium appendix body (LaTeX) from results/summary.json.

    python make_appendix.py [--summary results/summary.json] [--out /home/claude/tmrw-compendium/src/labrun_body.tex]
                            [--figdir /home/claude/tmrw-compendium/figures/lab]
"""
from __future__ import annotations
import argparse, json, shutil
from pathlib import Path


def tex(s: str) -> str:
    return (str(s).replace("\\", r"\textbackslash{}").replace("&", r"\&").replace("%", r"\%").replace("_", r"\_")
            .replace("#", r"\#").replace("^", r"\^{}").replace("~", r"\~{}").replace("<", r"$<$").replace(">", r"$>$"))


def texkey(s: str) -> str:
    """A dotted/underscored key, breakable at the dots and underscores (long keys in narrow columns)."""
    return tex(s).replace("\\_", "\\_\\allowbreak{}").replace(".", ".\\allowbreak{}")


def fmt(x):
    if x is None:
        return "--"
    ax = abs(x)
    if ax == 0:
        return "0"
    if ax >= 1e5 or ax < 1e-3:
        return f"{x:.3g}"
    return f"{x:.4g}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", default="results/summary.json")
    ap.add_argument("--out", default="/home/claude/tmrw-compendium/src/labrun_body.tex")
    ap.add_argument("--figdir", default="/home/claude/tmrw-compendium/figures/lab")
    ap.add_argument("--max-figs", type=int, default=14)
    a = ap.parse_args()
    S = json.loads(Path(a.summary).read_text())
    figdir = Path(a.figdir); figdir.mkdir(parents=True, exist_ok=True)
    out = []
    out.append(r"\paragraph{The run.} " + f"Preset \\texttt{{{S['preset']}}}, offline={S['offline']}, seed {S['seed']}: "
               f"{S['n_ok']} modules ran, {S['n_failed']} failed, {S['n_skipped']} were skipped. "
               r"Each module below reports the quantities it measured next to the value the compendium expects for them; "
               r"``match'' means inside the quoted range (or tolerance), ``differs'' outside it, ``measured'' when no expectation is quoted. "
               r"Modules on synthetic data test the pipeline, not the world: their verdicts say the code recovers the planted answer.")
    groups = {}
    for r in S["results"]:
        groups.setdefault(r["extra"].get("group", "other"), []).append(r)
    order = ["exact", "hindsight", "refuted", "conjectures", "practice", "hypotheses"]
    titles = {"exact": "The exact layer", "hindsight": "The hindsight tests", "refuted": "The refuted special case",
              "conjectures": "Toy models for the five conjectures", "practice": "The working-notes simulations",
              "hypotheses": "Registered hypothesis tests"}
    nfig = 0
    for g in order + [k for k in groups if k not in order]:
        if g not in groups:
            continue
        out.append(f"\\section{{{titles.get(g, g)}}}")
        if g == "hypotheses":
            out.append(r"\begin{longtable}{@{}p{7.6cm}p{2.1cm}p{1.9cm}p{4.6cm}@{}}")
            out.append(r"\caption{Hypothesis tests: verdict and the statistic behind it.}\\ \toprule Hypothesis & Data & Verdict & Statistic \\ \midrule \endfirsthead")
            out.append(r"\toprule Hypothesis & Data & Verdict & Statistic \\ \midrule \endhead")
            for r in groups[g]:
                stat = ""
                if r["numbers"]:
                    n = r["numbers"][0]
                    stat = f"{tex(n['key'])} = {fmt(n['value'])}"
                    if n.get("expected") is not None:
                        stat += f" (exp. {fmt(n['expected'])}" + (f"--{fmt(n['expected_hi'])}" if n.get("expected_hi") is not None else "") + ")"
                v = r.get("verdict") or r["status"]
                out.append(f"{tex(r['title'])} & {tex(r['data_origin'])} & {tex(v)} & {stat} \\\\")
            out.append(r"\bottomrule\end{longtable}")
            continue
        for r in groups[g]:
            st = {"ok": "", "failed": " (failed)", "skipped": " (skipped)"}[r["status"]]
            out.append(f"\\subsection{{{tex(r['title'])}{st}}}")
            out.append(f"\\texttt{{{tex(r['name'])}}}; data: {tex(r['data_origin'])}; {r['extra'].get('seconds', '?')} s."
                       + (f" Verdict: \\textbf{{{tex(r['verdict'])}}}." if r.get("verdict") else ""))
            if r["numbers"]:
                out.append(r"\begin{longtable}{@{}p{5.6cm}rrp{1.4cm}p{1.5cm}p{3.6cm}@{}}")
                out.append(r"\toprule Quantity & Measured & Expected & Unit & Verdict & Source \\ \midrule \endfirsthead")
                out.append(r"\toprule Quantity & Measured & Expected & Unit & Verdict & Source \\ \midrule \endhead")
                for n in r["numbers"]:
                    exp = "--" if n.get("expected") is None else (fmt(n["expected"]) + (f"--{fmt(n['expected_hi'])}" if n.get("expected_hi") is not None else ""))
                    out.append(f"{{\\footnotesize {texkey(n['key'])}}} & {fmt(n['value'])} & {exp} & {tex(n.get('unit',''))} & {tex(n['verdict'])} & {tex(n.get('source',''))} \\\\")
                out.append(r"\bottomrule\end{longtable}")
            notes = [x for x in r["notes"] if not x.startswith("Traceback")]
            if notes:
                out.append(r"\begin{itemize}")
                for x in notes[:12]:
                    out.append(r"\item " + tex(x[:400]))
                out.append(r"\end{itemize}")
            for f in r["figures"][:1]:
                if nfig >= a.max_figs:
                    break
                src = Path(f)
                if src.exists():
                    dst = figdir / src.name
                    shutil.copy(src, dst)
                    nfig += 1
                    out.append(r"\begin{figure}[h]\centering\includegraphics[width=0.92\textwidth]{lab/" + src.name + "}"
                               + r"\caption{" + tex(r["title"]) + r" (test bench, this run).}\end{figure}")
    Path(a.out).write_text("\n".join(out) + "\n")
    print("wrote", a.out, "figures:", nfig)


if __name__ == "__main__":
    main()
