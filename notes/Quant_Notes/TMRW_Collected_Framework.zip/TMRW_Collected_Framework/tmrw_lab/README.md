# tmrw_lab — the test bench of the Collected Framework

Every statement in the Collected Framework (Tomorrow Capital Research) that can be run is run here:
the exact identities of Aggregation Theory, the hindsight tests of the collected account, the toy
models for Conjectures 1–5, the working-notes simulations (market making, the Prosperity quoting
rules, the voucher surface, the stat-arb and trend blueprints) and twelve registered hypothesis tests.

```
pip install -e .            # numpy, scipy, pandas, matplotlib, mpmath, requests
pip install -e ".[full]"    # + statsmodels, scikit-learn, periodictable, particle
python run_all.py --preset quick          # one-minute smoke run, network allowed
AGG_OFFLINE=1 python run_all.py           # no network: synthetic data with planted answers
python run_all.py --preset full           # the sizes quoted in the paper (hours)
python run_all.py --only society zeta     # a subset
python -m pytest -q                        # the exact-layer and module tests
python make_appendix.py                    # LaTeX appendix for the compendium from results/
```

Outputs go to `results/`: `summary.json` (every number with the value the compendium expects and a
verdict), `numbers.tex`, `report.md`, one JSON per module and `figures/*.png`.

## Layout

| package | contents |
|---|---|
| `tmrw_lab/core/identities.py` | König split; speed ratio φ; collective share κ; turbulence Ψ² = H + (1−H)ρ̄; preserved mean and Jensen gap; cascade; mixture law; squeezing; linear-field split and Oort constants; invariant mass superadditivity; volatility subadditivity and the gap identity; virial mass and sign law; leftover dispersion; index rebuild; the Epps law |
| `tmrw_lab/core/lumping.py` | exact linear lumping `CA = BC`, invariant subspaces, Markov lumpability |
| `tmrw_lab/core/mfg.py` | logit choice, mean-field fixed points, exploitability, Lasry–Lions monotonicity, hierarchical consistency `A∘BR = BR∘A`, hysteresis |
| `tmrw_lab/core/impact.py` | OFI, microprice, square-root impact, propagator, sign autocorrelation, Hurst exponents |
| `tmrw_lab/core/matching.py` | the matching rule as a checker |
| `tmrw_lab/data/` | loaders with a cache (NYT and JHU COVID, World Bank GDP, FRED house prices, Pantheon+, nuclei via `periodictable`, hadrons, ATLAS/CMS open data, Gaia, Binance, Tardis) and the synthetic generators with planted answers used when `AGG_OFFLINE=1` or a host is unreachable |
| `tmrw_lab/experiments/` | `exact_layer`, `society`, `gas_beam`, `nuclei_hadrons`, `expansion`, `zeta`, `markets`, `order_book`, `bitcoin_restoration`, `conjecture_toys`, `market_making`, `prosperity`, `blueprints` |
| `tmrw_lab/hypotheses/` | H1–H12 (see `tmrw_lab/registry.py`), each returning supported / refuted / inconclusive |
| `tmrw_lab/conjectures/` | toys for C1 (path switching), C2 (central price + conformal regions), C3 (stealth schedule), C4 (hybrid MDP, MFG fixed point, least action), C5 (bilevel firm) |
| `tmrw_lab/micro/` | Avellaneda–Stoikov, the range-bound market-maker simulator, the Prosperity 3 quoting rules, a Hawkes-driven order book, the voucher surface |
| `tmrw_lab/strategies/` | the shared cost-aware optimiser, the stat-arb pipeline, the trend ensemble |
| `tests/test_core.py` | pytest suite |

## Conventions

Every module exposes `run(cfg) -> Result` (see `tmrw_lab/result.py`); numbers are recorded with the
value the compendium expects (`expected`, `expected_hi`, `source`) so `run_all.py` can give each a
verdict. Deterministic (`TMRW_SEED`); sizes by preset (`tmrw_lab/config.py`). A result on synthetic
data says `data_origin="synthetic"`: it tests the code, not the world.

Nothing here is investment advice; the strategies are blueprints and the simulators are toys.
