# Conventions for every module of tmrw_lab

Package root: `/home/claude/tmrw-lab` (run everything from there: `python run_all.py --preset quick --only <name>`;
`python -m pytest -q`).  Python 3.13, numpy 2.x, scipy, pandas 3.x, matplotlib (use the `Agg` backend:
`import matplotlib; matplotlib.use("Agg")` before pyplot), mpmath, statsmodels, scikit-learn, requests.
Do NOT add other dependencies. Do not edit `run_all.py`, `tmrw_lab/config.py`, `tmrw_lab/result.py`,
`tmrw_lab/registry.py` or `tmrw_lab/core/identities.py` (if you need a change there, say so in your report).

## The theory you are implementing

The compendium LaTeX source is in `/home/claude/tmrw-compendium/src/` (read the chapters named in your brief;
`main.pdf` next to it is the typeset version, `text/*.txt` the raw source documents). Quant working notes are
in `/home/claude/newinput/zip/quant-notes/*.md`. Implement what those documents *say*; where they leave a
choice open, make a sensible one and record it in a `Result.note(...)`.

`tmrw_lab/core/identities.py` already implements the exact identities (König split, speed ratio φ, collective
share κ, turbulence Ψ² = H + (1−H)ρ̄, mean preservation, Jensen growth gap, cascade, mixture law, squeezing,
linear-field split + Oort constants, invariant mass superadditivity, volatility subadditivity + gap identity,
virial mass, sign law, leftover dispersion, index return, Epps law). Import from `tmrw_lab.core.identities`
rather than re-implementing.

## Every experiment / hypothesis module

```python
from tmrw_lab.result import Result
def run(cfg) -> Result:      # cfg is tmrw_lab.config.Config: cfg.sizes[...], cfg.seed, cfg.offline,
    ...                      # cfg.results_dir, cfg.cache_dir, cfg.preset
```
* Deterministic: `rng = np.random.default_rng(cfg.seed)`.
* Sizes come from `cfg.sizes` (keys in `tmrw_lab/config.py: PRESETS`); add new keys there only by asking —
  otherwise derive from existing keys (e.g. `n = cfg.sizes["mc_paths"]`). `quick` must finish in a few seconds
  per module, `standard` in under ~2 minutes per module.
* Record every number the compendium quotes for that test with `res.add(key, value, expected=..., expected_hi=...,
  unit=..., source="AT-III Table 5", tol=...)`. Keys are dotted lower-case: `society.covid_us.kappa`.
  Use the *compendium's* expected value (read it from the LaTeX table); if the compendium gives a range use
  expected / expected_hi; if it gives only a sign or an inequality, put the bound in `expected` and explain in `note`.
* `res.data_origin` = "real" (downloaded), "synthetic" (generator with planted answers), "simulation" (a
  physical/agent simulation), "analytic".
* Figures: save PNG to `cfg.results_dir / "figures" / f"{name}.png"` (dpi 130, figsize ≤ (10, 6)) and append the
  path to `res.figures`. Prefer one multi-panel figure per experiment, matching the panels of the AT-III figure
  it reproduces.
* Never crash: wrap network / optional pieces in try/except and `res.note(...)` what was skipped;
  `res.status = "skipped"` only when nothing at all could be produced.
* Hypothesis modules additionally set `res.verdict` to `"supported"`, `"refuted"` or `"inconclusive"` and note
  the statistic and threshold used.

## Data (tmrw_lab/data)

`tmrw_lab.data.loaders` (owned by the data/experiments agent) exposes functions that (1) return cached data from
`cfg.cache_dir` if present, (2) download it when `not cfg.offline` and the host answers, (3) otherwise return the
synthetic version from `tmrw_lab.data.synthetic` and set a flag. Every loader returns `(data, origin)` with
origin in {"real", "synthetic"}. Reachable from this build machine: raw.githubusercontent.com (NYT COVID
counties, JHU CSSE world COVID, Pantheon+ DataRelease, datasets/gdp), PyPI (`pip install` works).
NOT reachable here (but may be on the user's machine): Binance, Tardis, CERN open data, IAEA AME, Yahoo, FRED,
Kaggle, LMFDB. For those write the loader with the real URL/API, let it time out quickly (`cfg.timeout`),
and fall back to synthetic.

Synthetic generators plant the answer the compendium expects (e.g. a crypto basket with κ rising from
0.75 to 0.8 with bar length; a Hawkes order flow with H≈0.85; nuclei with binding energy ≈ 8 MeV/nucleon)
so the pipeline can be checked end-to-end; the Result must then say `data_origin="synthetic"`.

## Style

Plain functions, numpy-vectorised, short docstrings that cite the theorem / section / note implemented,
no classes unless state is needed, no prints (use `res.note`). Keep each module self-contained apart from
`tmrw_lab.core`, `tmrw_lab.data`, `tmrw_lab.result`, `tmrw_lab.config`.

## Addendum (this build)

* The compendium chapters in `/home/claude/tmrw-compendium/src/` are being written in parallel and may
  not exist yet when you start: the authoritative sources are the raw texts in
  `/home/claude/tmrw-compendium/text/` (`aggregation_theory_2.txt` = AT-III with every measured number;
  `aggregation_part2.txt` = AT-II the matching rule; `Aggregation_theory_3.txt` = AT-0 the setup and the
  rigorous layer; `Conjecture_*.txt`; `Whitepaper_-_Financial_markets_model.txt`; the working notes in
  `/home/claude/tmrw-compendium/text/quant-notes/*.md`). Quote expected values from them.
* Data loaders are split by domain to let agents work in parallel: write yours as
  `tmrw_lab/data/loaders_<domain>.py` (+ `tmrw_lab/data/synthetic_<domain>.py`); a thin
  `tmrw_lab/data/loaders.py` re-exports all of them at the end (do not write it). Shared helpers you may
  use: `tmrw_lab.data.common` (`fetch_text(url, cfg, cache_name)`, `cached_csv(...)`) — see that file.
* `tmrw_lab/core/identities.py` exists: `python -c "import tmrw_lab.core.identities as I; help(I)"`.
* `Result.add(..., tol=0.15)` is a relative tolerance; `abs_tol=` an absolute one; ranges use
  `expected`/`expected_hi`. `res.n_match()` gives (matches, judged).
* Keep `quick` under ~10 s per module. Test with `cd /home/claude/tmrw-lab && python run_all.py --preset quick --offline --only <name>` AND once with network (`--only <name>` without `--offline`): a loader must time out fast (`cfg.timeout` seconds) when a host is unreachable.
